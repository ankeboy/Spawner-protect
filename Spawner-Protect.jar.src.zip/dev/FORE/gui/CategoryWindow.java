/*     */ package dev.FORE.gui;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.gui.components.ModuleButton;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.utils.Animation;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_9334;
/*     */ 
/*     */ public final class CategoryWindow {
/*     */   public List<ModuleButton> moduleButtons;
/*     */   public int x;
/*     */   public int y;
/*     */   private final int width;
/*     */   private final int height;
/*     */   public Color currentColor;
/*     */   private final Category category;
/*     */   public boolean dragging;
/*     */   public boolean extended;
/*     */   private int dragX;
/*     */   private int dragY;
/*     */   private int prevX;
/*     */   private int prevY;
/*     */   public ClickGUI parent;
/*     */   private float hoverAnimation;
/*     */   private float expandAnimation;
/*     */   private float glowAnimation;
/*  38 */   private String searchQuery = "";
/*     */   private boolean isSearchFocused = false;
/*  40 */   private float searchBarAnimation = 0.0F;
/*  41 */   private float cursorBlinkTimer = 0.0F;
/*     */ 
/*     */   
/*  44 */   private static final Color BG_COLOR = new Color(18, 18, 22);
/*  45 */   private static final Color BG_HOVER = new Color(25, 25, 30);
/*  46 */   private static final Color BORDER_COLOR = new Color(45, 45, 50, 120);
/*  47 */   private static final Color TEXT_PRIMARY = new Color(220, 220, 225);
/*  48 */   private static final Color TEXT_SECONDARY = new Color(150, 150, 160);
/*  49 */   private static final Color ACCENT_BLUE = new Color(88, 166, 255);
/*  50 */   private static final Color SEARCH_BG = new Color(30, 30, 35);
/*  51 */   private static final Color SEARCH_BG_FOCUSED = new Color(35, 35, 42);
/*     */   
/*     */   public CategoryWindow(int x, int y, int width, int height, Category category, ClickGUI parent) {
/*  54 */     this.moduleButtons = new ArrayList<>();
/*  55 */     this.hoverAnimation = 0.0F;
/*  56 */     this.expandAnimation = 1.0F;
/*  57 */     this.glowAnimation = 0.0F;
/*  58 */     this.x = x;
/*  59 */     this.y = y;
/*  60 */     this.width = width;
/*  61 */     this.dragging = false;
/*  62 */     this.extended = true;
/*  63 */     this.height = height;
/*  64 */     this.category = category;
/*  65 */     this.parent = parent;
/*  66 */     this.prevX = x;
/*  67 */     this.prevY = y;
/*     */     
/*  69 */     List<Module> modules = new ArrayList<>(DonutBBC.INSTANCE.getModuleManager().a(category));
/*  70 */     int offset = height;
/*     */ 
/*     */     
/*  73 */     if (category == Category.SEARCH) {
/*     */ 
/*     */       
/*  76 */       offset += 35;
/*     */     } else {
/*  78 */       for (Module module : modules) {
/*  79 */         this.moduleButtons.add(new ModuleButton(this, module, offset));
/*  80 */         offset += height;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void render(class_332 context, int mouseX, int mouseY, float delta) {
/*  86 */     Color baseColor = new Color(BG_COLOR.getRed(), BG_COLOR.getGreen(), BG_COLOR.getBlue(), DonutBBC.windowAlpha.getIntValue());
/*     */     
/*  88 */     if (this.currentColor == null) {
/*  89 */       this.currentColor = new Color(BG_COLOR.getRed(), BG_COLOR.getGreen(), BG_COLOR.getBlue(), 0);
/*     */     } else {
/*  91 */       this.currentColor = ColorUtil.interpolateAlpha(0.08F, baseColor.getAlpha(), this.currentColor);
/*     */     } 
/*     */ 
/*     */     
/*  95 */     float animSpeed = delta * 0.06F;
/*     */     
/*  97 */     float targetHover = (isHovered(mouseX, mouseY) && !this.dragging) ? 1.0F : 0.0F;
/*  98 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, targetHover, 0.08D, animSpeed);
/*     */     
/* 100 */     float targetExpand = this.extended ? 1.0F : 0.0F;
/* 101 */     this.expandAnimation = (float)MathUtil.exponentialInterpolate(this.expandAnimation, targetExpand, 0.006D, animSpeed);
/* 102 */     this.expandAnimation = (float)MathUtil.clampValue(this.expandAnimation, 0.0D, 1.0D);
/*     */     
/* 104 */     this.glowAnimation += delta * 0.02F;
/* 105 */     if (this.glowAnimation > 360.0F) this.glowAnimation = 0.0F;
/*     */ 
/*     */     
/* 108 */     if (this.category == Category.SEARCH) {
/* 109 */       float targetSearchAnim = this.extended ? 1.0F : 0.0F;
/* 110 */       this.searchBarAnimation = (float)MathUtil.exponentialInterpolate(this.searchBarAnimation, targetSearchAnim, 0.08D, animSpeed);
/* 111 */       this.cursorBlinkTimer += delta * 0.05F;
/* 112 */       if (this.cursorBlinkTimer > 2.0F) this.cursorBlinkTimer = 0.0F;
/*     */     
/*     */     } 
/*     */     
/* 116 */     Color bgColor = ColorUtil.a(baseColor, BG_HOVER, this.hoverAnimation * 0.3F);
/* 117 */     Color accentColor = Utils.getMainColor(255, this.category.ordinal());
/*     */ 
/*     */     
/* 120 */     float cornerRadius = 10.0F;
/* 121 */     float topLeft = cornerRadius;
/* 122 */     float topRight = cornerRadius;
/* 123 */     float bottomLeft = cornerRadius * (1.0F - this.expandAnimation);
/* 124 */     float bottomRight = cornerRadius * (1.0F - this.expandAnimation);
/*     */ 
/*     */     
/* 127 */     RenderUtils.renderRoundedQuad(context.method_51448(), bgColor, this.prevX, this.prevY, (this.prevX + this.width), (this.prevY + this.height), topLeft, topRight, bottomLeft, bottomRight, 50.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 132 */     renderCategoryHeader(context, accentColor);
/*     */ 
/*     */     
/* 135 */     if (this.category == Category.SEARCH && this.searchBarAnimation > 0.01F) {
/* 136 */       renderSearchBar(context, mouseX, mouseY);
/*     */     }
/*     */     
/* 139 */     updateButtons(delta);
/* 140 */     renderModuleButtons(context, mouseX, mouseY, delta);
/*     */   }
/*     */   
/*     */   private void renderSearchBar(class_332 context, int mouseX, int mouseY) {
/* 144 */     int searchBarHeight = 28;
/* 145 */     int searchBarY = this.prevY + this.height + (int)(5.0F * this.searchBarAnimation);
/* 146 */     int searchBarWidth = this.width - 16;
/* 147 */     int searchBarX = this.prevX + 8;
/*     */ 
/*     */     
/* 150 */     boolean searchHovered = (mouseX >= searchBarX && mouseX <= searchBarX + searchBarWidth && mouseY >= searchBarY && mouseY <= searchBarY + 28);
/*     */ 
/*     */ 
/*     */     
/* 154 */     Color searchBg = this.isSearchFocused ? SEARCH_BG_FOCUSED : SEARCH_BG;
/* 155 */     if (searchHovered && !this.isSearchFocused) {
/* 156 */       searchBg = ColorUtil.a(SEARCH_BG, SEARCH_BG_FOCUSED, 0.5F);
/*     */     }
/*     */ 
/*     */     
/* 160 */     RenderUtils.renderRoundedQuad(context.method_51448(), searchBg, searchBarX, searchBarY, (searchBarX + searchBarWidth), (searchBarY + 28), 6.0D, 6.0D, 6.0D, 6.0D, 30.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 166 */     if (this.isSearchFocused) {
/* 167 */       Color borderGlow = new Color(ACCENT_BLUE.getRed(), ACCENT_BLUE.getGreen(), ACCENT_BLUE.getBlue(), 100);
/* 168 */       RenderUtils.renderRoundedQuad(context.method_51448(), borderGlow, (searchBarX - 1), (searchBarY - 1), (searchBarX + searchBarWidth + 1), (searchBarY + 28 + 1), 7.0D, 7.0D, 7.0D, 7.0D, 30.0D);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 175 */     int iconSize = 14;
/* 176 */     int iconX = searchBarX + 8;
/* 177 */     int iconY = searchBarY + 7;
/*     */     
/* 179 */     class_1799 searchIcon = new class_1799((class_1935)class_1802.field_27070);
/* 180 */     searchIcon.method_57379(class_9334.field_49641, Boolean.valueOf(false));
/* 181 */     RenderUtils.drawItem(context, searchIcon, iconX, iconY, 14.0F, 200);
/*     */ 
/*     */     
/* 184 */     int textX = iconX + 14 + 8;
/* 185 */     int textY = searchBarY + 10;
/*     */     
/* 187 */     if (this.searchQuery.isEmpty() && !this.isSearchFocused) {
/*     */       
/* 189 */       TextRenderer.drawString("Search modules...", context, textX, textY, TEXT_SECONDARY.getRGB());
/*     */     } else {
/*     */       
/* 192 */       String displayText = this.searchQuery;
/* 193 */       TextRenderer.drawString(displayText, context, textX, textY, TEXT_PRIMARY.getRGB());
/*     */ 
/*     */       
/* 196 */       if (this.isSearchFocused && this.cursorBlinkTimer < 1.0F) {
/* 197 */         int cursorX = textX + TextRenderer.getWidth(displayText);
/* 198 */         int cursorY1 = searchBarY + 7;
/* 199 */         int cursorY2 = searchBarY + 28 - 7;
/*     */ 
/*     */         
/* 202 */         RenderUtils.renderQuad(context.method_51448(), cursorX * 2.0F, cursorY1 * 2.0F, 2.0F, (cursorY2 - cursorY1) * 2.0F, ACCENT_BLUE
/*     */ 
/*     */             
/* 205 */             .getRGB());
/*     */       } 
/*     */ 
/*     */       
/* 209 */       if (!this.searchQuery.isEmpty()) {
/* 210 */         int clearSize = 12;
/* 211 */         int clearX = searchBarX + searchBarWidth - 12 - 8;
/* 212 */         int clearY = searchBarY + 8;
/*     */         
/* 214 */         boolean clearHovered = (mouseX >= clearX && mouseX <= clearX + 12 && mouseY >= clearY && mouseY <= clearY + 12);
/*     */ 
/*     */         
/* 217 */         Color clearColor = clearHovered ? new Color(255, 100, 100) : TEXT_SECONDARY;
/*     */ 
/*     */         
/* 220 */         TextRenderer.drawString("×", context, clearX, clearY, clearColor.getRGB());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 225 */     if (!this.searchQuery.isEmpty() && this.moduleButtons.size() > 0) {
/* 226 */       String resultsText = "" + this.moduleButtons.size() + " found";
/* 227 */       int resultsWidth = TextRenderer.getWidth(resultsText);
/* 228 */       int resultsX = searchBarX + searchBarWidth - resultsWidth - 28;
/* 229 */       int resultsY = searchBarY + 10;
/* 230 */       TextRenderer.drawString(resultsText, context, resultsX, resultsY, (new Color(100, 200, 100))
/* 231 */           .getRGB());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderCategoryHeader(class_332 context, Color accentColor) {
/* 236 */     int iconSize = 20;
/* 237 */     int iconX = this.prevX + 12;
/* 238 */     int iconY = this.prevY + (this.height - 20) / 2;
/*     */ 
/*     */     
/* 241 */     class_1799 iconStack = getCategoryIcon();
/* 242 */     if (iconStack != null) {
/* 243 */       iconStack.method_57379(class_9334.field_49641, Boolean.valueOf(false));
/*     */ 
/*     */       
/* 246 */       float glowSize = 24.0F + (float)Math.sin(this.glowAnimation * 0.1D) * 2.0F;
/* 247 */       Color glowColor = new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), 30);
/* 248 */       RenderUtils.renderCircle(context.method_51448(), glowColor, iconX + 10.0D, iconY + 10.0D, glowSize / 2.0D, 20);
/*     */ 
/*     */       
/* 251 */       RenderUtils.drawItem(context, iconStack, iconX, iconY, 20.0F, 200);
/* 252 */     } else if (this.category == Category.DONUT) {
/*     */       try {
/* 254 */         class_2960 donutTexture = class_2960.method_60655("fore", "donut.png");
/* 255 */         context.method_25290(donutTexture, iconX, iconY, 0.0F, 0.0F, 20, 20, 20, 20);
/* 256 */       } catch (Exception e) {
/* 257 */         System.err.println("Error loading donut texture: " + e.getMessage());
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 262 */     String categoryName = this.category.toString();
/* 263 */     int textX = this.prevX + 38;
/* 264 */     int textY = this.prevY + (this.height - 8) / 2;
/*     */     
/* 266 */     Color textColor = ColorUtil.a(TEXT_PRIMARY, accentColor, this.hoverAnimation * 0.4F);
/* 267 */     TextRenderer.drawString(categoryName, context, textX, textY, textColor.getRGB());
/*     */ 
/*     */     
/* 270 */     if (this.category != Category.SEARCH) {
/* 271 */       int indicatorSize = 16;
/* 272 */       int indicatorX = this.prevX + this.width - 16 - 8;
/* 273 */       int indicatorY = this.prevY + (this.height - 16) / 2;
/*     */ 
/*     */       
/* 276 */       float rotation = this.expandAnimation * 180.0F;
/* 277 */       Color chevronColor = ColorUtil.a(TEXT_SECONDARY, accentColor, this.hoverAnimation * 0.6F);
/*     */       
/* 279 */       renderChevron(context, indicatorX + 8.0F, indicatorY + 8.0F, 5.0F, rotation, chevronColor);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderChevron(class_332 context, float x, float y, float size, float rotation, Color color) {
/* 285 */     context.method_51448().method_22903();
/* 286 */     context.method_51448().method_46416(x, y, 0.0F);
/* 287 */     context.method_51448().method_22907(class_7833.field_40718.rotationDegrees(rotation));
/*     */     
/* 289 */     String indicator = this.extended ? "▼" : "▶";
/* 290 */     int textWidth = TextRenderer.getWidth(indicator);
/* 291 */     TextRenderer.drawString(indicator, context, (int)(-textWidth / 2.0D), -4, color.getRGB());
/*     */     
/* 293 */     context.method_51448().method_22909();
/*     */   }
/*     */   
/*     */   private class_1799 getCategoryIcon() {
/* 297 */     switch (this.category) { case CRYSTAL: case COMBAT: case MISC: case RENDER: case CLIENT: case SEARCH:  }  return 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 304 */       null;
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderModuleButtons(class_332 context, int mouseX, int mouseY, float delta) {
/* 309 */     int totalHeight = 0;
/* 310 */     for (ModuleButton button : this.moduleButtons) {
/* 311 */       totalHeight += (int)button.animation.getAnimation();
/*     */     }
/*     */     
/* 314 */     int visibleHeight = (int)(totalHeight * this.expandAnimation);
/*     */     
/* 316 */     if (visibleHeight > 0) {
/*     */       
/* 318 */       int extraOffset = (this.category == Category.SEARCH) ? (int)(35.0F * this.searchBarAnimation) : 0;
/* 319 */       int scissorY = this.prevY + this.height + extraOffset;
/*     */       
/* 321 */       RenderSystem.enableScissor(this.prevX, DonutBBC.mc
/*     */           
/* 323 */           .method_22683().method_4507() - scissorY + visibleHeight, this.width, visibleHeight);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 328 */       for (ModuleButton module : this.moduleButtons) {
/* 329 */         module.render(context, mouseX, mouseY, delta);
/*     */       }
/*     */       
/* 332 */       RenderSystem.disableScissor();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void keyPressed(int key, int scancode, int modifiers) {
/* 337 */     if (this.category == Category.SEARCH && this.isSearchFocused) {
/* 338 */       if (key == 259 && !this.searchQuery.isEmpty()) {
/* 339 */         this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
/* 340 */         updateSearchResults(); return;
/*     */       } 
/* 342 */       if (key == 256) {
/* 343 */         this.isSearchFocused = false; return;
/*     */       } 
/* 345 */       if (key == 257) {
/*     */         return;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 351 */     for (ModuleButton moduleButton : this.moduleButtons) {
/* 352 */       moduleButton.keyPressed(key, scancode, modifiers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void charTyped(char chr, int modifiers) {
/* 357 */     if (this.category == Category.SEARCH && this.isSearchFocused && !Character.isISOControl(chr)) {
/* 358 */       this.searchQuery += this.searchQuery;
/* 359 */       updateSearchResults();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateSearchResults() {
/* 364 */     this.moduleButtons.clear();
/*     */     
/* 366 */     if (this.searchQuery.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 370 */     int offset = this.height + 35;
/*     */ 
/*     */     
/* 373 */     for (Category cat : Category.values()) {
/* 374 */       if (cat != Category.SEARCH) {
/*     */         
/* 376 */         List<Module> modules = DonutBBC.INSTANCE.getModuleManager().a(cat);
/* 377 */         for (Module module : modules) {
/* 378 */           String moduleName = module.getName().toString().toLowerCase();
/* 379 */           String query = this.searchQuery.toLowerCase();
/*     */           
/* 381 */           if (moduleName.contains(query)) {
/* 382 */             this.moduleButtons.add(new ModuleButton(this, module, offset));
/* 383 */             offset += this.height;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   public void onGuiClose() {
/* 390 */     this.currentColor = null;
/* 391 */     this.hoverAnimation = 0.0F;
/* 392 */     this.expandAnimation = this.extended ? 1.0F : 0.0F;
/* 393 */     this.searchBarAnimation = 0.0F;
/* 394 */     this.isSearchFocused = false;
/* 395 */     for (ModuleButton moduleButton : this.moduleButtons) {
/* 396 */       moduleButton.onGuiClose();
/*     */     }
/* 398 */     this.dragging = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double x, double y, int button) {
/* 403 */     if (this.category == Category.SEARCH && this.extended) {
/* 404 */       int searchBarHeight = 28;
/* 405 */       int searchBarY = this.prevY + this.height + 5;
/* 406 */       int searchBarWidth = this.width - 16;
/* 407 */       int searchBarX = this.prevX + 8;
/*     */       
/* 409 */       if (x >= searchBarX && x <= (searchBarX + searchBarWidth) && y >= searchBarY && y <= (searchBarY + 28)) {
/*     */ 
/*     */ 
/*     */         
/* 413 */         if (!this.searchQuery.isEmpty()) {
/* 414 */           int clearSize = 12;
/* 415 */           int clearX = searchBarX + searchBarWidth - 12 - 8;
/* 416 */           int clearY = searchBarY + 8;
/*     */           
/* 418 */           if (x >= clearX && x <= (clearX + 12) && y >= clearY && y <= (clearY + 12)) {
/*     */ 
/*     */             
/* 421 */             this.searchQuery = "";
/* 422 */             updateSearchResults();
/*     */             
/*     */             return;
/*     */           } 
/*     */         } 
/*     */         
/* 428 */         this.isSearchFocused = true;
/* 429 */         this.cursorBlinkTimer = 0.0F;
/*     */         
/*     */         return;
/*     */       } 
/* 433 */       this.isSearchFocused = false;
/*     */     } 
/*     */ 
/*     */     
/* 437 */     if (isHovered(x, y)) {
/* 438 */       switch (button) {
/*     */         case 0:
/* 440 */           if (!this.parent.method_25397()) {
/* 441 */             this.dragging = true;
/* 442 */             this.dragX = (int)(x - this.x);
/* 443 */             this.dragY = (int)(y - this.y);
/*     */           } 
/*     */           break;
/*     */         
/*     */         case 1:
/* 448 */           if (this.category != Category.SEARCH) {
/* 449 */             if (this.extended) {
/* 450 */               for (ModuleButton moduleButton : this.moduleButtons) {
/* 451 */                 moduleButton.extended = false;
/*     */               }
/*     */             }
/* 454 */             this.extended = !this.extended;
/*     */           } 
/*     */           break;
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 463 */     if (this.expandAnimation > 0.5F) {
/* 464 */       for (ModuleButton moduleButton : this.moduleButtons) {
/* 465 */         moduleButton.mouseClicked(x, y, button);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseDragged(double x, double y, int button, double deltaX, double deltaY) {
/* 471 */     if (this.expandAnimation > 0.5F) {
/* 472 */       for (ModuleButton moduleButton : this.moduleButtons) {
/* 473 */         moduleButton.mouseDragged(x, y, button, deltaX, deltaY);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void updateButtons(float delta) {
/* 479 */     int height = this.height;
/*     */ 
/*     */     
/* 482 */     if (this.category == Category.SEARCH) {
/* 483 */       height += (int)(35.0F * this.searchBarAnimation);
/*     */     }
/*     */     
/* 486 */     for (ModuleButton button : this.moduleButtons) {
/* 487 */       Animation animation = button.animation;
/*     */       
/* 489 */       double targetHeight = button.extended ? (this.height * (button.settings.size() + 1)) : this.height;
/*     */       
/* 491 */       animation.animate(0.6D * delta, targetHeight);
/* 492 */       button.offset = height;
/* 493 */       height += (int)button.animation.getAnimation();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void mouseReleased(double x, double y, int button) {
/* 498 */     if (button == 0 && this.dragging) {
/* 499 */       this.dragging = false;
/*     */     }
/* 501 */     if (this.expandAnimation > 0.5F) {
/* 502 */       for (ModuleButton moduleButton : this.moduleButtons) {
/* 503 */         moduleButton.mouseReleased(x, y, button);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseScrolled(double x, double y, double horizontalAmount, double verticalAmount) {
/* 509 */     this.prevX = this.x;
/* 510 */     this.prevY = this.y;
/* 511 */     this.prevY += (int)(verticalAmount * 20.0D);
/* 512 */     setY((int)(this.y + verticalAmount * 20.0D));
/*     */   }
/*     */   
/* 515 */   public int getX() { return this.prevX; }
/* 516 */   public int getY() { return this.prevY; }
/* 517 */   public void setY(int y) { this.y = y; }
/* 518 */   public void setX(int x) { this.x = x; }
/* 519 */   public int getWidth() { return this.width; } public int getHeight() {
/* 520 */     return this.height;
/*     */   }
/*     */   public boolean isHovered(double x, double y) {
/* 523 */     return (x > this.x && x < (this.x + this.width) && y > this.y && y < (this.y + this.height));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isPrevHovered(double x, double y) {
/* 528 */     return (x > this.prevX && x < (this.prevX + this.width) && y > this.prevY && y < (this.prevY + this.height));
/*     */   }
/*     */ 
/*     */   
/*     */   public void updatePosition(double mouseX, double mouseY, float delta) {
/* 533 */     this.prevX = this.x;
/* 534 */     this.prevY = this.y;
/*     */     
/* 536 */     if (this.dragging) {
/* 537 */       double targetX = isHovered(mouseX, mouseY) ? this.x : this.prevX;
/* 538 */       double targetY = isHovered(mouseX, mouseY) ? this.y : this.prevY;
/*     */       
/* 540 */       this.x = (int)MathUtil.approachValue(0.35F * delta, targetX, mouseX - this.dragX);
/* 541 */       this.y = (int)MathUtil.approachValue(0.35F * delta, targetY, mouseY - this.dragY);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\CategoryWindow.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */