/*     */ package dev.FORE.gui;
/*     */ 
/*     */ import dev.FORE.gui.components.ModuleButton;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public abstract class Component
/*     */ {
/*     */   public class_310 mc;
/*     */   public ModuleButton parent;
/*     */   public Setting setting;
/*     */   public int offset;
/*     */   public Color currentColor;
/*     */   public boolean mouseOver;
/*     */   int x;
/*     */   int y;
/*     */   int width;
/*     */   int height;
/*     */   
/*     */   public Component(ModuleButton parent, Setting setting, int offset) {
/*  26 */     this.mc = class_310.method_1551();
/*  27 */     this.parent = parent;
/*  28 */     this.setting = setting;
/*  29 */     this.offset = offset;
/*  30 */     this.x = parentX();
/*  31 */     this.y = parentY() + parentOffset() + offset;
/*  32 */     this.width = parentX() + parentWidth();
/*  33 */     this.height = parentY() + parentOffset() + offset + parentHeight();
/*     */   }
/*     */   
/*     */   public int parentX() {
/*  37 */     return this.parent.parent.getX();
/*     */   }
/*     */   
/*     */   public int parentY() {
/*  41 */     return this.parent.parent.getY();
/*     */   }
/*     */   
/*     */   public int parentWidth() {
/*  45 */     return this.parent.parent.getWidth();
/*     */   }
/*     */   
/*     */   public int parentHeight() {
/*  49 */     return this.parent.parent.getHeight();
/*     */   }
/*     */   
/*     */   public int parentOffset() {
/*  53 */     return this.parent.offset;
/*     */   }
/*     */   
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*  57 */     updateMouseOver(n, n2);
/*  58 */     this.x = parentX();
/*  59 */     this.y = parentY() + parentOffset() + this.offset;
/*  60 */     this.width = parentX() + parentWidth();
/*  61 */     this.height = parentY() + parentOffset() + this.offset + parentHeight();
/*     */ 
/*     */     
/*  64 */     if (this.currentColor == null) {
/*  65 */       this.currentColor = new Color(0, 0, 0, 0);
/*     */     }
/*     */     
/*  68 */     drawContext.method_25294(this.x, this.y, this.width, this.height, this.currentColor.getRGB());
/*     */   }
/*     */   
/*     */   private void updateMouseOver(double n, double n2) {
/*  72 */     this.mouseOver = isHovered(n, n2);
/*     */   }
/*     */   
/*     */   public void renderDescription(class_332 drawContext, int n, int n2, float n3) {
/*  76 */     if (isHovered(n, n2) && this.setting.getDescription() != null && !this.parent.parent.dragging) {
/*  77 */       CharSequence description = this.setting.getDescription();
/*  78 */       int descriptionWidth = TextRenderer.getWidth(description);
/*  79 */       int n4 = this.mc.method_22683().method_4480() / 2 - descriptionWidth / 2;
/*  80 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(100, 100, 100, 100), (n4 - 5), (this.mc.method_22683().method_4507() / 2 + 294), (n4 + descriptionWidth + 5), (this.mc.method_22683().method_4507() / 2 + 318), 3.0D, 10.0D);
/*  81 */       TextRenderer.drawString(description, drawContext, n4, this.mc.method_22683().method_4507() / 2 + 300, Color.WHITE.getRGB());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void onGuiClose() {
/*  86 */     this.currentColor = null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyPressed(int n, int n2, int n3) {}
/*     */   
/*     */   public boolean isHovered(double n, double n2) {
/*  93 */     return (n > parentX() && n < (parentX() + parentWidth()) && n2 > (this.offset + parentOffset() + parentY()) && n2 < (this.offset + parentOffset() + parentY() + parentHeight()));
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*  97 */     if (this.currentColor == null) {
/*  98 */       this.currentColor = new Color(0, 0, 0, 0);
/*     */     } else {
/* 100 */       this.currentColor = new Color(0, 0, 0, this.currentColor.getAlpha());
/*     */     } 
/* 102 */     if (this.currentColor.getAlpha() != 120)
/* 103 */       this.currentColor = ColorUtil.a(0.05F, 120, this.currentColor); 
/*     */   }
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {}
/*     */   
/*     */   public void mouseReleased(double n, double n2, int n3) {}
/*     */   
/*     */   public void mouseDragged(double n, double n2, int n3, double n4, double n5) {}
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\Component.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */