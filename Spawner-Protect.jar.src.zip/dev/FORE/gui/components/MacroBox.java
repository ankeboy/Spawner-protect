/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.MacroSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public class MacroBox
/*     */   extends Component {
/*     */   private final MacroSetting setting;
/*     */   private float hoverAnimation;
/*     */   private Color currentColor;
/*     */   private final Color TEXT_COLOR;
/*     */   private final Color HOVER_COLOR;
/*     */   private final Color CAT_BG;
/*     */   private final Color CAT_BORDER;
/*     */   private final Color CAT_EAR_COLOR;
/*     */   private final Color CAT_FACE_COLOR;
/*  25 */   private final float CORNER_RADIUS = 4.0F;
/*  26 */   private final float HOVER_ANIMATION_SPEED = 0.25F;
/*     */   
/*     */   public MacroBox(ModuleButton moduleButton, Setting setting, int n) {
/*  29 */     super(moduleButton, setting, n);
/*  30 */     this.hoverAnimation = 0.0F;
/*  31 */     this.TEXT_COLOR = new Color(230, 230, 230);
/*  32 */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/*  33 */     this.CAT_BG = new Color(60, 60, 65);
/*  34 */     this.CAT_BORDER = new Color(80, 80, 85);
/*  35 */     this.CAT_EAR_COLOR = new Color(100, 100, 105);
/*  36 */     this.CAT_FACE_COLOR = new Color(120, 120, 125);
/*  37 */     this.setting = (MacroSetting)setting;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  42 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*  43 */     if (this.currentColor == null) {
/*  44 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*     */     } else {
/*  46 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor.getAlpha());
/*     */     } 
/*  48 */     if (this.currentColor.getAlpha() != 255) {
/*  49 */       this.currentColor = ColorUtil.a(0.05F, 255, this.currentColor);
/*     */     }
/*  51 */     super.onUpdate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*  56 */     super.render(drawContext, n, n2, n3);
/*  57 */     updateAnimations(n, n2, n3);
/*  58 */     if (!this.parent.parent.dragging) {
/*  59 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR.getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*     */     }
/*  61 */     int n4 = parentX() + 5;
/*  62 */     int n5 = parentY() + parentOffset() + this.offset + parentHeight() / 2;
/*  63 */     TextRenderer.drawString(String.valueOf(this.setting.getName()), drawContext, n4, n5 - 8, this.TEXT_COLOR.getRGB());
/*  64 */     int n6 = n4 + TextRenderer.getWidth(String.valueOf(this.setting.getName()) + ": ") + 5;
/*  65 */     int n7 = n5 - 11;
/*     */ 
/*     */     
/*  68 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.CAT_BORDER, n6, n7, (n6 + 20), (n7 + 20), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*  69 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.CAT_BG, (n6 + 1), (n7 + 1), (n6 + 20 - 1), (n7 + 20 - 1), 3.5D, 3.5D, 3.5D, 3.5D, 50.0D);
/*     */ 
/*     */     
/*  72 */     drawContext.method_25294(n6 + 3, n7 + 2, n6 + 7, n7 + 6, this.CAT_EAR_COLOR.getRGB());
/*  73 */     drawContext.method_25294(n6 + 15, n7 + 2, n6 + 19, n7 + 6, this.CAT_EAR_COLOR.getRGB());
/*     */ 
/*     */     
/*  76 */     drawContext.method_25294(n6 + 8, n7 + 8, n6 + 14, n7 + 14, this.CAT_FACE_COLOR.getRGB());
/*     */ 
/*     */     
/*  79 */     drawContext.method_25294(n6 + 9, n7 + 9, n6 + 11, n7 + 11, Color.BLACK.getRGB());
/*  80 */     drawContext.method_25294(n6 + 11, n7 + 9, n6 + 13, n7 + 11, Color.BLACK.getRGB());
/*     */ 
/*     */     
/*  83 */     drawContext.method_25294(n6 + 10, n7 + 12, n6 + 12, n7 + 13, Color.PINK.getRGB());
/*     */ 
/*     */     
/*  86 */     int commandCount = this.setting.getCommands().size();
/*  87 */     if (commandCount > 0) {
/*  88 */       String countText = String.valueOf(commandCount);
/*  89 */       TextRenderer.drawCenteredString(countText, drawContext, n6 + 11, n7 + 16, Color.WHITE.getRGB());
/*     */     } else {
/*  91 */       TextRenderer.drawCenteredString("?", drawContext, n6 + 11, n7 + 16, (new Color(150, 150, 150, 200)).getRGB());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateAnimations(int n, int n2, float n3) {
/*     */     float n4;
/*  97 */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/*  98 */       n4 = 1.0F;
/*     */     } else {
/* 100 */       n4 = 0.0F;
/*     */     } 
/* 102 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n4, 0.25D, (n3 * 0.05F));
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {
/* 107 */     if (isHovered(n, n2) && n3 == 0) {
/* 108 */       this.mc.method_1507(new MacroFilter(this, this.setting));
/*     */     }
/* 110 */     super.mouseClicked(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onGuiClose() {
/* 115 */     this.currentColor = null;
/* 116 */     this.hoverAnimation = 0.0F;
/* 117 */     super.onGuiClose();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\MacroBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */