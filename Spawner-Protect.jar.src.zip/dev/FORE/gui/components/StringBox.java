/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.module.modules.client.DonutBBC;
/*     */ import dev.FORE.module.setting.StringSetting;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ public class StringBox extends class_437 {
/*     */   private final StringSetting setting;
/*     */   private String content;
/*     */   private int cursorPosition;
/*     */   private int selectionStart;
/*     */   private final boolean selecting;
/*     */   private long lastCursorBlink;
/*     */   private boolean cursorVisible;
/*  25 */   private final int CURSOR_BLINK_SPEED = 530;
/*     */   final TextBox this$0;
/*     */   
/*     */   public StringBox(TextBox this$0, StringSetting setting) {
/*  29 */     super((class_2561)class_2561.method_43473());
/*  30 */     this.this$0 = this$0;
/*  31 */     this.selectionStart = -1;
/*  32 */     this.selecting = false;
/*  33 */     this.lastCursorBlink = 0L;
/*  34 */     this.cursorVisible = true;
/*  35 */     this.setting = setting;
/*  36 */     this.content = setting.getValue();
/*  37 */     this.cursorPosition = this.content.length();
/*     */   }
/*     */   public void method_25394(class_332 drawContext, int n, int n2, float n3) {
/*     */     int a;
/*  41 */     RenderUtils.unscaledProjection();
/*  42 */     super.method_25394(drawContext, n * (int)class_310.method_1551().method_22683().method_4495(), n2 * (int)class_310.method_1551().method_22683().method_4495(), n3);
/*  43 */     long currentTimeMillis = System.currentTimeMillis();
/*  44 */     if (currentTimeMillis - this.lastCursorBlink > 530L) {
/*  45 */       this.cursorVisible = !this.cursorVisible;
/*  46 */       this.lastCursorBlink = currentTimeMillis;
/*     */     } 
/*  48 */     int width = this.this$0.mc.method_22683().method_4480();
/*  49 */     int height = this.this$0.mc.method_22683().method_4507();
/*     */     
/*  51 */     if (DonutBBC.renderBackground.getValue()) {
/*  52 */       a = 180;
/*     */     } else {
/*  54 */       a = 0;
/*     */     } 
/*  56 */     drawContext.method_25294(0, 0, width, height, (new Color(0, 0, 0, a)).getRGB());
/*  57 */     int width2 = this.this$0.mc.method_22683().method_4480();
/*  58 */     int height2 = this.this$0.mc.method_22683().method_4507();
/*  59 */     int a2 = MathUtil.clampInt(TextRenderer.getWidth(this.content) + 80, 700, this.this$0.mc.method_22683().method_4480() - 100);
/*  60 */     int n4 = (width2 - a2) / 2;
/*  61 */     int n5 = (height2 - 130) / 2;
/*  62 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(30, 30, 35, 240), n4, n5, (n4 + a2), (n5 + 130), 8.0D, 8.0D, 8.0D, 8.0D, 20.0D);
/*  63 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), n4, n5, (n4 + a2), (n5 + 30), 8.0D, 8.0D, 0.0D, 0.0D, 20.0D);
/*  64 */     drawContext.method_25294(n4, n5 + 30, n4 + a2, n5 + 31, Utils.getMainColor(255, 1).getRGB());
/*  65 */     TextRenderer.drawCenteredString(this.setting.getName(), drawContext, n4 + a2 / 2, n5 + 8, (new Color(245, 245, 245, 255)).getRGB());
/*  66 */     int n6 = n4 + 20;
/*  67 */     int n7 = n5 + 50;
/*  68 */     int n8 = a2 - 40;
/*  69 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 255), n6, n7, (n6 + n8), (n7 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*  70 */     RenderUtils.renderRoundedOutline(drawContext, new Color(60, 60, 65, 255), n6, n7, (n6 + n8), (n7 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 1.0D, 20.0D);
/*  71 */     String content = this.content;
/*  72 */     int n9 = n6 + 10;
/*  73 */     int n10 = n7 + 10;
/*  74 */     String substring = this.content.substring(0, this.cursorPosition);
/*  75 */     content.substring(this.cursorPosition);
/*  76 */     int n11 = n9 + TextRenderer.getWidth(substring);
/*  77 */     if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
/*  78 */       int min = Math.min(this.selectionStart, this.cursorPosition);
/*  79 */       int max = Math.max(this.selectionStart, this.cursorPosition);
/*  80 */       String substring2 = content.substring(0, min);
/*  81 */       String substring3 = content.substring(min, max);
/*  82 */       String substring4 = content.substring(max);
/*  83 */       int a3 = TextRenderer.getWidth(substring2);
/*  84 */       int a4 = TextRenderer.getWidth(substring3);
/*  85 */       TextRenderer.drawString(substring2, drawContext, n9, n10, (new Color(245, 245, 245, 255)).getRGB());
/*  86 */       drawContext.method_25294(n9 + a3, n10 - 2, n9 + a3 + a4, n10 + 14, Utils.getMainColor(100, 1).getRGB());
/*  87 */       TextRenderer.drawString(substring3, drawContext, n9 + a3, n10, (new Color(255, 255, 255, 255)).getRGB());
/*  88 */       TextRenderer.drawString(substring4, drawContext, n9 + a3 + a4, n10, (new Color(245, 245, 245, 255)).getRGB());
/*     */     } else {
/*  90 */       TextRenderer.drawString(content, drawContext, n9, n10, (new Color(245, 245, 245, 255)).getRGB());
/*  91 */       if (this.cursorVisible) {
/*  92 */         drawContext.method_25294(n11, n10 - 2, n11 + 1, n10 + 14, (new Color(245, 245, 245, 255)).getRGB());
/*     */       }
/*     */     } 
/*  95 */     int n12 = n5 + 130 - 30;
/*  96 */     int n13 = n4 + a2 - 80 - 20;
/*  97 */     int n14 = n13 - 80 - 10;
/*  98 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), n13, n12, (n13 + 80), (n12 + 25), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*  99 */     TextRenderer.drawCenteredString("Save", drawContext, n13 + 40, n12 + 6, (new Color(245, 245, 245, 255)).getRGB());
/* 100 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(60, 60, 65, 255), n14, n12, (n14 + 80), (n12 + 25), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 101 */     TextRenderer.drawCenteredString("Cancel", drawContext, n14 + 40, n12 + 6, (new Color(245, 245, 245, 255)).getRGB());
/* 102 */     TextRenderer.drawString("Press Escape to save and close", drawContext, n4 + 20, n5 + 130 - 20, (new Color(150, 150, 150, 200)).getRGB());
/* 103 */     RenderUtils.scaledProjection();
/*     */   }
/*     */   
/*     */   public void method_16014(double n, double n2) {
/* 107 */     super.method_16014(n, n2);
/* 108 */     this.cursorVisible = true;
/* 109 */     this.lastCursorBlink = System.currentTimeMillis();
/*     */   }
/*     */   
/*     */   public boolean method_25402(double n, double n2, int n3) {
/* 113 */     double n4 = n * class_310.method_1551().method_22683().method_4495();
/* 114 */     double n5 = n2 * class_310.method_1551().method_22683().method_4495();
/* 115 */     int width = this.this$0.mc.method_22683().method_4480();
/* 116 */     int height = this.this$0.mc.method_22683().method_4507();
/* 117 */     int max = Math.max(700, MathUtil.clampInt(TextRenderer.getWidth(this.content) + 80, 400, this.this$0.mc.method_22683().method_4480() - 100));
/* 118 */     int n6 = (height - 130) / 2 + 130 - 30;
/* 119 */     int n7 = (width - max) / 2 + max - 80 - 20;
/* 120 */     if (isHovered(n4, n5, n7, n6, 80, 25)) {
/* 121 */       this.setting.setValue(this.content.trim());
/* 122 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 123 */       return true;
/*     */     } 
/* 125 */     if (isHovered(n4, n5, n7 - 80 - 10, n6, 80, 25)) {
/* 126 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 127 */       return true;
/*     */     } 
/* 129 */     return super.method_25402(n4, n5, n3);
/*     */   }
/*     */   
/*     */   private boolean isHovered(double n, double n2, int n3, int n4, int n5, int n6) {
/* 133 */     return (n >= n3 && n <= (n3 + n5) && n2 >= n4 && n2 <= (n4 + n6));
/*     */   }
/*     */   
/*     */   public boolean method_25404(int n, int n2, int n3) {
/* 137 */     this.cursorVisible = true;
/* 138 */     this.lastCursorBlink = System.currentTimeMillis();
/* 139 */     if (n == 256) {
/* 140 */       this.setting.setValue(this.content.trim());
/* 141 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 142 */       return true;
/*     */     } 
/* 144 */     if (n == 257) {
/* 145 */       this.setting.setValue(this.content.trim());
/* 146 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 147 */       return true;
/*     */     } 
/* 149 */     if (isPaste(n)) {
/* 150 */       String clipboard = this.this$0.mc.field_1774.method_1460();
/* 151 */       if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
/* 152 */         int min = Math.min(this.selectionStart, this.cursorPosition);
/* 153 */         this.content = this.content.substring(0, min) + this.content.substring(0, min) + clipboard;
/* 154 */         this.cursorPosition = min + clipboard.length();
/*     */       } else {
/* 156 */         this.content = this.content.substring(0, this.cursorPosition) + this.content.substring(0, this.cursorPosition) + clipboard;
/* 157 */         this.cursorPosition += clipboard.length();
/*     */       } 
/* 159 */       this.selectionStart = -1;
/* 160 */       return true;
/*     */     } 
/* 162 */     if (isCopy(n)) {
/* 163 */       if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
/* 164 */         GLFW.glfwSetClipboardString(this.this$0.mc.method_22683().method_4490(), this.content.substring(Math.min(this.selectionStart, this.cursorPosition), Math.max(this.selectionStart, this.cursorPosition)));
/*     */       }
/* 166 */       return true;
/*     */     } 
/* 168 */     if (isCut(n)) {
/* 169 */       if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
/* 170 */         int min2 = Math.min(this.selectionStart, this.cursorPosition);
/* 171 */         int max = Math.max(this.selectionStart, this.cursorPosition);
/* 172 */         GLFW.glfwSetClipboardString(this.this$0.mc.method_22683().method_4490(), this.content.substring(min2, max));
/* 173 */         this.content = this.content.substring(0, min2) + this.content.substring(0, min2);
/* 174 */         this.cursorPosition = min2;
/* 175 */         this.selectionStart = -1;
/*     */       } 
/* 177 */       return true;
/*     */     } 
/* 179 */     if (n == 259) {
/* 180 */       if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
/* 181 */         int min3 = Math.min(this.selectionStart, this.cursorPosition);
/* 182 */         this.content = this.content.substring(0, min3) + this.content.substring(0, min3);
/* 183 */         this.cursorPosition = min3;
/* 184 */         this.selectionStart = -1;
/* 185 */       } else if (this.cursorPosition > 0) {
/* 186 */         this.content = this.content.substring(0, this.cursorPosition - 1) + this.content.substring(0, this.cursorPosition - 1);
/* 187 */         this.cursorPosition--;
/*     */       } 
/* 189 */       return true;
/*     */     } 
/* 191 */     if (n == 261) {
/* 192 */       if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
/* 193 */         int min4 = Math.min(this.selectionStart, this.cursorPosition);
/* 194 */         this.content = this.content.substring(0, min4) + this.content.substring(0, min4);
/* 195 */         this.cursorPosition = min4;
/* 196 */         this.selectionStart = -1;
/* 197 */       } else if (this.cursorPosition < this.content.length()) {
/* 198 */         this.content = this.content.substring(0, this.cursorPosition) + this.content.substring(0, this.cursorPosition);
/*     */       } 
/* 200 */       return true;
/*     */     } 
/* 202 */     if (n == 263) {
/* 203 */       if ((n3 & 0x1) != 0) {
/* 204 */         if (this.selectionStart == -1) {
/* 205 */           this.selectionStart = this.cursorPosition;
/*     */         }
/*     */       } else {
/* 208 */         this.selectionStart = -1;
/*     */       } 
/* 210 */       if (this.cursorPosition > 0) {
/* 211 */         this.cursorPosition--;
/*     */       }
/* 213 */       return true;
/*     */     } 
/* 215 */     if (n == 262) {
/* 216 */       if ((n3 & 0x1) != 0) {
/* 217 */         if (this.selectionStart == -1) {
/* 218 */           this.selectionStart = this.cursorPosition;
/*     */         }
/*     */       } else {
/* 221 */         this.selectionStart = -1;
/*     */       } 
/* 223 */       if (this.cursorPosition < this.content.length()) {
/* 224 */         this.cursorPosition++;
/*     */       }
/* 226 */       return true;
/*     */     } 
/* 228 */     if (n == 268) {
/* 229 */       if ((n3 & 0x1) != 0) {
/* 230 */         if (this.selectionStart == -1) {
/* 231 */           this.selectionStart = this.cursorPosition;
/*     */         }
/*     */       } else {
/* 234 */         this.selectionStart = -1;
/*     */       } 
/* 236 */       this.cursorPosition = 0;
/* 237 */       return true;
/*     */     } 
/* 239 */     if (n == 269) {
/* 240 */       if ((n3 & 0x1) != 0) {
/* 241 */         if (this.selectionStart == -1) {
/* 242 */           this.selectionStart = this.cursorPosition;
/*     */         }
/*     */       } else {
/* 245 */         this.selectionStart = -1;
/*     */       } 
/* 247 */       this.cursorPosition = this.content.length();
/* 248 */       return true;
/*     */     } 
/* 250 */     return super.method_25404(n, n2, n3);
/*     */   }
/*     */   
/*     */   public boolean method_25400(char c, int n) {
/* 254 */     if (this.selectionStart != -1 && this.selectionStart != this.cursorPosition) {
/* 255 */       int min = Math.min(this.selectionStart, this.cursorPosition);
/* 256 */       this.content = this.content.substring(0, min) + this.content.substring(0, min) + c;
/* 257 */       this.cursorPosition = min + 1;
/* 258 */       this.selectionStart = -1;
/*     */     } else {
/* 260 */       this.content = this.content.substring(0, this.cursorPosition) + this.content.substring(0, this.cursorPosition) + c;
/* 261 */       this.cursorPosition++;
/*     */     } 
/* 263 */     this.cursorVisible = true;
/* 264 */     this.lastCursorBlink = System.currentTimeMillis();
/* 265 */     return true;
/*     */   }
/*     */   
/*     */   public static boolean isPaste(int n) {
/* 269 */     return (n == 86 && hasControlDown());
/*     */   }
/*     */   
/*     */   public static boolean isCopy(int n) {
/* 273 */     return (n == 67 && hasControlDown());
/*     */   }
/*     */   
/*     */   public static boolean isCut(int n) {
/* 277 */     return (n == 88 && hasControlDown());
/*     */   }
/*     */   
/*     */   public static boolean hasControlDown() {
/*     */     int n;
/* 282 */     if (class_310.field_1703) {
/* 283 */       n = GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), 343);
/*     */     } else {
/* 285 */       n = GLFW.glfwGetKey(class_310.method_1551().method_22683().method_4490(), 341);
/*     */     } 
/* 287 */     return (n == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25420(class_332 drawContext, int n, int n2, float n3) {}
/*     */   
/*     */   public boolean method_25422() {
/* 294 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\StringBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */