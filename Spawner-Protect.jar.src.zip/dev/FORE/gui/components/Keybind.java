/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.BindSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.KeyUtils;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_4587;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Keybind
/*     */   extends Component
/*     */ {
/*     */   private final BindSetting keybind;
/*     */   private Color accentColor;
/*     */   private Color currentAlpha;
/*     */   private float hoverAnimation;
/*     */   private float listenAnimation;
/*     */   
/*     */   public Keybind(ModuleButton moduleButton, Setting setting, int n) {
/*  31 */     super(moduleButton, setting, n);
/*  32 */     this.hoverAnimation = 0.0F;
/*  33 */     this.listenAnimation = 0.0F;
/*  34 */     this.keybind = (BindSetting)setting;
/*     */   }
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*     */     String string;
/*     */     float hoverAlpha;
/*  39 */     super.render(drawContext, n, n2, n3);
/*  40 */     class_4587 matrices = drawContext.method_51448();
/*  41 */     updateAnimations(n, n2, n3);
/*  42 */     if (!this.parent.parent.dragging) {
/*  43 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(HOVER_COLOR.getRed(), HOVER_COLOR.getGreen(), HOVER_COLOR.getBlue(), (int)(HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*     */     }
/*  45 */     TextRenderer.drawString(this.setting.getName(), drawContext, parentX() + 5, parentY() + parentOffset() + this.offset + 9, TEXT_COLOR.getRGB());
/*     */     
/*  47 */     if (this.keybind.isListening()) {
/*  48 */       string = "Listening...";
/*     */     } else {
/*  50 */       string = KeyUtils.getKey(this.keybind.getValue()).toString();
/*     */     } 
/*  52 */     int textWidth = TextRenderer.getWidth(string);
/*  53 */     int max = Math.max(80, textWidth + 16);
/*  54 */     int n4 = parentX() + parentWidth() - max - 5;
/*  55 */     int n5 = parentY() + parentOffset() + this.offset + (parentHeight() - 20) / 2;
/*  56 */     RenderUtils.renderRoundedQuad(matrices, ColorUtil.a(BUTTON_BG_COLOR, BUTTON_ACTIVE_BG_COLOR, this.listenAnimation), n4, n5, (n4 + max), (n5 + 20), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*  57 */     float listenAlpha = this.listenAnimation * 0.7F;
/*     */     
/*  59 */     if (isButtonHovered(n, n2, n4, n5, max, 20)) {
/*  60 */       hoverAlpha = 0.2F;
/*     */     } else {
/*  62 */       hoverAlpha = 0.0F;
/*     */     } 
/*  64 */     float maxAlpha = Math.max(listenAlpha, hoverAlpha);
/*  65 */     if (maxAlpha > 0.0F) {
/*  66 */       RenderUtils.renderRoundedQuad(matrices, new Color(this.accentColor.getRed(), this.accentColor.getGreen(), this.accentColor.getBlue(), (int)(this.accentColor.getAlpha() * maxAlpha)), n4, n5, (n4 + max), (n5 + 20), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*     */     }
/*  68 */     TextRenderer.drawString(string, drawContext, n4 + (max - textWidth) / 2, n5 + 6 - 3, ColorUtil.a(TEXT_COLOR, LISTENING_TEXT_COLOR, this.listenAnimation).getRGB());
/*  69 */     if (this.keybind.isListening()) {
/*  70 */       RenderUtils.renderRoundedQuad(matrices, new Color(this.accentColor.getRed(), this.accentColor.getGreen(), this.accentColor.getBlue(), (int)(this.accentColor.getAlpha() * (float)Math.abs(Math.sin(System.currentTimeMillis() / 500.0D)) * 0.3F)), n4, n5, (n4 + max), (n5 + 20), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateAnimations(int n, int n2, float n3) {
/*  75 */     float n5, n6, n4 = n3 * 0.05F;
/*     */     
/*  77 */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/*  78 */       n5 = 1.0F;
/*     */     } else {
/*  80 */       n5 = 0.0F;
/*     */     } 
/*  82 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n5, 0.25D, n4);
/*     */     
/*  84 */     if (this.keybind.isListening()) {
/*  85 */       n6 = 1.0F;
/*     */     } else {
/*  87 */       n6 = 0.0F;
/*     */     } 
/*  89 */     this.listenAnimation = (float)MathUtil.exponentialInterpolate(this.listenAnimation, n6, 0.3499999940395355D, n4);
/*     */   }
/*     */   
/*     */   private boolean isButtonHovered(double n, double n2, int n3, int n4, int n5, int n6) {
/*  93 */     return (n >= n3 && n <= (n3 + n5) && n2 >= n4 && n2 <= (n4 + n6));
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {
/*     */     String string;
/*  99 */     if (this.keybind.isListening()) {
/* 100 */       string = "Listening...";
/*     */     } else {
/* 102 */       string = KeyUtils.getKey(this.keybind.getValue()).toString();
/*     */     } 
/* 104 */     int max = Math.max(80, TextRenderer.getWidth(string) + 16);
/* 105 */     if (isButtonHovered(n, n2, parentX() + parentWidth() - max - 5, parentY() + parentOffset() + this.offset + (parentHeight() - 20) / 2, max, 20)) {
/* 106 */       if (!this.keybind.isListening()) {
/* 107 */         if (n3 == 0) {
/* 108 */           this.keybind.setListening(true);
/*     */         }
/*     */       } else {
/*     */         
/* 112 */         this.keybind.setValue(n3);
/*     */ 
/*     */         
/* 115 */         if (this.keybind.isModuleKey() && this.parent != null && this.parent.module != null) {
/* 116 */           this.parent.module.setKeybind(n3);
/*     */         }
/*     */ 
/*     */         
/* 120 */         this.keybind.setListening(false);
/*     */       } 
/*     */     }
/* 123 */     super.mouseClicked(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyPressed(int n, int n2, int n3) {
/* 128 */     if (this.keybind.isListening()) {
/* 129 */       if (n == 256) {
/*     */         
/* 131 */         this.keybind.setListening(false);
/* 132 */       } else if (n == 259) {
/*     */         
/* 134 */         this.keybind.setValue(-1);
/*     */ 
/*     */         
/* 137 */         if (this.keybind.isModuleKey() && this.parent != null && this.parent.module != null) {
/* 138 */           this.parent.module.setKeybind(-1);
/*     */         }
/*     */         
/* 141 */         this.keybind.setListening(false);
/*     */       } else {
/*     */         
/* 144 */         this.keybind.setValue(n);
/*     */ 
/*     */         
/* 147 */         if (this.keybind.isModuleKey() && this.parent != null && this.parent.module != null) {
/* 148 */           this.parent.module.setKeybind(n);
/*     */         }
/*     */         
/* 151 */         this.keybind.setListening(false);
/*     */       } 
/*     */     }
/* 154 */     super.keyPressed(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 159 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/* 160 */     if (this.accentColor == null) {
/* 161 */       this.accentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*     */     } else {
/* 163 */       this.accentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.accentColor.getAlpha());
/*     */     } 
/* 165 */     if (this.accentColor.getAlpha() != 255) {
/* 166 */       this.accentColor = ColorUtil.a(0.05F, 255, this.accentColor);
/*     */     }
/* 168 */     super.onUpdate();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onGuiClose() {
/* 174 */     if (this.keybind.isListening()) {
/* 175 */       this.keybind.setListening(false);
/*     */     }
/* 177 */     this.accentColor = null;
/* 178 */     this.hoverAnimation = 0.0F;
/* 179 */     this.listenAnimation = 0.0F;
/* 180 */     super.onGuiClose();
/*     */   }
/*     */ 
/*     */   
/* 184 */   private static final Color TEXT_COLOR = new Color(230, 230, 230);
/* 185 */   private static final Color LISTENING_TEXT_COLOR = new Color(255, 255, 255);
/* 186 */   private static final Color HOVER_COLOR = new Color(255, 255, 255, 20);
/* 187 */   private static final Color BUTTON_BG_COLOR = new Color(60, 60, 65);
/* 188 */   private static final Color BUTTON_ACTIVE_BG_COLOR = new Color(80, 80, 85);
/*     */   private static final float BUTTON_RADIUS = 4.0F;
/*     */   private static final float ANIMATION_SPEED = 0.25F;
/*     */   private static final float LISTEN_ANIMATION_SPEED = 0.35F;
/*     */   private static final int BUTTON_MIN_WIDTH = 80;
/*     */   private static final int BUTTON_PADDING = 16;
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\Keybind.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */