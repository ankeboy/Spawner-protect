/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.module.modules.client.DonutBBC;
/*     */ import dev.FORE.module.setting.MacroSetting;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ 
/*     */ public class MacroFilter
/*     */   extends class_437
/*     */ {
/*     */   private final MacroSetting setting;
/*     */   private String newCommand;
/*  22 */   private final int CURSOR_BLINK_SPEED = 530; private int cursorPosition; private long lastCursorBlink; private boolean cursorVisible;
/*     */   private int scrollOffset;
/*  24 */   private final int COMMANDS_PER_PAGE = 6;
/*     */   final MacroBox this$0;
/*     */   
/*     */   public MacroFilter(MacroBox this$0, MacroSetting setting) {
/*  28 */     super((class_2561)class_2561.method_43473());
/*  29 */     this.this$0 = this$0;
/*  30 */     this.newCommand = "";
/*  31 */     this.cursorPosition = 0;
/*  32 */     this.lastCursorBlink = 0L;
/*  33 */     this.cursorVisible = true;
/*  34 */     this.scrollOffset = 0;
/*  35 */     this.setting = setting;
/*     */   }
/*     */   public void method_25394(class_332 drawContext, int n, int n2, float n3) {
/*     */     int a;
/*  39 */     RenderUtils.unscaledProjection();
/*  40 */     int n4 = n * (int)class_310.method_1551().method_22683().method_4495();
/*  41 */     int n5 = n2 * (int)class_310.method_1551().method_22683().method_4495();
/*  42 */     super.method_25394(drawContext, n4, n5, n3);
/*  43 */     int width = this.this$0.mc.method_22683().method_4480();
/*  44 */     int height = this.this$0.mc.method_22683().method_4507();
/*     */     
/*  46 */     if (DonutBBC.renderBackground.getValue()) {
/*  47 */       a = 180;
/*     */     } else {
/*  49 */       a = 0;
/*     */     } 
/*  51 */     drawContext.method_25294(0, 0, width, height, (new Color(0, 0, 0, a)).getRGB());
/*  52 */     double scale = DonutBBC.guiScale.getValue();
/*  53 */     int baseWidth = (int)(600.0D * scale);
/*  54 */     int baseHeight = (int)(450.0D * scale);
/*  55 */     int n6 = (this.this$0.mc.method_22683().method_4480() - baseWidth) / 2;
/*  56 */     int n7 = (this.this$0.mc.method_22683().method_4507() - baseHeight) / 2;
/*     */ 
/*     */     
/*  59 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(30, 30, 35, 240), n6, n7, (n6 + baseWidth), (n7 + baseHeight), 8.0D, 8.0D, 8.0D, 8.0D, 20.0D);
/*  60 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), n6, n7, (n6 + baseWidth), (n7 + 30), 8.0D, 8.0D, 0.0D, 0.0D, 20.0D);
/*  61 */     drawContext.method_25294(n6, n7 + 30, n6 + baseWidth, n7 + 31, Utils.getMainColor(255, 1).getRGB());
/*     */ 
/*     */     
/*  64 */     TextRenderer.drawCenteredString("Macro Editor: " + String.valueOf(this.setting.getName()), drawContext, n6 + baseWidth / 2, n7 + 8, (new Color(245, 245, 245, 255)).getRGB());
/*     */ 
/*     */     
/*  67 */     int n8 = n6 + 20;
/*  68 */     int n9 = n7 + 50;
/*  69 */     int inputWidth = baseWidth - 40;
/*  70 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 255), n8, n9, (n8 + inputWidth), (n9 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*  71 */     RenderUtils.renderRoundedOutline(drawContext, new Color(60, 60, 65, 255), n8, n9, (n8 + inputWidth), (n9 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 2.0D, 20.0D);
/*     */ 
/*     */     
/*  74 */     long currentTimeMillis = System.currentTimeMillis();
/*  75 */     if (currentTimeMillis - this.lastCursorBlink > 530L) {
/*  76 */       this.cursorVisible = !this.cursorVisible;
/*  77 */       this.lastCursorBlink = currentTimeMillis;
/*     */     } 
/*     */     
/*  80 */     String displayText = this.newCommand;
/*  81 */     if (this.cursorVisible) {
/*  82 */       displayText = displayText + "|";
/*     */     }
/*  84 */     TextRenderer.drawString("Add Command: " + displayText, drawContext, n8 + 10, n9 + 8, (new Color(50, 50, 50, 255)).getRGB());
/*     */ 
/*     */     
/*  87 */     int n10 = n8 + inputWidth - 80;
/*  88 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(50, 205, 50, 255), n10, n9, (n10 + 80), (n9 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*  89 */     TextRenderer.drawCenteredString("Add", drawContext, n10 + 40, n9 + 8, (new Color(245, 245, 245, 255)).getRGB());
/*     */ 
/*     */     
/*  92 */     int n11 = n7 + 100;
/*  93 */     int n12 = n8;
/*  94 */     int n13 = n9 + 30 + 20;
/*     */ 
/*     */     
/*  97 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), n12, n13, (n12 + inputWidth), (n13 + 25), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*  98 */     TextRenderer.drawCenteredString("Commands (" + this.setting.getCommands().size() + ")", drawContext, n12 + inputWidth / 2, n13 + 5, (new Color(245, 245, 245, 255)).getRGB());
/*     */ 
/*     */     
/* 101 */     List<String> commands = this.setting.getCommands();
/* 102 */     Objects.requireNonNull(this); int startIndex = this.scrollOffset * 6;
/* 103 */     Objects.requireNonNull(this); int endIndex = Math.min(startIndex + 6, commands.size());
/*     */     
/* 105 */     for (int i = startIndex; i < endIndex; i++) {
/* 106 */       int commandY = n13 + 30 + (i - startIndex) * 35;
/* 107 */       String command = commands.get(i);
/*     */ 
/*     */       
/* 110 */       int commandWidth = inputWidth - 100;
/* 111 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(255, 255, 255, 200), n12, commandY, (n12 + commandWidth), (commandY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 112 */       RenderUtils.renderRoundedOutline(drawContext, new Color(60, 60, 65, 255), n12, commandY, (n12 + commandWidth), (commandY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 1.0D, 20.0D);
/*     */ 
/*     */       
/* 115 */       TextRenderer.drawString("" + i + 1 + ". " + i + 1, drawContext, n12 + 10, commandY + 8, (new Color(50, 50, 50, 255)).getRGB());
/*     */ 
/*     */       
/* 118 */       int deleteX = n12 + commandWidth + 5;
/* 119 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(220, 20, 60, 255), deleteX, commandY, (deleteX + 75), (commandY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 120 */       TextRenderer.drawCenteredString("Delete", drawContext, deleteX + 37, commandY + 8, (new Color(245, 245, 245, 255)).getRGB());
/*     */     } 
/*     */ 
/*     */     
/* 124 */     int n14 = n7 + baseHeight - 45;
/* 125 */     int n15 = n6 + baseWidth - 80 - 20;
/* 126 */     int n16 = n15 - 80 - 10;
/* 127 */     int n17 = n16 - 80 - 10;
/*     */ 
/*     */     
/* 130 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(50, 205, 50, 255), n15, n14, (n15 + 80), (n14 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 131 */     TextRenderer.drawCenteredString("Save", drawContext, n15 + 40, n14 + 8, (new Color(245, 245, 245, 255)).getRGB());
/*     */ 
/*     */     
/* 134 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(128, 128, 128, 255), n16, n14, (n16 + 80), (n14 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 135 */     TextRenderer.drawCenteredString("Cancel", drawContext, n16 + 40, n14 + 8, (new Color(245, 245, 245, 255)).getRGB());
/*     */ 
/*     */     
/* 138 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(220, 20, 60, 255), n17, n14, (n17 + 80), (n14 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 139 */     TextRenderer.drawCenteredString("Clear All", drawContext, n17 + 40, n14 + 8, (new Color(245, 245, 245, 255)).getRGB());
/*     */ 
/*     */     
/* 142 */     Objects.requireNonNull(this); if (commands.size() > 6) {
/* 143 */       Objects.requireNonNull(this); int arrowY = n13 + 30 + 6 * 35 + 10;
/*     */ 
/*     */       
/* 146 */       if (this.scrollOffset > 0) {
/* 147 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(255, 105, 180, 255), n12, arrowY, (n12 + 40), (arrowY + 20), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 148 */         TextRenderer.drawCenteredString("←", drawContext, n12 + 20, arrowY + 5, (new Color(245, 245, 245, 255)).getRGB());
/*     */       } 
/*     */ 
/*     */       
/* 152 */       Objects.requireNonNull(this); if ((this.scrollOffset + 1) * 6 < commands.size()) {
/* 153 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(255, 105, 180, 255), (n12 + inputWidth - 40), arrowY, (n12 + inputWidth), (arrowY + 20), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 154 */         TextRenderer.drawCenteredString("→", drawContext, n12 + inputWidth - 20, arrowY + 5, (new Color(245, 245, 245, 255)).getRGB());
/*     */       } 
/*     */     } 
/*     */     
/* 158 */     RenderUtils.scaledProjection();
/*     */   }
/*     */   
/*     */   public boolean method_25402(double n, double n2, int n3) {
/* 162 */     double n4 = n * class_310.method_1551().method_22683().method_4495();
/* 163 */     double n5 = n2 * class_310.method_1551().method_22683().method_4495();
/* 164 */     double scale = DonutBBC.guiScale.getValue();
/* 165 */     int baseWidth = (int)(600.0D * scale);
/* 166 */     int baseHeight = (int)(450.0D * scale);
/* 167 */     int n6 = (this.this$0.mc.method_22683().method_4480() - baseWidth) / 2;
/* 168 */     int n7 = (this.this$0.mc.method_22683().method_4507() - baseHeight) / 2;
/* 169 */     int n8 = n7 + baseHeight - 45;
/* 170 */     int n9 = n6 + baseWidth - 80 - 20;
/* 171 */     int n10 = n9 - 80 - 10;
/* 172 */     int n11 = n10 - 80 - 10;
/*     */ 
/*     */     
/* 175 */     if (isInBounds(n4, n5, n9, n8, 80, 30)) {
/* 176 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 177 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 181 */     if (isInBounds(n4, n5, n10, n8, 80, 30)) {
/* 182 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 183 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 187 */     if (isInBounds(n4, n5, n11, n8, 80, 30)) {
/* 188 */       this.setting.clearCommands();
/* 189 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 193 */     int n12 = n6 + 20;
/* 194 */     int n13 = n7 + 50;
/* 195 */     int inputWidth = baseWidth - 40;
/* 196 */     if (isInBounds(n4, n5, n12 + inputWidth - 80, n13, 80, 30)) {
/* 197 */       if (!this.newCommand.trim().isEmpty()) {
/* 198 */         this.setting.addCommand(this.newCommand.trim());
/* 199 */         this.newCommand = "";
/* 200 */         this.cursorPosition = 0;
/*     */       } 
/* 202 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 206 */     List<String> commands = this.setting.getCommands();
/* 207 */     Objects.requireNonNull(this); int startIndex = this.scrollOffset * 6;
/* 208 */     Objects.requireNonNull(this); int endIndex = Math.min(startIndex + 6, commands.size());
/*     */     
/* 210 */     for (int i = startIndex; i < endIndex; i++) {
/* 211 */       int commandY = n7 + 100 + 30 + 20 + 30 + (i - startIndex) * 35;
/* 212 */       int commandWidth = inputWidth - 100;
/* 213 */       int deleteX = n6 + 20 + commandWidth + 5;
/* 214 */       if (isInBounds(n4, n5, deleteX, commandY, 75, 30)) {
/* 215 */         this.setting.removeCommand(i);
/* 216 */         return true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 221 */     Objects.requireNonNull(this); if (commands.size() > 6) {
/* 222 */       Objects.requireNonNull(this); int arrowY = n7 + 100 + 30 + 20 + 30 + 6 * 35 + 10;
/*     */ 
/*     */       
/* 225 */       if (this.scrollOffset > 0 && isInBounds(n4, n5, n6 + 20, arrowY, 40, 20)) {
/* 226 */         this.scrollOffset--;
/* 227 */         return true;
/*     */       } 
/*     */ 
/*     */       
/* 231 */       Objects.requireNonNull(this); if ((this.scrollOffset + 1) * 6 < commands.size() && isInBounds(n4, n5, n6 + 20 + inputWidth - 40, arrowY, 40, 20)) {
/* 232 */         this.scrollOffset++;
/* 233 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 237 */     return super.method_25402(n4, n5, n3);
/*     */   }
/*     */   
/*     */   public boolean method_25404(int n, int n2, int n3) {
/* 241 */     this.cursorVisible = true;
/* 242 */     this.lastCursorBlink = System.currentTimeMillis();
/*     */     
/* 244 */     if (n == 256) {
/* 245 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 246 */       return true;
/*     */     } 
/*     */     
/* 249 */     if (n == 257) {
/* 250 */       if (!this.newCommand.trim().isEmpty()) {
/* 251 */         this.setting.addCommand(this.newCommand.trim());
/* 252 */         this.newCommand = "";
/* 253 */         this.cursorPosition = 0;
/*     */       } 
/* 255 */       return true;
/*     */     } 
/*     */     
/* 258 */     if (n == 259) {
/* 259 */       if (this.cursorPosition > 0) {
/* 260 */         this.newCommand = this.newCommand.substring(0, this.cursorPosition - 1) + this.newCommand.substring(0, this.cursorPosition - 1);
/* 261 */         this.cursorPosition--;
/*     */       } 
/* 263 */       return true;
/*     */     } 
/*     */     
/* 266 */     if (n == 262) {
/* 267 */       if (this.cursorPosition < this.newCommand.length()) {
/* 268 */         this.cursorPosition++;
/*     */       }
/* 270 */       return true;
/*     */     } 
/*     */     
/* 273 */     if (n == 263) {
/* 274 */       if (this.cursorPosition > 0) {
/* 275 */         this.cursorPosition--;
/*     */       }
/* 277 */       return true;
/*     */     } 
/*     */     
/* 280 */     return super.method_25404(n, n2, n3);
/*     */   }
/*     */   
/*     */   public boolean method_25400(char c, int n) {
/* 284 */     if (Character.isISOControl(c)) {
/* 285 */       return false;
/*     */     }
/*     */     
/* 288 */     this.newCommand = this.newCommand.substring(0, this.cursorPosition) + this.newCommand.substring(0, this.cursorPosition) + c;
/* 289 */     this.cursorPosition++;
/* 290 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isInBounds(double n, double n2, int n3, int n4, int n5, int n6) {
/* 294 */     return (n >= n3 && n <= (n3 + n5) && n2 >= n4 && n2 <= (n4 + n6));
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\MacroFilter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */