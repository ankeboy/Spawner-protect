/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3532;
/*     */ 
/*     */ public final class NumberBox
/*     */   extends Component {
/*     */   public boolean dragging;
/*     */   public double offsetX;
/*     */   public double lerpedOffsetX;
/*     */   private float hoverAnimation;
/*     */   private final NumberSetting setting;
/*     */   public Color currentColor1;
/*     */   private Color currentAlpha;
/*     */   private final Color TEXT_COLOR;
/*     */   private final Color HOVER_COLOR;
/*     */   private final Color TRACK_BG_COLOR;
/*  27 */   private final float TRACK_HEIGHT = 4.0F;
/*  28 */   private final float TRACK_RADIUS = 2.0F;
/*  29 */   private final float ANIMATION_SPEED = 0.25F;
/*     */   
/*     */   public NumberBox(ModuleButton moduleButton, Setting setting, int n) {
/*  32 */     super(moduleButton, setting, n);
/*  33 */     this.lerpedOffsetX = 0.0D;
/*  34 */     this.hoverAnimation = 0.0F;
/*  35 */     this.TEXT_COLOR = new Color(230, 230, 230);
/*  36 */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/*  37 */     this.TRACK_BG_COLOR = new Color(60, 60, 65);
/*  38 */     this.setting = (NumberSetting)setting;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  43 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*  44 */     if (this.currentColor1 == null) {
/*  45 */       this.currentColor1 = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*     */     } else {
/*  47 */       this.currentColor1 = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor1.getAlpha());
/*     */     } 
/*  49 */     if (this.currentColor1.getAlpha() != 255) {
/*  50 */       this.currentColor1 = ColorUtil.a(0.05F, 255, this.currentColor1);
/*     */     }
/*  52 */     super.onUpdate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*  57 */     super.render(drawContext, n, n2, n3);
/*  58 */     updateAnimations(n, n2, n3);
/*  59 */     this.offsetX = (this.setting.getValue() - this.setting.getMin()) / (this.setting.getMax() - this.setting.getMin()) * parentWidth();
/*  60 */     this.lerpedOffsetX = MathUtil.approachValue((float)(0.5D * n3), this.lerpedOffsetX, this.offsetX);
/*  61 */     if (!this.parent.parent.dragging) {
/*  62 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR.getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*     */     }
/*  64 */     int n4 = parentY() + this.offset + parentOffset() + 25;
/*  65 */     int n5 = parentX() + 5;
/*  66 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.TRACK_BG_COLOR, n5, n4, (n5 + parentWidth() - 10), (n4 + 4.0F), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
/*  67 */     if (this.lerpedOffsetX > 2.5D) {
/*     */       
/*  69 */       if (this.currentColor1 == null) {
/*  70 */         Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*  71 */         this.currentColor1 = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 255);
/*     */       } 
/*  73 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.currentColor1, n5, n4, n5 + Math.max(this.lerpedOffsetX - 5.0D, 0.0D), (n4 + 4.0F), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
/*     */     } 
/*  75 */     String displayValue = getDisplayValue();
/*  76 */     TextRenderer.drawString(this.setting.getName(), drawContext, parentX() + 5, parentY() + parentOffset() + this.offset + 9, this.TEXT_COLOR.getRGB());
/*     */ 
/*     */     
/*  79 */     if (this.currentColor1 == null) {
/*  80 */       Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*  81 */       this.currentColor1 = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 255);
/*     */     } 
/*     */     
/*  84 */     TextRenderer.drawString(displayValue, drawContext, parentX() + parentWidth() - TextRenderer.getWidth(displayValue) - 5, parentY() + parentOffset() + this.offset + 9, this.currentColor1.getRGB());
/*     */   }
/*     */   
/*     */   private void updateAnimations(int n, int n2, float n3) {
/*     */     float n4;
/*  89 */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/*  90 */       n4 = 1.0F;
/*     */     } else {
/*  92 */       n4 = 0.0F;
/*     */     } 
/*  94 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n4, 0.25D, (n3 * 0.05F));
/*     */   }
/*     */   
/*     */   private String getDisplayValue() {
/*  98 */     double value = this.setting.getValue();
/*  99 */     double format = this.setting.getFormat();
/* 100 */     if (format == 0.1D) {
/* 101 */       return String.format("%.1f", new Object[] { Double.valueOf(value) });
/*     */     }
/* 103 */     if (format == 0.01D) {
/* 104 */       return String.format("%.2f", new Object[] { Double.valueOf(value) });
/*     */     }
/* 106 */     if (format == 0.001D) {
/* 107 */       return String.format("%.3f", new Object[] { Double.valueOf(value) });
/*     */     }
/* 109 */     if (format == 1.0E-4D) {
/* 110 */       return String.format("%.4f", new Object[] { Double.valueOf(value) });
/*     */     }
/* 112 */     if (format >= 1.0D) {
/* 113 */       return String.format("%.0f", new Object[] { Double.valueOf(value) });
/*     */     }
/* 115 */     return String.valueOf(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onGuiClose() {
/* 120 */     this.currentColor1 = null;
/* 121 */     this.hoverAnimation = 0.0F;
/* 122 */     super.onGuiClose();
/*     */   }
/*     */   
/*     */   private void slide(double n) {
/* 126 */     this.setting.getValue(MathUtil.roundToNearest(class_3532.method_15350((n - (parentX() + 5)) / (parentWidth() - 10), 0.0D, 1.0D) * (this.setting.getMax() - this.setting.getMin()) + this.setting.getMin(), this.setting.getFormat()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyPressed(int n, int n2, int n3) {
/* 131 */     if (this.mouseOver && this.parent.extended && n == 259) {
/* 132 */       this.setting.getValue(this.setting.getDefaultValue());
/*     */     }
/* 134 */     super.keyPressed(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {
/* 139 */     if (isHovered(n, n2) && n3 == 0) {
/* 140 */       this.dragging = true;
/* 141 */       slide(n);
/*     */     } 
/* 143 */     super.mouseClicked(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseReleased(double n, double n2, int n3) {
/* 148 */     if (this.dragging && n3 == 0) {
/* 149 */       this.dragging = false;
/*     */     }
/* 151 */     super.mouseReleased(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseDragged(double n, double n2, int n3, double n4, double n5) {
/* 156 */     if (this.dragging) {
/* 157 */       slide(n);
/*     */     }
/* 159 */     super.mouseDragged(n, n2, n3, n4, n5);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\NumberBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */