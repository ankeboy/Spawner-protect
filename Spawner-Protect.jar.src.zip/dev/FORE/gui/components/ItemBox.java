/*    */ package dev.FORE.gui.components;
/*    */ 
/*    */ import dev.FORE.gui.Component;
/*    */ import dev.FORE.module.setting.ItemSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.ColorUtil;
/*    */ import dev.FORE.utils.MathUtil;
/*    */ import dev.FORE.utils.RenderUtils;
/*    */ import dev.FORE.utils.TextRenderer;
/*    */ import dev.FORE.utils.Utils;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_1935;
/*    */ import net.minecraft.class_332;
/*    */ 
/*    */ public class ItemBox extends Component {
/*    */   private final ItemSetting setting;
/*    */   private float hoverAnimation;
/*    */   private Color currentColor;
/*    */   private final Color TEXT_COLOR;
/*    */   private final Color HOVER_COLOR;
/*    */   private final Color ITEM_BG;
/*    */   private final Color ITEM_BORDER;
/* 26 */   private final float CORNER_RADIUS = 4.0F;
/* 27 */   private final float HOVER_ANIMATION_SPEED = 0.25F;
/*    */   
/*    */   public ItemBox(ModuleButton moduleButton, Setting setting, int n) {
/* 30 */     super(moduleButton, setting, n);
/* 31 */     this.hoverAnimation = 0.0F;
/* 32 */     this.TEXT_COLOR = new Color(230, 230, 230);
/* 33 */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/* 34 */     this.ITEM_BG = new Color(30, 30, 35);
/* 35 */     this.ITEM_BORDER = new Color(60, 60, 65);
/* 36 */     this.setting = (ItemSetting)setting;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 41 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/* 42 */     if (this.currentColor == null) {
/* 43 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*    */     } else {
/* 45 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor.getAlpha());
/*    */     } 
/* 47 */     if (this.currentColor.getAlpha() != 255) {
/* 48 */       this.currentColor = ColorUtil.a(0.05F, 255, this.currentColor);
/*    */     }
/* 50 */     super.onUpdate();
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(class_332 drawContext, int n, int n2, float n3) {
/* 55 */     super.render(drawContext, n, n2, n3);
/* 56 */     updateAnimations(n, n2, n3);
/* 57 */     if (!this.parent.parent.dragging) {
/* 58 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR.getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*    */     }
/* 60 */     int n4 = parentX() + 5;
/* 61 */     int n5 = parentY() + parentOffset() + this.offset + parentHeight() / 2;
/* 62 */     TextRenderer.drawString(String.valueOf(this.setting.getName()), drawContext, n4, n5 - 8, this.TEXT_COLOR.getRGB());
/* 63 */     int n6 = n4 + TextRenderer.getWidth(String.valueOf(this.setting.getName()) + ": ") + 5;
/* 64 */     int n7 = n5 - 11;
/* 65 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.ITEM_BORDER, n6, n7, (n6 + 22), (n7 + 22), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/* 66 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.ITEM_BG, (n6 + 1), (n7 + 1), (n6 + 22 - 1), (n7 + 22 - 1), 3.5D, 3.5D, 3.5D, 3.5D, 50.0D);
/* 67 */     class_1792 a = this.setting.getItem();
/* 68 */     if (a != null && a != class_1802.field_8162) {
/* 69 */       drawContext.method_51427(new class_1799((class_1935)a), n6 + 3, n7 + 3);
/*    */     } else {
/* 71 */       TextRenderer.drawCenteredString("?", drawContext, n6 + 11 - 1, n7 + 4, (new Color(150, 150, 150, 200)).getRGB());
/*    */     } 
/*    */   }
/*    */   
/*    */   private void updateAnimations(int n, int n2, float n3) {
/*    */     float n4;
/* 77 */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/* 78 */       n4 = 1.0F;
/*    */     } else {
/* 80 */       n4 = 0.0F;
/*    */     } 
/* 82 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n4, 0.25D, (n3 * 0.05F));
/*    */   }
/*    */ 
/*    */   
/*    */   public void mouseClicked(double n, double n2, int n3) {
/* 87 */     if (isHovered(n, n2) && n3 == 0) {
/* 88 */       this.mc.method_1507(new ItemFilter(this, this.setting));
/*    */     }
/* 90 */     super.mouseClicked(n, n2, n3);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onGuiClose() {
/* 95 */     this.currentColor = null;
/* 96 */     this.hoverAnimation = 0.0F;
/* 97 */     super.onGuiClose();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\ItemBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */