/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.ItemsSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public class ItemsListBox
/*     */   extends Component
/*     */ {
/*     */   private final ItemsSetting setting;
/*     */   private float hoverAnimation;
/*     */   private Color currentColor;
/*     */   private final Color TEXT_COLOR;
/*     */   private final Color HOVER_COLOR;
/*     */   private boolean wasModuleEnabled;
/*     */   
/*     */   public ItemsListBox(ModuleButton moduleButton, Setting setting, int offset) {
/*  24 */     super(moduleButton, setting, offset);
/*  25 */     this.setting = (ItemsSetting)setting;
/*  26 */     this.hoverAnimation = 0.0F;
/*  27 */     this.TEXT_COLOR = new Color(230, 230, 230);
/*  28 */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  33 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*  34 */     if (this.currentColor == null) {
/*  35 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*     */     } else {
/*  37 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor.getAlpha());
/*     */     } 
/*     */     
/*  40 */     if (this.currentColor.getAlpha() != 255) {
/*  41 */       this.currentColor = ColorUtil.a(0.05F, 255, this.currentColor);
/*     */     }
/*  43 */     super.onUpdate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(class_332 drawContext, int mouseX, int mouseY, float partialTicks) {
/*  48 */     super.render(drawContext, mouseX, mouseY, partialTicks);
/*  49 */     updateAnimations(mouseX, mouseY, partialTicks);
/*     */     
/*  51 */     if (!this.parent.parent.dragging) {
/*  52 */       drawContext.method_25294(
/*  53 */           parentX(), 
/*  54 */           parentY() + parentOffset() + this.offset, 
/*  55 */           parentX() + parentWidth(), 
/*  56 */           parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR
/*  57 */             .getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), 
/*  58 */             (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*     */     }
/*     */ 
/*     */     
/*  62 */     int textX = parentX() + 5;
/*  63 */     int textY = parentY() + parentOffset() + this.offset + parentHeight() / 2;
/*     */     
/*  65 */     String label = String.valueOf(this.setting.getName()) + ": " + String.valueOf(this.setting.getName()) + " item" + this.setting.size();
/*  66 */     TextRenderer.drawString(label, drawContext, textX, textY - 4, this.TEXT_COLOR.getRGB());
/*     */   }
/*     */   
/*     */   private void updateAnimations(int mouseX, int mouseY, float partialTicks) {
/*  70 */     float target = (isHovered(mouseX, mouseY) && !this.parent.parent.dragging) ? 1.0F : 0.0F;
/*  71 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, target, 0.25D, (partialTicks * 0.05F));
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double mouseX, double mouseY, int button) {
/*  76 */     if (isHovered(mouseX, mouseY) && button == 0) {
/*     */       
/*  78 */       if (this.parent.module instanceof dev.FORE.module.modules.donut.ShearsToElytra && this.parent.module.isEnabled()) {
/*  79 */         this.wasModuleEnabled = true;
/*  80 */         this.parent.module.toggle(false);
/*     */       } else {
/*  82 */         this.wasModuleEnabled = false;
/*     */       } 
/*  84 */       this.mc.method_1507(new ItemsMultiFilter(this, this.setting));
/*     */     } 
/*  86 */     super.mouseClicked(mouseX, mouseY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onFilterGuiClose() {
/*  91 */     if (this.wasModuleEnabled && this.parent.module instanceof dev.FORE.module.modules.donut.ShearsToElytra) {
/*  92 */       this.parent.module.toggle(true);
/*  93 */       this.wasModuleEnabled = false;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onGuiClose() {
/*  99 */     this.currentColor = null;
/* 100 */     this.hoverAnimation = 0.0F;
/* 101 */     super.onGuiClose();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\ItemsListBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */