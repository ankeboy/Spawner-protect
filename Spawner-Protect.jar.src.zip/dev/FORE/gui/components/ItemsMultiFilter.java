/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.module.modules.client.DonutBBC;
/*     */ import dev.FORE.module.setting.ItemsSetting;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_7923;
/*     */ 
/*     */ public class ItemsMultiFilter
/*     */   extends class_437
/*     */ {
/*     */   private static final int PANEL_WIDTH = 600;
/*     */   private static final int PANEL_HEIGHT = 448;
/*     */   private static final int GRID_COLUMNS = 11;
/*     */   private static final int GRID_ROWS_VISIBLE = 6;
/*     */   private static final int ITEM_SLOT_SIZE = 40;
/*     */   private static final int ITEM_SLOT_SPACING = 8;
/*     */   private final ItemsSetting setting;
/*     */   private final Predicate<class_1792> filter;
/*     */   final ItemsListBox this$0;
/*     */   private final List<class_1792> allItems;
/*     */   private List<class_1792> filteredItems;
/*     */   private final Set<class_1792> selectedItems;
/*     */   private String searchQuery;
/*     */   private int scrollOffset;
/*     */   private boolean showingSelectedOnly;
/*     */   
/*     */   public ItemsMultiFilter(ItemsListBox parentBox, ItemsSetting setting) {
/*  45 */     super((class_2561)class_2561.method_43473());
/*  46 */     this.this$0 = parentBox;
/*  47 */     this.setting = setting;
/*  48 */     this.filter = setting.getFilter();
/*  49 */     this.searchQuery = "";
/*  50 */     this.scrollOffset = 0;
/*  51 */     this.showingSelectedOnly = false;
/*     */     
/*  53 */     this.selectedItems = new HashSet<>(setting.getItems());
/*  54 */     this.allItems = new ArrayList<>();
/*     */     
/*  56 */     class_7923.field_41178.forEach(item -> {
/*     */           if (item != null && (this.filter == null || this.filter.test(item))) {
/*     */             this.allItems.add(item);
/*     */           }
/*     */         });
/*     */     
/*  62 */     this.filteredItems = new ArrayList<>(this.allItems);
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
/*  67 */     RenderUtils.unscaledProjection();
/*     */     
/*  69 */     int scaledMouseX = (int)(mouseX * class_310.method_1551().method_22683().method_4495());
/*  70 */     int scaledMouseY = (int)(mouseY * class_310.method_1551().method_22683().method_4495());
/*     */     
/*  72 */     super.method_25394(drawContext, scaledMouseX, scaledMouseY, delta);
/*     */     
/*  74 */     int screenWidth = this.this$0.mc.method_22683().method_4480();
/*  75 */     int screenHeight = this.this$0.mc.method_22683().method_4507();
/*     */     
/*  77 */     int backgroundAlpha = DonutBBC.renderBackground.getValue() ? 180 : 0;
/*  78 */     drawContext.method_25294(0, 0, screenWidth, screenHeight, (new Color(0, 0, 0, backgroundAlpha)).getRGB());
/*     */     
/*  80 */     int panelX = (screenWidth - 600) / 2;
/*  81 */     int panelY = (screenHeight - 448) / 2;
/*     */     
/*  83 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(30, 30, 35, 240), panelX, panelY, (panelX + 600), (panelY + 448), 8.0D, 8.0D, 8.0D, 8.0D, 20.0D);
/*     */ 
/*     */     
/*  86 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), panelX, panelY, (panelX + 600), (panelY + 30), 8.0D, 8.0D, 0.0D, 0.0D, 20.0D);
/*     */     
/*  88 */     drawContext.method_25294(panelX, panelY + 30, panelX + 600, panelY + 31, Utils.getMainColor(255, 1).getRGB());
/*     */     
/*  90 */     TextRenderer.drawCenteredString("Select Items: " + String.valueOf(this.setting.getName()), drawContext, panelX + 300, panelY + 8, (new Color(245, 245, 245, 255))
/*     */         
/*  92 */         .getRGB());
/*     */     
/*  94 */     renderSearchBar(drawContext, panelX, panelY);
/*  95 */     renderSelectedCount(drawContext, panelX, panelY);
/*  96 */     renderItemsGrid(drawContext, panelX, panelY, scaledMouseX, scaledMouseY);
/*  97 */     renderButtons(drawContext, panelX, panelY, scaledMouseX, scaledMouseY);
/*     */     
/*  99 */     RenderUtils.scaledProjection();
/*     */   }
/*     */   
/*     */   private void renderSearchBar(class_332 drawContext, int panelX, int panelY) {
/* 103 */     int searchX = panelX + 20;
/* 104 */     int searchY = panelY + 50;
/* 105 */     int searchWidth = 360;
/* 106 */     int searchHeight = 30;
/*     */     
/* 108 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 255), searchX, searchY, (searchX + 360), (searchY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */ 
/*     */ 
/*     */     
/* 112 */     RenderUtils.renderRoundedOutline(drawContext, new Color(60, 60, 65, 255), searchX, searchY, (searchX + 360), (searchY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 1.0D, 20.0D);
/*     */ 
/*     */ 
/*     */     
/* 116 */     String cursor = (System.currentTimeMillis() % 1000L > 500L) ? "|" : "";
/* 117 */     TextRenderer.drawString("Search: " + this.searchQuery + cursor, drawContext, searchX + 10, searchY + 9, (new Color(200, 200, 200, 255))
/* 118 */         .getRGB());
/*     */   }
/*     */   
/*     */   private void renderSelectedCount(class_332 drawContext, int panelX, int panelY) {
/* 122 */     int countX = panelX + 20 + 360 + 20;
/* 123 */     int countY = panelY + 50;
/* 124 */     int countWidth = 180;
/* 125 */     int countHeight = 30;
/*     */     
/* 127 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 50, 255), countX, countY, (countX + 180), (countY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */ 
/*     */ 
/*     */     
/* 131 */     RenderUtils.renderRoundedOutline(drawContext, Utils.getMainColor(150, 1), countX, countY, (countX + 180), (countY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 1.0D, 20.0D);
/*     */ 
/*     */ 
/*     */     
/* 135 */     TextRenderer.drawCenteredString("Selected: " + this.selectedItems.size(), drawContext, countX + 90, countY + 9, 
/*     */         
/* 137 */         Utils.getMainColor(255, 1).getRGB());
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderItemsGrid(class_332 drawContext, int panelX, int panelY, int mouseX, int mouseY) {
/* 142 */     int gridX = panelX + 20;
/* 143 */     int gridY = panelY + 50 + 30 + 15;
/* 144 */     int gridWidth = 560;
/* 145 */     int gridHeight = 448 - gridY - panelY - 60;
/*     */     
/* 147 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(25, 25, 30, 255), gridX, gridY, (gridX + 560), (gridY + gridHeight), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 153 */     List<class_1792> displayItems = this.showingSelectedOnly ? new ArrayList<>(this.selectedItems) : this.filteredItems;
/*     */     
/* 155 */     int maxScroll = Math.max(0, (int)Math.ceil(displayItems.size() / 11.0D) - 6);
/* 156 */     this.scrollOffset = Math.min(this.scrollOffset, maxScroll);
/*     */     
/* 158 */     if ((int)Math.ceil(displayItems.size() / 11.0D) > 6) {
/* 159 */       int scrollbarX = gridX + 560 - 6 - 5;
/* 160 */       int scrollbarY = gridY + 5;
/* 161 */       int scrollbarHeight = gridHeight - 10;
/*     */       
/* 163 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 150), scrollbarX, scrollbarY, (scrollbarX + 6), (scrollbarY + scrollbarHeight), 3.0D, 3.0D, 3.0D, 3.0D, 20.0D);
/*     */ 
/*     */ 
/*     */       
/* 167 */       float progress = (maxScroll == 0) ? 0.0F : (this.scrollOffset / maxScroll);
/* 168 */       float sliderHeight = Math.max(40.0F, scrollbarHeight * 6.0F / (6 + maxScroll));
/* 169 */       int sliderY = scrollbarY + (int)((scrollbarHeight - sliderHeight) * progress);
/*     */       
/* 171 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), scrollbarX, sliderY, (scrollbarX + 6), (sliderY + sliderHeight), 3.0D, 3.0D, 3.0D, 3.0D, 20.0D);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 176 */     int startIndex = this.scrollOffset * 11;
/* 177 */     int endIndex = Math.min(displayItems.size(), startIndex + 66);
/*     */     
/* 179 */     for (int index = startIndex; index < endIndex; index++) {
/* 180 */       class_1792 item = displayItems.get(index);
/* 181 */       int column = (index - startIndex) % 11;
/* 182 */       int row = (index - startIndex) / 11;
/*     */       
/* 184 */       int slotX = gridX + 5 + column * 48;
/* 185 */       int slotY = gridY + 5 + row * 48;
/*     */       
/* 187 */       boolean selected = this.selectedItems.contains(item);
/* 188 */       Color slotColor = selected ? Utils.getMainColor(120, 1) : new Color(35, 35, 40, 255);
/*     */       
/* 190 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), slotColor, slotX, slotY, (slotX + 40), (slotY + 40), 4.0D, 4.0D, 4.0D, 4.0D, 20.0D);
/*     */ 
/*     */ 
/*     */       
/* 194 */       RenderUtils.drawItem(drawContext, new class_1799((class_1935)item), slotX, slotY, 40.0F, 0);
/*     */       
/* 196 */       if (selected) {
/* 197 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(200, 1), (slotX + 28), (slotY + 2), (slotX + 38), (slotY + 12), 2.0D, 2.0D, 2.0D, 2.0D, 20.0D);
/*     */ 
/*     */         
/* 200 */         TextRenderer.drawCenteredString("✓", drawContext, slotX + 33, slotY + 3, (new Color(255, 255, 255, 255))
/* 201 */             .getRGB());
/*     */       } 
/*     */       
/* 204 */       if (mouseX >= slotX && mouseX <= slotX + 40 && mouseY >= slotY && mouseY <= slotY + 40)
/*     */       {
/* 206 */         RenderUtils.renderRoundedOutline(drawContext, Utils.getMainColor(200, 1), slotX, slotY, (slotX + 40), (slotY + 40), 4.0D, 4.0D, 4.0D, 4.0D, 1.5D, 20.0D);
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 212 */     if (displayItems.isEmpty()) {
/* 213 */       String empty = this.showingSelectedOnly ? "No items selected" : "No items found";
/* 214 */       TextRenderer.drawCenteredString(empty, drawContext, gridX + 280, gridY + gridHeight / 2 - 10, (new Color(150, 150, 150, 200))
/*     */           
/* 216 */           .getRGB());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderButtons(class_332 drawContext, int panelX, int panelY, int mouseX, int mouseY) {
/* 222 */     int buttonY = panelY + 448 - 45;
/*     */     
/* 224 */     int saveX = panelX + 600 - 80 - 20;
/* 225 */     int cancelX = saveX - 90 - 10;
/* 226 */     int clearX = cancelX - 100 - 10;
/* 227 */     int toggleX = clearX - 90 - 10;
/*     */     
/* 229 */     renderButton(drawContext, saveX, buttonY, 80, 30, Utils.getMainColor(255, 1), "Save");
/* 230 */     renderButton(drawContext, cancelX, buttonY, 90, 30, new Color(60, 60, 65, 255), "Cancel");
/* 231 */     renderButton(drawContext, clearX, buttonY, 100, 30, new Color(70, 40, 40, 255), "Clear All");
/*     */     
/* 233 */     Color toggleColor = this.showingSelectedOnly ? Utils.getMainColor(200, 1) : new Color(50, 50, 60, 255);
/* 234 */     String toggleLabel = this.showingSelectedOnly ? "All Items" : "Selected";
/* 235 */     renderButton(drawContext, toggleX, buttonY, 90, 30, toggleColor, toggleLabel);
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderButton(class_332 drawContext, int x, int y, int width, int height, Color color, String label) {
/* 240 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), color, x, y, (x + width), (y + height), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 242 */     TextRenderer.drawCenteredString(label, drawContext, x + width / 2, y + 8, (new Color(245, 245, 245, 255))
/* 243 */         .getRGB());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 248 */     double scaledX = mouseX * class_310.method_1551().method_22683().method_4495();
/* 249 */     double scaledY = mouseY * class_310.method_1551().method_22683().method_4495();
/*     */     
/* 251 */     int screenWidth = this.this$0.mc.method_22683().method_4480();
/* 252 */     int screenHeight = this.this$0.mc.method_22683().method_4507();
/*     */     
/* 254 */     int panelX = (screenWidth - 600) / 2;
/* 255 */     int panelY = (screenHeight - 448) / 2;
/*     */     
/* 257 */     int saveX = panelX + 600 - 80 - 20;
/* 258 */     int cancelX = saveX - 90 - 10;
/* 259 */     int clearX = cancelX - 100 - 10;
/* 260 */     int toggleX = clearX - 90 - 10;
/* 261 */     int buttonY = panelY + 448 - 45;
/*     */     
/* 263 */     if (isInBounds(scaledX, scaledY, saveX, buttonY, 80, 30)) {
/* 264 */       applySelection();
/* 265 */       return true;
/*     */     } 
/*     */     
/* 268 */     if (isInBounds(scaledX, scaledY, cancelX, buttonY, 90, 30)) {
/* 269 */       closeWithoutSaving();
/* 270 */       return true;
/*     */     } 
/*     */     
/* 273 */     if (isInBounds(scaledX, scaledY, clearX, buttonY, 100, 30)) {
/* 274 */       this.selectedItems.clear();
/* 275 */       return true;
/*     */     } 
/*     */     
/* 278 */     if (isInBounds(scaledX, scaledY, toggleX, buttonY, 90, 30)) {
/* 279 */       this.showingSelectedOnly = !this.showingSelectedOnly;
/* 280 */       this.scrollOffset = 0;
/* 281 */       return true;
/*     */     } 
/*     */     
/* 284 */     if (handleGridClick(scaledX, scaledY, panelX, panelY)) {
/* 285 */       return true;
/*     */     }
/*     */     
/* 288 */     int selectedPanelX = panelX + 20 + 360 + 20;
/* 289 */     int selectedPanelY = panelY + 50;
/* 290 */     if (isInBounds(scaledX, scaledY, selectedPanelX, selectedPanelY, 180, 30)) {
/* 291 */       this.showingSelectedOnly = !this.showingSelectedOnly;
/* 292 */       this.scrollOffset = 0;
/* 293 */       return true;
/*     */     } 
/*     */     
/* 296 */     return super.method_25402(scaledX, scaledY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean handleGridClick(double mouseX, double mouseY, int panelX, int panelY) {
/* 301 */     int gridX = panelX + 20;
/* 302 */     int gridY = panelY + 50 + 30 + 15;
/* 303 */     int gridWidth = 560;
/* 304 */     int gridHeight = 448 - gridY - panelY - 60;
/*     */     
/* 306 */     if (!isInBounds(mouseX, mouseY, gridX, gridY, 560, gridHeight)) {
/* 307 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 312 */     List<class_1792> displayItems = this.showingSelectedOnly ? new ArrayList<>(this.selectedItems) : this.filteredItems;
/*     */     
/* 314 */     int column = (int)(mouseX - gridX - 5.0D) / 48;
/* 315 */     if (column < 0 || column >= 11) {
/* 316 */       return false;
/*     */     }
/*     */     
/* 319 */     int row = (int)(mouseY - gridY - 5.0D) / 48;
/* 320 */     int index = this.scrollOffset * 11 + row * 11 + column;
/*     */     
/* 322 */     if (index >= 0 && index < displayItems.size()) {
/* 323 */       class_1792 clicked = displayItems.get(index);
/* 324 */       if (this.selectedItems.contains(clicked)) {
/* 325 */         this.selectedItems.remove(clicked);
/*     */       } else {
/* 327 */         this.selectedItems.add(clicked);
/*     */       } 
/* 329 */       return true;
/*     */     } 
/*     */     
/* 332 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25401(double mouseX, double mouseY, double horizontal, double vertical) {
/* 337 */     double scaledX = mouseX * class_310.method_1551().method_22683().method_4495();
/* 338 */     double scaledY = mouseY * class_310.method_1551().method_22683().method_4495();
/*     */     
/* 340 */     int screenWidth = this.this$0.mc.method_22683().method_4480();
/* 341 */     int screenHeight = this.this$0.mc.method_22683().method_4507();
/*     */     
/* 343 */     int panelX = (screenWidth - 600) / 2;
/* 344 */     int panelY = (screenHeight - 448) / 2;
/*     */     
/* 346 */     int gridX = panelX + 20;
/* 347 */     int gridY = panelY + 50 + 30 + 15;
/* 348 */     int gridWidth = 560;
/* 349 */     int gridHeight = 448 - gridY - panelY - 60;
/*     */     
/* 351 */     if (isInBounds(scaledX, scaledY, gridX, gridY, 560, gridHeight)) {
/*     */ 
/*     */       
/* 354 */       List<class_1792> displayItems = this.showingSelectedOnly ? new ArrayList<>(this.selectedItems) : this.filteredItems;
/* 355 */       int maxScroll = Math.max(0, (int)Math.ceil(displayItems.size() / 11.0D) - 6);
/* 356 */       if (vertical > 0.0D) {
/* 357 */         this.scrollOffset = Math.max(0, this.scrollOffset - 1);
/* 358 */       } else if (vertical < 0.0D) {
/* 359 */         this.scrollOffset = Math.min(maxScroll, this.scrollOffset + 1);
/*     */       } 
/* 361 */       return true;
/*     */     } 
/* 363 */     return super.method_25401(scaledX, scaledY, horizontal, vertical);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
/* 368 */     if (keyCode == 256) {
/* 369 */       applySelection();
/* 370 */       return true;
/*     */     } 
/* 372 */     if (keyCode == 259) {
/* 373 */       if (!this.searchQuery.isEmpty()) {
/* 374 */         this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
/* 375 */         updateFilteredItems();
/*     */       } 
/* 377 */       return true;
/*     */     } 
/* 379 */     if (keyCode == 257) {
/* 380 */       applySelection();
/* 381 */       return true;
/*     */     } 
/* 383 */     if (keyCode == 265) {
/* 384 */       moveSelection(-11);
/* 385 */       return true;
/*     */     } 
/* 387 */     if (keyCode == 264) {
/* 388 */       moveSelection(11);
/* 389 */       return true;
/*     */     } 
/* 391 */     if (keyCode == 263) {
/* 392 */       moveSelection(-1);
/* 393 */       return true;
/*     */     } 
/* 395 */     if (keyCode == 262) {
/* 396 */       moveSelection(1);
/* 397 */       return true;
/*     */     } 
/* 399 */     return super.method_25404(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25400(char chr, int modifiers) {
/* 404 */     if (chr >= ' ' && chr != '') {
/* 405 */       this.searchQuery += this.searchQuery;
/* 406 */       updateFilteredItems();
/* 407 */       return true;
/*     */     } 
/* 409 */     return super.method_25400(chr, modifiers);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void moveSelection(int offset) {
/* 415 */     List<class_1792> displayItems = this.showingSelectedOnly ? new ArrayList<>(this.selectedItems) : this.filteredItems;
/*     */     
/* 417 */     if (displayItems.isEmpty()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 422 */     class_1792 last = this.selectedItems.isEmpty() ? null : this.selectedItems.iterator().next();
/* 423 */     int index = (last != null) ? displayItems.indexOf(last) : 0;
/* 424 */     if (index == -1) {
/* 425 */       index = 0;
/*     */     }
/*     */     
/* 428 */     index = Math.max(0, Math.min(displayItems.size() - 1, index + offset));
/* 429 */     class_1792 target = displayItems.get(index);
/* 430 */     if (this.selectedItems.contains(target)) {
/* 431 */       this.selectedItems.remove(target);
/*     */     } else {
/* 433 */       this.selectedItems.add(target);
/*     */     } 
/*     */     
/* 436 */     int targetRow = index / 11;
/* 437 */     if (targetRow < this.scrollOffset) {
/* 438 */       this.scrollOffset = targetRow;
/* 439 */     } else if (targetRow >= this.scrollOffset + 6) {
/* 440 */       this.scrollOffset = targetRow - 6 + 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateFilteredItems() {
/* 445 */     if (this.searchQuery.isEmpty()) {
/* 446 */       this.filteredItems = new ArrayList<>(this.allItems);
/*     */     } else {
/* 448 */       String lower = this.searchQuery.toLowerCase();
/* 449 */       this
/*     */         
/* 451 */         .filteredItems = (List<class_1792>)this.allItems.stream().filter(item -> item.method_7848().getString().toLowerCase().contains(lower)).collect(Collectors.toList());
/*     */     } 
/* 453 */     this.scrollOffset = 0;
/*     */   }
/*     */   
/*     */   private void applySelection() {
/* 457 */     this.setting.setItems(this.selectedItems);
/* 458 */     this.this$0.onFilterGuiClose();
/* 459 */     this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/*     */   }
/*     */   
/*     */   private void closeWithoutSaving() {
/* 463 */     this.this$0.onFilterGuiClose();
/* 464 */     this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/*     */   }
/*     */   
/*     */   private boolean isInBounds(double x, double y, int rectX, int rectY, int width, int height) {
/* 468 */     return (x >= rectX && x <= (rectX + width) && y >= rectY && y <= (rectY + height));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean method_25422() {
/* 478 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\ItemsMultiFilter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */