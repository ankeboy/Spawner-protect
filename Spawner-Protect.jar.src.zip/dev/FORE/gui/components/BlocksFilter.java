/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.module.modules.client.DonutBBC;
/*     */ import dev.FORE.module.setting.BlocksSetting;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_7923;
/*     */ 
/*     */ public class BlocksFilter extends class_437 {
/*     */   private final BlocksSetting setting;
/*     */   private String searchQuery;
/*     */   private final List<class_2248> allBlocks;
/*     */   private List<class_2248> filteredBlocks;
/*     */   private final Set<class_2248> selectedBlocks;
/*     */   private int scrollOffset;
/*  32 */   private final int BLOCKS_PER_ROW = 11;
/*  33 */   private final int MAX_ROWS_VISIBLE = 6;
/*  34 */   private final int BLOCK_SIZE = 40;
/*  35 */   private final int BLOCK_SPACING = 8;
/*     */   private boolean showingSelectedOnly = false;
/*     */   final BlocksBox this$0;
/*     */   
/*     */   public BlocksFilter(BlocksBox this$0, BlocksSetting setting) {
/*  40 */     super((class_2561)class_2561.method_43473());
/*  41 */     this.this$0 = this$0;
/*  42 */     this.searchQuery = "";
/*  43 */     this.scrollOffset = 0;
/*  44 */     this.setting = setting;
/*  45 */     this.selectedBlocks = new HashSet<>(setting.getBlocks());
/*  46 */     this.allBlocks = new ArrayList<>();
/*     */     
/*  48 */     class_7923.field_41175.forEach(block -> {
/*     */           if (block != class_2246.field_10124 && block.method_8389() instanceof net.minecraft.class_1747) {
/*     */             this.allBlocks.add(block);
/*     */           }
/*     */         });
/*     */     
/*  54 */     this.filteredBlocks = new ArrayList<>(this.allBlocks);
/*     */   }
/*     */   public void method_25394(class_332 drawContext, int n, int n2, float n3) {
/*     */     int a;
/*  58 */     RenderUtils.unscaledProjection();
/*  59 */     int n4 = n * (int)class_310.method_1551().method_22683().method_4495();
/*  60 */     int n5 = n2 * (int)class_310.method_1551().method_22683().method_4495();
/*  61 */     super.method_25394(drawContext, n4, n5, n3);
/*     */     
/*  63 */     int width = this.this$0.mc.method_22683().method_4480();
/*  64 */     int height = this.this$0.mc.method_22683().method_4507();
/*     */ 
/*     */     
/*  67 */     if (DonutBBC.renderBackground.getValue()) {
/*  68 */       a = 180;
/*     */     } else {
/*  70 */       a = 0;
/*     */     } 
/*  72 */     drawContext.method_25294(0, 0, width, height, (new Color(0, 0, 0, a)).getRGB());
/*     */     
/*  74 */     int panelX = (width - 600) / 2;
/*  75 */     int panelY = (height - 460) / 2;
/*     */ 
/*     */     
/*  78 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(30, 30, 35, 240), panelX, panelY, (panelX + 600), (panelY + 460), 8.0D, 8.0D, 8.0D, 8.0D, 20.0D);
/*     */ 
/*     */ 
/*     */     
/*  82 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), panelX, panelY, (panelX + 600), (panelY + 30), 8.0D, 8.0D, 0.0D, 0.0D, 20.0D);
/*     */     
/*  84 */     drawContext.method_25294(panelX, panelY + 30, panelX + 600, panelY + 31, Utils.getMainColor(255, 1).getRGB());
/*     */     
/*  86 */     TextRenderer.drawCenteredString("Select Blocks: " + String.valueOf(this.setting.getName()), drawContext, panelX + 300, panelY + 8, (new Color(245, 245, 245, 255))
/*  87 */         .getRGB());
/*     */ 
/*     */     
/*  90 */     int searchX = panelX + 20;
/*  91 */     int searchY = panelY + 50;
/*  92 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 255), searchX, searchY, (searchX + 360), (searchY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/*  94 */     RenderUtils.renderRoundedOutline(drawContext, new Color(60, 60, 65, 255), searchX, searchY, (searchX + 360), (searchY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 1.0D, 20.0D);
/*     */ 
/*     */     
/*  97 */     String searchQuery = this.searchQuery;
/*  98 */     String cursor = (System.currentTimeMillis() % 1000L > 500L) ? "|" : "";
/*  99 */     TextRenderer.drawString("Search: " + searchQuery + cursor, drawContext, searchX + 10, searchY + 9, (new Color(200, 200, 200, 255))
/* 100 */         .getRGB());
/*     */ 
/*     */     
/* 103 */     int selectedX = searchX + 360 + 20;
/* 104 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 50, 255), selectedX, searchY, (selectedX + 180), (searchY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 106 */     RenderUtils.renderRoundedOutline(drawContext, Utils.getMainColor(150, 1), selectedX, searchY, (selectedX + 180), (searchY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 1.0D, 20.0D);
/*     */ 
/*     */     
/* 109 */     TextRenderer.drawCenteredString("Selected: " + this.selectedBlocks.size(), drawContext, selectedX + 90, searchY + 9, 
/* 110 */         Utils.getMainColor(255, 1).getRGB());
/*     */ 
/*     */     
/* 113 */     int gridX = panelX + 20;
/* 114 */     int gridY = searchY + 30 + 15;
/* 115 */     int gridHeight = 530 - gridY - panelY - 142;
/* 116 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(25, 25, 30, 255), gridX, gridY, (gridX + 560), (gridY + gridHeight), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 121 */     List<class_2248> displayBlocks = this.showingSelectedOnly ? new ArrayList<>(this.selectedBlocks) : this.filteredBlocks;
/*     */     
/* 123 */     double totalRows = Math.ceil(displayBlocks.size() / 11.0D);
/* 124 */     int maxScroll = Math.max(0, (int)totalRows - 6);
/* 125 */     this.scrollOffset = Math.min(this.scrollOffset, maxScroll);
/*     */     
/* 127 */     if ((int)totalRows > 6) {
/* 128 */       int scrollbarX = gridX + 560 - 6 - 5;
/* 129 */       int scrollbarY = gridY + 5;
/* 130 */       int scrollbarHeight = gridHeight - 10;
/* 131 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 150), scrollbarX, scrollbarY, (scrollbarX + 6), (scrollbarY + scrollbarHeight), 3.0D, 3.0D, 3.0D, 3.0D, 20.0D);
/*     */ 
/*     */       
/* 134 */       float scrollPercent = this.scrollOffset / maxScroll;
/* 135 */       float thumbHeight = Math.max(40.0F, scrollbarHeight * 6.0F / (int)totalRows);
/* 136 */       int thumbY = scrollbarY + (int)((scrollbarHeight - thumbHeight) * scrollPercent);
/* 137 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), scrollbarX, thumbY, (scrollbarX + 6), (int)(thumbY + thumbHeight), 3.0D, 3.0D, 3.0D, 3.0D, 20.0D);
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 142 */     int startIndex = this.scrollOffset * 11;
/* 143 */     int endIndex = Math.min(startIndex + 66, displayBlocks.size());
/*     */     
/* 145 */     for (int i = startIndex; i < endIndex; i++) {
/* 146 */       int col = (i - startIndex) % 11;
/* 147 */       int row = (i - startIndex) / 11;
/* 148 */       int blockX = gridX + 5 + col * 48;
/* 149 */       int blockY = gridY + 5 + row * 48;
/*     */       
/* 151 */       class_2248 block = displayBlocks.get(i);
/* 152 */       boolean isSelected = this.selectedBlocks.contains(block);
/*     */       
/* 154 */       Color bgColor = isSelected ? Utils.getMainColor(120, 1) : new Color(35, 35, 40, 255);
/*     */       
/* 156 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), bgColor, blockX, blockY, (blockX + 40), (blockY + 40), 4.0D, 4.0D, 4.0D, 4.0D, 20.0D);
/*     */ 
/*     */       
/* 159 */       RenderUtils.drawItem(drawContext, new class_1799((class_1935)block.method_8389()), blockX, blockY, 40.0F, 0);
/*     */       
/* 161 */       if (isSelected) {
/*     */         
/* 163 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(200, 1), (blockX + 28), (blockY + 2), (blockX + 38), (blockY + 12), 2.0D, 2.0D, 2.0D, 2.0D, 20.0D);
/*     */         
/* 165 */         TextRenderer.drawCenteredString("✓", drawContext, blockX + 33, blockY + 3, (new Color(255, 255, 255, 255))
/* 166 */             .getRGB());
/*     */       } 
/*     */       
/* 169 */       if (n4 >= blockX && n4 <= blockX + 40 && n5 >= blockY && n5 <= blockY + 40) {
/* 170 */         RenderUtils.renderRoundedOutline(drawContext, Utils.getMainColor(200, 1), blockX, blockY, (blockX + 40), (blockY + 40), 4.0D, 4.0D, 4.0D, 4.0D, 1.5D, 20.0D);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 175 */     if (displayBlocks.isEmpty()) {
/* 176 */       String emptyText = this.showingSelectedOnly ? "No blocks selected" : "No blocks found";
/* 177 */       TextRenderer.drawCenteredString(emptyText, drawContext, gridX + 280, gridY + gridHeight / 2 - 10, (new Color(150, 150, 150, 200))
/* 178 */           .getRGB());
/*     */     } 
/*     */ 
/*     */     
/* 182 */     int buttonsY = gridY + gridHeight + 15;
/* 183 */     int saveX = panelX + 600 - 80 - 20;
/* 184 */     int cancelX = saveX - 90 - 10;
/* 185 */     int clearX = cancelX - 100 - 10;
/* 186 */     int backX = clearX - 80 - 10;
/*     */ 
/*     */     
/* 189 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), saveX, buttonsY, (saveX + 80), (buttonsY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 191 */     TextRenderer.drawCenteredString("Save", drawContext, saveX + 40, buttonsY + 8, (new Color(245, 245, 245, 255))
/* 192 */         .getRGB());
/*     */ 
/*     */     
/* 195 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(60, 60, 65, 255), cancelX, buttonsY, (cancelX + 90), (buttonsY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 197 */     TextRenderer.drawCenteredString("Cancel", drawContext, cancelX + 45, buttonsY + 8, (new Color(245, 245, 245, 255))
/* 198 */         .getRGB());
/*     */ 
/*     */     
/* 201 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(70, 40, 40, 255), clearX, buttonsY, (clearX + 100), (buttonsY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 203 */     TextRenderer.drawCenteredString("Clear All", drawContext, clearX + 50, buttonsY + 8, (new Color(245, 245, 245, 255))
/* 204 */         .getRGB());
/*     */ 
/*     */     
/* 207 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), 
/* 208 */         this.showingSelectedOnly ? Utils.getMainColor(200, 1) : new Color(50, 50, 60, 255), backX, buttonsY, (backX + 80), (buttonsY + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 210 */     TextRenderer.drawCenteredString(this.showingSelectedOnly ? "Back" : "Selected", drawContext, backX + 40, buttonsY + 8, (new Color(245, 245, 245, 255))
/* 211 */         .getRGB());
/*     */     
/* 213 */     RenderUtils.scaledProjection();
/*     */   }
/*     */   
/*     */   public boolean method_25402(double n, double n2, int n3) {
/* 217 */     double mouseX = n * class_310.method_1551().method_22683().method_4495();
/* 218 */     double mouseY = n2 * class_310.method_1551().method_22683().method_4495();
/*     */     
/* 220 */     int width = this.this$0.mc.method_22683().method_4480();
/* 221 */     int height = this.this$0.mc.method_22683().method_4507();
/*     */     
/* 223 */     int panelX = (width - 600) / 2;
/* 224 */     int panelY = (height - 460) / 2;
/*     */ 
/*     */     
/* 227 */     int searchX = panelX + 20;
/* 228 */     int searchY = panelY + 50;
/* 229 */     int selectedX = searchX + 360 + 20;
/* 230 */     int gridX = panelX + 20;
/* 231 */     int gridY = searchY + 30 + 15;
/* 232 */     int gridHeight = 530 - gridY - panelY - 142;
/* 233 */     int buttonsY = gridY + gridHeight + 15;
/*     */     
/* 235 */     int saveX = panelX + 600 - 80 - 20;
/* 236 */     int cancelX = saveX - 90 - 10;
/* 237 */     int clearX = cancelX - 100 - 10;
/* 238 */     int backX = clearX - 80 - 10;
/*     */ 
/*     */     
/* 241 */     if (isInBounds(mouseX, mouseY, selectedX, searchY, 180, 30)) {
/* 242 */       this.showingSelectedOnly = !this.showingSelectedOnly;
/* 243 */       this.scrollOffset = 0;
/* 244 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 248 */     if (isInBounds(mouseX, mouseY, saveX, buttonsY, 80, 30)) {
/* 249 */       this.setting.setBlocks(this.selectedBlocks);
/* 250 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 251 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 255 */     if (isInBounds(mouseX, mouseY, cancelX, buttonsY, 90, 30)) {
/* 256 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 257 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 261 */     if (isInBounds(mouseX, mouseY, clearX, buttonsY, 100, 30)) {
/* 262 */       this.selectedBlocks.clear();
/* 263 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 267 */     if (isInBounds(mouseX, mouseY, backX, buttonsY, 80, 30)) {
/* 268 */       this.showingSelectedOnly = !this.showingSelectedOnly;
/* 269 */       this.scrollOffset = 0;
/* 270 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 274 */     if (isInBounds(mouseX, mouseY, gridX, gridY, 560, gridHeight)) {
/*     */       
/* 276 */       List<class_2248> displayBlocks = this.showingSelectedOnly ? new ArrayList<>(this.selectedBlocks) : this.filteredBlocks;
/*     */       
/* 278 */       int relativeX = (int)(mouseX - gridX - 5.0D);
/* 279 */       int relativeY = (int)(mouseY - gridY - 5.0D);
/*     */       
/* 281 */       int col = relativeX / 48;
/* 282 */       int row = relativeY / 48;
/*     */       
/* 284 */       if (col >= 0 && col < 11 && row >= 0 && row < 6) {
/* 285 */         int blockIndex = this.scrollOffset * 11 + row * 11 + col;
/* 286 */         if (blockIndex >= 0 && blockIndex < displayBlocks.size()) {
/* 287 */           class_2248 clickedBlock = displayBlocks.get(blockIndex);
/* 288 */           if (this.selectedBlocks.contains(clickedBlock)) {
/* 289 */             this.selectedBlocks.remove(clickedBlock);
/*     */           } else {
/* 291 */             this.selectedBlocks.add(clickedBlock);
/*     */           } 
/* 293 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 298 */     return super.method_25402(mouseX, mouseY, n3);
/*     */   }
/*     */   
/*     */   public boolean method_25401(double n, double n2, double n3, double n4) {
/* 302 */     double mouseX = n * class_310.method_1551().method_22683().method_4495();
/* 303 */     double mouseY = n2 * class_310.method_1551().method_22683().method_4495();
/*     */     
/* 305 */     int width = this.this$0.mc.method_22683().method_4480();
/* 306 */     int height = this.this$0.mc.method_22683().method_4507();
/*     */     
/* 308 */     int panelX = (width - 600) / 2;
/* 309 */     int panelY = (height - 460) / 2;
/* 310 */     int searchY = panelY + 50;
/* 311 */     int gridX = panelX + 20;
/* 312 */     int gridY = searchY + 30 + 15;
/* 313 */     int gridHeight = 530 - gridY - panelY - 142;
/*     */     
/* 315 */     if (isInBounds(mouseX, mouseY, gridX, gridY, 560, gridHeight)) {
/*     */       
/* 317 */       List<class_2248> displayBlocks = this.showingSelectedOnly ? new ArrayList<>(this.selectedBlocks) : this.filteredBlocks;
/*     */       
/* 319 */       int maxScroll = Math.max(0, (int)Math.ceil(displayBlocks.size() / 11.0D) - 6);
/* 320 */       if (n4 > 0.0D) {
/* 321 */         this.scrollOffset = Math.max(0, this.scrollOffset - 1);
/* 322 */       } else if (n4 < 0.0D) {
/* 323 */         this.scrollOffset = Math.min(maxScroll, this.scrollOffset + 1);
/*     */       } 
/* 325 */       return true;
/*     */     } 
/*     */     
/* 328 */     return super.method_25401(mouseX, mouseY, n3, n4);
/*     */   }
/*     */   
/*     */   public boolean method_25404(int n, int n2, int n3) {
/* 332 */     if (n == 256) {
/* 333 */       this.setting.setBlocks(this.selectedBlocks);
/* 334 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 335 */       return true;
/*     */     } 
/*     */     
/* 338 */     if (n == 259) {
/* 339 */       if (!this.searchQuery.isEmpty()) {
/* 340 */         this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
/* 341 */         updateFilteredBlocks();
/*     */       } 
/* 343 */       return true;
/*     */     } 
/*     */     
/* 346 */     if (n == 257) {
/* 347 */       this.setting.setBlocks(this.selectedBlocks);
/* 348 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 349 */       return true;
/*     */     } 
/*     */     
/* 352 */     return super.method_25404(n, n2, n3);
/*     */   }
/*     */   
/*     */   public boolean method_25400(char c, int n) {
/* 356 */     this.searchQuery += this.searchQuery;
/* 357 */     updateFilteredBlocks();
/* 358 */     return true;
/*     */   }
/*     */   
/*     */   private void updateFilteredBlocks() {
/* 362 */     if (this.searchQuery.isEmpty()) {
/* 363 */       this.filteredBlocks = new ArrayList<>(this.allBlocks);
/*     */     } else {
/* 365 */       this
/*     */ 
/*     */         
/* 368 */         .filteredBlocks = (List<class_2248>)this.allBlocks.stream().filter(block -> block.method_9518().getString().toLowerCase().contains(this.searchQuery.toLowerCase())).collect(Collectors.toList());
/*     */     } 
/* 370 */     this.scrollOffset = 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isInBounds(double mouseX, double mouseY, int x, int y, int width, int height) {
/* 375 */     return (mouseX >= x && mouseX <= (x + width) && mouseY >= y && mouseY <= (y + height));
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25420(class_332 drawContext, int n, int n2, float n3) {}
/*     */   
/*     */   public boolean method_25422() {
/* 382 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\BlocksFilter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */