/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.ModeSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public final class ModeBox
/*     */   extends Component {
/*     */   private final ModeSetting<?> setting;
/*     */   private float hoverAnimation;
/*     */   private float selectAnimation;
/*     */   private float previousSelectAnimation;
/*     */   private boolean wasClicked;
/*     */   public Color currentColor;
/*     */   private final Color TEXT_COLOR;
/*     */   private final Color HOVER_COLOR;
/*     */   private final Color SELECTOR_BG;
/*  25 */   private final float SELECTOR_HEIGHT = 4.0F;
/*  26 */   private final float SELECTOR_RADIUS = 2.0F;
/*  27 */   private final float HOVER_ANIMATION_SPEED = 0.25F;
/*  28 */   private final float SELECT_ANIMATION_SPEED = 0.15F;
/*     */   
/*     */   public ModeBox(ModuleButton moduleButton, Setting setting, int n) {
/*  31 */     super(moduleButton, setting, n);
/*  32 */     this.hoverAnimation = 0.0F;
/*  33 */     this.selectAnimation = 0.0F;
/*  34 */     this.previousSelectAnimation = 0.0F;
/*  35 */     this.wasClicked = false;
/*  36 */     this.TEXT_COLOR = new Color(230, 230, 230);
/*  37 */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/*  38 */     this.SELECTOR_BG = new Color(40, 40, 45);
/*  39 */     this.setting = (ModeSetting)setting;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  44 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*  45 */     if (this.currentColor == null) {
/*  46 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*     */     } else {
/*  48 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor.getAlpha());
/*     */     } 
/*  50 */     if (this.currentColor.getAlpha() != 255) {
/*  51 */       this.currentColor = ColorUtil.a(0.05F, 255, this.currentColor);
/*     */     }
/*  53 */     super.onUpdate();
/*     */   }
/*     */   
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*     */     float n12;
/*  58 */     super.render(drawContext, n, n2, n3);
/*  59 */     updateAnimations(n, n2, n3);
/*  60 */     int index = this.setting.getPossibleValues().indexOf(this.setting.getValue());
/*  61 */     int size = this.setting.getPossibleValues().size();
/*  62 */     parentWidth();
/*  63 */     parentX();
/*  64 */     if (!this.parent.parent.dragging) {
/*  65 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR.getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*     */     }
/*  67 */     TextRenderer.drawString(String.valueOf(this.setting.getName()), drawContext, parentX() + 5, parentY() + parentOffset() + this.offset + 9, this.TEXT_COLOR.getRGB());
/*  68 */     TextRenderer.drawString(this.setting.getValue().name(), drawContext, parentX() + TextRenderer.getWidth(String.valueOf(this.setting.getName()) + ": ") + 8, parentY() + parentOffset() + this.offset + 9, this.currentColor.getRGB());
/*  69 */     int n4 = parentY() + this.offset + parentOffset() + 25;
/*  70 */     int n5 = parentX() + 5;
/*  71 */     int n6 = parentWidth() - 10;
/*  72 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.SELECTOR_BG, n5, n4, (n5 + n6), (n4 + 4.0F), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
/*  73 */     int n7 = index - 1;
/*  74 */     float n8 = n7;
/*  75 */     if (n7 < 0.0F) {
/*  76 */       n8 = (size - 1);
/*     */     }
/*  78 */     int n9 = index + 1;
/*  79 */     float n10 = n9;
/*  80 */     if (n9 >= size) {
/*  81 */       n10 = 0.0F;
/*     */     }
/*  83 */     int n11 = n6 / size;
/*     */     
/*  85 */     if (this.previousSelectAnimation > 0.01F) {
/*  86 */       n12 = (float)MathUtil.linearInterpolate((n5 + n8 * n11), (n5 + index * n11), (1.0F - this.previousSelectAnimation));
/*  87 */     } else if (this.selectAnimation > 0.01F) {
/*  88 */       n12 = (float)MathUtil.linearInterpolate((n5 + index * n11), (n5 + n10 * n11), this.selectAnimation);
/*     */     } else {
/*  90 */       n12 = n5 + index * n11;
/*     */     } 
/*  92 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.currentColor, n12, n4, (n12 + n11), (n4 + 4.0F), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
/*  93 */     int n13 = parentY() + parentOffset() + this.offset + 9;
/*  94 */     int parentX = parentX();
/*  95 */     int parentX2 = parentX();
/*  96 */     int parentWidth = parentWidth();
/*  97 */     TextRenderer.drawString("◄", drawContext, parentX + parentWidth() - 25, n13, this.TEXT_COLOR.getRGB());
/*  98 */     TextRenderer.drawString("►", drawContext, parentX2 + parentWidth - 12, n13, this.TEXT_COLOR.getRGB());
/*  99 */     if (this.wasClicked) {
/* 100 */       this.wasClicked = false;
/* 101 */       this.previousSelectAnimation = 0.0F;
/* 102 */       this.selectAnimation = 0.01F;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateAnimations(int n, int n2, float n3) {
/* 107 */     float n5, n4 = n3 * 0.05F;
/*     */     
/* 109 */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/* 110 */       n5 = 1.0F;
/*     */     } else {
/* 112 */       n5 = 0.0F;
/*     */     } 
/* 114 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n5, 0.25D, n4);
/* 115 */     if (this.selectAnimation > 0.01F) {
/* 116 */       this.selectAnimation = (float)MathUtil.exponentialInterpolate(this.selectAnimation, 0.0D, 0.15000000596046448D, n4);
/* 117 */       if (this.selectAnimation < 0.01F) {
/* 118 */         this.previousSelectAnimation = 0.99F;
/*     */       }
/*     */     } 
/* 121 */     if (this.previousSelectAnimation > 0.01F) {
/* 122 */       this.previousSelectAnimation = (float)MathUtil.exponentialInterpolate(this.previousSelectAnimation, 0.0D, 0.15000000596046448D, n4);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyPressed(int n, int n2, int n3) {
/* 128 */     if (this.mouseOver && this.parent.extended) {
/* 129 */       if (n == 259) {
/* 130 */         this.setting.setModeIndex(this.setting.getOriginalValue());
/* 131 */       } else if (n == 262) {
/* 132 */         cycleModeForward();
/* 133 */       } else if (n == 263) {
/* 134 */         cycleModeBackward();
/*     */       } 
/*     */     }
/* 137 */     super.keyPressed(n, n2, n3);
/*     */   }
/*     */   
/*     */   private void cycleModeForward() {
/* 141 */     this.setting.cycleUp();
/* 142 */     this.wasClicked = true;
/*     */   }
/*     */   
/*     */   private void cycleModeBackward() {
/* 146 */     this.setting.cycleDown();
/* 147 */     this.wasClicked = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {
/* 152 */     if (isHovered(n, n2)) {
/* 153 */       if (n3 == 0) {
/* 154 */         cycleModeForward();
/* 155 */       } else if (n3 == 1) {
/* 156 */         cycleModeBackward();
/* 157 */       } else if (n3 == 2) {
/* 158 */         this.setting.setModeIndex(this.setting.getOriginalValue());
/*     */       } 
/*     */     }
/* 161 */     super.mouseClicked(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onGuiClose() {
/* 166 */     this.currentColor = null;
/* 167 */     this.hoverAnimation = 0.0F;
/* 168 */     this.selectAnimation = 0.0F;
/* 169 */     this.previousSelectAnimation = 0.0F;
/* 170 */     super.onGuiClose();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\ModeBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */