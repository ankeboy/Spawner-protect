/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.module.modules.client.DonutBBC;
/*     */ import dev.FORE.module.setting.FriendsSetting;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ 
/*     */ public class FriendsFilter extends class_437 {
/*     */   private final FriendsSetting setting;
/*     */   private final List<String> friendsList;
/*     */   private String inputText;
/*     */   private int scrollOffset;
/*     */   private int selectedIndex;
/*     */   private boolean isTyping;
/*     */   final FriendsBox this$0;
/*     */   
/*     */   public FriendsFilter(FriendsBox this$0, FriendsSetting setting) {
/*  27 */     super((class_2561)class_2561.method_43473());
/*  28 */     this.this$0 = this$0;
/*  29 */     this.inputText = "";
/*  30 */     this.scrollOffset = 0;
/*  31 */     this.selectedIndex = -1;
/*  32 */     this.isTyping = false;
/*  33 */     this.setting = setting;
/*  34 */     this.friendsList = new ArrayList<>(setting.getFriends());
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25394(class_332 drawContext, int mouseX, int mouseY, float delta) {
/*  39 */     RenderUtils.unscaledProjection();
/*  40 */     int scaledMouseX = mouseX * (int)class_310.method_1551().method_22683().method_4495();
/*  41 */     int scaledMouseY = mouseY * (int)class_310.method_1551().method_22683().method_4495();
/*     */     
/*  43 */     super.method_25394(drawContext, scaledMouseX, scaledMouseY, delta);
/*     */     
/*  45 */     int screenWidth = this.this$0.mc.method_22683().method_4480();
/*  46 */     int screenHeight = this.this$0.mc.method_22683().method_4507();
/*     */ 
/*     */     
/*  49 */     int bgAlpha = DonutBBC.renderBackground.getValue() ? 180 : 0;
/*  50 */     drawContext.method_25294(0, 0, screenWidth, screenHeight, (new Color(0, 0, 0, bgAlpha)).getRGB());
/*     */     
/*  52 */     int panelWidth = 500;
/*  53 */     int panelHeight = 450;
/*  54 */     int panelX = (screenWidth - 500) / 2;
/*  55 */     int panelY = (screenHeight - 450) / 2;
/*     */ 
/*     */     
/*  58 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(30, 30, 35, 240), panelX, panelY, (panelX + 500), (panelY + 450), 8.0D, 8.0D, 8.0D, 8.0D, 20.0D);
/*     */ 
/*     */ 
/*     */     
/*  62 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), panelX, panelY, (panelX + 500), (panelY + 40), 8.0D, 8.0D, 0.0D, 0.0D, 20.0D);
/*     */     
/*  64 */     drawContext.method_25294(panelX, panelY + 40, panelX + 500, panelY + 41, 
/*  65 */         Utils.getMainColor(255, 1).getRGB());
/*     */     
/*  67 */     TextRenderer.drawCenteredString("FRIENDS LIST", drawContext, panelX + 250, panelY + 12, (new Color(245, 245, 245, 255))
/*  68 */         .getRGB());
/*     */ 
/*     */     
/*  71 */     int inputX = panelX + 20;
/*  72 */     int inputY = panelY + 60;
/*  73 */     int inputWidth = 380;
/*     */     
/*  75 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 255), inputX, inputY, (inputX + 380), (inputY + 35), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/*  77 */     RenderUtils.renderRoundedOutline(drawContext, 
/*  78 */         this.isTyping ? Utils.getMainColor(150, 1) : new Color(60, 60, 65, 255), inputX, inputY, (inputX + 380), (inputY + 35), 5.0D, 5.0D, 5.0D, 5.0D, 1.5D, 20.0D);
/*     */ 
/*     */     
/*  81 */     String displayText = this.inputText;
/*  82 */     if (this.isTyping && System.currentTimeMillis() % 1000L > 500L) {
/*  83 */       displayText = displayText + "|";
/*     */     }
/*     */     
/*  86 */     String placeholder = (this.inputText.isEmpty() && !this.isTyping) ? "Player Name" : displayText;
/*  87 */     Color textColor = (this.inputText.isEmpty() && !this.isTyping) ? new Color(120, 120, 120, 200) : new Color(200, 200, 200, 255);
/*     */     
/*  89 */     if (TextRenderer.getWidth(placeholder) > 360) {
/*  90 */       while (TextRenderer.getWidth(placeholder) > 360 && placeholder.length() > 0) {
/*  91 */         placeholder = placeholder.substring(0, placeholder.length() - 1);
/*     */       }
/*     */     }
/*  94 */     TextRenderer.drawString(placeholder, drawContext, inputX + 10, inputY + 12, textColor.getRGB());
/*     */ 
/*     */     
/*  97 */     int addBtnX = inputX + 380 + 10;
/*  98 */     boolean addHovered = isInBounds(scaledMouseX, scaledMouseY, addBtnX, inputY, 70, 35);
/*  99 */     Color addBtnColor = addHovered ? Utils.getMainColor(255, 1) : Utils.getMainColor(200, 1);
/*     */     
/* 101 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), addBtnColor, addBtnX, inputY, (addBtnX + 70), (inputY + 35), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 103 */     TextRenderer.drawCenteredString("ADD ITEM", drawContext, addBtnX + 35, inputY + 12, (new Color(245, 245, 245, 255))
/* 104 */         .getRGB());
/*     */ 
/*     */     
/* 107 */     int listX = panelX + 20;
/* 108 */     int listY = inputY + 50;
/* 109 */     int listWidth = 460;
/* 110 */     int listHeight = 230;
/*     */     
/* 112 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(25, 25, 30, 255), listX, listY, (listX + 460), (listY + 230), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */ 
/*     */ 
/*     */     
/* 116 */     int itemY = listY + 10;
/* 117 */     int itemHeight = 40;
/* 118 */     int visibleItems = 5;
/*     */     
/* 120 */     if (this.friendsList.isEmpty()) {
/* 121 */       TextRenderer.drawCenteredString("No friends added yet", drawContext, listX + 230, listY + 115 - 10, (new Color(150, 150, 150, 200))
/*     */           
/* 123 */           .getRGB());
/*     */     } else {
/* 125 */       int startIndex = Math.max(0, this.scrollOffset);
/* 126 */       int endIndex = Math.min(this.friendsList.size(), startIndex + 5);
/*     */       
/* 128 */       for (int i = startIndex; i < endIndex; i++) {
/* 129 */         String friendName = this.friendsList.get(i);
/* 130 */         int itemX = listX + 10;
/* 131 */         int currentItemY = itemY + (i - startIndex) * 40;
/*     */         
/* 133 */         boolean isHovered = isInBounds(scaledMouseX, scaledMouseY, itemX, currentItemY, 440, 35);
/*     */         
/* 135 */         boolean isSelected = (i == this.selectedIndex);
/*     */ 
/*     */         
/* 138 */         Color itemBg = isSelected ? Utils.getMainColor(80, 1) : (isHovered ? new Color(35, 35, 40, 200) : new Color(30, 30, 35, 150));
/*     */         
/* 140 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), itemBg, itemX, currentItemY, (itemX + 460 - 20), (currentItemY + 40 - 5), 4.0D, 4.0D, 4.0D, 4.0D, 20.0D);
/*     */ 
/*     */ 
/*     */         
/* 144 */         TextRenderer.drawString(friendName, drawContext, itemX + 10, currentItemY + 13, (new Color(230, 230, 230, 255))
/* 145 */             .getRGB());
/*     */ 
/*     */         
/* 148 */         int removeBtnX = itemX + 460 - 55;
/* 149 */         int removeBtnY = currentItemY + 7;
/* 150 */         boolean removeHovered = isInBounds(scaledMouseX, scaledMouseY, removeBtnX, removeBtnY, 25, 25);
/*     */ 
/*     */         
/* 153 */         Color removeBg = removeHovered ? new Color(239, 68, 68, 150) : new Color(60, 60, 70, 100);
/* 154 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), removeBg, removeBtnX, removeBtnY, (removeBtnX + 25), (removeBtnY + 25), 4.0D, 4.0D, 4.0D, 4.0D, 20.0D);
/*     */         
/* 156 */         TextRenderer.drawCenteredString("✕", drawContext, removeBtnX + 12, removeBtnY + 6, (new Color(245, 245, 245, 255))
/* 157 */             .getRGB());
/*     */       } 
/*     */ 
/*     */       
/* 161 */       if (this.friendsList.size() > 5) {
/* 162 */         int scrollbarX = listX + 460 - 8;
/* 163 */         int scrollbarY = listY + 5;
/* 164 */         int scrollbarHeight = 220;
/*     */         
/* 166 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 150), scrollbarX, scrollbarY, (scrollbarX + 6), (scrollbarY + 220), 3.0D, 3.0D, 3.0D, 3.0D, 20.0D);
/*     */ 
/*     */ 
/*     */         
/* 170 */         float scrollPercentage = this.scrollOffset / Math.max(1, this.friendsList.size() - 5);
/* 171 */         float thumbHeight = Math.max(40.0F, 220.0F * 5.0F / this.friendsList.size());
/* 172 */         int thumbY = scrollbarY + (int)((220.0F - thumbHeight) * scrollPercentage);
/*     */         
/* 174 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), scrollbarX, thumbY, (scrollbarX + 6), (thumbY + thumbHeight), 3.0D, 3.0D, 3.0D, 3.0D, 20.0D);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     int btnY = panelY + 450 - 50;
/* 182 */     int saveX = panelX + 500 - 90 - 20;
/* 183 */     int cancelX = saveX - 90 - 10;
/*     */ 
/*     */     
/* 186 */     boolean saveHovered = isInBounds(scaledMouseX, scaledMouseY, saveX, btnY, 90, 35);
/* 187 */     Color saveBg = saveHovered ? Utils.getMainColor(255, 1) : Utils.getMainColor(200, 1);
/* 188 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), saveBg, saveX, btnY, (saveX + 90), (btnY + 35), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 190 */     TextRenderer.drawCenteredString("SAVE", drawContext, saveX + 45, btnY + 12, (new Color(245, 245, 245, 255))
/* 191 */         .getRGB());
/*     */ 
/*     */     
/* 194 */     boolean cancelHovered = isInBounds(scaledMouseX, scaledMouseY, cancelX, btnY, 90, 35);
/* 195 */     Color cancelBg = cancelHovered ? new Color(70, 70, 75, 255) : new Color(60, 60, 65, 255);
/* 196 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), cancelBg, cancelX, btnY, (cancelX + 90), (btnY + 35), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*     */     
/* 198 */     TextRenderer.drawCenteredString("CANCEL", drawContext, cancelX + 45, btnY + 12, (new Color(245, 245, 245, 255))
/* 199 */         .getRGB());
/*     */     
/* 201 */     RenderUtils.scaledProjection();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 206 */     double scaledX = mouseX * class_310.method_1551().method_22683().method_4495();
/* 207 */     double scaledY = mouseY * class_310.method_1551().method_22683().method_4495();
/*     */     
/* 209 */     int screenWidth = this.this$0.mc.method_22683().method_4480();
/* 210 */     int screenHeight = this.this$0.mc.method_22683().method_4507();
/* 211 */     int panelWidth = 500;
/* 212 */     int panelHeight = 450;
/* 213 */     int panelX = (screenWidth - 500) / 2;
/* 214 */     int panelY = (screenHeight - 450) / 2;
/*     */ 
/*     */     
/* 217 */     int inputX = panelX + 20;
/* 218 */     int inputY = panelY + 60;
/* 219 */     int inputWidth = 380;
/*     */     
/* 221 */     if (isInBounds(scaledX, scaledY, inputX, inputY, 380, 35)) {
/* 222 */       this.isTyping = true;
/* 223 */       return true;
/*     */     } 
/* 225 */     this.isTyping = false;
/*     */ 
/*     */ 
/*     */     
/* 229 */     int addBtnX = inputX + 380 + 10;
/* 230 */     if (isInBounds(scaledX, scaledY, addBtnX, inputY, 70, 35)) {
/* 231 */       if (!this.inputText.trim().isEmpty()) {
/* 232 */         this.friendsList.add(this.inputText.trim());
/* 233 */         this.inputText = "";
/*     */       } 
/* 235 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 239 */     int listX = panelX + 20;
/* 240 */     int listY = inputY + 50;
/* 241 */     int listWidth = 460;
/* 242 */     int listHeight = 230;
/* 243 */     int itemHeight = 40;
/* 244 */     int visibleItems = 5;
/*     */     
/* 246 */     int itemY = listY + 10;
/* 247 */     int startIndex = Math.max(0, this.scrollOffset);
/* 248 */     int endIndex = Math.min(this.friendsList.size(), startIndex + 5);
/*     */     
/* 250 */     for (int i = startIndex; i < endIndex; i++) {
/* 251 */       int itemX = listX + 10;
/* 252 */       int currentItemY = itemY + (i - startIndex) * 40;
/*     */ 
/*     */       
/* 255 */       int removeBtnX = itemX + 460 - 55;
/* 256 */       int removeBtnY = currentItemY + 7;
/*     */       
/* 258 */       if (isInBounds(scaledX, scaledY, removeBtnX, removeBtnY, 25, 25)) {
/* 259 */         this.friendsList.remove(i);
/* 260 */         if (this.selectedIndex == i) { this.selectedIndex = -1; }
/* 261 */         else if (this.selectedIndex > i) { this.selectedIndex--; }
/* 262 */          return true;
/*     */       } 
/*     */ 
/*     */       
/* 266 */       if (isInBounds(scaledX, scaledY, itemX, currentItemY, 440, 35)) {
/* 267 */         this.selectedIndex = i;
/* 268 */         return true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 273 */     int btnY = panelY + 450 - 50;
/* 274 */     int saveX = panelX + 500 - 90 - 20;
/*     */     
/* 276 */     if (isInBounds(scaledX, scaledY, saveX, btnY, 90, 35)) {
/* 277 */       this.setting.setFriends(this.friendsList);
/* 278 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 279 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 283 */     int cancelX = saveX - 90 - 10;
/* 284 */     if (isInBounds(scaledX, scaledY, cancelX, btnY, 90, 35)) {
/* 285 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 286 */       return true;
/*     */     } 
/*     */     
/* 289 */     return super.method_25402(scaledX, scaledY, button);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
/* 294 */     double scaledX = mouseX * class_310.method_1551().method_22683().method_4495();
/* 295 */     double scaledY = mouseY * class_310.method_1551().method_22683().method_4495();
/*     */     
/* 297 */     int screenWidth = this.this$0.mc.method_22683().method_4480();
/* 298 */     int screenHeight = this.this$0.mc.method_22683().method_4507();
/* 299 */     int panelWidth = 500;
/* 300 */     int panelHeight = 450;
/* 301 */     int panelX = (screenWidth - 500) / 2;
/* 302 */     int panelY = (screenHeight - 450) / 2;
/*     */     
/* 304 */     int listX = panelX + 20;
/* 305 */     int listY = panelY + 110;
/* 306 */     int listWidth = 460;
/* 307 */     int listHeight = 230;
/*     */     
/* 309 */     if (isInBounds(scaledX, scaledY, listX, listY, 460, 230)) {
/* 310 */       int visibleItems = 5;
/* 311 */       int maxScroll = Math.max(0, this.friendsList.size() - 5);
/*     */       
/* 313 */       if (verticalAmount > 0.0D) {
/* 314 */         this.scrollOffset = Math.max(0, this.scrollOffset - 1);
/* 315 */       } else if (verticalAmount < 0.0D) {
/* 316 */         this.scrollOffset = Math.min(maxScroll, this.scrollOffset + 1);
/*     */       } 
/* 318 */       return true;
/*     */     } 
/*     */     
/* 321 */     return super.method_25401(scaledX, scaledY, horizontalAmount, verticalAmount);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
/* 326 */     if (keyCode == 256) {
/* 327 */       this.setting.setFriends(this.friendsList);
/* 328 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 329 */       return true;
/*     */     } 
/*     */     
/* 332 */     if (this.isTyping) {
/* 333 */       if (keyCode == 259) {
/* 334 */         if (!this.inputText.isEmpty()) {
/* 335 */           this.inputText = this.inputText.substring(0, this.inputText.length() - 1);
/*     */         }
/* 337 */         return true;
/*     */       } 
/*     */       
/* 340 */       if (keyCode == 257) {
/* 341 */         if (!this.inputText.trim().isEmpty()) {
/* 342 */           this.friendsList.add(this.inputText.trim());
/* 343 */           this.inputText = "";
/*     */         } 
/* 345 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 349 */     return super.method_25404(keyCode, scanCode, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean method_25400(char chr, int modifiers) {
/* 354 */     if (this.isTyping && !Character.isISOControl(chr)) {
/* 355 */       this.inputText += this.inputText;
/* 356 */       return true;
/*     */     } 
/* 358 */     return super.method_25400(chr, modifiers);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isInBounds(double x, double y, int boundX, int boundY, int width, int height) {
/* 363 */     return (x >= boundX && x <= (boundX + width) && y >= boundY && y <= (boundY + height));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void method_25420(class_332 drawContext, int n, int n2, float n3) {}
/*     */ 
/*     */   
/*     */   public boolean method_25422() {
/* 372 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\FriendsFilter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */