/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.module.modules.client.DonutBBC;
/*     */ import dev.FORE.module.setting.ItemSetting;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.stream.Collectors;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_7923;
/*     */ 
/*     */ public class ItemFilter
/*     */   extends class_437
/*     */ {
/*     */   private final ItemSetting setting;
/*     */   private String searchQuery;
/*  28 */   private final int ITEMS_PER_ROW = 11; private final List<class_1792> allItems; private List<class_1792> filteredItems; private int scrollOffset;
/*  29 */   private final int MAX_ROWS_VISIBLE = 6;
/*     */   private int selectedIndex;
/*  31 */   private final int ITEM_SIZE = 40;
/*  32 */   private final int ITEM_SPACING = 8;
/*     */   final ItemBox this$0;
/*     */   
/*     */   public ItemFilter(ItemBox this$0, ItemSetting setting) {
/*  36 */     super((class_2561)class_2561.method_43473());
/*  37 */     this.this$0 = this$0;
/*  38 */     this.searchQuery = "";
/*  39 */     this.scrollOffset = 0;
/*  40 */     this.selectedIndex = -1;
/*  41 */     this.setting = setting;
/*  42 */     this.allItems = new ArrayList<>();
/*  43 */     class_7923.field_41178.forEach(item -> {
/*     */           if (item != class_1802.field_8162) {
/*     */             this.allItems.add(item);
/*     */           }
/*     */         });
/*  48 */     this.filteredItems = new ArrayList<>(this.allItems);
/*  49 */     if (setting.getItem() != null && setting.getItem() != class_1802.field_8162)
/*  50 */       for (int i = 0; i < this.filteredItems.size(); i++) {
/*  51 */         if (this.filteredItems.get(i) == setting.getItem()) {
/*  52 */           this.selectedIndex = i;
/*     */           break;
/*     */         } 
/*     */       }  
/*     */   }
/*     */   public void method_25394(class_332 drawContext, int n, int n2, float n3) {
/*     */     int a;
/*     */     String s;
/*  60 */     RenderUtils.unscaledProjection();
/*  61 */     int n4 = n * (int)class_310.method_1551().method_22683().method_4495();
/*  62 */     int n5 = n2 * (int)class_310.method_1551().method_22683().method_4495();
/*  63 */     super.method_25394(drawContext, n4, n5, n3);
/*  64 */     int width = this.this$0.mc.method_22683().method_4480();
/*  65 */     int height = this.this$0.mc.method_22683().method_4507();
/*     */     
/*  67 */     if (DonutBBC.renderBackground.getValue()) {
/*  68 */       a = 180;
/*     */     } else {
/*  70 */       a = 0;
/*     */     } 
/*  72 */     drawContext.method_25294(0, 0, width, height, (new Color(0, 0, 0, a)).getRGB());
/*  73 */     int n6 = (this.this$0.mc.method_22683().method_4480() - 600) / 2;
/*  74 */     int n7 = (this.this$0.mc.method_22683().method_4507() - 500) / 2;
/*  75 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(30, 30, 35, 240), n6, n7, (n6 + 600), (n7 + 500), 8.0D, 8.0D, 8.0D, 8.0D, 20.0D);
/*  76 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), n6, n7, (n6 + 600), (n7 + 30), 8.0D, 8.0D, 0.0D, 0.0D, 20.0D);
/*  77 */     drawContext.method_25294(n6, n7 + 30, n6 + 600, n7 + 31, Utils.getMainColor(255, 1).getRGB());
/*  78 */     TextRenderer.drawCenteredString("Select Item: " + String.valueOf(this.setting.getName()), drawContext, n6 + 300, n7 + 8, (new Color(245, 245, 245, 255)).getRGB());
/*  79 */     int n8 = n6 + 20;
/*  80 */     int n9 = n7 + 50;
/*  81 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 255), n8, n9, (n8 + 560), (n9 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*  82 */     RenderUtils.renderRoundedOutline(drawContext, new Color(60, 60, 65, 255), n8, n9, (n8 + 560), (n9 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 1.0D, 20.0D);
/*  83 */     String searchQuery = this.searchQuery;
/*     */     
/*  85 */     if (System.currentTimeMillis() % 1000L > 500L) {
/*  86 */       s = "|";
/*     */     } else {
/*  88 */       s = "";
/*     */     } 
/*  90 */     TextRenderer.drawString("Search: " + searchQuery + s, drawContext, n8 + 10, n9 + 9, (new Color(200, 200, 200, 255)).getRGB());
/*  91 */     int n10 = n6 + 20;
/*  92 */     int n11 = n9 + 30 + 15;
/*  93 */     int n12 = 500 - n11 - n7 - 60;
/*  94 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(25, 25, 30, 255), n10, n11, (n10 + 560), (n11 + n12), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/*  95 */     double ceil = Math.ceil(this.filteredItems.size() / 11.0D);
/*  96 */     int max = Math.max(0, (int)ceil - 6);
/*  97 */     this.scrollOffset = Math.min(this.scrollOffset, max);
/*  98 */     if ((int)ceil > 6) {
/*  99 */       int n13 = n10 + 560 - 6 - 5;
/* 100 */       int n14 = n11 + 5;
/* 101 */       int n15 = n12 - 10;
/* 102 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 150), n13, n14, (n13 + 6), (n14 + n15), 3.0D, 3.0D, 3.0D, 3.0D, 20.0D);
/* 103 */       float n16 = this.scrollOffset / max;
/* 104 */       float max2 = Math.max(40.0F, n15 * 6.0F / (int)ceil);
/* 105 */       int n17 = n14 + (int)((n15 - max2) * n16);
/* 106 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), n13, n17, (n13 + 6), (n17 + max2), 3.0D, 3.0D, 3.0D, 3.0D, 20.0D);
/*     */     } 
/*     */     
/* 109 */     for (int i = this.scrollOffset * 11, n18 = i; i < Math.min(n18 + Math.min(this.filteredItems.size(), 66), this.filteredItems.size()); i++) {
/* 110 */       Color mainColor; int n19 = n10 + 5 + (i - n18) % 11 * 48;
/* 111 */       int n20 = n11 + 5 + (i - n18) / 11 * 48;
/*     */       
/* 113 */       if (i == this.selectedIndex) {
/* 114 */         mainColor = Utils.getMainColor(100, 1);
/*     */       } else {
/* 116 */         mainColor = new Color(35, 35, 40, 255);
/*     */       } 
/* 118 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), mainColor, n19, n20, (n19 + 40), (n20 + 40), 4.0D, 4.0D, 4.0D, 4.0D, 20.0D);
/* 119 */       RenderUtils.drawItem(drawContext, new class_1799((class_1935)this.filteredItems.get(i)), n19, n20, 40.0F, 0);
/* 120 */       if (n4 >= n19 && n4 <= n19 + 40 && n5 >= n20 && n5 <= n20 + 40) {
/* 121 */         RenderUtils.renderRoundedOutline(drawContext, Utils.getMainColor(200, 1), n19, n20, (n19 + 40), (n20 + 40), 4.0D, 4.0D, 4.0D, 4.0D, 1.0D, 20.0D);
/*     */       }
/*     */     } 
/* 124 */     if (this.filteredItems.isEmpty()) {
/* 125 */       TextRenderer.drawCenteredString("No items found", drawContext, n10 + 280, n11 + n12 / 2 - 10, (new Color(150, 150, 150, 200)).getRGB());
/*     */     }
/* 127 */     int n21 = n7 + 500 - 45;
/* 128 */     int n22 = n6 + 600 - 80 - 20;
/* 129 */     int n23 = n22 - 80 - 10;
/* 130 */     int n24 = n23 - 80 - 10;
/* 131 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), Utils.getMainColor(255, 1), n22, n21, (n22 + 80), (n21 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 132 */     TextRenderer.drawCenteredString("Save", drawContext, n22 + 40, n21 + 8, (new Color(245, 245, 245, 255)).getRGB());
/* 133 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(60, 60, 65, 255), n23, n21, (n23 + 80), (n21 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 134 */     TextRenderer.drawCenteredString("Cancel", drawContext, n23 + 40, n21 + 8, (new Color(245, 245, 245, 255)).getRGB());
/* 135 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(70, 40, 40, 255), n24, n21, (n24 + 80), (n21 + 30), 5.0D, 5.0D, 5.0D, 5.0D, 20.0D);
/* 136 */     TextRenderer.drawCenteredString("Reset", drawContext, n24 + 40, n21 + 8, (new Color(245, 245, 245, 255)).getRGB());
/* 137 */     RenderUtils.scaledProjection();
/*     */   }
/*     */   
/*     */   public boolean method_25402(double n, double n2, int n3) {
/* 141 */     double n4 = n * class_310.method_1551().method_22683().method_4495();
/* 142 */     double n5 = n2 * class_310.method_1551().method_22683().method_4495();
/* 143 */     int n6 = (this.this$0.mc.method_22683().method_4480() - 600) / 2;
/* 144 */     int n7 = (this.this$0.mc.method_22683().method_4507() - 500) / 2;
/* 145 */     int n8 = n7 + 500 - 45;
/* 146 */     int n9 = n6 + 600 - 80 - 20;
/* 147 */     int n10 = n9 - 80 - 10;
/* 148 */     if (isInBounds(n4, n5, n9, n8, 80, 30)) {
/* 149 */       if (this.selectedIndex >= 0 && this.selectedIndex < this.filteredItems.size()) {
/* 150 */         this.setting.setItem(this.filteredItems.get(this.selectedIndex));
/*     */       }
/* 152 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 153 */       return true;
/*     */     } 
/* 155 */     if (isInBounds(n4, n5, n10, n8, 80, 30)) {
/* 156 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 157 */       return true;
/*     */     } 
/* 159 */     if (isInBounds(n4, n5, n10 - 80 - 10, n8, 80, 30)) {
/* 160 */       this.setting.setItem(this.setting.getDefaultValue());
/* 161 */       this.selectedIndex = -1;
/* 162 */       for (int i = 0; i < this.filteredItems.size(); i++) {
/* 163 */         if (this.filteredItems.get(i) == this.setting.getDefaultValue()) {
/* 164 */           this.selectedIndex = i;
/*     */           break;
/*     */         } 
/*     */       } 
/* 168 */       return true;
/*     */     } 
/* 170 */     int n11 = n6 + 20;
/* 171 */     int n12 = n7 + 50 + 30 + 15;
/* 172 */     if (isInBounds(n4, n5, n11, n12, 560, 500 - n12 - n7 - 60)) {
/* 173 */       int n13 = this.scrollOffset * 11;
/* 174 */       int n14 = (int)(n4 - n11 - 5.0D) / 48;
/* 175 */       if (n14 >= 0 && n14 < 11) {
/* 176 */         int selectedIndex = n13 + (int)(n5 - n12 - 5.0D) / 48 * 11 + n14;
/* 177 */         if (selectedIndex >= 0 && selectedIndex < this.filteredItems.size()) {
/* 178 */           this.selectedIndex = selectedIndex;
/* 179 */           return true;
/*     */         } 
/*     */       } 
/*     */     } 
/* 183 */     return super.method_25402(n4, n5, n3);
/*     */   }
/*     */   
/*     */   public boolean method_25401(double n, double n2, double n3, double n4) {
/* 187 */     double n5 = n * class_310.method_1551().method_22683().method_4495();
/* 188 */     double n6 = n2 * class_310.method_1551().method_22683().method_4495();
/* 189 */     int width = this.this$0.mc.method_22683().method_4480();
/* 190 */     int n7 = (this.this$0.mc.method_22683().method_4507() - 500) / 2;
/* 191 */     int n8 = n7 + 50 + 30 + 15;
/* 192 */     if (isInBounds(n5, n6, (width - 600) / 2 + 20, n8, 560, 500 - n8 - n7 - 60)) {
/* 193 */       int max = Math.max(0, (int)Math.ceil(this.filteredItems.size() / 11.0D) - 6);
/* 194 */       if (n4 > 0.0D) {
/* 195 */         this.scrollOffset = Math.max(0, this.scrollOffset - 1);
/* 196 */       } else if (n4 < 0.0D) {
/* 197 */         this.scrollOffset = Math.min(max, this.scrollOffset + 1);
/*     */       } 
/* 199 */       return true;
/*     */     } 
/* 201 */     return super.method_25401(n5, n6, n3, n4);
/*     */   }
/*     */   
/*     */   public boolean method_25404(int n, int n2, int n3) {
/* 205 */     if (n == 256) {
/* 206 */       if (this.selectedIndex >= 0 && this.selectedIndex < this.filteredItems.size()) {
/* 207 */         this.setting.setItem(this.filteredItems.get(this.selectedIndex));
/*     */       }
/* 209 */       this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/* 210 */       return true;
/*     */     } 
/* 212 */     if (n == 259) {
/* 213 */       if (!this.searchQuery.isEmpty()) {
/* 214 */         this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
/* 215 */         updateFilteredItems();
/*     */       } 
/* 217 */       return true;
/*     */     } 
/* 219 */     if (n == 265) {
/* 220 */       if (this.selectedIndex >= 11) {
/* 221 */         this.selectedIndex -= 11;
/* 222 */         ensureSelectedItemVisible();
/*     */       } 
/* 224 */       return true;
/*     */     } 
/* 226 */     if (n == 264) {
/* 227 */       if (this.selectedIndex + 11 < this.filteredItems.size()) {
/* 228 */         this.selectedIndex += 11;
/* 229 */         ensureSelectedItemVisible();
/*     */       } 
/* 231 */       return true;
/*     */     } 
/* 233 */     if (n == 263) {
/* 234 */       if (this.selectedIndex > 0) {
/* 235 */         this.selectedIndex--;
/* 236 */         ensureSelectedItemVisible();
/*     */       } 
/* 238 */       return true;
/*     */     } 
/* 240 */     if (n == 262) {
/* 241 */       if (this.selectedIndex < this.filteredItems.size() - 1) {
/* 242 */         this.selectedIndex++;
/* 243 */         ensureSelectedItemVisible();
/*     */       } 
/* 245 */       return true;
/*     */     } 
/* 247 */     if (n == 257) {
/* 248 */       if (this.selectedIndex >= 0 && this.selectedIndex < this.filteredItems.size()) {
/* 249 */         this.setting.setItem(this.filteredItems.get(this.selectedIndex));
/* 250 */         this.this$0.mc.method_1507((class_437)DonutBBC.INSTANCE.GUI);
/*     */       } 
/* 252 */       return true;
/*     */     } 
/* 254 */     return super.method_25404(n, n2, n3);
/*     */   }
/*     */   
/*     */   public boolean method_25400(char c, int n) {
/* 258 */     this.searchQuery += this.searchQuery;
/* 259 */     updateFilteredItems();
/* 260 */     return true;
/*     */   }
/*     */   
/*     */   private void updateFilteredItems() {
/* 264 */     if (this.searchQuery.isEmpty()) {
/* 265 */       this.filteredItems = new ArrayList<>(this.allItems);
/*     */     } else {
/* 267 */       this.filteredItems = (List<class_1792>)this.allItems.stream().filter(item -> item.method_7848().getString().toLowerCase().contains(this.searchQuery.toLowerCase())).collect(Collectors.toList());
/*     */     } 
/* 269 */     this.scrollOffset = 0;
/* 270 */     this.selectedIndex = -1;
/* 271 */     class_1792 a = this.setting.getItem();
/* 272 */     if (a != null) {
/* 273 */       for (int i = 0; i < this.filteredItems.size(); i++) {
/* 274 */         if (this.filteredItems.get(i) == a) {
/* 275 */           this.selectedIndex = i;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   private void ensureSelectedItemVisible() {
/* 283 */     if (this.selectedIndex < 0) {
/*     */       return;
/*     */     }
/* 286 */     int scrollOffset = this.selectedIndex / 11;
/* 287 */     if (scrollOffset < this.scrollOffset) {
/* 288 */       this.scrollOffset = scrollOffset;
/* 289 */     } else if (scrollOffset >= this.scrollOffset + 6) {
/* 290 */       this.scrollOffset = scrollOffset - 6 + 1;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean isInBounds(double n, double n2, int n3, int n4, int n5, int n6) {
/* 295 */     return (n >= n3 && n <= (n3 + n5) && n2 >= n4 && n2 <= (n4 + n6));
/*     */   }
/*     */ 
/*     */   
/*     */   public void method_25420(class_332 drawContext, int n, int n2, float n3) {}
/*     */   
/*     */   public boolean method_25422() {
/* 302 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\ItemFilter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */