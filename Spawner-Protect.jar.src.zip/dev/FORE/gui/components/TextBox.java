/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.module.setting.StringSetting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public class TextBox
/*     */   extends Component {
/*     */   private final StringSetting setting;
/*     */   private float hoverAnimation;
/*     */   private Color currentColor;
/*     */   private final Color TEXT_COLOR;
/*     */   private final Color VALUE_COLOR;
/*     */   private final Color HOVER_COLOR;
/*     */   private final Color INPUT_BG;
/*     */   private final Color INPUT_BORDER;
/*  24 */   private final float CORNER_RADIUS = 4.0F;
/*  25 */   private final float HOVER_ANIMATION_SPEED = 0.25F;
/*  26 */   private final int MAX_VISIBLE_CHARS = 7;
/*     */   
/*     */   public TextBox(ModuleButton moduleButton, Setting setting, int n) {
/*  29 */     super(moduleButton, setting, n);
/*  30 */     this.hoverAnimation = 0.0F;
/*  31 */     this.TEXT_COLOR = new Color(230, 230, 230);
/*  32 */     this.VALUE_COLOR = new Color(120, 210, 255);
/*  33 */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/*  34 */     this.INPUT_BG = new Color(30, 30, 35);
/*  35 */     this.INPUT_BORDER = new Color(60, 60, 65);
/*  36 */     this.setting = (StringSetting)setting;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/*  41 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*  42 */     if (this.currentColor == null) {
/*  43 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*     */     } else {
/*  45 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor.getAlpha());
/*     */     } 
/*  47 */     if (this.currentColor.getAlpha() != 255) {
/*  48 */       this.currentColor = ColorUtil.a(0.05F, 255, this.currentColor);
/*     */     }
/*  50 */     super.onUpdate();
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*  55 */     super.render(drawContext, n, n2, n3);
/*  56 */     updateAnimations(n, n2, n3);
/*  57 */     if (!this.parent.parent.dragging) {
/*  58 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR.getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*     */     }
/*  60 */     int n4 = parentX() + 5;
/*  61 */     int n5 = parentY() + parentOffset() + this.offset + 9;
/*  62 */     TextRenderer.drawString(String.valueOf(this.setting.getName()), drawContext, n4, n5, this.TEXT_COLOR.getRGB());
/*  63 */     int n6 = n4 + TextRenderer.getWidth(String.valueOf(this.setting.getName()) + ": ") + 5;
/*  64 */     int n7 = parentWidth() - n6 + parentX() - 5;
/*  65 */     int n8 = n5 - 2;
/*  66 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.INPUT_BORDER, n6, n8, (n6 + n7), (n8 + 18), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*  67 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.INPUT_BG, (n6 + 1), (n8 + 1), (n6 + n7 - 1), (n8 + 18 - 1), 3.5D, 3.5D, 3.5D, 3.5D, 50.0D);
/*  68 */     TextRenderer.drawString(formatDisplayValue(this.setting.getValue()), drawContext, n6 + 4, n8 + 3, this.VALUE_COLOR.getRGB());
/*     */   }
/*     */   
/*     */   private void updateAnimations(int n, int n2, float n3) {
/*     */     float n4;
/*  73 */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/*  74 */       n4 = 1.0F;
/*     */     } else {
/*  76 */       n4 = 0.0F;
/*     */     } 
/*  78 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n4, 0.25D, (n3 * 0.05F));
/*     */   }
/*     */   
/*     */   private String formatDisplayValue(String s) {
/*  82 */     if (s == null || s.isEmpty()) {
/*  83 */       return "...";
/*     */     }
/*  85 */     if (s.length() <= 7) {
/*  86 */       return s;
/*     */     }
/*  88 */     return s.substring(0, 4) + "...";
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {
/*  93 */     if (isHovered(n, n2) && n3 == 0) {
/*  94 */       this.mc.method_1507(new StringBox(this, this.setting));
/*     */     }
/*  96 */     super.mouseClicked(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onGuiClose() {
/* 101 */     this.currentColor = null;
/* 102 */     this.hoverAnimation = 0.0F;
/* 103 */     super.onGuiClose();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\TextBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */