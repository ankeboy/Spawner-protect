/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.ColorSetting;
/*     */ import dev.FORE.module.setting.ModeSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public final class ColorBox
/*     */   extends Component {
/*     */   private final ColorSetting setting;
/*     */   private float hoverAnimation;
/*     */   private Color currentColor;
/*     */   private final Color TEXT_COLOR;
/*     */   private final Color HOVER_COLOR;
/*     */   private final Color COLOR_BORDER;
/*  25 */   private final float CORNER_RADIUS = 4.0F;
/*  26 */   private final float HOVER_ANIMATION_SPEED = 0.25F; private boolean colorPickerOpen;
/*     */   
/*     */   public ColorBox(ModuleButton moduleButton, Setting setting, int n) {
/*  29 */     super(moduleButton, setting, n);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 137 */     this.colorPickerOpen = false;
/* 138 */     this.colorPalette = new Color[] { Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.CYAN, Color.MAGENTA, Color.ORANGE, Color.PINK, Color.WHITE, Color.GRAY, Color.DARK_GRAY, Color.BLACK, new Color(255, 100, 100), new Color(100, 255, 100), new Color(100, 100, 255), new Color(255, 255, 100), new Color(255, 100, 255), new Color(100, 255, 255) };
/*     */     this.hoverAnimation = 0.0F;
/*     */     this.TEXT_COLOR = new Color(230, 230, 230);
/*     */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/*     */     this.COLOR_BORDER = new Color(60, 60, 65);
/*     */     this.setting = (ColorSetting)setting;
/*     */   }
/*     */   private final Color[] colorPalette;
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {
/* 148 */     if (this.colorPickerOpen) {
/*     */       
/* 150 */       int pickerX = parentX() + parentWidth() + 5;
/* 151 */       int pickerY = parentY() + parentOffset() + this.offset;
/* 152 */       int pickerWidth = 160;
/* 153 */       int pickerHeight = 70;
/*     */ 
/*     */       
/* 156 */       if (pickerX + pickerWidth > this.mc.method_22683().method_4480() - 10) {
/* 157 */         pickerX = parentX() - pickerWidth - 5;
/*     */       }
/*     */ 
/*     */       
/* 161 */       if (pickerY + pickerHeight > this.mc.method_22683().method_4507() - 10) {
/* 162 */         pickerY = this.mc.method_22683().method_4507() - pickerHeight - 10;
/*     */       }
/* 164 */       if (pickerY < 10) {
/* 165 */         pickerY = 10;
/*     */       }
/*     */       
/* 168 */       if (n >= pickerX && n <= (pickerX + pickerWidth) && n2 >= pickerY && n2 <= (pickerY + pickerHeight)) {
/*     */         
/* 170 */         int colorsPerRow = 8;
/* 171 */         int colorSize = 16;
/* 172 */         int spacing = 2;
/*     */         
/* 174 */         int relativeX = (int)(n - pickerX);
/* 175 */         int relativeY = (int)(n2 - pickerY);
/*     */         
/* 177 */         int colorIndex = relativeY / (colorSize + spacing) * colorsPerRow + relativeX / (colorSize + spacing);
/*     */         
/* 179 */         if (colorIndex >= 0 && colorIndex < this.colorPalette.length) {
/* 180 */           this.setting.setValue(this.colorPalette[colorIndex]);
/* 181 */           this.colorPickerOpen = false;
/*     */         } 
/*     */         
/*     */         return;
/*     */       } 
/* 186 */       this.colorPickerOpen = false;
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 192 */     if (isHovered(n, n2))
/* 193 */       if (n3 == 0) {
/*     */         
/* 195 */         Color newColor, currentColor = this.setting.getValue();
/*     */ 
/*     */         
/* 198 */         if (currentColor.equals(Color.WHITE)) {
/* 199 */           newColor = Color.RED;
/* 200 */         } else if (currentColor.equals(Color.RED)) {
/* 201 */           newColor = Color.GREEN;
/* 202 */         } else if (currentColor.equals(Color.GREEN)) {
/* 203 */           newColor = Color.BLUE;
/* 204 */         } else if (currentColor.equals(Color.BLUE)) {
/* 205 */           newColor = Color.YELLOW;
/* 206 */         } else if (currentColor.equals(Color.YELLOW)) {
/* 207 */           newColor = Color.CYAN;
/* 208 */         } else if (currentColor.equals(Color.CYAN)) {
/* 209 */           newColor = Color.MAGENTA;
/*     */         } else {
/* 211 */           newColor = Color.WHITE;
/*     */         } 
/*     */         
/* 214 */         this.setting.setValue(newColor);
/* 215 */       } else if (n3 == 1) {
/*     */         
/* 217 */         int n4 = parentX() + 5;
/* 218 */         int n5 = parentY() + parentOffset() + this.offset + parentHeight() / 2;
/* 219 */         int n6 = n4 + TextRenderer.getWidth(String.valueOf(this.setting.getName()) + ": ") + 5;
/* 220 */         int n7 = n5 - 11;
/* 221 */         int colorBoxSize = 20;
/*     */ 
/*     */         
/* 224 */         if (n >= n6 && n <= (n6 + 20) && n2 >= n7 && n2 <= (n7 + 20)) {
/*     */           
/* 226 */           int currentIndex = this.parent.settings.indexOf(this);
/* 227 */           if (currentIndex >= 0 && currentIndex < this.parent.settings.size() - 1) {
/*     */             
/* 229 */             Component nextComponent = this.parent.settings.get(currentIndex + 1);
/*     */ 
/*     */             
/* 232 */             if (nextComponent instanceof ColorBox) {
/* 233 */               Color newColor; ColorBox nextColorBox = (ColorBox)nextComponent;
/*     */               
/* 235 */               Color currentColor = nextColorBox.setting.getValue();
/*     */ 
/*     */               
/* 238 */               if (currentColor.equals(Color.WHITE)) {
/* 239 */                 newColor = Color.RED;
/* 240 */               } else if (currentColor.equals(Color.RED)) {
/* 241 */                 newColor = Color.GREEN;
/* 242 */               } else if (currentColor.equals(Color.GREEN)) {
/* 243 */                 newColor = Color.BLUE;
/* 244 */               } else if (currentColor.equals(Color.BLUE)) {
/* 245 */                 newColor = Color.YELLOW;
/* 246 */               } else if (currentColor.equals(Color.YELLOW)) {
/* 247 */                 newColor = Color.CYAN;
/* 248 */               } else if (currentColor.equals(Color.CYAN)) {
/* 249 */                 newColor = Color.MAGENTA;
/*     */               } else {
/* 251 */                 newColor = Color.WHITE;
/*     */               } 
/*     */               
/* 254 */               nextColorBox.setting.setValue(newColor);
/* 255 */             } else if (nextComponent.setting instanceof NumberSetting) {
/* 256 */               NumberSetting numberSetting = (NumberSetting)nextComponent.setting;
/* 257 */               double currentValue = numberSetting.getValue();
/* 258 */               double newValue = Math.max(numberSetting.getMin(), currentValue - numberSetting.getFormat());
/* 259 */               numberSetting.setValue(newValue);
/* 260 */             } else if (nextComponent.setting instanceof BooleanSetting) {
/* 261 */               BooleanSetting booleanSetting = (BooleanSetting)nextComponent.setting;
/* 262 */               booleanSetting.toggle();
/* 263 */             } else if (nextComponent.setting instanceof ModeSetting) {
/* 264 */               ModeSetting<?> modeSetting = (ModeSetting)nextComponent.setting;
/* 265 */               modeSetting.cycleDown();
/*     */             } 
/*     */           } 
/*     */         } else {
/*     */           
/* 270 */           this.colorPickerOpen = true;
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   public void onUpdate() {
/*     */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*     */     if (this.currentColor == null) {
/*     */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*     */     } else {
/*     */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor.getAlpha());
/*     */     } 
/*     */     if (this.currentColor.getAlpha() != 255)
/*     */       this.currentColor = ColorUtil.a(0.05F, 255, this.currentColor); 
/*     */     super.onUpdate();
/*     */   }
/*     */   
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*     */     super.render(drawContext, n, n2, n3);
/*     */     updateAnimations(n, n2, n3);
/*     */     if (!this.parent.parent.dragging)
/*     */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR.getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB()); 
/*     */     int n4 = parentX() + 5;
/*     */     int n5 = parentY() + parentOffset() + this.offset + parentHeight() / 2;
/*     */     TextRenderer.drawString(String.valueOf(this.setting.getName()), drawContext, n4, n5 - 8, this.TEXT_COLOR.getRGB());
/*     */     int n6 = n4 + TextRenderer.getWidth(String.valueOf(this.setting.getName()) + ": ") + 5;
/*     */     int n7 = n5 - 11;
/*     */     int colorBoxSize = 20;
/*     */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.COLOR_BORDER, n6, n7, (n6 + 20), (n7 + 20), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*     */     Color settingColor = this.setting.getValue();
/*     */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), settingColor, (n6 + 1), (n7 + 1), (n6 + 20 - 1), (n7 + 20 - 1), 3.5D, 3.5D, 3.5D, 3.5D, 50.0D);
/*     */     int n8 = n6 + 20 + 10;
/*     */     int n9 = n5 - 8;
/*     */     String rgbText = String.format("RGB(%d,%d,%d)", new Object[] { Integer.valueOf(settingColor.getRed()), Integer.valueOf(settingColor.getGreen()), Integer.valueOf(settingColor.getBlue()) });
/*     */     TextRenderer.drawString(rgbText, drawContext, n8, n9, this.TEXT_COLOR.getRGB());
/*     */     if (this.colorPickerOpen) {
/*     */       int pickerX = parentX() + parentWidth() + 5;
/*     */       int pickerY = parentY() + parentOffset() + this.offset;
/*     */       int pickerWidth = 160;
/*     */       int pickerHeight = 70;
/*     */       if (pickerX + pickerWidth > this.mc.method_22683().method_4480() - 10)
/*     */         pickerX = parentX() - pickerWidth - 5; 
/*     */       if (pickerY + pickerHeight > this.mc.method_22683().method_4507() - 10)
/*     */         pickerY = this.mc.method_22683().method_4507() - pickerHeight - 10; 
/*     */       if (pickerY < 10)
/*     */         pickerY = 10; 
/*     */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(20, 20, 25, 255), (pickerX - 2), (pickerY - 2), (pickerX + pickerWidth + 2), (pickerY + pickerHeight + 2), 6.0D, 6.0D, 6.0D, 6.0D, 50.0D);
/*     */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(40, 40, 45, 255), pickerX, pickerY, (pickerX + pickerWidth), (pickerY + pickerHeight), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*     */       int colorsPerRow = 8;
/*     */       int colorSize = 16;
/*     */       int spacing = 2;
/*     */       for (int i = 0; i < this.colorPalette.length; i++) {
/*     */         int row = i / colorsPerRow;
/*     */         int col = i % colorsPerRow;
/*     */         int colorX = pickerX + 2 + col * (colorSize + spacing);
/*     */         int colorY = pickerY + 2 + row * (colorSize + spacing);
/*     */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.colorPalette[i], colorX, colorY, (colorX + colorSize), (colorY + colorSize), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
/*     */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(80, 80, 85, 255), colorX, colorY, (colorX + colorSize), (colorY + colorSize), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateAnimations(int n, int n2, float n3) {
/*     */     float n4;
/*     */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/*     */       n4 = 1.0F;
/*     */     } else {
/*     */       n4 = 0.0F;
/*     */     } 
/*     */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n4, 0.25D, (n3 * 0.05F));
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\ColorBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */