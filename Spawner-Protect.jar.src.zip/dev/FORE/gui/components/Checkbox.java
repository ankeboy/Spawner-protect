/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public final class Checkbox
/*     */   extends Component {
/*     */   private final BooleanSetting setting;
/*     */   private float hoverAnimation;
/*     */   private float enabledAnimation;
/*     */   private final float CORNER_RADIUS = 3.0F;
/*     */   private final Color TEXT_COLOR;
/*     */   private final Color HOVER_COLOR;
/*     */   private final Color BOX_BORDER;
/*     */   private final Color BOX_BG;
/*     */   private final int BOX_SIZE = 13;
/*     */   private final float HOVER_ANIMATION_SPEED = 0.005F;
/*     */   private final float TOGGLE_ANIMATION_SPEED = 0.002F;
/*     */   
/*     */   public Checkbox(ModuleButton moduleButton, Setting setting, int n) {
/*  28 */     super(moduleButton, setting, n); float enabledAnimation; this.CORNER_RADIUS = 3.0F; this.BOX_SIZE = 13; this.HOVER_ANIMATION_SPEED = 0.005F; this.TOGGLE_ANIMATION_SPEED = 0.002F;
/*  29 */     this.hoverAnimation = 0.0F;
/*  30 */     this.enabledAnimation = 0.0F;
/*  31 */     this.TEXT_COLOR = new Color(230, 230, 230);
/*  32 */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/*  33 */     this.BOX_BORDER = new Color(100, 100, 110);
/*  34 */     this.BOX_BG = new Color(40, 40, 45);
/*  35 */     this.setting = (BooleanSetting)setting;
/*     */     
/*  37 */     if (this.setting.getValue()) {
/*  38 */       enabledAnimation = 1.0F;
/*     */     } else {
/*  40 */       enabledAnimation = 0.0F;
/*     */     } 
/*  42 */     this.enabledAnimation = enabledAnimation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*  47 */     super.render(drawContext, n, n2, n3);
/*  48 */     updateAnimations(n, n2, n3);
/*  49 */     if (!this.parent.parent.dragging) {
/*  50 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR.getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*     */     }
/*  52 */     TextRenderer.drawString(this.setting.getName(), drawContext, parentX() + 27, parentY() + parentOffset() + this.offset + parentHeight() / 2 - 6, this.TEXT_COLOR.getRGB());
/*  53 */     renderModernCheckbox(drawContext);
/*     */   }
/*     */   
/*     */   private void updateAnimations(int n, int n2, float n3) {
/*  57 */     float n5, n6, n4 = n3 * 0.05F;
/*     */     
/*  59 */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/*  60 */       n5 = 1.0F;
/*     */     } else {
/*  62 */       n5 = 0.0F;
/*     */     } 
/*  64 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n5, 0.004999999888241291D, n4);
/*     */     
/*  66 */     if (this.setting.getValue()) {
/*  67 */       n6 = 1.0F;
/*     */     } else {
/*  69 */       n6 = 0.0F;
/*     */     } 
/*  71 */     this.enabledAnimation = (float)MathUtil.exponentialInterpolate(this.enabledAnimation, n6, 0.0020000000949949026D, n4);
/*  72 */     this.enabledAnimation = (float)MathUtil.clampValue(this.enabledAnimation, 0.0D, 1.0D);
/*     */   }
/*     */   
/*     */   private void renderModernCheckbox(class_332 drawContext) {
/*  76 */     int checkboxX = parentX() + 8;
/*  77 */     int checkboxY = parentY() + parentOffset() + this.offset + parentHeight() / 2 - 6;
/*  78 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/*  79 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.BOX_BORDER, checkboxX, checkboxY, (checkboxX + 13), (checkboxY + 13), 3.0D, 3.0D, 3.0D, 3.0D, 50.0D);
/*  80 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.BOX_BG, (checkboxX + 1), (checkboxY + 1), (checkboxX + 13 - 1), (checkboxY + 13 - 1), 2.5D, 2.5D, 2.5D, 2.5D, 50.0D);
/*  81 */     if (this.enabledAnimation > 0.01F) {
/*  82 */       Color color = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), (int)(255.0F * this.enabledAnimation));
/*  83 */       float checkmarkX = (checkboxX + 2) + 9.0F * (1.0F - this.enabledAnimation) / 2.0F;
/*  84 */       float checkmarkY = (checkboxY + 2) + 9.0F * (1.0F - this.enabledAnimation) / 2.0F;
/*  85 */       RenderUtils.renderRoundedQuad(drawContext.method_51448(), color, checkmarkX, checkmarkY, (checkmarkX + 9.0F * this.enabledAnimation), (checkmarkY + 9.0F * this.enabledAnimation), 1.5D, 1.5D, 1.5D, 1.5D, 50.0D);
/*  86 */       if (this.enabledAnimation > 0.7F) {
/*  87 */         RenderUtils.renderRoundedQuad(drawContext.method_51448(), new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), (int)(40.0F * (this.enabledAnimation - 0.7F) * 3.33F)), (checkboxX - 1), (checkboxY - 1), (checkboxX + 13 + 1), (checkboxY + 13 + 1), 3.5D, 3.5D, 3.5D, 3.5D, 50.0D);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyPressed(int n, int n2, int n3) {
/*  94 */     if (this.mouseOver && this.parent.extended && n == 259) {
/*  95 */       this.setting.setValue(this.setting.getDefaultValue());
/*     */     }
/*  97 */     super.keyPressed(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {
/* 102 */     if (isHovered(n, n2) && n3 == 0) {
/* 103 */       this.setting.toggle();
/*     */     }
/* 105 */     super.mouseClicked(n, n2, n3);
/*     */   }
/*     */   
/*     */   public void onGuiClose() {
/*     */     float enabledAnimation;
/* 110 */     super.onGuiClose();
/* 111 */     this.hoverAnimation = 0.0F;
/*     */     
/* 113 */     if (this.setting.getValue()) {
/* 114 */       enabledAnimation = 1.0F;
/*     */     } else {
/* 116 */       enabledAnimation = 0.0F;
/*     */     } 
/* 118 */     this.enabledAnimation = enabledAnimation;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\Checkbox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */