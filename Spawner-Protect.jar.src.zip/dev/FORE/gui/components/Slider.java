/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.setting.MinMaxSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4587;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class Slider
/*     */   extends Component
/*     */ {
/*     */   private boolean draggingMin;
/*     */   private boolean draggingMax;
/*     */   private double offsetMinX;
/*     */   private double offsetMaxX;
/*     */   public double lerpedOffsetMinX;
/*     */   public double lerpedOffsetMaxX;
/*     */   private float hoverAnimation;
/*     */   private final MinMaxSetting setting;
/*     */   public Color accentColor1;
/*     */   public Color accentColor2;
/*     */   
/*     */   public Slider(ModuleButton moduleButton, Setting setting, int n) {
/*  38 */     super(moduleButton, setting, n);
/*  39 */     this.hoverAnimation = 0.0F;
/*  40 */     this.setting = (MinMaxSetting)setting;
/*  41 */     this.lerpedOffsetMinX = parentX();
/*  42 */     this.lerpedOffsetMaxX = (parentX() + parentWidth());
/*     */   }
/*     */ 
/*     */   
/*     */   public void render(class_332 drawContext, int n, int n2, float n3) {
/*  47 */     super.render(drawContext, n, n2, n3);
/*  48 */     class_4587 matrices = drawContext.method_51448();
/*  49 */     updateAnimations(n, n2, n3);
/*  50 */     this.offsetMinX = (this.setting.getCurrentMin() - this.setting.getMinValue()) / (this.setting.getMaxValue() - this.setting.getMinValue()) * (parentWidth() - 10) + 5.0D;
/*  51 */     this.offsetMaxX = (this.setting.getCurrentMax() - this.setting.getMinValue()) / (this.setting.getMaxValue() - this.setting.getMinValue()) * (parentWidth() - 10) + 5.0D;
/*  52 */     this.lerpedOffsetMinX = MathUtil.approachValue((float)(0.5D * n3), this.lerpedOffsetMinX, this.offsetMinX);
/*  53 */     this.lerpedOffsetMaxX = MathUtil.approachValue((float)(0.5D * n3), this.lerpedOffsetMaxX, this.offsetMaxX);
/*  54 */     if (!this.parent.parent.dragging) {
/*  55 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(HOVER_COLOR.getRed(), HOVER_COLOR.getGreen(), HOVER_COLOR.getBlue(), (int)(HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*     */     }
/*  57 */     int n4 = parentY() + this.offset + parentOffset() + 25;
/*  58 */     int n5 = parentX() + 5;
/*  59 */     RenderUtils.renderRoundedQuad(matrices, TRACK_BG_COLOR, n5, n4, (n5 + parentWidth() - 10), (n4 + 4.0F), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
/*  60 */     if (this.lerpedOffsetMaxX > this.lerpedOffsetMinX) {
/*  61 */       RenderUtils.renderRoundedQuad(matrices, this.accentColor1, n5 + this.lerpedOffsetMinX - 5.0D, n4, n5 + this.lerpedOffsetMaxX - 5.0D, (n4 + 4.0F), 2.0D, 2.0D, 2.0D, 2.0D, 50.0D);
/*     */     }
/*  63 */     String displayText = getDisplayText();
/*  64 */     TextRenderer.drawString(this.setting.getName(), drawContext, parentX() + 5, parentY() + parentOffset() + this.offset + 9, TEXT_COLOR.getRGB());
/*  65 */     TextRenderer.drawString(displayText, drawContext, parentX() + parentWidth() - TextRenderer.getWidth(displayText) - 5, parentY() + parentOffset() + this.offset + 9, this.accentColor1.getRGB());
/*  66 */     float n6 = n4 + 2.0F - 4.0F;
/*  67 */     RenderUtils.renderRoundedQuad(matrices, THUMB_COLOR, (float)(n5 + this.lerpedOffsetMinX - 5.0D - 4.0D), n6, (float)(n5 + this.lerpedOffsetMinX - 5.0D + 4.0D), (n6 + 8.0F), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*  68 */     RenderUtils.renderRoundedQuad(matrices, THUMB_COLOR, (float)(n5 + this.lerpedOffsetMaxX - 5.0D - 4.0D), n6, (float)(n5 + this.lerpedOffsetMaxX - 5.0D + 4.0D), (n6 + 8.0F), 4.0D, 4.0D, 4.0D, 4.0D, 50.0D);
/*     */   }
/*     */   
/*     */   private void updateAnimations(int n, int n2, float n3) {
/*     */     float n4;
/*  73 */     if (isHovered(n, n2) && !this.parent.parent.dragging) {
/*  74 */       n4 = 1.0F;
/*     */     } else {
/*  76 */       n4 = 0.0F;
/*     */     } 
/*  78 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, n4, 0.25D, (n3 * 0.05F));
/*     */   }
/*     */   
/*     */   private String getDisplayText() {
/*  82 */     if (this.setting.getCurrentMin() == this.setting.getCurrentMax()) {
/*  83 */       return formatValue(this.setting.getCurrentMin());
/*     */     }
/*  85 */     return formatValue(this.setting.getCurrentMin()) + " - " + formatValue(this.setting.getCurrentMin());
/*     */   }
/*     */   
/*     */   private String formatValue(double value) {
/*  89 */     double step = this.setting.getStep();
/*  90 */     if (step == 0.1D) {
/*  91 */       return String.format("%.1f", new Object[] { Double.valueOf(value) });
/*     */     }
/*  93 */     if (step == 0.01D) {
/*  94 */       return String.format("%.2f", new Object[] { Double.valueOf(value) });
/*     */     }
/*  96 */     if (step == 0.001D) {
/*  97 */       return String.format("%.3f", new Object[] { Double.valueOf(value) });
/*     */     }
/*  99 */     if (step >= 1.0D) {
/* 100 */       return String.format("%.0f", new Object[] { Double.valueOf(value) });
/*     */     }
/* 102 */     return String.valueOf(value);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseClicked(double n, double n2, int n3) {
/* 107 */     if (n3 == 0 && isHovered(n, n2)) {
/* 108 */       if (isHoveredMin(n, n2)) {
/* 109 */         this.draggingMin = true;
/* 110 */         slideMin(n);
/* 111 */       } else if (isHoveredMax(n, n2)) {
/* 112 */         this.draggingMax = true;
/* 113 */         slideMax(n);
/* 114 */       } else if (n < parentX() + this.offsetMinX) {
/* 115 */         this.draggingMin = true;
/* 116 */         slideMin(n);
/* 117 */       } else if (n > parentX() + this.offsetMaxX) {
/* 118 */         this.draggingMax = true;
/* 119 */         slideMax(n);
/* 120 */       } else if (n - parentX() + this.offsetMinX < parentX() + this.offsetMaxX - n) {
/* 121 */         this.draggingMin = true;
/* 122 */         slideMin(n);
/*     */       } else {
/* 124 */         this.draggingMax = true;
/* 125 */         slideMax(n);
/*     */       } 
/*     */     }
/* 128 */     super.mouseClicked(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void keyPressed(int n, int n2, int n3) {
/* 133 */     if (this.mouseOver && n == 259) {
/* 134 */       this.setting.setCurrentMax(this.setting.getDefaultMax());
/* 135 */       this.setting.setCurrentMin(this.setting.getDefaultMin());
/*     */     } 
/* 137 */     super.keyPressed(n, n2, n3);
/*     */   }
/*     */   
/*     */   public boolean isHoveredMin(double n, double n2) {
/* 141 */     return (isHovered(n, n2) && n > parentX() + this.offsetMinX - 8.0D && n < parentX() + this.offsetMinX + 8.0D);
/*     */   }
/*     */   
/*     */   public boolean isHoveredMax(double n, double n2) {
/* 145 */     return (isHovered(n, n2) && n > parentX() + this.offsetMaxX - 8.0D && n < parentX() + this.offsetMaxX + 8.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseReleased(double n, double n2, int n3) {
/* 150 */     if (n3 == 0) {
/* 151 */       this.draggingMin = false;
/* 152 */       this.draggingMax = false;
/*     */     } 
/* 154 */     super.mouseReleased(n, n2, n3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void mouseDragged(double n, double n2, int n3, double n4, double n5) {
/* 159 */     if (this.draggingMin) {
/* 160 */       slideMin(n);
/*     */     }
/* 162 */     if (this.draggingMax) {
/* 163 */       slideMax(n);
/*     */     }
/* 165 */     super.mouseDragged(n, n2, n3, n4, n5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onGuiClose() {
/* 170 */     this.accentColor1 = null;
/* 171 */     this.accentColor2 = null;
/* 172 */     this.hoverAnimation = 0.0F;
/* 173 */     super.onGuiClose();
/*     */   }
/*     */   
/*     */   private void slideMin(double n) {
/* 177 */     this.setting.setCurrentMin(Math.min(MathUtil.roundToNearest(class_3532.method_15350((n - (parentX() + 5)) / (parentWidth() - 10), 0.0D, 1.0D) * (this.setting.getMaxValue() - this.setting.getMinValue()) + this.setting.getMinValue(), this.setting.getStep()), this.setting.getCurrentMax()));
/*     */   }
/*     */   
/*     */   private void slideMax(double n) {
/* 181 */     this.setting.setCurrentMax(Math.max(MathUtil.roundToNearest(class_3532.method_15350((n - (parentX() + 5)) / (parentWidth() - 10), 0.0D, 1.0D) * (this.setting.getMaxValue() - this.setting.getMinValue()) + this.setting.getMinValue(), this.setting.getStep()), this.setting.getCurrentMin()));
/*     */   }
/*     */ 
/*     */   
/*     */   public void onUpdate() {
/* 186 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/* 187 */     Color mainColor2 = Utils.getMainColor(255, this.parent.settings.indexOf(this) + 1);
/* 188 */     if (this.accentColor1 == null) {
/* 189 */       this.accentColor1 = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*     */     } else {
/* 191 */       this.accentColor1 = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.accentColor1.getAlpha());
/*     */     } 
/* 193 */     if (this.accentColor2 == null) {
/* 194 */       this.accentColor2 = new Color(mainColor2.getRed(), mainColor2.getGreen(), mainColor2.getBlue(), 0);
/*     */     } else {
/* 196 */       this.accentColor2 = new Color(mainColor2.getRed(), mainColor2.getGreen(), mainColor2.getBlue(), this.accentColor2.getAlpha());
/*     */     } 
/* 198 */     if (this.accentColor1.getAlpha() != 255) {
/* 199 */       this.accentColor1 = ColorUtil.a(0.05F, 255, this.accentColor1);
/*     */     }
/* 201 */     if (this.accentColor2.getAlpha() != 255) {
/* 202 */       this.accentColor2 = ColorUtil.a(0.05F, 255, this.accentColor2);
/*     */     }
/* 204 */     super.onUpdate();
/*     */   }
/*     */ 
/*     */   
/* 208 */   private static final Color TEXT_COLOR = new Color(230, 230, 230);
/* 209 */   private static final Color HOVER_COLOR = new Color(255, 255, 255, 20);
/* 210 */   private static final Color TRACK_BG_COLOR = new Color(60, 60, 65);
/* 211 */   private static final Color THUMB_COLOR = new Color(240, 240, 240);
/*     */   private static final float TRACK_HEIGHT = 4.0F;
/*     */   private static final float TRACK_RADIUS = 2.0F;
/*     */   private static final float THUMB_SIZE = 8.0F;
/*     */   private static final float ANIMATION_SPEED = 0.25F;
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\Slider.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */