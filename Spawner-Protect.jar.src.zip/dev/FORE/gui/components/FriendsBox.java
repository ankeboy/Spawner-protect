/*    */ package dev.FORE.gui.components;
/*    */ 
/*    */ import dev.FORE.gui.Component;
/*    */ import dev.FORE.module.setting.FriendsSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.ColorUtil;
/*    */ import dev.FORE.utils.MathUtil;
/*    */ import dev.FORE.utils.RenderUtils;
/*    */ import dev.FORE.utils.TextRenderer;
/*    */ import dev.FORE.utils.Utils;
/*    */ import java.awt.Color;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.class_332;
/*    */ 
/*    */ public class FriendsBox extends Component {
/*    */   private final FriendsSetting setting;
/*    */   private float hoverAnimation;
/*    */   private Color currentColor;
/*    */   private final Color TEXT_COLOR;
/*    */   private final Color HOVER_COLOR;
/*    */   private final Color COUNT_BG;
/* 22 */   private final float CORNER_RADIUS = 4.0F;
/* 23 */   private final float HOVER_ANIMATION_SPEED = 0.25F;
/*    */   
/*    */   public FriendsBox(ModuleButton moduleButton, Setting setting, int n) {
/* 26 */     super(moduleButton, setting, n);
/* 27 */     this.hoverAnimation = 0.0F;
/* 28 */     this.TEXT_COLOR = new Color(230, 230, 230);
/* 29 */     this.HOVER_COLOR = new Color(255, 255, 255, 20);
/* 30 */     this.COUNT_BG = new Color(50, 50, 60, 100);
/* 31 */     this.setting = (FriendsSetting)setting;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onUpdate() {
/* 36 */     Color mainColor = Utils.getMainColor(255, this.parent.settings.indexOf(this));
/* 37 */     if (this.currentColor == null) {
/* 38 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), 0);
/*    */     } else {
/* 40 */       this.currentColor = new Color(mainColor.getRed(), mainColor.getGreen(), mainColor.getBlue(), this.currentColor.getAlpha());
/*    */     } 
/* 42 */     if (this.currentColor.getAlpha() != 255) {
/* 43 */       this.currentColor = ColorUtil.a(0.05F, 255, this.currentColor);
/*    */     }
/* 45 */     super.onUpdate();
/*    */   }
/*    */ 
/*    */   
/*    */   public void render(class_332 drawContext, int n, int n2, float n3) {
/* 50 */     super.render(drawContext, n, n2, n3);
/* 51 */     updateAnimations(n, n2, n3);
/*    */     
/* 53 */     if (!this.parent.parent.dragging) {
/* 54 */       drawContext.method_25294(parentX(), parentY() + parentOffset() + this.offset, 
/* 55 */           parentX() + parentWidth(), parentY() + parentOffset() + this.offset + parentHeight(), (new Color(this.HOVER_COLOR
/* 56 */             .getRed(), this.HOVER_COLOR.getGreen(), this.HOVER_COLOR.getBlue(), 
/* 57 */             (int)(this.HOVER_COLOR.getAlpha() * this.hoverAnimation))).getRGB());
/*    */     }
/*    */     
/* 60 */     int textX = parentX() + 5;
/* 61 */     int textY = parentY() + parentOffset() + this.offset + parentHeight() / 2 - 8;
/*    */     
/* 63 */     TextRenderer.drawString(String.valueOf(this.setting.getName()), drawContext, textX, textY, this.TEXT_COLOR.getRGB());
/*    */ 
/*    */     
/* 66 */     int friendCount = this.setting.size();
/* 67 */     String countText = String.valueOf(friendCount);
/* 68 */     int badgeWidth = Math.max(24, TextRenderer.getWidth(countText) + 12);
/* 69 */     int badgeX = parentX() + parentWidth() - badgeWidth - 8;
/* 70 */     int badgeY = parentY() + parentOffset() + this.offset + (parentHeight() - 18) / 2;
/*    */     
/* 72 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.COUNT_BG, badgeX, badgeY, (badgeX + badgeWidth), (badgeY + 18), 9.0D, 9.0D, 9.0D, 9.0D, 50.0D);
/*    */ 
/*    */     
/* 75 */     TextRenderer.drawCenteredString(countText, drawContext, badgeX + badgeWidth / 2, badgeY + 5, 
/* 76 */         Utils.getMainColor(255, this.parent.settings.indexOf(this)).getRGB());
/*    */   }
/*    */   
/*    */   private void updateAnimations(int n, int n2, float n3) {
/* 80 */     float target = (isHovered(n, n2) && !this.parent.parent.dragging) ? 1.0F : 0.0F;
/*    */     
/* 82 */     Objects.requireNonNull(this); this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, target, 0.25D, (n3 * 0.05F));
/*    */   }
/*    */ 
/*    */   
/*    */   public void mouseClicked(double n, double n2, int n3) {
/* 87 */     if (isHovered(n, n2) && n3 == 0) {
/* 88 */       this.mc.method_1507(new FriendsFilter(this, this.setting));
/*    */     }
/* 90 */     super.mouseClicked(n, n2, n3);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onGuiClose() {
/* 95 */     this.currentColor = null;
/* 96 */     this.hoverAnimation = 0.0F;
/* 97 */     super.onGuiClose();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\FriendsBox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */