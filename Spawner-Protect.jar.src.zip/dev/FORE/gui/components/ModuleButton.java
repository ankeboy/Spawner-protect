/*     */ package dev.FORE.gui.components;
/*     */ 
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.gui.CategoryWindow;
/*     */ import dev.FORE.gui.Component;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.Animation;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public final class ModuleButton
/*     */ {
/*     */   public List<Component> settings;
/*     */   public CategoryWindow parent;
/*     */   public Module module;
/*     */   public int offset;
/*     */   public boolean extended;
/*     */   public int settingOffset;
/*     */   public Color currentColor;
/*     */   public Color currentAlpha;
/*     */   public Animation animation;
/*     */   private static final float CORNER_RADIUS = 12.0F;
/*     */   private static final float INNER_CORNER_RADIUS = 8.0F;
/*  34 */   private static final Color BG_BASE = new Color(18, 18, 24, 220);
/*  35 */   private static final Color BG_HOVER = new Color(25, 25, 35, 245);
/*  36 */   private static final Color BG_ENABLED = new Color(30, 30, 40, 255);
/*     */ 
/*     */   
/*  39 */   private static final Color TEXT_ENABLED = new Color(255, 255, 255, 255);
/*  40 */   private static final Color TEXT_DISABLED = new Color(150, 150, 165, 200);
/*     */ 
/*     */   
/*  43 */   private static final Color BORDER_SUBTLE = new Color(60, 60, 75, 100);
/*  44 */   private static final Color GLASS_OVERLAY = new Color(255, 255, 255, 8);
/*  45 */   private static final Color SHADOW_COLOR = new Color(0, 0, 0, 80);
/*     */   
/*     */   private float hoverAnimation;
/*     */   private float enabledAnimation;
/*     */   private float glowPulse;
/*     */   private float extendAnimation;
/*     */   private float pressAnimation;
/*     */   private float rippleAnimation;
/*     */   private double rippleX;
/*     */   private double rippleY;
/*     */   
/*     */   public ModuleButton(CategoryWindow parent, Module module, int offset) {
/*  57 */     this.settings = new ArrayList<>();
/*  58 */     this.animation = new Animation(0.0D);
/*  59 */     this.hoverAnimation = 0.0F;
/*  60 */     this.enabledAnimation = module.isEnabled() ? 1.0F : 0.0F;
/*  61 */     this.glowPulse = 0.0F;
/*  62 */     this.extendAnimation = 0.0F;
/*  63 */     this.pressAnimation = 0.0F;
/*  64 */     this.rippleAnimation = 0.0F;
/*  65 */     this.parent = parent;
/*  66 */     this.module = module;
/*  67 */     this.offset = offset;
/*  68 */     this.extended = false;
/*  69 */     this.settingOffset = parent.getHeight();
/*     */ 
/*     */     
/*  72 */     for (Object setting : module.getSettings()) {
/*  73 */       Component component = null;
/*     */       
/*  75 */       if (setting instanceof dev.FORE.module.setting.BooleanSetting) {
/*  76 */         component = new Checkbox(this, (Setting)setting, this.settingOffset);
/*  77 */       } else if (setting instanceof dev.FORE.module.setting.NumberSetting) {
/*  78 */         component = new NumberBox(this, (Setting)setting, this.settingOffset);
/*  79 */       } else if (setting instanceof dev.FORE.module.setting.ModeSetting) {
/*  80 */         component = new ModeBox(this, (Setting)setting, this.settingOffset);
/*  81 */       } else if (setting instanceof dev.FORE.module.setting.BindSetting) {
/*  82 */         component = new Keybind(this, (Setting)setting, this.settingOffset);
/*  83 */       } else if (setting instanceof dev.FORE.module.setting.StringSetting) {
/*  84 */         component = new TextBox(this, (Setting)setting, this.settingOffset);
/*  85 */       } else if (setting instanceof dev.FORE.module.setting.MinMaxSetting) {
/*  86 */         component = new Slider(this, (Setting)setting, this.settingOffset);
/*  87 */       } else if (setting instanceof dev.FORE.module.setting.ItemsSetting) {
/*  88 */         component = new ItemsListBox(this, (Setting)setting, this.settingOffset);
/*  89 */       } else if (setting instanceof dev.FORE.module.setting.ItemSetting) {
/*  90 */         component = new ItemBox(this, (Setting)setting, this.settingOffset);
/*  91 */       } else if (setting instanceof dev.FORE.module.setting.BlocksSetting) {
/*  92 */         component = new BlocksBox(this, (Setting)setting, this.settingOffset);
/*  93 */       } else if (setting instanceof dev.FORE.module.setting.FriendsSetting) {
/*  94 */         component = new FriendsBox(this, (Setting)setting, this.settingOffset);
/*  95 */       } else if (setting instanceof dev.FORE.module.setting.MacroSetting) {
/*  96 */         component = new MacroBox(this, (Setting)setting, this.settingOffset);
/*  97 */       } else if (setting instanceof dev.FORE.module.setting.ColorSetting) {
/*  98 */         component = new ColorBox(this, (Setting)setting, this.settingOffset);
/*     */       } 
/*     */       
/* 101 */       if (component != null) {
/* 102 */         this.settings.add(component);
/* 103 */         this.settingOffset += parent.getHeight();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void render(class_332 context, int mouseX, int mouseY, float delta) {
/* 109 */     if (this.parent.getY() + this.offset > class_310.method_1551().method_22683().method_4507()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 114 */     for (Component setting : this.settings) {
/* 115 */       setting.onUpdate();
/*     */     }
/*     */     
/* 118 */     updateAnimations(mouseX, mouseY, delta);
/*     */     
/* 120 */     int x = this.parent.getX();
/* 121 */     int y = this.parent.getY() + this.offset;
/* 122 */     int width = this.parent.getWidth();
/* 123 */     int height = this.parent.getHeight();
/*     */ 
/*     */     
/* 126 */     renderDepthShadow(context, x, y, width, height);
/* 127 */     renderBackground(context, x, y, width, height);
/* 128 */     renderRippleEffect(context, x, y, width, height);
/* 129 */     renderBorderAndOverlay(context, x, y, width, height);
/* 130 */     renderModuleContent(context, x, y, width, height);
/*     */     
/* 132 */     if (this.extended) {
/* 133 */       renderSettings(context, mouseX, mouseY, delta);
/*     */     }
/*     */ 
/*     */     
/* 137 */     if (isHovered(mouseX, mouseY) && !this.parent.dragging) {
/* 138 */       DonutBBC.INSTANCE.GUI.setTooltip(this.module.getDescription(), mouseX + 12, mouseY + 12);
/*     */     }
/*     */   }
/*     */   
/*     */   private void updateAnimations(int mouseX, int mouseY, float delta) {
/* 143 */     float animSpeed = delta * 0.1F;
/*     */ 
/*     */     
/* 146 */     float targetHover = (isHovered(mouseX, mouseY) && !this.parent.dragging) ? 1.0F : 0.0F;
/* 147 */     this.hoverAnimation = (float)MathUtil.exponentialInterpolate(this.hoverAnimation, targetHover, 0.12D, animSpeed);
/*     */ 
/*     */     
/* 150 */     float targetEnabled = this.module.isEnabled() ? 1.0F : 0.0F;
/* 151 */     this.enabledAnimation = (float)MathUtil.exponentialInterpolate(this.enabledAnimation, targetEnabled, 0.008D, animSpeed);
/* 152 */     this.enabledAnimation = (float)MathUtil.clampValue(this.enabledAnimation, 0.0D, 1.0D);
/*     */ 
/*     */     
/* 155 */     float targetExtend = this.extended ? 1.0F : 0.0F;
/* 156 */     this.extendAnimation = (float)MathUtil.exponentialInterpolate(this.extendAnimation, targetExtend, 0.1D, animSpeed);
/*     */ 
/*     */     
/* 159 */     if (this.pressAnimation > 0.0F) {
/* 160 */       this.pressAnimation = Math.max(0.0F, this.pressAnimation - delta * 0.08F);
/*     */     }
/*     */ 
/*     */     
/* 164 */     if (this.rippleAnimation > 0.0F) {
/* 165 */       this.rippleAnimation = Math.max(0.0F, this.rippleAnimation - delta * 0.05F);
/*     */     }
/*     */ 
/*     */     
/* 169 */     if (this.module.isEnabled()) {
/* 170 */       this.glowPulse += delta * 0.02F;
/* 171 */       if (this.glowPulse > 6.28F) this.glowPulse = 0.0F; 
/*     */     } else {
/* 173 */       this.glowPulse = 0.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderDepthShadow(class_332 context, int x, int y, int width, int height) {
/* 179 */     float shadowIntensity = 0.3F + this.hoverAnimation * 0.3F;
/* 180 */     Color shadowColor = new Color(0, 0, 0, (int)(shadowIntensity * 100.0F));
/*     */ 
/*     */     
/* 183 */     RenderUtils.renderRoundedQuad(context.method_51448(), shadowColor, (x + 2), (y + 3), (x + width - 2), (y + height + 2), 12.0D, 12.0D, 12.0D, 12.0D, 60.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderBackground(class_332 context, int x, int y, int width, int height) {
/* 190 */     Color bgColor = BG_BASE;
/*     */     
/* 192 */     if (this.enabledAnimation > 0.01F) {
/* 193 */       bgColor = ColorUtil.a(bgColor, BG_ENABLED, this.enabledAnimation);
/*     */     }
/*     */     
/* 196 */     if (this.hoverAnimation > 0.01F) {
/* 197 */       bgColor = ColorUtil.a(bgColor, BG_HOVER, this.hoverAnimation);
/*     */     }
/*     */ 
/*     */     
/* 201 */     boolean isFirst = (this.parent.moduleButtons.get(0) == this);
/* 202 */     boolean isLast = (this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) == this);
/*     */     
/* 204 */     float topLeftRadius = isFirst ? 12.0F : 0.0F;
/* 205 */     float topRightRadius = isFirst ? 12.0F : 0.0F;
/* 206 */     float bottomLeftRadius = (isLast && !this.extended) ? 12.0F : 0.0F;
/* 207 */     float bottomRightRadius = (isLast && !this.extended) ? 12.0F : 0.0F;
/*     */ 
/*     */     
/* 210 */     RenderUtils.renderRoundedQuad(context.method_51448(), bgColor, x, y, (x + width), (y + height), topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius, 60.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 215 */     if (this.pressAnimation > 0.0F) {
/* 216 */       Color pressColor = new Color(0, 0, 0, (int)(30.0F * this.pressAnimation));
/* 217 */       RenderUtils.renderRoundedQuad(context.method_51448(), pressColor, x, y, (x + width), (y + height), topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius, 60.0D);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 223 */     if (this.enabledAnimation > 0.01F) {
/* 224 */       Color accentColor = Utils.getMainColor((int)(255.0F * this.enabledAnimation), DonutBBC.INSTANCE
/* 225 */           .getModuleManager().a(this.module.getCategory()).indexOf(this.module));
/*     */ 
/*     */       
/* 228 */       float barWidth = 4.0F;
/* 229 */       RenderUtils.renderRoundedQuad(context.method_51448(), accentColor, x, y, (x + barWidth), (y + height), topLeftRadius, 0.0D, 0.0D, bottomLeftRadius, 60.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 234 */       if (this.module.isEnabled()) {
/* 235 */         float glowIntensity = (float)(Math.sin(this.glowPulse) * 0.2D + 0.25D);
/*     */         
/* 237 */         Color glowColor = new Color(accentColor.getRed(), accentColor.getGreen(), accentColor.getBlue(), (int)(255.0F * glowIntensity * 0.3F));
/*     */ 
/*     */         
/* 240 */         RenderUtils.renderRoundedQuad(context.method_51448(), glowColor, x, y, (x + width), (y + height), topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius, 60.0D);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderRippleEffect(class_332 context, int x, int y, int width, int height) {
/* 248 */     if (this.rippleAnimation > 0.0F) {
/* 249 */       float rippleRadius = (1.0F - this.rippleAnimation) * width * 0.8F;
/* 250 */       float rippleAlpha = this.rippleAnimation * 80.0F;
/*     */       
/* 252 */       Color accentColor = Utils.getMainColor((int)rippleAlpha, DonutBBC.INSTANCE
/* 253 */           .getModuleManager().a(this.module.getCategory()).indexOf(this.module));
/*     */       
/* 255 */       RenderUtils.renderCircle(context.method_51448(), accentColor, this.rippleX, this.rippleY, rippleRadius, 32);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderBorderAndOverlay(class_332 context, int x, int y, int width, int height) {
/* 261 */     boolean isFirst = (this.parent.moduleButtons.get(0) == this);
/* 262 */     boolean isLast = (this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) == this);
/*     */     
/* 264 */     float topLeftRadius = isFirst ? 12.0F : 0.0F;
/* 265 */     float topRightRadius = isFirst ? 12.0F : 0.0F;
/* 266 */     float bottomLeftRadius = (isLast && !this.extended) ? 12.0F : 0.0F;
/* 267 */     float bottomRightRadius = (isLast && !this.extended) ? 12.0F : 0.0F;
/*     */ 
/*     */     
/* 270 */     Color borderColor = ColorUtil.a(BORDER_SUBTLE, new Color(100, 100, 120, 150), this.hoverAnimation);
/*     */ 
/*     */     
/* 273 */     RenderUtils.renderRoundedOutline(context, borderColor, x, y, (x + width), (y + height), topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius, 1.0D, 60.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     RenderUtils.renderRoundedQuad(context.method_51448(), GLASS_OVERLAY, x, y, (x + width), (y + height / 2), topLeftRadius, topRightRadius, 0.0D, 0.0D, 60.0D);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderModuleContent(class_332 context, int x, int y, int width, int height) {
/* 285 */     Color textColor = ColorUtil.a(TEXT_DISABLED, TEXT_ENABLED, this.enabledAnimation);
/* 286 */     int textX = x + 18;
/* 287 */     int textY = y + height / 2 - 4;
/*     */ 
/*     */     
/* 290 */     TextRenderer.drawString(this.module.getName(), context, textX, textY, textColor.getRGB());
/*     */ 
/*     */     
/* 293 */     renderStatusDot(context, x, y, height);
/*     */ 
/*     */     
/* 296 */     renderModernToggle(context, x, y, width, height);
/*     */ 
/*     */     
/* 299 */     if (!this.module.getSettings().isEmpty()) {
/* 300 */       renderExpandIndicator(context, x, y, width, height);
/*     */     }
/*     */   }
/*     */   
/*     */   private void renderStatusDot(class_332 context, int x, int y, int height) {
/* 305 */     if (this.enabledAnimation > 0.01F) {
/* 306 */       Color accentColor = Utils.getMainColor((int)(255.0F * this.enabledAnimation), DonutBBC.INSTANCE
/* 307 */           .getModuleManager().a(this.module.getCategory()).indexOf(this.module));
/*     */       
/* 309 */       float dotX = (x + 9);
/* 310 */       float dotY = y + height / 2.0F;
/*     */ 
/*     */       
/* 313 */       RenderUtils.renderCircle(context.method_51448(), new Color(accentColor
/* 314 */             .getRed(), accentColor.getGreen(), accentColor.getBlue(), 60), dotX, dotY, 4.0D, 16);
/*     */ 
/*     */ 
/*     */       
/* 318 */       RenderUtils.renderCircle(context.method_51448(), accentColor, dotX, dotY, 2.5D, 12);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderModernToggle(class_332 context, int x, int y, int width, int height) {
/* 323 */     int toggleWidth = 42;
/* 324 */     int toggleHeight = 22;
/* 325 */     int toggleX = x + width - 42 - 10;
/* 326 */     int toggleY = y + height / 2 - 11;
/*     */     
/* 328 */     Color accentColor = Utils.getMainColor(255, DonutBBC.INSTANCE
/* 329 */         .getModuleManager().a(this.module.getCategory()).indexOf(this.module));
/*     */ 
/*     */     
/* 332 */     Color trackBg = ColorUtil.a(new Color(40, 40, 50, 200), accentColor, this.enabledAnimation);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 337 */     RenderUtils.renderRoundedQuad(context.method_51448(), trackBg, toggleX, toggleY, (toggleX + 42), (toggleY + 22), 11.0D, 11.0D, 11.0D, 11.0D, 50.0D);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 342 */     float knobSize = 16.0F;
/* 343 */     float knobPadding = 3.0F;
/* 344 */     float knobTravel = 20.0F;
/* 345 */     float knobX = toggleX + 3.0F + 20.0F * this.enabledAnimation;
/* 346 */     float knobY = (toggleY + 3);
/*     */ 
/*     */     
/* 349 */     RenderUtils.renderCircle(context.method_51448(), new Color(0, 0, 0, 100), (knobX + 8.0F), (knobY + 8.0F + 1.0F), 9.0D, 20);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 354 */     Color knobColor = new Color(255, 255, 255, 255);
/* 355 */     RenderUtils.renderCircle(context.method_51448(), knobColor, (knobX + 8.0F), (knobY + 8.0F), 8.0D, 24);
/*     */ 
/*     */ 
/*     */     
/* 359 */     RenderUtils.renderCircle(context.method_51448(), new Color(255, 255, 255, 100), (knobX + 8.0F), (knobY + 8.0F) - 1.5D, 5.333333492279053D, 16);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderExpandIndicator(class_332 context, int x, int y, int width, int height) {
/* 365 */     int size = 14;
/* 366 */     int indicatorX = x + width - 14 - 58;
/* 367 */     int indicatorY = y + height / 2 - 7;
/*     */     
/* 369 */     Color accentColor = Utils.getMainColor(255, DonutBBC.INSTANCE
/* 370 */         .getModuleManager().a(this.module.getCategory()).indexOf(this.module));
/*     */     
/* 372 */     float colorBlend = this.hoverAnimation * 0.6F + this.extendAnimation * 0.4F;
/* 373 */     Color indicatorColor = ColorUtil.a(new Color(110, 110, 125, 180), accentColor, colorBlend);
/*     */ 
/*     */     
/* 376 */     String chevron = "⌄";
/*     */ 
/*     */     
/* 379 */     if (this.extendAnimation > 0.5F) {
/* 380 */       chevron = "⌃";
/*     */     }
/*     */     
/* 383 */     TextRenderer.drawString(chevron, context, indicatorX + 1, indicatorY + 1, indicatorColor.getRGB());
/*     */   }
/*     */   
/*     */   private void renderSettings(class_332 context, int mouseX, int mouseY, float delta) {
/* 387 */     int y = this.parent.getY() + this.offset + this.parent.getHeight();
/* 388 */     double animHeight = this.animation.getAnimation();
/*     */     
/* 390 */     RenderSystem.enableScissor(this.parent
/* 391 */         .getX(), DonutBBC.mc
/* 392 */         .method_22683().method_4507() - y + (int)animHeight, this.parent
/* 393 */         .getWidth(), (int)animHeight);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 398 */     boolean isLast = (this.parent.moduleButtons.get(this.parent.moduleButtons.size() - 1) == this);
/* 399 */     if (isLast && this.extended) {
/* 400 */       int settingsHeight = (int)animHeight;
/* 401 */       Color settingsBg = new Color(16, 16, 22, 235);
/*     */       
/* 403 */       RenderUtils.renderRoundedQuad(context.method_51448(), settingsBg, this.parent
/* 404 */           .getX(), y, (this.parent
/* 405 */           .getX() + this.parent.getWidth()), (y + settingsHeight), 0.0D, 0.0D, 12.0D, 12.0D, 60.0D);
/*     */     } 
/*     */ 
/*     */     
/* 409 */     for (Component setting : this.settings) {
/* 410 */       setting.render(context, mouseX, mouseY - y, delta);
/*     */     }
/*     */     
/* 413 */     renderSliderControls(context);
/* 414 */     RenderSystem.disableScissor();
/*     */   }
/*     */   
/*     */   private void renderSliderControls(class_332 context) {
/* 418 */     for (Component setting : this.settings) {
/* 419 */       if (setting instanceof NumberBox) { NumberBox numberBox = (NumberBox)setting;
/* 420 */         renderModernSliderKnob(context, setting
/* 421 */             .parentX() + Math.max(numberBox.lerpedOffsetX, 3.0D), (setting
/* 422 */             .parentY() + numberBox.offset + setting.parentOffset()) + 27.5D, numberBox.currentColor1); continue; }
/*     */       
/* 424 */       if (setting instanceof Slider) { Slider slider = (Slider)setting;
/* 425 */         renderModernSliderKnob(context, setting
/* 426 */             .parentX() + Math.max(slider.lerpedOffsetMinX, 3.0D), (setting
/* 427 */             .parentY() + setting.offset + setting.parentOffset()) + 27.5D, slider.accentColor1);
/*     */         
/* 429 */         renderModernSliderKnob(context, setting
/* 430 */             .parentX() + Math.max(slider.lerpedOffsetMaxX, 3.0D), (setting
/* 431 */             .parentY() + setting.offset + setting.parentOffset()) + 27.5D, slider.accentColor1); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void renderModernSliderKnob(class_332 context, double x, double y, Color color) {
/* 439 */     RenderUtils.renderCircle(context.method_51448(), new Color(color
/* 440 */           .getRed(), color.getGreen(), color.getBlue(), 80), x, y, 9.0D, 20);
/*     */ 
/*     */ 
/*     */     
/* 444 */     RenderUtils.renderCircle(context.method_51448(), new Color(0, 0, 0, 120), x, y + 0.5D, 7.0D, 18);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 449 */     RenderUtils.renderCircle(context.method_51448(), color, x, y, 6.5D, 20);
/*     */ 
/*     */     
/* 452 */     RenderUtils.renderCircle(context.method_51448(), new Color(255, 255, 255, 100), x, y - 1.5D, 3.5D, 14);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 457 */     RenderUtils.renderCircle(context.method_51448(), new Color(255, 255, 255, 180), x, y, 1.5D, 10);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onExtend() {
/* 463 */     for (ModuleButton button : this.parent.moduleButtons) {
/* 464 */       button.extended = false;
/*     */     }
/*     */   }
/*     */   
/*     */   public void keyPressed(int key, int scancode, int modifiers) {
/* 469 */     for (Component setting : this.settings) {
/* 470 */       setting.keyPressed(key, scancode, modifiers);
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseDragged(double x, double y, int button, double deltaX, double deltaY) {
/* 475 */     if (this.extended) {
/* 476 */       for (Component setting : this.settings) {
/* 477 */         setting.mouseDragged(x, y, button, deltaX, deltaY);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseClicked(double x, double y, int button) {
/* 483 */     if (isHovered(x, y)) {
/*     */       
/* 485 */       this.rippleX = x;
/* 486 */       this.rippleY = y;
/* 487 */       this.rippleAnimation = 1.0F;
/* 488 */       this.pressAnimation = 1.0F;
/*     */       
/* 490 */       if (button == 0) {
/*     */         
/* 492 */         int toggleX = this.parent.getX() + this.parent.getWidth() - 42 - 10;
/* 493 */         int toggleY = this.parent.getY() + this.offset + this.parent.getHeight() / 2 - 11;
/*     */         
/* 495 */         if (x >= toggleX && x <= (toggleX + 42) && y >= toggleY && y <= (toggleY + 22)) {
/* 496 */           this.module.toggle();
/* 497 */         } else if (!this.module.getSettings().isEmpty() && x > (this.parent.getX() + this.parent.getWidth() - 75)) {
/*     */           
/* 499 */           if (!this.extended) {
/* 500 */             onExtend();
/*     */           }
/* 502 */           this.extended = !this.extended;
/*     */         } else {
/*     */           
/* 505 */           this.module.toggle();
/*     */         } 
/* 507 */       } else if (button == 1) {
/*     */         
/* 509 */         if (this.module.getSettings().isEmpty()) {
/*     */           return;
/*     */         }
/* 512 */         if (!this.extended) {
/* 513 */           onExtend();
/*     */         }
/* 515 */         this.extended = !this.extended;
/*     */       } 
/*     */     } 
/*     */     
/* 519 */     if (this.extended) {
/* 520 */       for (Component setting : this.settings) {
/* 521 */         setting.mouseClicked(x, y, button);
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   public void onGuiClose() {
/* 527 */     this.currentAlpha = null;
/* 528 */     this.currentColor = null;
/* 529 */     this.hoverAnimation = 0.0F;
/* 530 */     this.enabledAnimation = this.module.isEnabled() ? 1.0F : 0.0F;
/* 531 */     this.extendAnimation = 0.0F;
/* 532 */     this.pressAnimation = 0.0F;
/* 533 */     this.rippleAnimation = 0.0F;
/*     */     
/* 535 */     for (Component setting : this.settings) {
/* 536 */       setting.onGuiClose();
/*     */     }
/*     */   }
/*     */   
/*     */   public void mouseReleased(double x, double y, int button) {
/* 541 */     for (Component setting : this.settings) {
/* 542 */       setting.mouseReleased(x, y, button);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean isHovered(double x, double y) {
/* 547 */     return (x > this.parent.getX() && x < (this.parent
/* 548 */       .getX() + this.parent.getWidth()) && y > (this.parent
/* 549 */       .getY() + this.offset) && y < (this.parent
/* 550 */       .getY() + this.offset + this.parent.getHeight()));
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\components\ModuleButton.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */