/*      */ package dev.FORE.gui;
/*      */ import dev.FORE.DonutBBC;
/*      */ import dev.FORE.gui.components.FriendsBox;
/*      */ import dev.FORE.gui.components.ModuleButton;
/*      */ import dev.FORE.module.Category;
/*      */ import dev.FORE.module.Module;
/*      */ import dev.FORE.module.modules.client.DonutBBC;
/*      */ import dev.FORE.module.setting.BindSetting;
/*      */ import dev.FORE.module.setting.BlocksSetting;
/*      */ import dev.FORE.module.setting.BooleanSetting;
/*      */ import dev.FORE.module.setting.ColorSetting;
/*      */ import dev.FORE.module.setting.FriendsSetting;
/*      */ import dev.FORE.module.setting.ItemSetting;
/*      */ import dev.FORE.module.setting.ItemsSetting;
/*      */ import dev.FORE.module.setting.MacroSetting;
/*      */ import dev.FORE.module.setting.MinMaxSetting;
/*      */ import dev.FORE.module.setting.ModeSetting;
/*      */ import dev.FORE.module.setting.NumberSetting;
/*      */ import dev.FORE.module.setting.Setting;
/*      */ import dev.FORE.module.setting.StringSetting;
/*      */ import dev.FORE.utils.RenderUtils;
/*      */ import dev.FORE.utils.TextRenderer;
/*      */ import java.awt.Color;
/*      */ import java.util.List;
/*      */ import net.minecraft.class_1792;
/*      */ import net.minecraft.class_310;
/*      */ import net.minecraft.class_332;
/*      */ import net.minecraft.class_437;
/*      */ 
/*      */ public final class ClickGUI extends class_437 {
/*   31 */   private static final Color BG_DEEPEST = new Color(8, 8, 12, 250); public Color currentColor;
/*   32 */   private static final Color BG_DEEP = new Color(14, 14, 20, 240);
/*   33 */   private static final Color BG_CARD = new Color(20, 20, 28, 230);
/*   34 */   private static final Color BG_ELEVATED = new Color(28, 28, 38, 220);
/*   35 */   private static final Color BG_HOVER = new Color(35, 35, 48, 200);
/*      */   
/*   37 */   private static final Color ACCENT_PRIMARY = new Color(124, 58, 237);
/*   38 */   private static final Color ACCENT_GLOW = new Color(167, 139, 250);
/*   39 */   private static final Color ACCENT_SECONDARY = new Color(59, 130, 246);
/*   40 */   private static final Color ACCENT_TERTIARY = new Color(236, 72, 153);
/*      */   
/*   42 */   private static final Color TEXT_PRIMARY = new Color(248, 250, 252);
/*   43 */   private static final Color TEXT_SECONDARY = new Color(203, 213, 225);
/*   44 */   private static final Color TEXT_MUTED = new Color(148, 163, 184);
/*   45 */   private static final Color TEXT_DIM = new Color(100, 116, 139);
/*      */   
/*   47 */   private static final Color SUCCESS = new Color(34, 197, 94);
/*   48 */   private static final Color ERROR = new Color(239, 68, 68);
/*   49 */   private static final Color DIVIDER = new Color(51, 65, 85, 100);
/*      */ 
/*      */   
/*   52 */   private int guiX = -1; private int guiY = -1;
/*   53 */   private final int GUI_WIDTH = 980;
/*   54 */   private final int GUI_HEIGHT = 640;
/*   55 */   private final int SIDEBAR_WIDTH = 240;
/*   56 */   private final int HEADER_HEIGHT = 72;
/*   57 */   private final int PADDING = 20;
/*   58 */   private final int CARD_RADIUS = 14;
/*      */   
/*      */   private List<CategoryWindow> reaperWindows;
/*      */   
/*      */   private CharSequence tooltipText;
/*      */   private int tooltipX;
/*      */   private int tooltipY;
/*   65 */   private final Color DESCRIPTION_BG = new Color(40, 40, 40, 200);
/*      */   
/*   67 */   private Category selectedCategory = Category.CRYSTAL;
/*   68 */   private Module selectedModule = null;
/*   69 */   private String searchQuery = "";
/*      */   private boolean isSearchFocused = false;
/*   71 */   private int moduleScrollOffset = 0;
/*   72 */   private int settingsScrollOffset = 0;
/*      */ 
/*      */   
/*   75 */   private final Map<Category, Float> categoryHoverAnim = new HashMap<>();
/*   76 */   private final Map<Module, Float> moduleHoverAnim = new HashMap<>();
/*   77 */   private float panelTransition = 0.0F;
/*   78 */   private float searchPulse = 0.0F;
/*   79 */   private float globalTime = 0.0F;
/*      */   
/*      */   private boolean isDragging = false;
/*      */   
/*   83 */   private int dragOffsetX = 0; private int dragOffsetY = 0;
/*      */   private boolean isDraggingSlider = false;
/*   85 */   private Setting draggedSetting = null;
/*      */   private boolean draggedIsMin = false;
/*      */   
/*      */   public ClickGUI() {
/*   89 */     super((class_2561)class_2561.method_43473());
/*      */ 
/*      */     
/*   92 */     for (Category cat : Category.values()) {
/*   93 */       this.categoryHoverAnim.put(cat, Float.valueOf(0.0F));
/*      */     }
/*      */ 
/*      */     
/*   97 */     this.reaperWindows = new ArrayList<>();
/*   98 */     int windowX = 20;
/*   99 */     Category[] categories = Category.values();
/*  100 */     for (Category category : categories) {
/*  101 */       this.reaperWindows.add(new CategoryWindow(windowX, 50, 260, 30, category, this));
/*  102 */       windowX += 270;
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean shouldUseReaperGUI() {
/*  107 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
/*  113 */     if (shouldUseReaperGUI()) {
/*      */       
/*  115 */       if ((class_310.method_1551()).field_1755 == this) {
/*  116 */         if (DonutBBC.INSTANCE.screen != null) {
/*  117 */           DonutBBC.INSTANCE.screen.method_25394(context, 0, 0, delta);
/*      */         }
/*      */         
/*  120 */         if (this.currentColor == null) {
/*  121 */           this.currentColor = new Color(0, 0, 0, 0);
/*      */         } else {
/*  123 */           this.currentColor = new Color(0, 0, 0, this.currentColor.getAlpha());
/*      */         } 
/*      */         
/*  126 */         int alpha = this.currentColor.getAlpha();
/*  127 */         int targetAlpha = DonutBBC.renderBackground.getValue() ? 200 : 0;
/*      */         
/*  129 */         if (alpha != targetAlpha) {
/*  130 */           this.currentColor = ColorUtil.a(0.05F, targetAlpha, this.currentColor);
/*      */         }
/*      */         
/*  133 */         if ((class_310.method_1551()).field_1755 instanceof ClickGUI) {
/*  134 */           context.method_25294(0, 0, class_310.method_1551().method_22683().method_4480(), 
/*  135 */               class_310.method_1551().method_22683().method_4507(), this.currentColor.getRGB());
/*      */         }
/*      */         
/*  138 */         RenderUtils.unscaledProjection();
/*      */         
/*  140 */         int scaledMouseX = mouseX * (int)class_310.method_1551().method_22683().method_4495();
/*  141 */         int scaledMouseY = mouseY * (int)class_310.method_1551().method_22683().method_4495();
/*      */         
/*  143 */         super.method_25394(context, scaledMouseX, scaledMouseY, delta);
/*      */         
/*  145 */         for (CategoryWindow window : this.reaperWindows) {
/*  146 */           window.render(context, scaledMouseX, scaledMouseY, delta);
/*  147 */           window.updatePosition(scaledMouseX, scaledMouseY, delta);
/*      */         } 
/*      */         
/*  150 */         if (this.tooltipText != null) {
/*  151 */           renderReaperTooltip(context, this.tooltipText, this.tooltipX, this.tooltipY);
/*  152 */           this.tooltipText = null;
/*      */         } 
/*      */         
/*  155 */         RenderUtils.scaledProjection();
/*      */       } 
/*      */     } else {
/*      */       
/*  159 */       int scaledMouseX = (int)(mouseX * class_310.method_1551().method_22683().method_4495());
/*  160 */       int scaledMouseY = (int)(mouseY * class_310.method_1551().method_22683().method_4495());
/*      */       
/*  162 */       RenderUtils.unscaledProjection();
/*      */       
/*  164 */       if (this.guiX == -1 || this.guiY == -1) {
/*  165 */         int screenW = class_310.method_1551().method_22683().method_4480();
/*  166 */         int screenH = class_310.method_1551().method_22683().method_4507();
/*  167 */         this.guiX = (screenW - 980) / 2;
/*  168 */         this.guiY = (screenH - 640) / 2;
/*      */       } 
/*      */       
/*  171 */       if (this.isDragging) {
/*  172 */         this.guiX = scaledMouseX - this.dragOffsetX;
/*  173 */         this.guiY = scaledMouseY - this.dragOffsetY;
/*      */       } 
/*      */       
/*  176 */       this.globalTime += delta * 0.05F;
/*  177 */       this.panelTransition = Math.min(1.0F, this.panelTransition + delta * 0.08F);
/*  178 */       this.searchPulse = (float)Math.sin((this.globalTime * 2.0F)) * 0.5F + 0.5F;
/*      */       
/*  180 */       renderBackdrop(context);
/*  181 */       renderMainContainer(context, scaledMouseX, scaledMouseY, delta);
/*      */       
/*  183 */       RenderUtils.scaledProjection();
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderReaperTooltip(class_332 drawContext, CharSequence charSequence, int x, int y) {
/*  189 */     if (charSequence == null || charSequence.length() == 0) {
/*      */       return;
/*      */     }
/*  192 */     int width = TextRenderer.getWidth(charSequence);
/*  193 */     int framebufferWidth = class_310.method_1551().method_22683().method_4489();
/*  194 */     if (x + width + 10 > framebufferWidth) {
/*  195 */       x = framebufferWidth - width - 10;
/*      */     }
/*  197 */     RenderUtils.renderRoundedQuad(drawContext.method_51448(), this.DESCRIPTION_BG, (x - 5), (y - 5), (x + width + 5), (y + 15), 6.0D, 6.0D, 6.0D, 6.0D, 50.0D);
/*      */     
/*  199 */     TextRenderer.drawString(charSequence, drawContext, x, y, Color.WHITE.getRGB());
/*      */   }
/*      */   
/*      */   public void setTooltip(CharSequence tooltipText, int tooltipX, int tooltipY) {
/*  203 */     this.tooltipText = tooltipText;
/*  204 */     this.tooltipX = tooltipX;
/*  205 */     this.tooltipY = tooltipY;
/*      */   }
/*      */   
/*      */   private void renderBackdrop(class_332 context) {
/*  209 */     int screenW = class_310.method_1551().method_22683().method_4480();
/*  210 */     int screenH = class_310.method_1551().method_22683().method_4507();
/*      */     
/*  212 */     Color gradTop = new Color(6, 6, 10, 200);
/*  213 */     Color gradBot = new Color(15, 10, 25, 220);
/*  214 */     context.method_25296(0, 0, screenW, screenH, gradTop.getRGB(), gradBot.getRGB());
/*      */     
/*  216 */     long time = System.currentTimeMillis();
/*      */     
/*  218 */     float orb1X = (float)(screenW * 0.2D + Math.sin(time / 8000.0D) * 150.0D);
/*  219 */     float orb1Y = (float)(screenH * 0.3D + Math.cos(time / 6000.0D) * 100.0D);
/*  220 */     renderGlowOrb(context, orb1X, orb1Y, 180.0F, ACCENT_PRIMARY, 3);
/*      */     
/*  222 */     float orb2X = (float)(screenW * 0.75D + Math.cos(time / 7000.0D) * 120.0D);
/*  223 */     float orb2Y = (float)(screenH * 0.6D + Math.sin(time / 9000.0D) * 80.0D);
/*  224 */     renderGlowOrb(context, orb2X, orb2Y, 140.0F, ACCENT_SECONDARY, 2);
/*      */     
/*  226 */     float orb3X = (float)(screenW * 0.5D + Math.sin(time / 5000.0D) * 100.0D);
/*  227 */     float orb3Y = (float)(screenH * 0.8D + Math.cos(time / 8000.0D) * 60.0D);
/*  228 */     renderGlowOrb(context, orb3X, orb3Y, 100.0F, ACCENT_TERTIARY, 2);
/*      */   }
/*      */   
/*      */   private void renderGlowOrb(class_332 context, float x, float y, float size, Color color, int layers) {
/*  232 */     for (int i = layers; i > 0; i--) {
/*  233 */       float layerSize = size * (1.0F - i * 0.2F);
/*  234 */       int alpha = 2 + i * 2;
/*  235 */       Color layerColor = new Color(color.getRed(), color.getGreen(), color.getBlue(), alpha);
/*  236 */       RenderUtils.renderCircle(context.method_51448(), layerColor, x, y, layerSize, 32);
/*      */     } 
/*      */   }
/*      */   
/*      */   private void renderMainContainer(class_332 context, int mouseX, int mouseY, float delta) {
/*  241 */     renderDropShadow(context, this.guiX, this.guiY, 980, 640);
/*      */     
/*  243 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), BG_DEEPEST, this.guiX, this.guiY, 980.0D, 640.0D, 14.0D, 120.0D);
/*      */ 
/*      */ 
/*      */     
/*  247 */     Color borderGlow = new Color(ACCENT_PRIMARY.getRed(), ACCENT_PRIMARY.getGreen(), ACCENT_PRIMARY.getBlue(), 40);
/*  248 */     RenderUtils.renderRoundedOutline(context, borderGlow, this.guiX, this.guiY, (this.guiX + 980), (this.guiY + 640), 14.0D, 14.0D, 14.0D, 14.0D, 1.5D, 120.0D);
/*      */ 
/*      */ 
/*      */     
/*  252 */     renderHeader(context, mouseX, mouseY);
/*  253 */     renderSidebar(context, mouseX, mouseY, delta);
/*  254 */     renderContent(context, mouseX, mouseY, delta);
/*      */     
/*  256 */     if (this.selectedModule != null) {
/*  257 */       renderSettingsPanel(context, mouseX, mouseY, delta);
/*      */     }
/*      */   }
/*      */   
/*      */   private void renderDropShadow(class_332 context, int x, int y, int width, int height) {
/*  262 */     int shadowSize = 20;
/*  263 */     for (int i = 0; i < shadowSize; i++) {
/*  264 */       int alpha = (shadowSize - i) * 3;
/*  265 */       Color shadowColor = new Color(0, 0, 0, alpha);
/*  266 */       RenderUtils.renderRoundedQuadShader(context.method_51448(), shadowColor, (x - i), (y - i), (width + i * 2), (height + i * 2), (14 + i), 80.0D);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderHeader(class_332 context, int mouseX, int mouseY) {
/*  272 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), BG_DEEP, this.guiX, this.guiY, 980.0D, 72.0D, 14.0D, 100.0D);
/*      */ 
/*      */     
/*  275 */     int lineY = this.guiY + 72 - 1;
/*  276 */     context.method_25296(this.guiX + 20, lineY, this.guiX + 980 - 20, lineY + 2, (new Color(ACCENT_PRIMARY
/*  277 */           .getRed(), ACCENT_PRIMARY.getGreen(), ACCENT_PRIMARY
/*  278 */           .getBlue(), 80)).getRGB(), (new Color(ACCENT_TERTIARY
/*  279 */           .getRed(), ACCENT_TERTIARY.getGreen(), ACCENT_TERTIARY
/*  280 */           .getBlue(), 80)).getRGB());
/*      */     
/*  282 */     int titleX = this.guiX + 20 + 8;
/*  283 */     int titleY = this.guiY + 24;
/*      */     
/*  285 */     RenderUtils.renderCircle(context.method_51448(), ACCENT_PRIMARY, (titleX + 12), (titleY + 12), 12.0D, 16);
/*      */     
/*  287 */     RenderUtils.renderCircle(context.method_51448(), ACCENT_GLOW, (titleX + 12), (titleY + 12), 8.0D, 16);
/*      */ 
/*      */     
/*  290 */     TextRenderer.drawString("4E", context, titleX + 38, titleY + 3, TEXT_PRIMARY.getRGB());
/*  291 */     TextRenderer.drawString("CLIENT", context, titleX + 38, titleY + 14, TEXT_MUTED.getRGB());
/*      */     
/*  293 */     int versionX = titleX + 130;
/*  294 */     int versionY = titleY + 5;
/*  295 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), new Color(ACCENT_PRIMARY
/*  296 */           .getRed(), ACCENT_PRIMARY.getGreen(), ACCENT_PRIMARY
/*  297 */           .getBlue(), 80), versionX, versionY, 50.0D, 18.0D, 9.0D, 60.0D);
/*      */     
/*  299 */     TextRenderer.drawCenteredString("v1.3", context, versionX + 25, versionY + 5, ACCENT_GLOW
/*  300 */         .getRGB());
/*      */     
/*  302 */     int btnY = this.guiY + 18;
/*  303 */     int closeX = this.guiX + 980 - 20 - 36;
/*  304 */     boolean closeHovered = isPointInRect(mouseX, mouseY, closeX, btnY, 36, 36);
/*      */ 
/*      */ 
/*      */     
/*  308 */     Color closeBg = closeHovered ? new Color(ERROR.getRed(), ERROR.getGreen(), ERROR.getBlue(), 120) : new Color(BG_ELEVATED.getRed(), BG_ELEVATED.getGreen(), BG_ELEVATED.getBlue(), 100);
/*  309 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), closeBg, closeX, btnY, 36.0D, 36.0D, 10.0D, 60.0D);
/*      */ 
/*      */     
/*  312 */     Color textColor = closeHovered ? TEXT_PRIMARY : TEXT_SECONDARY;
/*  313 */     TextRenderer.drawCenteredString("✕", context, closeX + 18, btnY + 11, textColor.getRGB());
/*      */   }
/*      */   
/*      */   private void renderSidebar(class_332 context, int mouseX, int mouseY, float delta) {
/*  317 */     int sidebarX = this.guiX;
/*  318 */     int sidebarY = this.guiY + 72;
/*  319 */     int sidebarH = 568;
/*      */     
/*  321 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), BG_DEEP, sidebarX, sidebarY, 240.0D, sidebarH, 0.0D, 100.0D);
/*      */ 
/*      */     
/*  324 */     int contentY = sidebarY + 20;
/*  325 */     TextRenderer.drawString("CATEGORIES", context, sidebarX + 20, contentY, TEXT_DIM
/*  326 */         .getRGB());
/*  327 */     contentY += 32;
/*      */     
/*  329 */     Category[] categories = Category.values();
/*  330 */     for (Category cat : categories) {
/*  331 */       Color btnBg; boolean isSelected = (cat == this.selectedCategory);
/*  332 */       boolean isHovered = isPointInRect(mouseX, mouseY, sidebarX + 12, contentY, 216, 50);
/*      */ 
/*      */       
/*  335 */       float targetAnim = isHovered ? 1.0F : (isSelected ? 0.5F : 0.0F);
/*  336 */       float currentAnim = ((Float)this.categoryHoverAnim.get(cat)).floatValue();
/*  337 */       this.categoryHoverAnim.put(cat, Float.valueOf(currentAnim + (targetAnim - currentAnim) * delta * 0.15F));
/*  338 */       float anim = ((Float)this.categoryHoverAnim.get(cat)).floatValue();
/*      */       
/*  340 */       int btnX = sidebarX + 12;
/*  341 */       int btnW = 216;
/*      */ 
/*      */       
/*  344 */       if (isSelected) {
/*      */ 
/*      */ 
/*      */         
/*  348 */         btnBg = new Color((int)(ACCENT_PRIMARY.getRed() + (BG_CARD.getRed() - ACCENT_PRIMARY.getRed()) * (1.0F - anim)), (int)(ACCENT_PRIMARY.getGreen() + (BG_CARD.getGreen() - ACCENT_PRIMARY.getGreen()) * (1.0F - anim)), (int)(ACCENT_PRIMARY.getBlue() + (BG_CARD.getBlue() - ACCENT_PRIMARY.getBlue()) * (1.0F - anim)), 140 + (int)(40.0F * anim));
/*      */       }
/*      */       else {
/*      */         
/*  352 */         btnBg = new Color(BG_CARD.getRed(), BG_CARD.getGreen(), BG_CARD.getBlue(), 80 + (int)(80.0F * anim));
/*      */       } 
/*      */ 
/*      */       
/*  356 */       RenderUtils.renderRoundedQuadShader(context.method_51448(), btnBg, btnX, contentY, btnW, 50.0D, 12.0D, 80.0D);
/*      */ 
/*      */       
/*  359 */       if (isSelected) {
/*  360 */         int barAlpha = 180 + (int)(75.0D * Math.sin((this.globalTime * 3.0F)));
/*      */         
/*  362 */         Color barColor = new Color(ACCENT_GLOW.getRed(), ACCENT_GLOW.getGreen(), ACCENT_GLOW.getBlue(), barAlpha);
/*  363 */         RenderUtils.renderRoundedQuadShader(context.method_51448(), barColor, (btnX + 4), (contentY + 10), 3.0D, 30.0D, 2.0D, 50.0D);
/*      */       } 
/*      */ 
/*      */       
/*  367 */       int iconX = btnX + 22;
/*  368 */       int iconY = contentY + 25;
/*  369 */       Color iconColor = isSelected ? ACCENT_GLOW : TEXT_MUTED;
/*  370 */       RenderUtils.renderCircle(context.method_51448(), iconColor, iconX, iconY, 7.0D, 16);
/*  371 */       if (isSelected) {
/*  372 */         RenderUtils.renderCircle(context.method_51448(), new Color(255, 255, 255, 100), iconX, iconY, 4.0D, 12);
/*      */       }
/*      */ 
/*      */       
/*  376 */       int textX = iconX + 20;
/*  377 */       int textY = contentY + 20;
/*  378 */       Color textColor = isSelected ? TEXT_PRIMARY : TEXT_SECONDARY;
/*  379 */       TextRenderer.drawString(cat.name, context, textX, textY, textColor.getRGB());
/*      */       
/*  381 */       int moduleCount = DonutBBC.INSTANCE.getModuleManager().a(cat).size();
/*  382 */       String countStr = String.valueOf(moduleCount);
/*  383 */       int badgeW = 32;
/*  384 */       int badgeX = btnX + btnW - badgeW - 8;
/*  385 */       int badgeY = contentY + 16;
/*      */ 
/*      */       
/*  388 */       Color badgeBg = isSelected ? new Color(BG_DEEPEST.getRed(), BG_DEEPEST.getGreen(), BG_DEEPEST.getBlue(), 150) : BG_ELEVATED;
/*  389 */       RenderUtils.renderRoundedQuadShader(context.method_51448(), badgeBg, badgeX, badgeY, badgeW, 20.0D, 10.0D, 50.0D);
/*      */       
/*  391 */       TextRenderer.drawCenteredString(countStr, context, badgeX + 16, badgeY + 6, TEXT_MUTED
/*  392 */           .getRGB());
/*      */       
/*  394 */       contentY += 58;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void renderContent(class_332 context, int mouseX, int mouseY, float delta) {
/*  399 */     int contentX = this.guiX + 240;
/*  400 */     int contentY = this.guiY + 72;
/*  401 */     int contentW = 740 - ((this.selectedModule != null) ? 320 : 0);
/*  402 */     int contentH = 568;
/*      */     
/*  404 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), BG_CARD, contentX, contentY, contentW, contentH, 0.0D, 100.0D);
/*      */ 
/*      */     
/*  407 */     renderSearchBar(context, contentX, contentY, contentW, mouseX, mouseY);
/*      */     
/*  409 */     int gridY = contentY + 90;
/*  410 */     int gridH = contentH - 90;
/*  411 */     renderModulesGrid(context, contentX, gridY, contentW, gridH, mouseX, mouseY, delta);
/*      */   }
/*      */   
/*      */   private void renderSearchBar(class_332 context, int x, int y, int width, int mouseX, int mouseY) {
/*  415 */     int searchX = x + 20;
/*  416 */     int searchY = y + 20;
/*  417 */     int searchW = width - 40;
/*  418 */     int searchH = 52;
/*      */     
/*  420 */     boolean hovered = isPointInRect(mouseX, mouseY, searchX, searchY, searchW, searchH);
/*      */ 
/*      */ 
/*      */     
/*  424 */     Color searchBg = this.isSearchFocused ? BG_ELEVATED : (hovered ? BG_HOVER : new Color(BG_DEEP.getRed(), BG_DEEP.getGreen(), BG_DEEP.getBlue(), 150));
/*      */     
/*  426 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), searchBg, searchX, searchY, searchW, searchH, 12.0D, 80.0D);
/*      */ 
/*      */     
/*  429 */     if (this.isSearchFocused) {
/*  430 */       int glowAlpha = 60 + (int)(40.0F * this.searchPulse);
/*      */       
/*  432 */       Color glowColor = new Color(ACCENT_PRIMARY.getRed(), ACCENT_PRIMARY.getGreen(), ACCENT_PRIMARY.getBlue(), glowAlpha);
/*  433 */       RenderUtils.renderRoundedOutline(context, glowColor, searchX, searchY, (searchX + searchW), (searchY + searchH), 12.0D, 12.0D, 12.0D, 12.0D, 2.0D, 80.0D);
/*      */     } 
/*      */ 
/*      */     
/*  437 */     int iconX = searchX + 18;
/*  438 */     int iconY = searchY + 20;
/*  439 */     TextRenderer.drawString("🔍", context, iconX, iconY, TEXT_SECONDARY.getRGB());
/*      */     
/*  441 */     String displayText = this.searchQuery.isEmpty() ? "Search modules..." : this.searchQuery;
/*  442 */     Color textColor = this.searchQuery.isEmpty() ? TEXT_DIM : TEXT_PRIMARY;
/*  443 */     int textX = iconX + 32;
/*  444 */     int textY = searchY + 20;
/*  445 */     TextRenderer.drawString(displayText, context, textX, textY, textColor.getRGB());
/*      */     
/*  447 */     if (this.isSearchFocused && System.currentTimeMillis() / 600L % 2L == 0L) {
/*  448 */       int cursorX = textX + TextRenderer.getWidth(this.searchQuery);
/*  449 */       int cursorH = 16;
/*  450 */       context.method_25294(cursorX, textY - 2, cursorX + 2, textY + cursorH, ACCENT_PRIMARY
/*  451 */           .getRGB());
/*      */     } 
/*      */     
/*  454 */     if (!this.searchQuery.isEmpty()) {
/*  455 */       int clearX = searchX + searchW - 40;
/*  456 */       int clearY = searchY + (searchH - 28) / 2;
/*  457 */       boolean clearHovered = isPointInRect(mouseX, mouseY, clearX, clearY, 28, 28);
/*      */ 
/*      */       
/*  460 */       Color clearBg = clearHovered ? new Color(ERROR.getRed(), ERROR.getGreen(), ERROR.getBlue(), 100) : BG_ELEVATED;
/*  461 */       RenderUtils.renderRoundedQuadShader(context.method_51448(), clearBg, clearX, clearY, 28.0D, 28.0D, 8.0D, 50.0D);
/*      */       
/*  463 */       TextRenderer.drawCenteredString("✕", context, clearX + 14, clearY + 8, TEXT_SECONDARY
/*  464 */           .getRGB());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderModulesGrid(class_332 context, int x, int y, int width, int height, int mouseX, int mouseY, float delta) {
/*  470 */     List<Module> modules = DonutBBC.INSTANCE.getModuleManager().a(this.selectedCategory);
/*      */     
/*  472 */     if (!this.searchQuery.isEmpty())
/*      */     {
/*      */ 
/*      */       
/*  476 */       modules = (List<Module>)modules.stream().filter(m -> m.getName().toString().toLowerCase().contains(this.searchQuery.toLowerCase())).collect(Collectors.toList());
/*      */     }
/*      */     
/*  479 */     int cardW = 280;
/*  480 */     int cardH = 110;
/*  481 */     int gap = 16;
/*  482 */     int cols = Math.max(1, (width - 40) / (cardW + gap));
/*      */     
/*  484 */     int startX = x + 20;
/*  485 */     int startY = y + 20;
/*      */     
/*  487 */     double scale = class_310.method_1551().method_22683().method_4495();
/*  488 */     context.method_44379((int)(x / scale), (int)(y / scale), (int)((x + width) / scale), (int)((y + height) / scale));
/*      */ 
/*      */     
/*  491 */     for (int i = 0; i < modules.size(); i++) {
/*  492 */       Module module = modules.get(i);
/*      */       
/*  494 */       if (!this.moduleHoverAnim.containsKey(module)) {
/*  495 */         this.moduleHoverAnim.put(module, Float.valueOf(0.0F));
/*      */       }
/*      */       
/*  498 */       int row = i / cols;
/*  499 */       int col = i % cols;
/*  500 */       int cardX = startX + col * (cardW + gap);
/*  501 */       int cardY = startY + row * (cardH + gap) - this.moduleScrollOffset * 50;
/*      */       
/*  503 */       if (cardY + cardH >= y && cardY <= y + height) {
/*      */         Color cardBg;
/*  505 */         boolean hovered = isPointInRect(mouseX, mouseY, cardX, cardY, cardW, cardH);
/*  506 */         boolean enabled = module.isEnabled();
/*  507 */         boolean selected = (module == this.selectedModule);
/*      */         
/*  509 */         float targetAnim = hovered ? 1.0F : 0.0F;
/*  510 */         float currentAnim = ((Float)this.moduleHoverAnim.get(module)).floatValue();
/*  511 */         this.moduleHoverAnim.put(module, Float.valueOf(currentAnim + (targetAnim - currentAnim) * delta * 0.15F));
/*  512 */         float anim = ((Float)this.moduleHoverAnim.get(module)).floatValue();
/*      */         
/*  514 */         int liftOffset = (int)(anim * -3.0F);
/*      */         
/*  516 */         if (selected) {
/*      */           
/*  518 */           cardBg = new Color(BG_ELEVATED.getRed(), BG_ELEVATED.getGreen(), BG_ELEVATED.getBlue(), 220);
/*      */         } else {
/*  520 */           cardBg = new Color(BG_CARD.getRed(), BG_CARD.getGreen(), BG_CARD.getBlue(), 180 + (int)(40.0F * anim));
/*      */         } 
/*      */ 
/*      */         
/*  524 */         RenderUtils.renderRoundedQuadShader(context.method_51448(), cardBg, cardX, (cardY + liftOffset), cardW, cardH, 12.0D, 80.0D);
/*      */ 
/*      */         
/*  527 */         if (enabled || selected) {
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*  532 */           Color borderColor = enabled ? new Color(SUCCESS.getRed(), SUCCESS.getGreen(), SUCCESS.getBlue(), 100 + (int)(60.0F * anim)) : new Color(ACCENT_PRIMARY.getRed(), ACCENT_PRIMARY.getGreen(), ACCENT_PRIMARY.getBlue(), 80);
/*  533 */           RenderUtils.renderRoundedOutline(context, borderColor, cardX, (cardY + liftOffset), (cardX + cardW), (cardY + liftOffset + cardH), 12.0D, 12.0D, 12.0D, 12.0D, 1.5D + anim, 80.0D);
/*      */         } 
/*      */ 
/*      */ 
/*      */         
/*  538 */         int statusX = cardX + 16;
/*  539 */         int statusY = cardY + liftOffset + 20;
/*  540 */         Color statusColor = enabled ? SUCCESS : new Color(71, 85, 105);
/*      */         
/*  542 */         if (enabled) {
/*  543 */           int pulseAlpha = 20 + (int)(15.0D * Math.sin((this.globalTime * 4.0F)));
/*  544 */           RenderUtils.renderCircle(context.method_51448(), new Color(SUCCESS
/*  545 */                 .getRed(), SUCCESS.getGreen(), SUCCESS.getBlue(), pulseAlpha), statusX, statusY, 10.0D, 16);
/*      */         } 
/*      */         
/*  548 */         RenderUtils.renderCircle(context.method_51448(), statusColor, statusX, statusY, 6.0D, 16);
/*      */         
/*  550 */         int nameX = statusX + 20;
/*  551 */         int nameY = cardY + liftOffset + 15;
/*  552 */         TextRenderer.drawString(module.getName().toString(), context, nameX, nameY, TEXT_PRIMARY
/*  553 */             .getRGB());
/*      */         
/*  555 */         String desc = module.getDescription().toString();
/*  556 */         int descMaxW = cardW - 32;
/*  557 */         if (TextRenderer.getWidth(desc) > descMaxW) {
/*  558 */           while (TextRenderer.getWidth(desc + "...") > descMaxW && desc.length() > 1) {
/*  559 */             desc = desc.substring(0, desc.length() - 1);
/*      */           }
/*  561 */           desc = desc + "...";
/*      */         } 
/*  563 */         int descY = cardY + liftOffset + 52;
/*  564 */         TextRenderer.drawString(desc, context, cardX + 16, descY, TEXT_MUTED.getRGB());
/*      */         
/*  566 */         int footerY = cardY + liftOffset + cardH - 36;
/*      */         
/*  568 */         if (!module.getSettings().isEmpty()) {
/*  569 */           int settingsCount = module.getSettings().size();
/*  570 */           String settingsText = "" + settingsCount + " setting" + settingsCount;
/*  571 */           TextRenderer.drawString(settingsText, context, cardX + 16, footerY + 8, TEXT_DIM
/*  572 */               .getRGB());
/*      */         } 
/*      */         
/*  575 */         int switchX = cardX + cardW - 60;
/*  576 */         int switchY = footerY;
/*  577 */         renderEnhancedSwitch(context, switchX, switchY, enabled, (hovered || selected));
/*      */       } 
/*      */     } 
/*  580 */     context.method_44380();
/*      */     
/*  582 */     if (modules.isEmpty()) {
/*  583 */       int emptyY = y + height / 2 - 40;
/*  584 */       TextRenderer.drawCenteredString("No modules found", context, x + width / 2, emptyY, TEXT_MUTED
/*  585 */           .getRGB());
/*  586 */       TextRenderer.drawCenteredString("Try a different search term", context, x + width / 2, emptyY + 20, TEXT_DIM
/*  587 */           .getRGB());
/*      */     } 
/*      */   }
/*      */   
/*      */   private void renderEnhancedSwitch(class_332 context, int x, int y, boolean enabled, boolean highlighted) {
/*  592 */     int switchW = 48;
/*  593 */     int switchH = 26;
/*      */ 
/*      */ 
/*      */     
/*  597 */     Color trackColor = enabled ? new Color(SUCCESS.getRed(), SUCCESS.getGreen(), SUCCESS.getBlue(), 180) : new Color(71, 85, 105, 150);
/*      */     
/*  599 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), trackColor, x, y, switchW, switchH, 13.0D, 60.0D);
/*      */ 
/*      */     
/*  602 */     if (!enabled) {
/*  603 */       Color innerShadow = new Color(0, 0, 0, 30);
/*  604 */       RenderUtils.renderRoundedQuadShader(context.method_51448(), innerShadow, (x + 2), (y + 2), (switchW - 4), (switchH - 4), 11.0D, 50.0D);
/*      */     } 
/*      */ 
/*      */     
/*  608 */     int knobSize = 20;
/*  609 */     float knobX = enabled ? (x + switchW - knobSize - 3) : (x + 3);
/*      */     
/*  611 */     Color knobShadow = new Color(0, 0, 0, 40);
/*  612 */     RenderUtils.renderCircle(context.method_51448(), knobShadow, (knobX + knobSize / 2.0F + 1.0F), (y + switchH / 2.0F + 1.0F), (knobSize / 2.0F + 1.0F), 16);
/*      */ 
/*      */ 
/*      */     
/*  616 */     Color knobColor = enabled ? new Color(248, 250, 252) : new Color(203, 213, 225);
/*  617 */     RenderUtils.renderCircle(context.method_51448(), knobColor, (knobX + knobSize / 2.0F), (y + switchH / 2.0F), (knobSize / 2.0F), 20);
/*      */ 
/*      */     
/*  620 */     if (highlighted || enabled) {
/*  621 */       Color highlight = new Color(255, 255, 255, enabled ? 120 : 60);
/*  622 */       RenderUtils.renderCircle(context.method_51448(), highlight, (knobX + knobSize / 2.0F - 2.0F), (y + switchH / 2.0F - 2.0F), 4.0D, 12);
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderSettingsPanel(class_332 context, int mouseX, int mouseY, float delta) {
/*  628 */     int panelW = 320;
/*  629 */     int panelX = this.guiX + 980 - panelW;
/*  630 */     int panelY = this.guiY + 72;
/*  631 */     int panelH = 568;
/*      */     
/*  633 */     int slideOffset = (int)((1.0F - this.panelTransition) * 50.0F);
/*      */     
/*  635 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), BG_DEEP, (panelX + slideOffset), panelY, panelW, panelH, 0.0D, 100.0D);
/*      */ 
/*      */     
/*  638 */     context.method_25294(panelX + slideOffset, panelY, panelX + slideOffset + 1, panelY + panelH, DIVIDER
/*  639 */         .getRGB());
/*      */     
/*  641 */     int headerY = panelY + 20;
/*      */     
/*  643 */     int iconX = panelX + slideOffset + 20;
/*  644 */     RenderUtils.renderCircle(context.method_51448(), ACCENT_PRIMARY, (iconX + 6), (headerY + 8), 6.0D, 12);
/*      */ 
/*      */     
/*  647 */     String moduleName = this.selectedModule.getName().toString();
/*  648 */     int nameX = iconX + 20;
/*  649 */     TextRenderer.drawString(moduleName, context, nameX, headerY + 3, TEXT_PRIMARY
/*  650 */         .getRGB());
/*      */     
/*  652 */     boolean enabled = this.selectedModule.isEnabled();
/*  653 */     String statusText = enabled ? "ENABLED" : "DISABLED";
/*  654 */     Color statusColor = enabled ? SUCCESS : TEXT_MUTED;
/*  655 */     int statusY = headerY + 22;
/*  656 */     TextRenderer.drawString(statusText, context, nameX, statusY, statusColor.getRGB());
/*      */     
/*  658 */     int closeX = panelX + slideOffset + panelW - 20 - 32;
/*  659 */     int closeY = headerY;
/*  660 */     boolean closeHovered = isPointInRect(mouseX, mouseY, closeX, closeY, 32, 32);
/*      */ 
/*      */     
/*  663 */     Color closeBg = closeHovered ? new Color(ERROR.getRed(), ERROR.getGreen(), ERROR.getBlue(), 100) : BG_ELEVATED;
/*  664 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), closeBg, closeX, closeY, 32.0D, 32.0D, 10.0D, 60.0D);
/*      */     
/*  666 */     TextRenderer.drawCenteredString("✕", context, closeX + 16, closeY + 10, TEXT_SECONDARY
/*  667 */         .getRGB());
/*      */     
/*  669 */     int settingsStartY = headerY + 70;
/*  670 */     int availableHeight = panelH - settingsStartY - panelY - 20;
/*      */     
/*  672 */     double scale = class_310.method_1551().method_22683().method_4495();
/*  673 */     context.method_44379((int)((panelX + slideOffset) / scale), (int)(settingsStartY / scale), (int)((panelX + slideOffset + panelW) / scale), (int)((settingsStartY + availableHeight) / scale));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  678 */     int settingY = settingsStartY - this.settingsScrollOffset;
/*  679 */     List<Setting> settings = this.selectedModule.getSettings();
/*      */     
/*  681 */     if (settings.isEmpty()) {
/*  682 */       int emptyY = settingsStartY + availableHeight / 2 - 20;
/*  683 */       TextRenderer.drawCenteredString("No settings available", context, panelX + slideOffset + panelW / 2, emptyY, TEXT_MUTED
/*  684 */           .getRGB());
/*      */     } else {
/*  686 */       for (Setting setting : settings) {
/*  687 */         int itemHeight = getSettingHeight(setting);
/*      */         
/*  689 */         if (settingY + itemHeight >= settingsStartY && settingY <= settingsStartY + availableHeight) {
/*  690 */           renderSettingItem(context, panelX + slideOffset + 20, settingY, panelW - 40, setting, mouseX, mouseY);
/*      */         }
/*      */ 
/*      */         
/*  694 */         settingY += itemHeight + 16;
/*      */       } 
/*      */     } 
/*      */     
/*  698 */     context.method_44380();
/*      */     
/*  700 */     int totalHeight = getTotalSettingsHeight(settings);
/*  701 */     if (totalHeight > availableHeight) {
/*  702 */       renderScrollbar(context, panelX + slideOffset, settingsStartY, panelW, availableHeight, totalHeight, this.settingsScrollOffset);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderScrollbar(class_332 context, int panelX, int startY, int panelW, int viewHeight, int contentHeight, int scrollOffset) {
/*  709 */     int scrollbarW = 5;
/*  710 */     int scrollbarX = panelX + panelW - 10 - scrollbarW;
/*      */     
/*  712 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), new Color(BG_ELEVATED
/*  713 */           .getRed(), BG_ELEVATED.getGreen(), BG_ELEVATED
/*  714 */           .getBlue(), 100), scrollbarX, startY, scrollbarW, viewHeight, 3.0D, 50.0D);
/*      */ 
/*      */     
/*  717 */     float scrollRatio = viewHeight / contentHeight;
/*  718 */     int thumbHeight = Math.max(30, (int)(viewHeight * scrollRatio));
/*  719 */     float scrollProgress = scrollOffset / (contentHeight - viewHeight);
/*  720 */     int thumbY = startY + (int)((viewHeight - thumbHeight) * scrollProgress);
/*      */     
/*  722 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), ACCENT_PRIMARY, scrollbarX, thumbY, scrollbarW, thumbHeight, 3.0D, 50.0D);
/*      */   }
/*      */ 
/*      */   
/*      */   private int getTotalSettingsHeight(List<Setting> settings) {
/*  727 */     int total = 0;
/*  728 */     for (Setting setting : settings) {
/*  729 */       total += getSettingHeight(setting) + 16;
/*      */     }
/*  731 */     return total;
/*      */   }
/*      */   
/*      */   private int getSettingHeight(Setting setting) {
/*  735 */     if (setting instanceof NumberSetting || setting instanceof MinMaxSetting)
/*  736 */       return 70; 
/*  737 */     if (setting instanceof ColorSetting) {
/*  738 */       return 80;
/*      */     }
/*  740 */     return 64;
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderSettingItem(class_332 context, int x, int y, int width, Setting setting, int mouseX, int mouseY) {
/*  745 */     int itemHeight = getSettingHeight(setting);
/*  746 */     boolean hovered = isPointInRect(mouseX, mouseY, x, y, width, itemHeight);
/*      */ 
/*      */     
/*  749 */     Color itemBg = hovered ? BG_HOVER : new Color(BG_CARD.getRed(), BG_CARD.getGreen(), BG_CARD.getBlue(), 120);
/*  750 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), itemBg, x, y, width, itemHeight, 10.0D, 70.0D);
/*      */ 
/*      */     
/*  753 */     TextRenderer.drawString(setting.getName().toString(), context, x + 14, y + 14, TEXT_SECONDARY
/*  754 */         .getRGB());
/*      */     
/*  756 */     if (setting instanceof BooleanSetting) {
/*  757 */       BooleanSetting bool = (BooleanSetting)setting;
/*  758 */       renderEnhancedSwitch(context, x + width - 60, y + 18, bool.getValue(), hovered);
/*      */     }
/*  760 */     else if (setting instanceof NumberSetting) {
/*  761 */       NumberSetting num = (NumberSetting)setting;
/*  762 */       renderNumberSetting(context, x, y, width, num, mouseX, mouseY, hovered);
/*      */     }
/*  764 */     else if (setting instanceof MinMaxSetting) {
/*  765 */       MinMaxSetting minMax = (MinMaxSetting)setting;
/*  766 */       renderMinMaxSetting(context, x, y, width, minMax, mouseX, mouseY, hovered);
/*      */     }
/*  768 */     else if (setting instanceof ModeSetting) {
/*  769 */       ModeSetting<?> mode = (ModeSetting)setting;
/*  770 */       renderModeSetting(context, x, y, width, mode, hovered);
/*      */     
/*      */     }
/*  773 */     else if (setting instanceof BlocksSetting) {
/*  774 */       BlocksSetting blocks = (BlocksSetting)setting;
/*  775 */       renderCountSetting(context, x, y, width, blocks.size(), "block");
/*      */     }
/*  777 */     else if (setting instanceof ItemsSetting) {
/*  778 */       ItemsSetting items = (ItemsSetting)setting;
/*  779 */       renderCountSetting(context, x, y, width, items.size(), "item");
/*      */     
/*      */     }
/*  782 */     else if (setting instanceof BindSetting) {
/*  783 */       BindSetting bind = (BindSetting)setting;
/*  784 */       renderBindSetting(context, x, y, width, bind, hovered);
/*      */     }
/*  786 */     else if (setting instanceof StringSetting) {
/*  787 */       StringSetting str = (StringSetting)setting;
/*  788 */       renderStringSetting(context, x, y, width, str, hovered);
/*      */     }
/*  790 */     else if (setting instanceof ColorSetting) {
/*  791 */       ColorSetting color = (ColorSetting)setting;
/*  792 */       renderColorSetting(context, x, y, width, color, hovered);
/*      */     }
/*  794 */     else if (setting instanceof ItemSetting) {
/*  795 */       ItemSetting item = (ItemSetting)setting;
/*  796 */       renderItemSetting(context, x, y, width, item);
/*      */     }
/*  798 */     else if (setting instanceof MacroSetting) {
/*  799 */       MacroSetting macro = (MacroSetting)setting;
/*  800 */       renderCountSetting(context, x, y, width, macro.getCommands().size(), "command");
/*      */     }
/*  802 */     else if (setting instanceof FriendsSetting) {
/*  803 */       FriendsSetting friends = (FriendsSetting)setting;
/*  804 */       renderCountSetting(context, x, y, width, friends.size(), "friend");
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderNumberSetting(class_332 context, int x, int y, int width, NumberSetting num, int mouseX, int mouseY, boolean hovered) {
/*  810 */     String value = formatNumberValue(num);
/*  811 */     int valueX = x + width - TextRenderer.getWidth(value) - 14;
/*  812 */     TextRenderer.drawString(value, context, valueX, y + 14, ACCENT_PRIMARY.getRGB());
/*      */     
/*  814 */     int sliderY = y + 42;
/*  815 */     int sliderX = x + 14;
/*  816 */     int sliderW = width - 28;
/*  817 */     int sliderH = 6;
/*      */     
/*  819 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), new Color(BG_ELEVATED
/*  820 */           .getRed(), BG_ELEVATED.getGreen(), BG_ELEVATED
/*  821 */           .getBlue(), 150), sliderX, sliderY, sliderW, sliderH, 3.0D, 50.0D);
/*      */ 
/*      */     
/*  824 */     double progress = (num.getValue() - num.getMin()) / (num.getMax() - num.getMin());
/*  825 */     int progressW = (int)(sliderW * progress);
/*      */ 
/*      */     
/*  828 */     Color progressColor = new Color(ACCENT_PRIMARY.getRed(), ACCENT_PRIMARY.getGreen(), ACCENT_PRIMARY.getBlue(), 200);
/*  829 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), progressColor, sliderX, sliderY, progressW, sliderH, 3.0D, 50.0D);
/*      */ 
/*      */     
/*  832 */     int thumbX = sliderX + progressW;
/*  833 */     int thumbY = sliderY + sliderH / 2;
/*      */     
/*  835 */     boolean thumbHovered = (Math.abs(mouseX - thumbX) < 10 && Math.abs(mouseY - thumbY) < 10);
/*      */     
/*  837 */     if (thumbHovered || this.isDraggingSlider) {
/*  838 */       RenderUtils.renderCircle(context.method_51448(), new Color(ACCENT_PRIMARY
/*  839 */             .getRed(), ACCENT_PRIMARY.getGreen(), ACCENT_PRIMARY
/*  840 */             .getBlue(), 40), thumbX, thumbY, 12.0D, 16);
/*      */     }
/*      */ 
/*      */     
/*  844 */     RenderUtils.renderCircle(context.method_51448(), ACCENT_PRIMARY, thumbX, thumbY, 8.0D, 16);
/*  845 */     RenderUtils.renderCircle(context.method_51448(), new Color(255, 255, 255, 180), thumbX, thumbY, 4.0D, 12);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderMinMaxSetting(class_332 context, int x, int y, int width, MinMaxSetting minMax, int mouseX, int mouseY, boolean hovered) {
/*  851 */     String value = formatMinMaxValue(minMax);
/*  852 */     int valueX = x + width - TextRenderer.getWidth(value) - 14;
/*  853 */     TextRenderer.drawString(value, context, valueX, y + 14, ACCENT_PRIMARY.getRGB());
/*      */     
/*  855 */     int sliderY = y + 42;
/*  856 */     int sliderX = x + 14;
/*  857 */     int sliderW = width - 28;
/*  858 */     int sliderH = 6;
/*      */     
/*  860 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), new Color(BG_ELEVATED
/*  861 */           .getRed(), BG_ELEVATED.getGreen(), BG_ELEVATED
/*  862 */           .getBlue(), 150), sliderX, sliderY, sliderW, sliderH, 3.0D, 50.0D);
/*      */ 
/*      */ 
/*      */     
/*  866 */     double minProgress = (minMax.getCurrentMin() - minMax.getMinValue()) / (minMax.getMaxValue() - minMax.getMinValue());
/*      */     
/*  868 */     double maxProgress = (minMax.getCurrentMax() - minMax.getMinValue()) / (minMax.getMaxValue() - minMax.getMinValue());
/*  869 */     int minX = sliderX + (int)(sliderW * minProgress);
/*  870 */     int maxX = sliderX + (int)(sliderW * maxProgress);
/*      */     
/*  872 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), ACCENT_PRIMARY, minX, sliderY, (maxX - minX), sliderH, 3.0D, 50.0D);
/*      */ 
/*      */     
/*  875 */     int thumbY = sliderY + sliderH / 2;
/*  876 */     RenderUtils.renderCircle(context.method_51448(), ACCENT_PRIMARY, minX, thumbY, 8.0D, 16);
/*  877 */     RenderUtils.renderCircle(context.method_51448(), ACCENT_SECONDARY, maxX, thumbY, 8.0D, 16);
/*  878 */     RenderUtils.renderCircle(context.method_51448(), new Color(255, 255, 255, 180), minX, thumbY, 4.0D, 12);
/*      */     
/*  880 */     RenderUtils.renderCircle(context.method_51448(), new Color(255, 255, 255, 180), maxX, thumbY, 4.0D, 12);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderModeSetting(class_332 context, int x, int y, int width, ModeSetting<?> mode, boolean hovered) {
/*  886 */     String modeName = mode.getValue().name();
/*  887 */     int btnW = Math.min(140, TextRenderer.getWidth(modeName) + 28);
/*  888 */     int btnX = x + width - btnW - 14;
/*  889 */     int btnY = y + 36;
/*      */     
/*  891 */     Color btnBg = hovered ? BG_HOVER : BG_ELEVATED;
/*  892 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), btnBg, btnX, btnY, btnW, 24.0D, 8.0D, 60.0D);
/*      */ 
/*      */     
/*  895 */     TextRenderer.drawCenteredString(modeName, context, btnX + btnW / 2, btnY + 8, ACCENT_PRIMARY
/*  896 */         .getRGB());
/*      */     
/*  898 */     TextRenderer.drawString("‹", context, btnX + 6, btnY + 6, TEXT_MUTED.getRGB());
/*  899 */     TextRenderer.drawString("›", context, btnX + btnW - 14, btnY + 6, TEXT_MUTED.getRGB());
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderBindSetting(class_332 context, int x, int y, int width, BindSetting bind, boolean hovered) {
/*      */     Color btnBg;
/*  905 */     String keyName = bind.isListening() ? "Press a key..." : KeyUtils.getKey(bind.getValue()).toString();
/*  906 */     int btnW = Math.min(140, TextRenderer.getWidth(keyName) + 28);
/*  907 */     int btnX = x + width - btnW - 14;
/*  908 */     int btnY = y + 36;
/*      */ 
/*      */     
/*  911 */     if (bind.isListening()) {
/*  912 */       int pulseAlpha = 100 + (int)(60.0D * Math.sin((this.globalTime * 5.0F)));
/*      */       
/*  914 */       btnBg = new Color(ACCENT_PRIMARY.getRed(), ACCENT_PRIMARY.getGreen(), ACCENT_PRIMARY.getBlue(), pulseAlpha);
/*      */     } else {
/*  916 */       btnBg = hovered ? BG_HOVER : BG_ELEVATED;
/*      */     } 
/*      */     
/*  919 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), btnBg, btnX, btnY, btnW, 24.0D, 8.0D, 60.0D);
/*      */ 
/*      */     
/*  922 */     Color textColor = bind.isListening() ? TEXT_PRIMARY : ACCENT_PRIMARY;
/*  923 */     TextRenderer.drawCenteredString(keyName, context, btnX + btnW / 2, btnY + 8, textColor
/*  924 */         .getRGB());
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderStringSetting(class_332 context, int x, int y, int width, StringSetting str, boolean hovered) {
/*  929 */     String value = str.getValue();
/*  930 */     if (value.length() > 18) {
/*  931 */       value = value.substring(0, 15) + "...";
/*      */     }
/*      */     
/*  934 */     int btnW = Math.min(160, TextRenderer.getWidth(value) + 32);
/*  935 */     int btnX = x + width - btnW - 14;
/*  936 */     int btnY = y + 36;
/*      */     
/*  938 */     Color btnBg = hovered ? BG_HOVER : BG_ELEVATED;
/*  939 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), btnBg, btnX, btnY, btnW, 24.0D, 8.0D, 60.0D);
/*      */ 
/*      */     
/*  942 */     TextRenderer.drawString(value, context, btnX + 12, btnY + 8, TEXT_SECONDARY.getRGB());
/*  943 */     TextRenderer.drawString("✎", context, btnX + btnW - 20, btnY + 8, TEXT_MUTED.getRGB());
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderColorSetting(class_332 context, int x, int y, int width, ColorSetting color, boolean hovered) {
/*  948 */     Color colorValue = color.getValue();
/*      */     
/*  950 */     int previewSize = 32;
/*  951 */     int previewX = x + width - previewSize - 14;
/*  952 */     int previewY = y + 32;
/*      */     
/*  954 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), colorValue, previewX, previewY, previewSize, previewSize, 8.0D, 60.0D);
/*      */ 
/*      */     
/*  957 */     RenderUtils.renderRoundedOutline(context, TEXT_MUTED, previewX, previewY, (previewX + previewSize), (previewY + previewSize), 8.0D, 8.0D, 8.0D, 8.0D, 1.5D, 60.0D);
/*      */ 
/*      */ 
/*      */     
/*  961 */     String rgb = String.format("RGB(%d,%d,%d)", new Object[] { Integer.valueOf(colorValue.getRed()), 
/*  962 */           Integer.valueOf(colorValue.getGreen()), Integer.valueOf(colorValue.getBlue()) });
/*  963 */     TextRenderer.drawString(rgb, context, x + 14, y + 42, TEXT_MUTED.getRGB());
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderItemSetting(class_332 context, int x, int y, int width, ItemSetting item) {
/*  968 */     class_1792 itemValue = item.getItem();
/*  969 */     int iconSize = 28;
/*  970 */     int iconX = x + width - iconSize - 16;
/*  971 */     int iconY = y + 32;
/*      */     
/*  973 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), BG_ELEVATED, (iconX - 4), (iconY - 4), (iconSize + 8), (iconSize + 8), 8.0D, 60.0D);
/*      */ 
/*      */     
/*  976 */     if (itemValue != null && itemValue != class_1802.field_8162) {
/*  977 */       context.method_51427(new class_1799((class_1935)itemValue), iconX, iconY);
/*      */     } else {
/*  979 */       TextRenderer.drawCenteredString("?", context, iconX + iconSize / 2, iconY + 8, TEXT_MUTED
/*  980 */           .getRGB());
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderCountSetting(class_332 context, int x, int y, int width, int count, String singular) {
/*  986 */     String countText = "" + count + " " + count + singular;
/*  987 */     int btnW = Math.min(140, TextRenderer.getWidth(countText) + 28);
/*  988 */     int btnX = x + width - btnW - 14;
/*  989 */     int btnY = y + 36;
/*      */     
/*  991 */     RenderUtils.renderRoundedQuadShader(context.method_51448(), BG_ELEVATED, btnX, btnY, btnW, 24.0D, 8.0D, 60.0D);
/*      */     
/*  993 */     TextRenderer.drawCenteredString(countText, context, btnX + btnW / 2, btnY + 8, ACCENT_PRIMARY
/*  994 */         .getRGB());
/*      */   }
/*      */   
/*      */   private String formatNumberValue(NumberSetting num) {
/*  998 */     double format = num.getFormat();
/*  999 */     double value = num.getValue();
/*      */     
/* 1001 */     if (format == 0.1D) return String.format("%.1f", new Object[] { Double.valueOf(value) }); 
/* 1002 */     if (format == 0.01D) return String.format("%.2f", new Object[] { Double.valueOf(value) }); 
/* 1003 */     if (format == 0.001D) return String.format("%.3f", new Object[] { Double.valueOf(value) }); 
/* 1004 */     if (format >= 1.0D) return String.format("%.0f", new Object[] { Double.valueOf(value) }); 
/* 1005 */     return String.valueOf(value);
/*      */   }
/*      */   private String formatMinMaxValue(MinMaxSetting minMax) {
/*      */     String minStr, maxStr;
/* 1009 */     double step = minMax.getStep();
/*      */ 
/*      */     
/* 1012 */     if (step == 0.1D) {
/* 1013 */       minStr = String.format("%.1f", new Object[] { Double.valueOf(minMax.getCurrentMin()) });
/* 1014 */       maxStr = String.format("%.1f", new Object[] { Double.valueOf(minMax.getCurrentMax()) });
/* 1015 */     } else if (step == 0.01D) {
/* 1016 */       minStr = String.format("%.2f", new Object[] { Double.valueOf(minMax.getCurrentMin()) });
/* 1017 */       maxStr = String.format("%.2f", new Object[] { Double.valueOf(minMax.getCurrentMax()) });
/* 1018 */     } else if (step >= 1.0D) {
/* 1019 */       minStr = String.format("%.0f", new Object[] { Double.valueOf(minMax.getCurrentMin()) });
/* 1020 */       maxStr = String.format("%.0f", new Object[] { Double.valueOf(minMax.getCurrentMax()) });
/*      */     } else {
/* 1022 */       minStr = String.valueOf(minMax.getCurrentMin());
/* 1023 */       maxStr = String.valueOf(minMax.getCurrentMax());
/*      */     } 
/*      */     
/* 1026 */     return minStr + " - " + minStr;
/*      */   }
/*      */   
/*      */   private boolean isPointInRect(int px, int py, int x, int y, int width, int height) {
/* 1030 */     return (px >= x && px <= x + width && py >= y && py <= y + height);
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 1035 */     if (shouldUseReaperGUI()) {
/* 1036 */       double d1 = mouseX * (int)class_310.method_1551().method_22683().method_4495();
/* 1037 */       double d2 = mouseY * (int)class_310.method_1551().method_22683().method_4495();
/*      */       
/* 1039 */       for (CategoryWindow window : this.reaperWindows) {
/* 1040 */         window.mouseClicked(d1, d2, button);
/*      */       }
/* 1042 */       return super.method_25402(d1, d2, button);
/*      */     } 
/*      */     
/* 1045 */     int scaledX = (int)(mouseX * class_310.method_1551().method_22683().method_4495());
/* 1046 */     int scaledY = (int)(mouseY * class_310.method_1551().method_22683().method_4495());
/*      */     
/* 1048 */     int closeX = this.guiX + 980 - 20 - 36;
/* 1049 */     int closeY = this.guiY + 18;
/* 1050 */     if (isPointInRect(scaledX, scaledY, closeX, closeY, 36, 36)) {
/* 1051 */       method_25419();
/* 1052 */       return true;
/*      */     } 
/*      */     
/* 1055 */     if (this.selectedModule != null && handleSettingsInteraction(scaledX, scaledY, button)) {
/* 1056 */       return true;
/*      */     }
/*      */     
/* 1059 */     if (!this.searchQuery.isEmpty()) {
/* 1060 */       int i = this.guiX + 240;
/* 1061 */       int j = 740 - ((this.selectedModule != null) ? 320 : 0);
/* 1062 */       int k = i + 20;
/* 1063 */       int m = j - 40;
/* 1064 */       int clearX = k + m - 40;
/* 1065 */       int clearY = this.guiY + 72 + 20 + 12;
/*      */       
/* 1067 */       if (isPointInRect(scaledX, scaledY, clearX, clearY, 28, 28)) {
/* 1068 */         this.searchQuery = "";
/* 1069 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 1073 */     int contentX = this.guiX + 240;
/* 1074 */     int contentW = 740 - ((this.selectedModule != null) ? 320 : 0);
/* 1075 */     int searchX = contentX + 20;
/* 1076 */     int searchY = this.guiY + 72 + 20;
/* 1077 */     int searchW = contentW - 40;
/*      */     
/* 1079 */     if (isPointInRect(scaledX, scaledY, searchX, searchY, searchW, 52)) {
/* 1080 */       this.isSearchFocused = true;
/* 1081 */       return true;
/*      */     } 
/* 1083 */     this.isSearchFocused = false;
/*      */ 
/*      */     
/* 1086 */     if (handleCategoryClick(scaledX, scaledY)) {
/* 1087 */       return true;
/*      */     }
/*      */     
/* 1090 */     if (handleModuleClick(scaledX, scaledY, button)) {
/* 1091 */       return true;
/*      */     }
/*      */     
/* 1094 */     if (isPointInRect(scaledX, scaledY, this.guiX, this.guiY, 980, 72)) {
/* 1095 */       this.isDragging = true;
/* 1096 */       this.dragOffsetX = scaledX - this.guiX;
/* 1097 */       this.dragOffsetY = scaledY - this.guiY;
/* 1098 */       return true;
/*      */     } 
/*      */     
/* 1101 */     return super.method_25402(mouseX, mouseY, button);
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean handleSettingsInteraction(int mouseX, int mouseY, int button) {
/* 1106 */     int panelX = this.guiX + 980 - 320;
/* 1107 */     int panelW = 320;
/* 1108 */     int panelY = this.guiY + 72;
/* 1109 */     int panelH = 568;
/*      */     
/* 1111 */     int settingsCloseX = panelX + panelW - 20 - 32;
/* 1112 */     int settingsCloseY = panelY + 20;
/* 1113 */     if (isPointInRect(mouseX, mouseY, settingsCloseX, settingsCloseY, 32, 32)) {
/* 1114 */       this.selectedModule = null;
/* 1115 */       this.settingsScrollOffset = 0;
/* 1116 */       this.panelTransition = 0.0F;
/* 1117 */       return true;
/*      */     } 
/*      */ 
/*      */     
/* 1121 */     int headerY = panelY + 20;
/* 1122 */     int settingsStartY = headerY + 70;
/* 1123 */     int settingY = settingsStartY - this.settingsScrollOffset;
/* 1124 */     int availableHeight = panelH - settingsStartY - panelY - 20;
/*      */     
/* 1126 */     List<Setting> settings = this.selectedModule.getSettings();
/* 1127 */     int settingX = panelX + 20;
/* 1128 */     int settingW = panelW - 40;
/*      */     
/* 1130 */     for (Setting setting : settings) {
/* 1131 */       int itemHeight = getSettingHeight(setting);
/*      */       
/* 1133 */       if (settingY + itemHeight >= settingsStartY && settingY <= settingsStartY + availableHeight && 
/* 1134 */         isPointInRect(mouseX, mouseY, settingX, settingY, settingW, itemHeight)) {
/*      */         
/* 1136 */         if (setting instanceof BooleanSetting) {
/* 1137 */           BooleanSetting bool = (BooleanSetting)setting;
/* 1138 */           bool.setValue(!bool.getValue());
/* 1139 */           return true;
/*      */         } 
/* 1141 */         if (setting instanceof NumberSetting) {
/* 1142 */           NumberSetting num = (NumberSetting)setting;
/* 1143 */           int sliderY = settingY + 42;
/* 1144 */           int sliderX = settingX + 14;
/* 1145 */           int sliderW = settingW - 28;
/*      */           
/* 1147 */           if (mouseY >= sliderY - 8 && mouseY <= sliderY + 14) {
/* 1148 */             this.isDraggingSlider = true;
/* 1149 */             this.draggedSetting = setting;
/* 1150 */             updateSliderValue(num, mouseX, sliderX, sliderW);
/* 1151 */             return true;
/*      */           }
/*      */         
/* 1154 */         } else if (setting instanceof MinMaxSetting) {
/* 1155 */           MinMaxSetting minMax = (MinMaxSetting)setting;
/* 1156 */           int sliderY = settingY + 42;
/* 1157 */           int sliderX = settingX + 14;
/* 1158 */           int sliderW = settingW - 28;
/*      */           
/* 1160 */           if (mouseY >= sliderY - 8 && mouseY <= sliderY + 14) {
/*      */             
/* 1162 */             double minProgress = (minMax.getCurrentMin() - minMax.getMinValue()) / (minMax.getMaxValue() - minMax.getMinValue());
/*      */             
/* 1164 */             double maxProgress = (minMax.getCurrentMax() - minMax.getMinValue()) / (minMax.getMaxValue() - minMax.getMinValue());
/* 1165 */             int minX = sliderX + (int)(sliderW * minProgress);
/* 1166 */             int maxX = sliderX + (int)(sliderW * maxProgress);
/*      */             
/* 1168 */             this.draggedIsMin = (Math.abs(mouseX - minX) < Math.abs(mouseX - maxX));
/* 1169 */             this.isDraggingSlider = true;
/* 1170 */             this.draggedSetting = setting;
/* 1171 */             updateMinMaxSlider(minMax, mouseX, sliderX, sliderW, this.draggedIsMin);
/* 1172 */             return true;
/*      */           } 
/*      */         } else {
/* 1175 */           if (setting instanceof ModeSetting) {
/* 1176 */             ModeSetting<?> mode = (ModeSetting)setting;
/* 1177 */             if (button == 0) { mode.cycleUp(); }
/* 1178 */             else if (button == 1) { mode.cycleDown(); }
/* 1179 */              return true;
/*      */           } 
/* 1181 */           if (setting instanceof BindSetting) {
/* 1182 */             BindSetting bind = (BindSetting)setting;
/* 1183 */             if (button == 0) {
/* 1184 */               bind.setListening(!bind.isListening());
/* 1185 */             } else if (button == 1 && bind.isListening()) {
/* 1186 */               bind.setValue(-1);
/* 1187 */               bind.setListening(false);
/*      */             } 
/* 1189 */             return true;
/*      */           } 
/* 1191 */           if (setting instanceof StringSetting) {
/* 1192 */             class_310.method_1551().method_1507((class_437)new StringBox(createDummyTextBox(setting), (StringSetting)setting));
/* 1193 */             return true;
/*      */           } 
/* 1195 */           if (setting instanceof ItemSetting) {
/* 1196 */             class_310.method_1551().method_1507((class_437)new ItemFilter(createDummyItemBox(setting), (ItemSetting)setting));
/* 1197 */             return true;
/*      */           } 
/* 1199 */           if (setting instanceof ItemsSetting) {
/* 1200 */             class_310.method_1551().method_1507((class_437)new ItemsMultiFilter(createDummyItemsListBox(setting), (ItemsSetting)setting));
/* 1201 */             return true;
/*      */           } 
/* 1203 */           if (setting instanceof MacroSetting) {
/* 1204 */             class_310.method_1551().method_1507((class_437)new MacroFilter(createDummyMacroBox(setting), (MacroSetting)setting));
/* 1205 */             return true;
/*      */           } 
/* 1207 */           if (setting instanceof FriendsSetting) {
/* 1208 */             class_310.method_1551().method_1507((class_437)new FriendsFilter(createDummyFriendsBox(setting), (FriendsSetting)setting));
/* 1209 */             return true;
/*      */           } 
/*      */ 
/*      */           
/* 1213 */           if (setting instanceof BlocksSetting) {
/* 1214 */             class_310.method_1551().method_1507((class_437)new BlocksFilter(createDummyBlocksBox(setting), (BlocksSetting)setting));
/* 1215 */             return true;
/*      */           } 
/* 1217 */           if (setting instanceof ColorSetting) {
/* 1218 */             Color newColor; ColorSetting color = (ColorSetting)setting;
/* 1219 */             Color current = color.getValue();
/*      */ 
/*      */             
/* 1222 */             if (current.equals(Color.WHITE)) { newColor = Color.RED; }
/* 1223 */             else if (current.equals(Color.RED)) { newColor = new Color(255, 128, 0); }
/* 1224 */             else if (current.getRed() == 255 && current.getGreen() == 128) { newColor = Color.YELLOW; }
/* 1225 */             else if (current.equals(Color.YELLOW)) { newColor = Color.GREEN; }
/* 1226 */             else if (current.equals(Color.GREEN)) { newColor = Color.CYAN; }
/* 1227 */             else if (current.equals(Color.CYAN)) { newColor = Color.BLUE; }
/* 1228 */             else if (current.equals(Color.BLUE)) { newColor = new Color(128, 0, 255); }
/* 1229 */             else if (current.getRed() == 128 && current.getBlue() == 255) { newColor = Color.MAGENTA; }
/* 1230 */             else if (current.equals(Color.MAGENTA)) { newColor = new Color(255, 0, 128); }
/* 1231 */             else { newColor = Color.WHITE; }
/*      */             
/* 1233 */             color.setValue(newColor);
/* 1234 */             return true;
/*      */           } 
/*      */         } 
/*      */       } 
/* 1238 */       settingY += itemHeight + 16;
/*      */     } 
/*      */     
/* 1241 */     return false;
/*      */   }
/*      */   
/*      */   private boolean handleCategoryClick(int mouseX, int mouseY) {
/* 1245 */     int sidebarX = this.guiX;
/* 1246 */     int categoryY = this.guiY + 72 + 20 + 32;
/*      */     
/* 1248 */     Category[] categories = Category.values();
/* 1249 */     for (Category cat : categories) {
/* 1250 */       int btnX = sidebarX + 12;
/* 1251 */       int btnW = 216;
/*      */       
/* 1253 */       if (isPointInRect(mouseX, mouseY, btnX, categoryY, btnW, 50)) {
/* 1254 */         if (this.selectedCategory != cat) {
/* 1255 */           this.selectedCategory = cat;
/* 1256 */           this.moduleScrollOffset = 0;
/*      */         } 
/* 1258 */         return true;
/*      */       } 
/* 1260 */       categoryY += 58;
/*      */     } 
/*      */     
/* 1263 */     return false;
/*      */   }
/*      */   
/*      */   private boolean handleModuleClick(int mouseX, int mouseY, int button) {
/* 1267 */     boolean lala = DonutBBC.OpenGui();
/* 1268 */     List<Module> modules = DonutBBC.INSTANCE.getModuleManager().a(this.selectedCategory);
/*      */     
/* 1270 */     if (!this.searchQuery.isEmpty())
/*      */     {
/*      */ 
/*      */       
/* 1274 */       modules = (List<Module>)modules.stream().filter(m -> m.getName().toString().toLowerCase().contains(this.searchQuery.toLowerCase())).collect(Collectors.toList());
/*      */     }
/*      */     
/* 1277 */     int contentX = this.guiX + 240;
/* 1278 */     int contentY = this.guiY + 72 + 90;
/* 1279 */     int contentW = 740 - ((this.selectedModule != null) ? 320 : 0);
/*      */     
/* 1281 */     int cardW = 280;
/* 1282 */     int cardH = 110;
/* 1283 */     int gap = 16;
/* 1284 */     int cols = Math.max(1, (contentW - 40) / (cardW + gap));
/* 1285 */     int startX = contentX + 20;
/* 1286 */     int startY = contentY + 20;
/*      */     
/* 1288 */     for (int i = 0; i < modules.size(); i++) {
/* 1289 */       Module module = modules.get(i);
/* 1290 */       int row = i / cols;
/* 1291 */       int col = i % cols;
/* 1292 */       int cardX = startX + col * (cardW + gap);
/* 1293 */       int cardY = startY + row * (cardH + gap) - this.moduleScrollOffset * 50;
/*      */       
/* 1295 */       if (isPointInRect(mouseX, mouseY, cardX, cardY, cardW, cardH)) {
/* 1296 */         int switchX = cardX + cardW - 60;
/* 1297 */         int switchY = cardY + cardH - 36;
/*      */         
/* 1299 */         if (isPointInRect(mouseX, mouseY, switchX, switchY, 48, 26)) {
/* 1300 */           module.toggle();
/* 1301 */           return true;
/*      */         } 
/*      */         
/* 1304 */         if (button == 0) {
/* 1305 */           module.toggle();
/* 1306 */         } else if (button == 1) {
/* 1307 */           this.selectedModule = module;
/* 1308 */           this.settingsScrollOffset = 0;
/* 1309 */           this.panelTransition = 0.0F;
/*      */         } 
/* 1311 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 1315 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
/* 1320 */     if (shouldUseReaperGUI()) {
/* 1321 */       double scaledX = mouseX * (int)class_310.method_1551().method_22683().method_4495();
/* 1322 */       double scaledY = mouseY * (int)class_310.method_1551().method_22683().method_4495();
/*      */       
/* 1324 */       for (CategoryWindow window : this.reaperWindows) {
/* 1325 */         window.mouseDragged(scaledX, scaledY, button, deltaX, deltaY);
/*      */       }
/* 1327 */       return super.method_25403(scaledX, scaledY, button, deltaX, deltaY);
/*      */     } 
/*      */     
/* 1330 */     if (this.isDraggingSlider && this.draggedSetting != null && this.selectedModule != null) {
/* 1331 */       int scaledX = (int)(mouseX * class_310.method_1551().method_22683().method_4495());
/*      */       
/* 1333 */       int panelX = this.guiX + 980 - 320;
/* 1334 */       int panelW = 320;
/* 1335 */       int settingX = panelX + 20;
/* 1336 */       int settingW = panelW - 40;
/* 1337 */       int sliderX = settingX + 14;
/* 1338 */       int sliderW = settingW - 28;
/*      */       
/* 1340 */       if (this.draggedSetting instanceof NumberSetting) {
/* 1341 */         updateSliderValue((NumberSetting)this.draggedSetting, scaledX, sliderX, sliderW);
/* 1342 */         return true;
/* 1343 */       }  if (this.draggedSetting instanceof MinMaxSetting) {
/* 1344 */         updateMinMaxSlider((MinMaxSetting)this.draggedSetting, scaledX, sliderX, sliderW, this.draggedIsMin);
/* 1345 */         return true;
/*      */       } 
/*      */     } 
/* 1348 */     return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean method_25406(double mouseX, double mouseY, int button) {
/* 1355 */     if (shouldUseReaperGUI()) {
/* 1356 */       double scaledX = mouseX * (int)class_310.method_1551().method_22683().method_4495();
/* 1357 */       double scaledY = mouseY * (int)class_310.method_1551().method_22683().method_4495();
/*      */       
/* 1359 */       for (CategoryWindow window : this.reaperWindows) {
/* 1360 */         window.mouseReleased(scaledX, scaledY, button);
/*      */       }
/* 1362 */       return super.method_25406(scaledX, scaledY, button);
/*      */     } 
/* 1364 */     this.isDragging = false;
/* 1365 */     this.isDraggingSlider = false;
/* 1366 */     this.draggedSetting = null;
/* 1367 */     return super.method_25406(mouseX, mouseY, button);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
/* 1373 */     if (shouldUseReaperGUI()) {
/* 1374 */       double d = mouseY * class_310.method_1551().method_22683().method_4495();
/*      */       
/* 1376 */       for (CategoryWindow window : this.reaperWindows) {
/* 1377 */         window.mouseScrolled(mouseX, d, horizontalAmount, verticalAmount);
/*      */       }
/* 1379 */       return super.method_25401(mouseX, d, horizontalAmount, verticalAmount);
/*      */     } 
/*      */     
/* 1382 */     int scaledX = (int)(mouseX * class_310.method_1551().method_22683().method_4495());
/* 1383 */     int scaledY = (int)(mouseY * class_310.method_1551().method_22683().method_4495());
/*      */     
/* 1385 */     if (this.selectedModule != null) {
/* 1386 */       int panelX = this.guiX + 980 - 320;
/* 1387 */       int panelY = this.guiY + 72;
/* 1388 */       int panelW = 320;
/* 1389 */       int panelH = 568;
/*      */       
/* 1391 */       if (isPointInRect(scaledX, scaledY, panelX, panelY, panelW, panelH)) {
/* 1392 */         List<Setting> settings = this.selectedModule.getSettings();
/* 1393 */         int totalHeight = getTotalSettingsHeight(settings);
/* 1394 */         int headerHeight = 90;
/* 1395 */         int availableHeight = panelH - headerHeight - 20;
/* 1396 */         int maxScroll = Math.max(0, totalHeight - availableHeight);
/*      */         
/* 1398 */         this.settingsScrollOffset = Math.max(0, Math.min(maxScroll, this.settingsScrollOffset - (int)(verticalAmount * 25.0D)));
/*      */         
/* 1400 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 1404 */     this.moduleScrollOffset = Math.max(0, this.moduleScrollOffset - (int)verticalAmount);
/* 1405 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
/* 1410 */     if (shouldUseReaperGUI()) {
/* 1411 */       for (CategoryWindow window : this.reaperWindows) {
/* 1412 */         window.keyPressed(keyCode, scanCode, modifiers);
/*      */       }
/* 1414 */       return super.method_25404(keyCode, scanCode, modifiers);
/*      */     } 
/*      */     
/* 1417 */     if (this.selectedModule != null) {
/* 1418 */       for (Setting setting : this.selectedModule.getSettings()) {
/* 1419 */         if (setting instanceof BindSetting) {
/* 1420 */           BindSetting bind = (BindSetting)setting;
/* 1421 */           if (bind.isListening()) {
/* 1422 */             if (keyCode == 256) {
/* 1423 */               bind.setListening(false);
/* 1424 */             } else if (keyCode == 259) {
/* 1425 */               bind.setValue(-1);
/* 1426 */               bind.setListening(false);
/*      */             } else {
/* 1428 */               bind.setValue(keyCode);
/* 1429 */               bind.setListening(false);
/*      */             } 
/* 1431 */             return true;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */     
/* 1437 */     if (this.isSearchFocused) {
/* 1438 */       if (keyCode == 259 && !this.searchQuery.isEmpty()) {
/* 1439 */         this.searchQuery = this.searchQuery.substring(0, this.searchQuery.length() - 1);
/* 1440 */         return true;
/* 1441 */       }  if (keyCode == 256) {
/* 1442 */         this.isSearchFocused = false;
/* 1443 */         return true;
/* 1444 */       }  if (keyCode == 257) {
/* 1445 */         this.isSearchFocused = false;
/* 1446 */         return true;
/*      */       } 
/*      */     } 
/*      */     
/* 1450 */     return super.method_25404(keyCode, scanCode, modifiers);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean method_25400(char chr, int modifiers) {
/* 1456 */     if (shouldUseReaperGUI()) {
/*      */       
/* 1458 */       for (CategoryWindow window : this.reaperWindows) {
/* 1459 */         window.charTyped(chr, modifiers);
/*      */       }
/* 1461 */       return super.method_25400(chr, modifiers);
/*      */     } 
/* 1463 */     if (this.isSearchFocused && !Character.isISOControl(chr)) {
/* 1464 */       this.searchQuery += this.searchQuery;
/* 1465 */       return true;
/*      */     } 
/* 1467 */     return super.method_25400(chr, modifiers);
/*      */   }
/*      */ 
/*      */   
/*      */   private void updateSliderValue(NumberSetting setting, int mouseX, int sliderX, int sliderW) {
/* 1472 */     double progress = Math.max(0.0D, Math.min(1.0D, (mouseX - sliderX) / sliderW));
/* 1473 */     double newValue = setting.getMin() + progress * (setting.getMax() - setting.getMin());
/* 1474 */     double format = setting.getFormat();
/* 1475 */     newValue = Math.round(newValue / format) * format;
/* 1476 */     setting.setValue(newValue);
/*      */   }
/*      */   
/*      */   private void updateMinMaxSlider(MinMaxSetting setting, int mouseX, int sliderX, int sliderW, boolean isMin) {
/* 1480 */     double progress = Math.max(0.0D, Math.min(1.0D, (mouseX - sliderX) / sliderW));
/* 1481 */     double newValue = setting.getMinValue() + progress * (setting.getMaxValue() - setting.getMinValue());
/* 1482 */     double step = setting.getStep();
/* 1483 */     newValue = Math.round(newValue / step) * step;
/*      */     
/* 1485 */     if (isMin) {
/* 1486 */       setting.setCurrentMin(Math.min(newValue, setting.getCurrentMax()));
/*      */     } else {
/* 1488 */       setting.setCurrentMax(Math.max(newValue, setting.getCurrentMin()));
/*      */     } 
/*      */   }
/*      */   
/*      */   private TextBox createDummyTextBox(Setting setting) {
/* 1493 */     return new TextBox(this, null, setting, 0) {
/* 1494 */         public int parentX() { return 0; }
/* 1495 */         public int parentY() { return 0; }
/* 1496 */         public int parentWidth() { return 0; }
/* 1497 */         public int parentHeight() { return 0; } public int parentOffset() {
/* 1498 */           return 0;
/*      */         }
/*      */       };
/*      */   }
/*      */   private ItemBox createDummyItemBox(Setting setting) {
/* 1503 */     return new ItemBox(this, null, setting, 0) {
/* 1504 */         public int parentX() { return 0; }
/* 1505 */         public int parentY() { return 0; }
/* 1506 */         public int parentWidth() { return 0; }
/* 1507 */         public int parentHeight() { return 0; } public int parentOffset() {
/* 1508 */           return 0;
/*      */         }
/*      */       };
/*      */   }
/*      */   private MacroBox createDummyMacroBox(Setting setting) {
/* 1513 */     return new MacroBox(this, null, setting, 0) {
/* 1514 */         public int parentX() { return 0; }
/* 1515 */         public int parentY() { return 0; }
/* 1516 */         public int parentWidth() { return 0; }
/* 1517 */         public int parentHeight() { return 0; } public int parentOffset() {
/* 1518 */           return 0;
/*      */         }
/*      */       };
/*      */   }
/*      */   private FriendsBox createDummyFriendsBox(Setting setting) {
/* 1523 */     return new FriendsBox(this, null, setting, 0) {
/* 1524 */         public int parentX() { return 0; }
/* 1525 */         public int parentY() { return 0; }
/* 1526 */         public int parentWidth() { return 0; }
/* 1527 */         public int parentHeight() { return 0; } public int parentOffset() {
/* 1528 */           return 0;
/*      */         }
/*      */       };
/*      */   }
/*      */   private BlocksBox createDummyBlocksBox(Setting setting) {
/* 1533 */     return new BlocksBox(this, null, setting, 0) {
/* 1534 */         public int parentX() { return 0; }
/* 1535 */         public int parentY() { return 0; }
/* 1536 */         public int parentWidth() { return 0; }
/* 1537 */         public int parentHeight() { return 0; } public int parentOffset() {
/* 1538 */           return 0;
/*      */         }
/*      */       };
/*      */   }
/*      */   private ItemsListBox createDummyItemsListBox(Setting setting) {
/* 1543 */     return new ItemsListBox(this, null, setting, 0) {
/* 1544 */         public int parentX() { return 0; }
/* 1545 */         public int parentY() { return 0; }
/* 1546 */         public int parentWidth() { return 0; }
/* 1547 */         public int parentHeight() { return 0; } public int parentOffset() {
/* 1548 */           return 0;
/*      */         }
/*      */       };
/*      */   }
/*      */   
/*      */   public void method_25419() {
/* 1554 */     if (shouldUseReaperGUI()) {
/* 1555 */       DonutBBC.INSTANCE.getModuleManager()
/* 1556 */         .getModuleByClass(DonutBBC.class)
/* 1557 */         .setEnabled(false);
/*      */     } else {
/* 1559 */       DonutBBC.INSTANCE.getModuleManager()
/* 1560 */         .getModuleByClass(DonutBBC.class)
/* 1561 */         .setEnabled(false);
/*      */     } 
/* 1563 */     onGuiClose();
/* 1564 */     super.method_25419();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean method_25421() {
/* 1570 */     return false;
/*      */   }
/*      */ 
/*      */   
/*      */   public void onGuiClose() {
/* 1575 */     this.selectedModule = null;
/* 1576 */     this.searchQuery = "";
/* 1577 */     this.isSearchFocused = false;
/* 1578 */     this.moduleScrollOffset = 0;
/* 1579 */     this.settingsScrollOffset = 0;
/* 1580 */     this.isDragging = false;
/* 1581 */     this.isDraggingSlider = false;
/* 1582 */     this.draggedSetting = null;
/* 1583 */     this.panelTransition = 0.0F;
/* 1584 */     this.globalTime = 0.0F;
/* 1585 */     this.categoryHoverAnim.clear();
/* 1586 */     this.moduleHoverAnim.clear();
/* 1587 */     for (Category cat : Category.values()) {
/* 1588 */       this.categoryHoverAnim.put(cat, Float.valueOf(0.0F));
/*      */     }
/*      */ 
/*      */     
/* 1592 */     if (shouldUseReaperGUI()) {
/* 1593 */       class_310.method_1551().method_29970(DonutBBC.INSTANCE.screen);
/* 1594 */       this.currentColor = null;
/* 1595 */       for (CategoryWindow window : this.reaperWindows)
/* 1596 */         window.onGuiClose(); 
/*      */     } 
/*      */   }
/*      */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\ClickGUI.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */