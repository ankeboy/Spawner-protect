/*     */ package dev.FORE.gui;
/*     */ 
/*     */ import dev.FORE.module.Category;
/*     */ 


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\gui\CategoryWindow$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */