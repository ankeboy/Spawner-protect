/*     */ package dev.FORE.module.setting;
/*     */ 
/*     */ import java.util.Collections;
/*     */ import java.util.HashSet;
/*     */ import java.util.Set;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1802;
/*     */ 
/*     */ public class ItemsSetting
/*     */   extends Setting {
/*     */   private final Set<class_1792> defaultValue;
/*     */   private Set<class_1792> value;
/*     */   
/*     */   static {
/*  16 */     DEFAULT_FILTER = (item -> (item != null && item != class_1802.field_8162));
/*     */   } private final Predicate<class_1792> filter; private static final Predicate<class_1792> DEFAULT_FILTER;
/*     */   public ItemsSetting(CharSequence name, Set<class_1792> items) {
/*  19 */     this(name, items, DEFAULT_FILTER);
/*     */   }
/*     */   
/*     */   public ItemsSetting(CharSequence name, Predicate<class_1792> filter, class_1792... items) {
/*  23 */     this(name, toSet(items, (filter != null) ? filter : DEFAULT_FILTER), filter);
/*     */   }
/*     */   
/*     */   public ItemsSetting(CharSequence name, Set<class_1792> items, Predicate<class_1792> filter) {
/*  27 */     super(name);
/*  28 */     Predicate<class_1792> effectiveFilter = (filter != null) ? filter : DEFAULT_FILTER;
/*  29 */     this.filter = effectiveFilter;
/*  30 */     this.value = new HashSet<>();
/*  31 */     this.defaultValue = new HashSet<>();
/*     */     
/*  33 */     for (class_1792 item : items) {
/*  34 */       if (isAllowed(item)) {
/*  35 */         this.value.add(item);
/*  36 */         this.defaultValue.add(item);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public Set<class_1792> getItems() {
/*  42 */     return new HashSet<>(this.value);
/*     */   }
/*     */   
/*     */   public void setItems(Set<class_1792> items) {
/*  46 */     this.value = new HashSet<>();
/*  47 */     for (class_1792 item : items) {
/*  48 */       if (isAllowed(item)) {
/*  49 */         this.value.add(item);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void addItem(class_1792 item) {
/*  55 */     if (isAllowed(item)) {
/*  56 */       this.value.add(item);
/*     */     }
/*     */   }
/*     */   
/*     */   public void removeItem(class_1792 item) {
/*  61 */     this.value.remove(item);
/*     */   }
/*     */   
/*     */   public boolean contains(class_1792 item) {
/*  65 */     return this.value.contains(item);
/*     */   }
/*     */   
/*     */   public void toggleItem(class_1792 item) {
/*  69 */     if (contains(item)) {
/*  70 */       removeItem(item);
/*     */     } else {
/*  72 */       addItem(item);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void clearItems() {
/*  77 */     this.value.clear();
/*     */   }
/*     */   
/*     */   public int size() {
/*  81 */     return this.value.size();
/*     */   }
/*     */   
/*     */   public Set<class_1792> getDefaultValue() {
/*  85 */     return new HashSet<>(this.defaultValue);
/*     */   }
/*     */   
/*     */   public void resetValue() {
/*  89 */     this.value = new HashSet<>(this.defaultValue);
/*     */   }
/*     */   
/*     */   public Predicate<class_1792> getFilter() {
/*  93 */     return this.filter;
/*     */   }
/*     */   
/*     */   private boolean isAllowed(class_1792 item) {
/*  97 */     return (item != null && this.filter.test(item));
/*     */   }
/*     */   
/*     */   private static Set<class_1792> toSet(class_1792[] items, Predicate<class_1792> filter) {
/* 101 */     if (items == null || items.length == 0) {
/* 102 */       return Collections.emptySet();
/*     */     }
/* 104 */     Predicate<class_1792> effectiveFilter = (filter != null) ? filter : DEFAULT_FILTER;
/* 105 */     Set<class_1792> set = new HashSet<>();
/* 106 */     for (class_1792 item : items) {
/* 107 */       if (item != null && effectiveFilter.test(item)) {
/* 108 */         set.add(item);
/*     */       }
/*     */     } 
/* 111 */     return set;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\setting\ItemsSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */