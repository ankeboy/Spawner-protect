/*     */ package dev.FORE.module.setting;
/*     */ 
/*     */ import java.util.Random;
/*     */ 
/*     */ public class MinMaxSetting extends Setting {
/*     */   private final double min;
/*     */   private final double max;
/*     */   private final double step;
/*     */   private final double defaultMin;
/*     */   private final double defaultMax;
/*     */   private double currentMin;
/*     */   private double currentMax;
/*     */   
/*     */   public MinMaxSetting(CharSequence charSequence, double min, double max, double step, double defaultMin, double defaultMax) {
/*  15 */     super(charSequence);
/*  16 */     this.min = min;
/*  17 */     this.max = max;
/*  18 */     this.step = step;
/*  19 */     this.currentMin = defaultMin;
/*  20 */     this.currentMax = defaultMax;
/*  21 */     this.defaultMin = defaultMin;
/*  22 */     this.defaultMax = defaultMax;
/*     */   }
/*     */   
/*     */   public int getMinInt() {
/*  26 */     return (int)this.currentMin;
/*     */   }
/*     */   
/*     */   public float getMinFloat() {
/*  30 */     return (float)this.currentMin;
/*     */   }
/*     */   
/*     */   public long getMinLong() {
/*  34 */     return (long)this.currentMin;
/*     */   }
/*     */   
/*     */   public int getMaxInt() {
/*  38 */     return (int)this.currentMax;
/*     */   }
/*     */   
/*     */   public float getMaxFloat() {
/*  42 */     return (float)this.currentMax;
/*     */   }
/*     */   
/*     */   public long getMaxLong() {
/*  46 */     return (long)this.currentMax;
/*     */   }
/*     */   
/*     */   public double getMinValue() {
/*  50 */     return this.min;
/*     */   }
/*     */   
/*     */   public double getMaxValue() {
/*  54 */     return this.max;
/*     */   }
/*     */   
/*     */   public double getCurrentMin() {
/*  58 */     return this.currentMin;
/*     */   }
/*     */   
/*     */   public double getCurrentMax() {
/*  62 */     return this.currentMax;
/*     */   }
/*     */   
/*     */   public double getDefaultMin() {
/*  66 */     return this.defaultMin;
/*     */   }
/*     */   
/*     */   public double getDefaultMax() {
/*  70 */     return this.defaultMax;
/*     */   }
/*     */   
/*     */   public double getStep() {
/*  74 */     return this.step;
/*     */   }
/*     */   
/*     */   public double getRandomDoubleInRange() {
/*  78 */     if (getCurrentMax() > getCurrentMin()) {
/*  79 */       return (new Random()).nextDouble(getCurrentMin(), getCurrentMax());
/*     */     }
/*  81 */     return getCurrentMin();
/*     */   }
/*     */   
/*     */   public int getRandomIntInRange() {
/*  85 */     if (getCurrentMax() > getCurrentMin()) {
/*  86 */       return (new Random()).nextInt(getMinInt(), getMaxInt());
/*     */     }
/*  88 */     return getMinInt();
/*     */   }
/*     */   
/*     */   public float getRandomFloatInRange() {
/*  92 */     if (getCurrentMax() > getCurrentMin()) {
/*  93 */       return (new Random()).nextFloat(getMinFloat(), getMaxFloat());
/*     */     }
/*  95 */     return getMinFloat();
/*     */   }
/*     */   
/*     */   public long getRandomLongInRange() {
/*  99 */     if (getCurrentMax() > getCurrentMin()) {
/* 100 */       return (new Random()).nextLong(getMinLong(), getMaxLong());
/*     */     }
/* 102 */     return getMinLong();
/*     */   }
/*     */   
/*     */   public void setCurrentMin(double value) {
/* 106 */     double stepSize = 1.0D / this.step;
/* 107 */     this.currentMin = Math.round(Math.max(this.min, Math.min(this.max, value)) * stepSize) / stepSize;
/*     */   }
/*     */   
/*     */   public void setCurrentMax(double value) {
/* 111 */     double stepSize = 1.0D / this.step;
/* 112 */     this.currentMax = Math.round(Math.max(this.min, Math.min(this.max, value)) * stepSize) / stepSize;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\setting\MinMaxSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */