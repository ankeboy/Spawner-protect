/*    */ package dev.FORE.module.setting;
/*    */ 
/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ public class FriendsSetting extends Setting {
/*    */   private final List<String> friends;
/*    */   private final List<String> defaultFriends;
/*    */   public static FriendsSetting instance;
/*    */   
/*    */   public FriendsSetting(CharSequence name, List<String> defaultFriends) {
/* 12 */     super(name);
/* 13 */     this.defaultFriends = new ArrayList<>(defaultFriends);
/* 14 */     this.friends = new ArrayList<>(defaultFriends);
/*    */   }
/*    */   
/*    */   public FriendsSetting(CharSequence name) {
/* 18 */     this(name, new ArrayList<>());
/*    */   }
/*    */   
/*    */   public List<String> getFriends() {
/* 22 */     return new ArrayList<>(this.friends);
/*    */   }
/*    */   
/*    */   public void addFriend(String name) {
/* 26 */     if (!this.friends.contains(name) && !name.trim().isEmpty()) {
/* 27 */       this.friends.add(name);
/*    */     }
/*    */   }
/*    */   
/*    */   public void removeFriend(String name) {
/* 32 */     this.friends.remove(name);
/*    */   }
/*    */   
/*    */   public void clearFriends() {
/* 36 */     this.friends.clear();
/*    */   }
/*    */   
/*    */   public boolean isFriend(String name) {
/* 40 */     return this.friends.contains(name);
/*    */   }
/*    */   
/*    */   public void setFriends(List<String> friends) {
/* 44 */     this.friends.clear();
/* 45 */     this.friends.addAll(friends);
/*    */   }
/*    */   
/*    */   public List<String> getDefaultFriends() {
/* 49 */     return new ArrayList<>(this.defaultFriends);
/*    */   }
/*    */   
/*    */   public void resetValue() {
/* 53 */     this.friends.clear();
/* 54 */     this.friends.addAll(this.defaultFriends);
/*    */   }
/*    */   
/*    */   public int size() {
/* 58 */     return this.friends.size();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\setting\FriendsSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */