/*    */ package dev.FORE.module.setting;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.class_2246;
/*    */ import net.minecraft.class_2248;
/*    */ 
/*    */ public class BlocksSetting
/*    */   extends Setting {
/*    */   private final Set<class_2248> defaultValue;
/*    */   private Set<class_2248> value;
/*    */   
/*    */   public BlocksSetting(CharSequence name, Set<class_2248> value) {
/* 14 */     super(name);
/* 15 */     this.value = new HashSet<>(value);
/* 16 */     this.defaultValue = new HashSet<>(value);
/*    */   }
/*    */   
/*    */   public BlocksSetting(CharSequence name, class_2248... blocks) {
/* 20 */     super(name);
/* 21 */     this.value = new HashSet<>();
/* 22 */     this.defaultValue = new HashSet<>();
/* 23 */     for (class_2248 block : blocks) {
/* 24 */       this.value.add(block);
/* 25 */       this.defaultValue.add(block);
/*    */     } 
/*    */   }
/*    */   
/*    */   public Set<class_2248> getBlocks() {
/* 30 */     return new HashSet<>(this.value);
/*    */   }
/*    */   
/*    */   public void setBlocks(Set<class_2248> blocks) {
/* 34 */     this.value = new HashSet<>(blocks);
/*    */   }
/*    */   
/*    */   public void addBlock(class_2248 block) {
/* 38 */     if (block != null && block != class_2246.field_10124) {
/* 39 */       this.value.add(block);
/*    */     }
/*    */   }
/*    */   
/*    */   public void removeBlock(class_2248 block) {
/* 44 */     this.value.remove(block);
/*    */   }
/*    */   
/*    */   public boolean contains(class_2248 block) {
/* 48 */     return this.value.contains(block);
/*    */   }
/*    */   
/*    */   public void toggleBlock(class_2248 block) {
/* 52 */     if (contains(block)) {
/* 53 */       removeBlock(block);
/*    */     } else {
/* 55 */       addBlock(block);
/*    */     } 
/*    */   }
/*    */   
/*    */   public void clearBlocks() {
/* 60 */     this.value.clear();
/*    */   }
/*    */   
/*    */   public int size() {
/* 64 */     return this.value.size();
/*    */   }
/*    */   
/*    */   public Set<class_2248> getDefaultValue() {
/* 68 */     return new HashSet<>(this.defaultValue);
/*    */   }
/*    */   
/*    */   public void resetValue() {
/* 72 */     this.value = new HashSet<>(this.defaultValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\setting\BlocksSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */