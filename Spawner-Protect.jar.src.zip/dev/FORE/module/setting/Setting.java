/*    */ package dev.FORE.module.setting;
/*    */ 
/*    */ public abstract class Setting {
/*    */   private CharSequence name;
/*    */   public CharSequence description;
/*    */   
/*    */   public Setting(CharSequence a) {
/*  8 */     this.name = a;
/*    */   }
/*    */   
/*    */   public void getDescription(CharSequence a) {
/* 12 */     this.name = a;
/*    */   }
/*    */   
/*    */   public CharSequence getName() {
/* 16 */     return this.name;
/*    */   }
/*    */   
/*    */   public CharSequence getDescription() {
/* 20 */     return this.description;
/*    */   }
/*    */   
/*    */   public Setting setDescription(CharSequence description) {
/* 24 */     this.description = description;
/* 25 */     return this;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\setting\Setting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */