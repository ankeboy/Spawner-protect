/*    */ package dev.FORE.module.setting;
/*    */ 
/*    */ import net.minecraft.class_1792;
/*    */ 
/*    */ public class ItemSetting extends Setting {
/*    */   private final class_1792 defaultValue;
/*    */   private class_1792 value;
/*    */   
/*    */   public ItemSetting(CharSequence name, class_1792 value) {
/* 10 */     super(name);
/* 11 */     this.value = value;
/* 12 */     this.defaultValue = value;
/*    */   }
/*    */   
/*    */   public class_1792 getItem() {
/* 16 */     return this.value;
/*    */   }
/*    */   
/*    */   public void setItem(class_1792 a) {
/* 20 */     this.value = a;
/*    */   }
/*    */   
/*    */   public class_1792 getDefaultValue() {
/* 24 */     return this.defaultValue;
/*    */   }
/*    */   
/*    */   public void resetValue() {
/* 28 */     this.value = this.defaultValue;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\setting\ItemSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */