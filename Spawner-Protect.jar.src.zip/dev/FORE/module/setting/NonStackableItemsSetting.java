/*    */ package dev.FORE.module.setting;
/*    */ 
/*    */ import java.util.Set;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.class_1792;
/*    */ 
/*    */ public class NonStackableItemsSetting extends ItemsSetting {
/*    */   static {
/*  9 */     NON_STACKABLE_FILTER = (item -> (item != null && item.method_7882() <= 1));
/*    */   } private static final Predicate<class_1792> NON_STACKABLE_FILTER;
/*    */   public NonStackableItemsSetting(CharSequence name, Set<class_1792> items) {
/* 12 */     super(name, items, NON_STACKABLE_FILTER);
/*    */   }
/*    */   
/*    */   public NonStackableItemsSetting(CharSequence name, class_1792... items) {
/* 16 */     super(name, NON_STACKABLE_FILTER, items);
/*    */   }
/*    */   
/*    */   public Predicate<class_1792> getNonStackableFilter() {
/* 20 */     return NON_STACKABLE_FILTER;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\setting\NonStackableItemsSetting.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */