/*    */ package dev.FORE.module.modules.misc;
/*    */ 
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.AttackBlockEvent;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import dev.FORE.utils.InventoryUtil;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_2680;
/*    */ import net.minecraft.class_3481;
/*    */ 
/*    */ public final class AutoTool
/*    */   extends Module
/*    */ {
/* 22 */   private final BooleanSetting antiBreak = new BooleanSetting((CharSequence)EncryptedString.of("Anti Break"), true);
/* 23 */   private final NumberSetting antiBreakPercentage = new NumberSetting((CharSequence)EncryptedString.of("Anti Break Percentage"), 1.0D, 100.0D, 5.0D, 1.0D);
/*    */   private boolean isToolSwapping;
/*    */   private int keybindCounter;
/*    */   private int selectedToolSlot;
/*    */   
/*    */   public AutoTool() {
/* 29 */     super((CharSequence)EncryptedString.of("Auto Tool"), (CharSequence)EncryptedString.of("Module that automatically switches to best tool"), -1, Category.MISC);
/* 30 */     addsettings(new Setting[] { (Setting)this.antiBreak, (Setting)this.antiBreakPercentage });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 35 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 40 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {
/* 45 */     if (this.keybindCounter <= 0 && this.isToolSwapping && this.selectedToolSlot != -1) {
/* 46 */       InventoryUtil.swap(this.selectedToolSlot);
/* 47 */       this.isToolSwapping = false;
/*    */     } else {
/* 49 */       this.keybindCounter--;
/*    */     } 
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void handleAttackBlockEvent(AttackBlockEvent attackBlockEvent) {
/* 55 */     class_2680 blockState = this.mc.field_1687.method_8320(attackBlockEvent.pos);
/* 56 */     class_1799 currentItem = this.mc.field_1724.method_6047();
/* 57 */     double bestEfficiency = -1.0D;
/* 58 */     this.selectedToolSlot = -1;
/* 59 */     for (int slotIndex = 0; slotIndex < 9; slotIndex++) {
/* 60 */       double efficiency = calculateToolEfficiency(this.mc.field_1724.method_31548().method_5438(slotIndex), blockState, itemStack -> !isToolBreakingSoon(itemStack));
/* 61 */       if (efficiency >= 0.0D && 
/* 62 */         efficiency > bestEfficiency) {
/* 63 */         this.selectedToolSlot = slotIndex;
/* 64 */         bestEfficiency = efficiency;
/*    */       } 
/*    */     } 
/*    */     
/* 68 */     if ((this.selectedToolSlot != -1 && bestEfficiency > calculateToolEfficiency(currentItem, blockState, itemStack2 -> !isToolBreakingSoon(itemStack2))) || isToolBreakingSoon(currentItem) || !isToolItemStack(currentItem)) {
/* 69 */       InventoryUtil.swap(this.selectedToolSlot);
/*    */     }
/* 71 */     class_1799 mainHandItem = this.mc.field_1724.method_6047();
/* 72 */     if (isToolBreakingSoon(mainHandItem) && isToolItemStack(mainHandItem)) {
/* 73 */       this.mc.field_1690.field_1886.method_23481(false);
/* 74 */       attackBlockEvent.cancel();
/*    */     } 
/*    */   }
/*    */   
/*    */   public static double calculateToolEfficiency(class_1799 itemStack, class_2680 blockState, Predicate<class_1799> predicate) {
/* 79 */     if (!predicate.test(itemStack) || !isToolItemStack(itemStack)) {
/* 80 */       return -1.0D;
/*    */     }
/* 82 */     if (!itemStack.method_7951(blockState) && (!(itemStack.method_7909() instanceof net.minecraft.class_1829) || (!(blockState.method_26204() instanceof net.minecraft.class_2211) && !(blockState.method_26204() instanceof net.minecraft.class_2202))) && (!(itemStack.method_7909() instanceof net.minecraft.class_1820) || !(blockState.method_26204() instanceof net.minecraft.class_2397)) && !blockState.method_26164(class_3481.field_15481)) {
/* 83 */       return -1.0D;
/*    */     }
/* 85 */     return 0.0D + (itemStack.method_7924(blockState) * 1000.0F);
/*    */   }
/*    */   
/*    */   public static boolean isToolItemStack(class_1799 itemStack) {
/* 89 */     return isToolItem(itemStack.method_7909());
/*    */   }
/*    */   
/*    */   public static boolean isToolItem(class_1792 item) {
/* 93 */     return (item instanceof net.minecraft.class_1831 || item instanceof net.minecraft.class_1820);
/*    */   }
/*    */   
/*    */   private boolean isToolBreakingSoon(class_1799 itemStack) {
/* 97 */     return (this.antiBreak.getValue() && itemStack.method_7936() - itemStack.method_7919() < itemStack.method_7936() * this.antiBreakPercentage.getIntValue() / 100);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\AutoTool.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */