/*    */ package dev.FORE.module.modules.misc;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.modules.donut.MediaSpoof;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.module.setting.StringSetting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ 
/*    */ public class NameProtect extends Module {
/* 10 */   private final StringSetting fakeName = new StringSetting("Fake Name", "Player");
/*    */   
/*    */   public NameProtect() {
/* 13 */     super((CharSequence)EncryptedString.of("Name Protect"), (CharSequence)EncryptedString.of("Replaces your name with given one."), -1, Category.MISC);
/* 14 */     addsettings(new Setting[] { (Setting)this.fakeName });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 19 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 24 */     super.onDisable();
/*    */   }
/*    */   
/*    */   public String getFakeName() {
/* 28 */     return (MediaSpoof.getInstance()).Goodstring + (MediaSpoof.getInstance()).Goodstring;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\NameProtect.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */