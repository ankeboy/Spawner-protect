/*     */ package dev.FORE.module.modules.misc;
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.PostItemUseEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BindSetting;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.InventoryUtil;
/*     */ import dev.FORE.utils.KeyUtils;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_9334;
/*     */ 
/*     */ public final class AutoFirework extends Module {
/*  21 */   private final BindSetting activateKey = new BindSetting((CharSequence)EncryptedString.of("Activate Key"), -1, false);
/*  22 */   private final NumberSetting delay = new NumberSetting((CharSequence)EncryptedString.of("Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  23 */   private final BooleanSetting switchBack = new BooleanSetting((CharSequence)EncryptedString.of("Switch Back"), true);
/*  24 */   private final NumberSetting switchDelay = (new NumberSetting((CharSequence)EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 0.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("Delay after using firework before switching back."));
/*  25 */   private final BooleanSetting antiConsume = new BooleanSetting((CharSequence)EncryptedString.of("Anti Consume"), false);
/*     */   private boolean isFireworkActive;
/*     */   private boolean hasUsedFirework;
/*     */   private int useDelayCounter;
/*     */   private int previousSelectedSlot;
/*     */   private int switchDelayCounter;
/*     */   private int cooldownCounter;
/*     */   
/*     */   public AutoFirework() {
/*  34 */     super((CharSequence)EncryptedString.of("Auto Firework"), (CharSequence)EncryptedString.of("Switches to a firework and uses it when you press a bind."), -1, Category.MISC);
/*  35 */     addsettings(new Setting[] { (Setting)this.activateKey, (Setting)this.delay, (Setting)this.switchBack, (Setting)this.switchDelay, (Setting)this.antiConsume });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  40 */     resetState();
/*  41 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  46 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  51 */     if (this.mc.field_1755 != null) {
/*     */       return;
/*     */     }
/*  54 */     if (this.cooldownCounter > 0) {
/*  55 */       this.cooldownCounter--;
/*     */       return;
/*     */     } 
/*  58 */     if (this.mc.field_1724 != null && KeyUtils.isKeyPressed(this.activateKey.getValue()) && (DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(ElytraGlide.class).isEnabled() || this.mc.field_1724.method_6128()) && this.mc.field_1724.method_31548().method_7372(2).method_31574(class_1802.field_8833) && !this.mc.field_1724.method_31548().method_7391().method_31574(class_1802.field_8639) && !this.mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_50075) && !(this.mc.field_1724.method_6047().method_7909() instanceof net.minecraft.class_1738)) {
/*  59 */       this.isFireworkActive = true;
/*     */     }
/*  61 */     if (this.isFireworkActive) {
/*  62 */       if (this.previousSelectedSlot == -1) {
/*  63 */         this.previousSelectedSlot = (this.mc.field_1724.method_31548()).field_7545;
/*     */       }
/*  65 */       if (!InventoryUtil.swap(class_1802.field_8639)) {
/*  66 */         resetState();
/*     */         return;
/*     */       } 
/*  69 */       if (this.useDelayCounter < this.delay.getIntValue()) {
/*  70 */         this.useDelayCounter++;
/*     */         return;
/*     */       } 
/*  73 */       if (!this.hasUsedFirework) {
/*  74 */         this.mc.field_1761.method_2919((class_1657)this.mc.field_1724, class_1268.field_5808);
/*  75 */         this.hasUsedFirework = true;
/*     */       } 
/*  77 */       if (this.switchBack.getValue()) {
/*  78 */         handleSwitchBack();
/*     */       } else {
/*  80 */         resetState();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleSwitchBack() {
/*  86 */     if (this.switchDelayCounter < this.switchDelay.getIntValue()) {
/*  87 */       this.switchDelayCounter++;
/*     */       return;
/*     */     } 
/*  90 */     InventoryUtil.swap(this.previousSelectedSlot);
/*  91 */     resetState();
/*     */   }
/*     */   
/*     */   private void resetState() {
/*  95 */     this.previousSelectedSlot = -1;
/*  96 */     this.useDelayCounter = 0;
/*  97 */     this.switchDelayCounter = 0;
/*  98 */     this.cooldownCounter = 4;
/*  99 */     this.isFireworkActive = false;
/* 100 */     this.hasUsedFirework = false;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onPostItemUse(PostItemUseEvent postItemUseEvent) {
/* 105 */     if (this.mc.field_1724.method_6047().method_31574(class_1802.field_8639)) {
/* 106 */       this.hasUsedFirework = true;
/*     */     }
/* 108 */     if (this.cooldownCounter > 0)
/* 109 */       postItemUseEvent.cancel(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\AutoFirework.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */