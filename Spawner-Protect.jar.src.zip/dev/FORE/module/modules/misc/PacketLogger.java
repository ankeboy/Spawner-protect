/*    */ package dev.FORE.module.modules.misc;
/*    */ import dev.FORE.event.events.PacketReceiveEvent;
/*    */ import dev.FORE.imixin.IEntityVelocityUpdateS2CPacket;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2604;
/*    */ import net.minecraft.class_2668;
/*    */ import net.minecraft.class_2708;
/*    */ import net.minecraft.class_2743;
/*    */ 
/*    */ public class PacketLogger extends Module {
/* 15 */   private final BooleanSetting cameraPackets = (new BooleanSetting((CharSequence)EncryptedString.of("Camera Packets"), true))
/* 16 */     .setDescription((CharSequence)EncryptedString.of("Log camera-related packets"));
/* 17 */   private final BooleanSetting movementPackets = (new BooleanSetting((CharSequence)EncryptedString.of("Movement Packets"), true))
/* 18 */     .setDescription((CharSequence)EncryptedString.of("Log movement-related packets"));
/* 19 */   private final BooleanSetting entityPackets = (new BooleanSetting((CharSequence)EncryptedString.of("Entity Packets"), true))
/* 20 */     .setDescription((CharSequence)EncryptedString.of("Log entity position/teleport packets"));
/* 21 */   private final BooleanSetting weirdPackets = (new BooleanSetting((CharSequence)EncryptedString.of("Weird Packets"), true))
/* 22 */     .setDescription((CharSequence)EncryptedString.of("Log potentially suspicious packets"));
/*    */   
/*    */   public PacketLogger() {
/* 25 */     super((CharSequence)EncryptedString.of("Packet Logger"), (CharSequence)EncryptedString.of("Logs camera, movement, and weird packets from server"), -1, Category.MISC);
/* 26 */     addsettings(new Setting[] { (Setting)this.cameraPackets, (Setting)this.movementPackets, (Setting)this.entityPackets, (Setting)this.weirdPackets });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 31 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 36 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onPacketReceive(PacketReceiveEvent event) {
/* 41 */     if (!isEnabled()) {
/*    */       return;
/*    */     }
/* 44 */     if (this.cameraPackets.getValue()) {
/* 45 */       class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2708) { class_2708 packet = (class_2708)class_2596;
/* 46 */         class_243 pos = new class_243(packet.method_11734(), packet.method_11735(), packet.method_11738());
/* 47 */         System.out.println("[PacketLogger] CAMERA - PlayerPositionLook: pos=" + String.valueOf(pos) + " yaw=" + packet
/* 48 */             .method_11736() + " pitch=" + packet.method_11739() + " flags=" + 
/* 49 */             String.valueOf(packet.method_11733())); }
/*    */     
/*    */     } 
/*    */ 
/*    */     
/* 54 */     if (this.movementPackets.getValue()) {
/* 55 */       class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2743) { class_2743 packet = (class_2743)class_2596;
/* 56 */         IEntityVelocityUpdateS2CPacket iPacket = (IEntityVelocityUpdateS2CPacket)packet;
/* 57 */         class_243 velocity = iPacket.getVelocity();
/* 58 */         System.out.println("[PacketLogger] MOVEMENT - EntityVelocity: entityId=" + packet.method_11818() + " velocity=" + velocity
/* 59 */             .method_10216() + "," + velocity.method_10214() + "," + velocity.method_10215()); }
/*    */     
/*    */     } 
/*    */ 
/*    */     
/* 64 */     if (this.entityPackets.getValue()) {
/* 65 */       class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2604) { class_2604 packet = (class_2604)class_2596;
/* 66 */         class_243 pos = new class_243(packet.method_11175(), packet.method_11174(), packet.method_11176());
/* 67 */         System.out.println("[PacketLogger] ENTITY - EntitySpawn: type=" + String.valueOf(packet.method_11169()) + " pos=" + String.valueOf(pos)); }
/*    */     
/*    */     } 
/*    */ 
/*    */     
/* 72 */     if (this.weirdPackets.getValue()) {
/* 73 */       if (event.packet instanceof net.minecraft.class_2661) {
/* 74 */         System.out.println("[PacketLogger] WEIRD - Disconnect packet received");
/*    */       }
/* 76 */       class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2668) { class_2668 packet = (class_2668)class_2596;
/* 77 */         System.out.println("[PacketLogger] WEIRD - GameStateChange: reason=" + String.valueOf(packet.method_11491()) + " value=" + packet
/* 78 */             .method_11492()); }
/*    */ 
/*    */       
/* 81 */       class_2596 = event.packet; if (class_2596 instanceof class_2708) { class_2708 packet = (class_2708)class_2596;
/* 82 */         double x = packet.method_11734();
/* 83 */         double y = packet.method_11735();
/* 84 */         double z = packet.method_11738();
/*    */ 
/*    */         
/* 87 */         if (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(z) || 
/* 88 */           Double.isInfinite(x) || Double.isInfinite(y) || Double.isInfinite(z) || 
/* 89 */           Math.abs(x) > 500000.0D || Math.abs(y) > 500000.0D || Math.abs(z) > 500000.0D) {
/* 90 */           System.out.println("[PacketLogger] WEIRD - PlayerPositionLook with suspicious values: x=" + x + " y=" + y + " z=" + z);
/*    */         } }
/*    */ 
/*    */ 
/*    */       
/* 95 */       String packetName = event.packet.getClass().getSimpleName();
/* 96 */       if (packetName.contains("Position") || packetName.contains("Move") || packetName
/* 97 */         .contains("Teleport") || packetName.contains("Camera"))
/* 98 */         System.out.println("[PacketLogger] WEIRD - Suspicious packet type: " + packetName); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\PacketLogger.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */