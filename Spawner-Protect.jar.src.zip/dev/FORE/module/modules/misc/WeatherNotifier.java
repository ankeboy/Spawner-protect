/*     */ package dev.FORE.module.modules.misc;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.module.setting.StringSetting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.embed.DiscordWebhook;
/*     */ import java.awt.Color;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.time.LocalDateTime;
/*     */ import java.time.format.DateTimeFormatter;
/*     */ import net.minecraft.class_638;
/*     */ 
/*     */ public class WeatherNotifier extends Module {
/*  19 */   private final BooleanSetting enableWebhook = (new BooleanSetting("Enable Webhook", true))
/*  20 */     .setDescription((CharSequence)EncryptedString.of("Send webhook notifications when weather changes"));
/*     */   
/*  22 */   private final StringSetting webhookUrl = (new StringSetting("Webhook URL", ""))
/*  23 */     .setDescription((CharSequence)EncryptedString.of("Discord webhook URL"));
/*     */   
/*  25 */   private final BooleanSetting notifyRain = (new BooleanSetting("Notify Rain", true))
/*  26 */     .setDescription((CharSequence)EncryptedString.of("Send notification when it starts raining"));
/*     */   
/*  28 */   private final BooleanSetting notifyThunder = (new BooleanSetting("Notify Thunder", true))
/*  29 */     .setDescription((CharSequence)EncryptedString.of("Send notification when there's thunder"));
/*     */   
/*  31 */   private final BooleanSetting notifyClear = (new BooleanSetting("Notify Clear", false))
/*  32 */     .setDescription((CharSequence)EncryptedString.of("Send notification when weather clears"));
/*     */   
/*  34 */   private final BooleanSetting debugMode = (new BooleanSetting("Debug Mode", false))
/*  35 */     .setDescription((CharSequence)EncryptedString.of("Show debug information in chat"));
/*     */   
/*  37 */   private final BooleanSetting testWebhook = (new BooleanSetting("Test Webhook", false))
/*  38 */     .setDescription((CharSequence)EncryptedString.of("Send a test webhook message"));
/*     */   
/*     */   private boolean wasRaining = false;
/*     */   private boolean wasThundering = false;
/*     */   private boolean wasClear = true;
/*  43 */   private int tickCounter = 0;
/*     */   private boolean testSent = false;
/*     */   
/*     */   public WeatherNotifier() {
/*  47 */     super((CharSequence)EncryptedString.of("Weather Notifier"), (CharSequence)EncryptedString.of("Sends webhook notifications when weather changes"), -1, Category.MISC);
/*  48 */     addsettings(new Setting[] { (Setting)this.enableWebhook, (Setting)this.webhookUrl, (Setting)this.notifyRain, (Setting)this.notifyThunder, (Setting)this.notifyClear, (Setting)this.debugMode, (Setting)this.testWebhook });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  53 */     super.onEnable();
/*  54 */     System.out.println("[WeatherNotifier] Module enabled!");
/*     */ 
/*     */     
/*  57 */     if (this.mc.field_1687 != null) {
/*  58 */       this.wasRaining = this.mc.field_1687.method_8419();
/*  59 */       this.wasThundering = this.mc.field_1687.method_8546();
/*  60 */       this.wasClear = (!this.mc.field_1687.method_8419() && !this.mc.field_1687.method_8546());
/*     */       
/*  62 */       System.out.println("[WeatherNotifier] Initial weather state - Rain: " + this.wasRaining + ", Thunder: " + this.wasThundering + ", Clear: " + this.wasClear);
/*     */ 
/*     */       
/*  65 */       if (this.enableWebhook.getValue() && !this.webhookUrl.getValue().trim().isEmpty()) {
/*  66 */         sendSimpleWebhook("🔧 Weather Notifier Test", "Module has been enabled and is ready to detect weather changes!");
/*     */       }
/*     */     } else {
/*  69 */       System.out.println("[WeatherNotifier] World is null, cannot initialize weather state");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  75 */     super.onDisable();
/*  76 */     System.out.println("[WeatherNotifier] Module disabled!");
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  81 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null)
/*     */       return; 
/*  83 */     this.tickCounter++;
/*     */ 
/*     */     
/*  86 */     if (this.testWebhook.getValue() && !this.testSent) {
/*  87 */       this.testSent = true;
/*  88 */       System.out.println("[WeatherNotifier] Sending test webhook...");
/*  89 */       sendSimpleWebhook("🧪 Manual Test", "This is a manual test webhook from Weather Notifier!");
/*  90 */     } else if (!this.testWebhook.getValue()) {
/*  91 */       this.testSent = false;
/*     */     } 
/*     */     
/*  94 */     class_638 class_638 = this.mc.field_1687;
/*  95 */     boolean isRaining = class_638.method_8419();
/*  96 */     boolean isThundering = class_638.method_8546();
/*  97 */     boolean isClear = (!isRaining && !isThundering);
/*     */ 
/*     */     
/* 100 */     if (this.debugMode.getValue() && this.tickCounter % 100 == 0) {
/* 101 */       System.out.println("[WeatherNotifier] Debug - Rain: " + isRaining + ", Thunder: " + isThundering + ", Clear: " + isClear);
/* 102 */       System.out.println("[WeatherNotifier] Debug - Was Rain: " + this.wasRaining + ", Was Thunder: " + this.wasThundering + ", Was Clear: " + this.wasClear);
/* 103 */       System.out.println("[WeatherNotifier] Debug - Webhook enabled: " + this.enableWebhook.getValue() + ", URL set: " + (!this.webhookUrl.getValue().trim().isEmpty() ? 1 : 0));
/*     */     } 
/*     */ 
/*     */     
/* 107 */     if (this.enableWebhook.getValue() && !this.webhookUrl.getValue().trim().isEmpty()) {
/*     */       
/* 109 */       if (this.notifyRain.getValue() && isRaining && !this.wasRaining) {
/* 110 */         System.out.println("[WeatherNotifier] Rain detected! Sending notification...");
/* 111 */         sendSimpleWebhook("🌧️ Rain Started", "It's starting to rain!");
/*     */       } 
/*     */ 
/*     */       
/* 115 */       if (this.notifyThunder.getValue() && isThundering && !this.wasThundering) {
/* 116 */         System.out.println("[WeatherNotifier] Thunder detected! Sending notification...");
/* 117 */         sendSimpleWebhook("⛈️ Thunderstorm Started", "A thunderstorm has begun!");
/*     */       } 
/*     */ 
/*     */       
/* 121 */       if (this.notifyClear.getValue() && isClear && !this.wasClear) {
/* 122 */         System.out.println("[WeatherNotifier] Clear weather detected! Sending notification...");
/* 123 */         sendSimpleWebhook("☀️ Weather Cleared", "The weather has cleared up!");
/*     */       } 
/* 125 */     } else if (this.enableWebhook.getValue() && this.webhookUrl.getValue().trim().isEmpty()) {
/*     */       
/* 127 */       if (this.tickCounter % 200 == 0) {
/* 128 */         System.out.println("[WeatherNotifier] Warning: Webhook is enabled but no URL is set!");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 133 */     this.wasRaining = isRaining;
/* 134 */     this.wasThundering = isThundering;
/* 135 */     this.wasClear = isClear;
/*     */   }
/*     */   
/*     */   private void sendSimpleWebhook(String title, String description) {
/*     */     try {
/* 140 */       String url = this.webhookUrl.getValue().trim();
/* 141 */       if (url.isEmpty()) {
/* 142 */         System.out.println("[WeatherNotifier] Webhook URL not configured!");
/*     */         
/*     */         return;
/*     */       } 
/* 146 */       System.out.println("[WeatherNotifier] Sending simple webhook to: " + url);
/*     */ 
/*     */       
/* 149 */       String jsonPayload = String.format("{\"username\":\"Weather Notifier\",\"avatar_url\":\"https://i.imgur.com/OL2y1cr.png\",\"embeds\":[{\"title\":\"%s\",\"description\":\"%s\",\"color\":3447003,\"footer\":{\"text\":\"Krypton Weather Notifier\"},\"fields\":[{\"name\":\"Time\",\"value\":\"%s\",\"inline\":true},{\"name\":\"Location\",\"value\":\"X: %.1f, Y: %.1f, Z: %.1f\",\"inline\":true}]}]}", new Object[] { title, description, 
/*     */ 
/*     */ 
/*     */             
/* 153 */             LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), 
/* 154 */             Double.valueOf(this.mc.field_1724.method_23317()), 
/* 155 */             Double.valueOf(this.mc.field_1724.method_23318()), 
/* 156 */             Double.valueOf(this.mc.field_1724.method_23321()) });
/*     */ 
/*     */ 
/*     */       
/* 160 */       URL webhookUrl = new URL(url);
/* 161 */       HttpURLConnection connection = (HttpURLConnection)webhookUrl.openConnection();
/* 162 */       connection.setRequestMethod("POST");
/* 163 */       connection.setRequestProperty("Content-Type", "application/json");
/* 164 */       connection.setRequestProperty("User-Agent", "WeatherNotifier/1.0");
/* 165 */       connection.setDoOutput(true);
/*     */ 
/*     */       
/* 168 */       OutputStream os = connection.getOutputStream(); 
/* 169 */       try { byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
/* 170 */         os.write(input, 0, input.length);
/* 171 */         if (os != null) os.close();  } catch (Throwable throwable) { if (os != null)
/*     */           try { os.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */             throw throwable; }
/* 174 */        int responseCode = connection.getResponseCode();
/* 175 */       System.out.println("[WeatherNotifier] Webhook response code: " + responseCode);
/*     */       
/* 177 */       if (responseCode == 204) {
/* 178 */         System.out.println("[WeatherNotifier] Webhook sent successfully!");
/*     */       } else {
/* 180 */         System.out.println("[WeatherNotifier] Webhook failed with response code: " + responseCode);
/*     */         
/* 182 */         BufferedReader br = new BufferedReader(new InputStreamReader(connection.getErrorStream()));
/*     */         
/* 184 */         try { StringBuilder response = new StringBuilder(); String line;
/* 185 */           while ((line = br.readLine()) != null) {
/* 186 */             response.append(line);
/*     */           }
/* 188 */           System.out.println("[WeatherNotifier] Error response: " + response.toString());
/* 189 */           br.close(); } catch (Throwable throwable) { try { br.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */            throw throwable; }
/*     */       
/* 192 */       }  connection.disconnect();
/*     */     }
/* 194 */     catch (Exception e) {
/* 195 */       System.err.println("[WeatherNotifier] Failed to send webhook: " + e.getMessage());
/* 196 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendWeatherNotification(String title, String description, Color color) {
/*     */     try {
/* 202 */       String url = this.webhookUrl.getValue().trim();
/* 203 */       if (url.isEmpty()) {
/* 204 */         System.out.println("[WeatherNotifier] Webhook URL not configured!");
/*     */         
/*     */         return;
/*     */       } 
/* 208 */       System.out.println("[WeatherNotifier] Sending webhook to: " + url);
/*     */       
/* 210 */       DiscordWebhook webhook = new DiscordWebhook(url);
/* 211 */       webhook.setUsername("Weather Notifier");
/* 212 */       webhook.setAvatarUrl("https://i.imgur.com/OL2y1cr.png");
/*     */       
/* 214 */       DiscordWebhook.EmbedObject embed = new DiscordWebhook.EmbedObject();
/* 215 */       embed.setTitle(title);
/* 216 */       embed.setDescription(description);
/* 217 */       embed.setColor(color);
/* 218 */       embed.setFooter("Krypton Weather Notifier", "https://i.imgur.com/OL2y1cr.png");
/*     */ 
/*     */       
/* 221 */       embed.addField("Time", LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss")), true);
/*     */ 
/*     */       
/* 224 */       if (this.mc.field_1724 != null) {
/* 225 */         embed.addField("Location", String.format("X: %.1f, Y: %.1f, Z: %.1f", new Object[] {
/* 226 */                 Double.valueOf(this.mc.field_1724.method_23317()), Double.valueOf(this.mc.field_1724.method_23318()), Double.valueOf(this.mc.field_1724.method_23321())
/*     */               }), true);
/*     */       }
/*     */       
/* 230 */       if (this.mc.method_1558() != null) {
/* 231 */         embed.addField("Server", (this.mc.method_1558()).field_3761, true);
/*     */       }
/*     */       
/* 234 */       webhook.addEmbed(embed);
/* 235 */       webhook.execute();
/*     */       
/* 237 */       System.out.println("[WeatherNotifier] Weather notification sent successfully: " + title);
/*     */     }
/* 239 */     catch (Throwable e) {
/* 240 */       System.err.println("[WeatherNotifier] Failed to send webhook: " + e.getMessage());
/* 241 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\WeatherNotifier.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */