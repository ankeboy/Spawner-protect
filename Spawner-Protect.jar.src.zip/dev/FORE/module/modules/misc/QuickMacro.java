/*    */ package dev.FORE.module.modules.misc;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.MacroSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import java.util.List;
/*    */ 
/*    */ public final class QuickMacro extends Module {
/* 12 */   private final MacroSetting quickCommands = (new MacroSetting((CharSequence)EncryptedString.of("Quick Commands")))
/* 13 */     .setDescription((CharSequence)EncryptedString.of("Commands to execute when keybind is pressed"));
/*    */   
/* 15 */   private final BooleanSetting showNotifications = (new BooleanSetting((CharSequence)EncryptedString.of("Show Notifications"), true))
/* 16 */     .setDescription((CharSequence)EncryptedString.of("Show chat notifications when commands are executed"));
/*    */   
/* 18 */   private final BooleanSetting executeAll = (new BooleanSetting((CharSequence)EncryptedString.of("Execute All"), false))
/* 19 */     .setDescription((CharSequence)EncryptedString.of("Execute all commands or just the first one"));
/*    */   
/*    */   public QuickMacro() {
/* 22 */     super((CharSequence)EncryptedString.of("Quick Macro"), 
/* 23 */         (CharSequence)EncryptedString.of("🐱 Execute macro commands quickly with a keybind"), -1, Category.MISC);
/*    */ 
/*    */     
/* 26 */     addsettings(new Setting[] { (Setting)this.quickCommands, (Setting)this.showNotifications, (Setting)this.executeAll });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 31 */     super.onEnable();
/* 32 */     executeQuickMacro();
/*    */     
/* 34 */     toggle();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 39 */     super.onDisable();
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {}
/*    */ 
/*    */   
/*    */   private void executeQuickMacro() {
/* 48 */     if (this.mc.field_1724 == null || this.mc.method_1562() == null) {
/*    */       return;
/*    */     }
/*    */     
/* 52 */     List<String> commandList = this.quickCommands.getCommands();
/* 53 */     if (commandList.isEmpty()) {
/* 54 */       if (this.showNotifications.getValue()) {
/* 55 */         this.mc.field_1724.method_43496(EncryptedString.of("§c🐱 Quick Macro: No commands configured!").toText());
/*    */       }
/*    */       
/*    */       return;
/*    */     } 
/* 60 */     if (this.executeAll.getValue()) {
/*    */       
/* 62 */       for (int i = 0; i < commandList.size(); i++) {
/* 63 */         String command = commandList.get(i);
/* 64 */         executeCommand(command);
/* 65 */         if (this.showNotifications.getValue()) {
/* 66 */           this.mc.field_1724.method_43496(EncryptedString.of("§e🐱 Quick Macro: Executed command " + i + 1 + "/" + commandList.size()).toText());
/*    */         }
/*    */       } 
/* 69 */       if (this.showNotifications.getValue()) {
/* 70 */         this.mc.field_1724.method_43496(EncryptedString.of("§a🐱 Quick Macro: All commands executed!").toText());
/*    */       }
/*    */     } else {
/*    */       
/* 74 */       String command = commandList.get(0);
/* 75 */       executeCommand(command);
/* 76 */       if (this.showNotifications.getValue()) {
/* 77 */         this.mc.field_1724.method_43496(EncryptedString.of("§a🐱 Quick Macro: Executed command!").toText());
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private void executeCommand(String command) {
/* 83 */     if (command.startsWith("/")) {
/*    */       
/* 85 */       command = command.substring(1);
/* 86 */       this.mc.method_1562().method_45730(command);
/*    */     } else {
/*    */       
/* 89 */       this.mc.method_1562().method_45729(command);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\QuickMacro.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */