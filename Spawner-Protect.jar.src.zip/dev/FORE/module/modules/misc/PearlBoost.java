/*    */ package dev.FORE.module.modules.misc;
/*    */ 
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ 
/*    */ public final class PearlBoost extends Module {
/*    */   public static PearlBoost instance;
/* 11 */   private final NumberSetting SpeedMultiplier = new NumberSetting((CharSequence)EncryptedString.of("Boost"), 0.1D, 50.0D, 2.0D, 0.1D);
/*    */   
/*    */   public PearlBoost() {
/* 14 */     super((CharSequence)EncryptedString.of("Pearl Boost"), (CharSequence)EncryptedString.of("Boosts your pearl so it goes further"), -1, Category.MISC);
/* 15 */     addsettings(new Setting[] { (Setting)this.SpeedMultiplier });
/*    */ 
/*    */     
/* 18 */     instance = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 23 */     super.onEnable();
/*    */   }
/*    */   
/*    */   public double getMultiplier() {
/* 27 */     return isEnabled() ? this.SpeedMultiplier.getIntValue() : 1.0D;
/*    */   }
/*    */ 
/*    */   
/*    */   public static PearlBoost getInstance() {
/* 32 */     if (instance == null) {
/* 33 */       instance = new PearlBoost();
/*    */     }
/* 35 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\PearlBoost.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */