/*    */ package dev.FORE.module.modules.misc;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.PacketReceiveEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2708;
/*    */ 
/*    */ public class PositionPacketFilter extends Module {
/* 13 */   private final BooleanSetting filterExtremePositions = (new BooleanSetting((CharSequence)EncryptedString.of("Filter Extreme Positions"), true))
/* 14 */     .setDescription((CharSequence)EncryptedString.of("Filters position packets with coordinates beyond normal Minecraft bounds"));
/* 15 */   private final NumberSetting maxCoordinate = (new NumberSetting((CharSequence)EncryptedString.of("Max Coordinate"), 100000.0D, 1.0E7D, 500000.0D, 10000.0D))
/* 16 */     .setDescription((CharSequence)EncryptedString.of("Maximum valid coordinate value (normal gameplay is ~-100k to +100k)"));
/*    */   
/*    */   public PositionPacketFilter() {
/* 19 */     super((CharSequence)EncryptedString.of("Position Packet Filter"), (CharSequence)EncryptedString.of("Filters invalid position packets from server that cause ESP wobbling"), -1, Category.MISC);
/* 20 */     addsettings(new Setting[] { (Setting)this.filterExtremePositions, (Setting)this.maxCoordinate });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 25 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 30 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onPacketReceive(PacketReceiveEvent event) {
/* 35 */     if (!isEnabled() || !this.filterExtremePositions.getValue())
/*    */       return; 
/* 37 */     class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2708) { class_2708 packet = (class_2708)class_2596;
/* 38 */       double x = packet.method_11734();
/* 39 */       double y = packet.method_11735();
/* 40 */       double z = packet.method_11738();
/* 41 */       double maxCoord = this.maxCoordinate.getValue();
/*    */ 
/*    */ 
/*    */ 
/*    */       
/* 46 */       boolean isInvalid = (Double.isNaN(x) || Double.isNaN(y) || Double.isNaN(z) || Double.isInfinite(x) || Double.isInfinite(y) || Double.isInfinite(z) || Math.abs(x) > maxCoord || Math.abs(y) > maxCoord || Math.abs(z) > maxCoord);
/*    */       
/* 48 */       if (isInvalid) {
/*    */         
/* 50 */         event.cancel();
/* 51 */         System.out.println("[PositionPacketFilter] Blocked invalid position packet: x=" + x + " y=" + y + " z=" + z);
/*    */       }  }
/*    */   
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\PositionPacketFilter.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */