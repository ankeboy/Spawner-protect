/*    */ package dev.FORE.module.modules.misc;
/*    */ 
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BindSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.module.setting.StringSetting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import dev.FORE.utils.KeyUtils;
/*    */ import dev.FORE.utils.embed.DiscordWebhook;
/*    */ import java.util.concurrent.CompletableFuture;
/*    */ 
/*    */ public final class CordSnapper extends Module {
/* 16 */   private final BindSetting activateKey = new BindSetting((CharSequence)EncryptedString.of("Activate Key"), -1, false);
/* 17 */   private final StringSetting webhookUrl = new StringSetting((CharSequence)EncryptedString.of("Webhook"), "");
/*    */   private int cooldownCounter;
/*    */   
/*    */   public CordSnapper() {
/* 21 */     super((CharSequence)EncryptedString.of("Cord Snapper"), (CharSequence)EncryptedString.of("Sends base coordinates to discord webhook"), -1, Category.MISC);
/* 22 */     this.cooldownCounter = 0;
/* 23 */     addsettings(new Setting[] { (Setting)this.activateKey, (Setting)this.webhookUrl });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 28 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 33 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {
/* 38 */     if (this.mc.field_1724 == null) {
/*    */       return;
/*    */     }
/* 41 */     if (this.cooldownCounter > 0) {
/* 42 */       this.cooldownCounter--;
/*    */       return;
/*    */     } 
/* 45 */     if (KeyUtils.isKeyPressed(this.activateKey.getValue())) {
/* 46 */       DiscordWebhook embedSender = new DiscordWebhook(this.webhookUrl.value);
/* 47 */       embedSender.setContent("Coordinates: x: " + this.mc.field_1724.method_23317() + " y: " + this.mc.field_1724.method_23318() + " z: " + this.mc.field_1724.method_23321());
/* 48 */       CompletableFuture.runAsync(() -> {
/*    */             try {
/*    */               embedSender.execute();
/* 51 */             } catch (Throwable _t) {
/*    */               _t.printStackTrace(System.err);
/*    */             } 
/*    */           });
/* 55 */       this.cooldownCounter = 40;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\CordSnapper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */