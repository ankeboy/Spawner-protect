/*    */ package dev.FORE.module.modules.misc;
/*    */ 
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ 
/*    */ public final class TridentBoost extends Module {
/*    */   public static TridentBoost instance;
/* 12 */   private final NumberSetting SpeedMultiplier = new NumberSetting((CharSequence)EncryptedString.of("Boost"), 0.1D, 50.0D, 2.0D, 0.1D);
/* 13 */   private final BooleanSetting allowOutOfWater = new BooleanSetting((CharSequence)EncryptedString.of("Out of water"), true);
/*    */   
/*    */   public TridentBoost() {
/* 16 */     super((CharSequence)EncryptedString.of("Trident Boost"), (CharSequence)EncryptedString.of("Boosts you when using riptide with a trident."), -1, Category.MISC);
/* 17 */     addsettings(new Setting[] { (Setting)this.allowOutOfWater, (Setting)this.SpeedMultiplier });
/*    */ 
/*    */     
/* 20 */     instance = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 25 */     super.onEnable();
/*    */   }
/*    */   
/*    */   public double getMultiplier() {
/* 29 */     return isEnabled() ? this.SpeedMultiplier.getIntValue() : 1.0D;
/*    */   }
/*    */   
/*    */   public boolean allowOutOfWater() {
/* 33 */     return isEnabled() ? this.allowOutOfWater.getValue() : false;
/*    */   }
/*    */   
/*    */   public static TridentBoost getInstance() {
/* 37 */     if (instance == null) {
/* 38 */       instance = new TridentBoost();
/*    */     }
/* 40 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\TridentBoost.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */