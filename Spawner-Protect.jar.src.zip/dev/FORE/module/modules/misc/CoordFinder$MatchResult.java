/*    */ package dev.FORE.module.modules.misc;
/*    */ 
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class MatchResult
/*    */ {
/*    */   class_2338 position;
/*    */   int matchCount;
/*    */   
/*    */   MatchResult(class_2338 position, int matchCount) {
/* 44 */     this.position = position;
/* 45 */     this.matchCount = matchCount;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\CoordFinder$MatchResult.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */