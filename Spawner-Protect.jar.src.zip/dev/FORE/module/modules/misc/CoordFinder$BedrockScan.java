/*    */ package dev.FORE.module.modules.misc;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class BedrockScan
/*    */ {
/*    */   int displayX;
/*    */   int displayZ;
/*    */   long patternHash;
/*    */   String biome;
/*    */   
/*    */   BedrockScan(int displayX, int displayZ, long patternHash, String biome) {
/* 32 */     this.displayX = displayX;
/* 33 */     this.displayZ = displayZ;
/* 34 */     this.patternHash = patternHash;
/* 35 */     this.biome = biome;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\CoordFinder$BedrockScan.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */