/*     */ package dev.FORE.module.modules.misc;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.mixin.MinecraftClientAccessor;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.InventoryUtil;
/*     */ import net.minecraft.class_4174;
/*     */ import net.minecraft.class_9334;
/*     */ 
/*     */ public final class AutoEat extends Module {
/*  15 */   private final NumberSetting healthThreshold = new NumberSetting((CharSequence)EncryptedString.of("Health Threshold"), 0.0D, 19.0D, 17.0D, 1.0D);
/*  16 */   private final NumberSetting hungerThreshold = new NumberSetting((CharSequence)EncryptedString.of("Hunger Threshold"), 0.0D, 19.0D, 19.0D, 1.0D);
/*     */   public boolean isEa;
/*     */   private int selectedFoodSlot;
/*     */   private int previousSelectedSlot;
/*     */   
/*     */   public AutoEat() {
/*  22 */     super((CharSequence)EncryptedString.of("Auto Eat"), (CharSequence)EncryptedString.of(" It detects whenever the hungerbar/health falls a certain threshold, selects food in your hotbar, and starts eating."), -1, Category.MISC);
/*  23 */     addsettings(new Setting[] { (Setting)this.healthThreshold, (Setting)this.hungerThreshold });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  28 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  33 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent tickEvent) {
/*  38 */     if (this.isEa) {
/*  39 */       if (shouldEat()) {
/*  40 */         if (this.mc.field_1724.method_31548().method_5438(this.selectedFoodSlot).method_57824(class_9334.field_50075) != null) {
/*  41 */           int bestSlot = findBestFoodSlot();
/*  42 */           if (bestSlot == -1) {
/*  43 */             stopEating();
/*     */             return;
/*     */           } 
/*  46 */           selectSlot(bestSlot);
/*     */         } 
/*  48 */         startEating();
/*     */       } else {
/*  50 */         stopEating();
/*     */       } 
/*  52 */     } else if (shouldEat()) {
/*  53 */       this.selectedFoodSlot = findBestFoodSlot();
/*  54 */       if (this.selectedFoodSlot != -1) {
/*  55 */         saveCurrentSlot();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean shouldEat() {
/*  61 */     boolean healthLow = (this.mc.field_1724.method_6032() <= this.healthThreshold.getIntValue());
/*  62 */     boolean hungerLow = (this.mc.field_1724.method_7344().method_7586() <= this.hungerThreshold.getIntValue());
/*  63 */     return (findBestFoodSlot() != -1 && (healthLow || hungerLow));
/*     */   }
/*     */   
/*     */   private int findBestFoodSlot() {
/*  67 */     int bestSlot = -1;
/*  68 */     int bestNutrition = -1;
/*  69 */     for (int slotIndex = 0; slotIndex < 9; slotIndex++) {
/*  70 */       Object value = this.mc.field_1724.method_31548().method_5438(slotIndex).method_7909().method_57347().method_57829(class_9334.field_50075);
/*  71 */       if (value != null) {
/*  72 */         int nutrition = ((class_4174)value).comp_2491();
/*  73 */         if (nutrition > bestNutrition) {
/*  74 */           bestSlot = slotIndex;
/*  75 */           bestNutrition = nutrition;
/*     */         } 
/*     */       } 
/*     */     } 
/*  79 */     return bestSlot;
/*     */   }
/*     */   
/*     */   private void saveCurrentSlot() {
/*  83 */     this.previousSelectedSlot = (this.mc.field_1724.method_31548()).field_7545;
/*  84 */     startEating();
/*     */   }
/*     */   
/*     */   private void startEating() {
/*  88 */     selectSlot(this.selectedFoodSlot);
/*  89 */     setUseKeyPressed(true);
/*  90 */     if (!this.mc.field_1724.method_6115()) {
/*  91 */       ((MinecraftClientAccessor)this.mc).invokeDoItemUse();
/*     */     }
/*  93 */     this.isEa = true;
/*     */   }
/*     */   
/*     */   private void stopEating() {
/*  97 */     selectSlot(this.previousSelectedSlot);
/*  98 */     setUseKeyPressed(false);
/*  99 */     this.isEa = false;
/*     */   }
/*     */   
/*     */   private void setUseKeyPressed(boolean pressed) {
/* 103 */     this.mc.field_1690.field_1904.method_23481(pressed);
/*     */   }
/*     */   
/*     */   private void selectSlot(int slotIndex) {
/* 107 */     InventoryUtil.swap(slotIndex);
/* 108 */     this.selectedFoodSlot = slotIndex;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\AutoEat.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */