/*    */ package dev.FORE.module.modules.misc;
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_239;
/*    */ import net.minecraft.class_3965;
/*    */ 
/*    */ public final class AutoMine extends Module {
/* 18 */   private final BooleanSetting lockView = new BooleanSetting((CharSequence)EncryptedString.of("Lock View"), true);
/* 19 */   private final NumberSetting pitch = new NumberSetting((CharSequence)EncryptedString.of("Pitch"), -180.0D, 180.0D, 0.0D, 0.1D);
/* 20 */   private final NumberSetting yaw = new NumberSetting((CharSequence)EncryptedString.of("Yaw"), -180.0D, 180.0D, 0.0D, 0.1D);
/*    */   
/*    */   public AutoMine() {
/* 23 */     super((CharSequence)EncryptedString.of("Auto Mine"), (CharSequence)EncryptedString.of("Module that allows players to automatically mine"), -1, Category.MISC);
/* 24 */     addsettings(new Setting[] { (Setting)this.lockView, (Setting)this.pitch, (Setting)this.yaw });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 29 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 34 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {
/* 39 */     if (this.mc.field_1755 != null) {
/*    */       return;
/*    */     }
/* 42 */     Module moduleByClass = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoEat.class);
/* 43 */     if (moduleByClass.isEnabled() && ((AutoEat)moduleByClass).shouldEat()) {
/*    */       return;
/*    */     }
/* 46 */     processMiningAction(true);
/* 47 */     if (this.lockView.getValue()) {
/* 48 */       float currentYaw = this.mc.field_1724.method_36454();
/* 49 */       float currentPitch = this.mc.field_1724.method_36455();
/* 50 */       float targetYaw = this.yaw.getFloatValue();
/* 51 */       float targetPitch = this.pitch.getFloatValue();
/* 52 */       if (currentYaw != targetYaw || currentPitch != targetPitch) {
/* 53 */         this.mc.field_1724.method_36456(targetYaw);
/* 54 */         this.mc.field_1724.method_36457(targetPitch);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void processMiningAction(boolean shouldMine) {
/* 60 */     if (!this.mc.field_1724.method_6115())
/* 61 */       if (shouldMine && this.mc.field_1765 != null && this.mc.field_1765.method_17783() == class_239.class_240.field_1332) {
/* 62 */         class_3965 blockHitResult = (class_3965)this.mc.field_1765;
/* 63 */         class_2338 blockPos = ((class_3965)this.mc.field_1765).method_17777();
/* 64 */         if (!this.mc.field_1687.method_8320(blockPos).method_26215()) {
/* 65 */           class_2350 side = blockHitResult.method_17780();
/* 66 */           if (this.mc.field_1761.method_2902(blockPos, side)) {
/* 67 */             this.mc.field_1713.method_3054(blockPos, side);
/* 68 */             this.mc.field_1724.method_6104(class_1268.field_5808);
/*    */           } 
/*    */         } 
/*    */       } else {
/* 72 */         this.mc.field_1761.method_2925();
/*    */       }  
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\AutoMine.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */