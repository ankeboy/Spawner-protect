/*    */ package dev.FORE.module.modules.misc;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BindSetting;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import dev.FORE.utils.InventoryUtil;
/*    */ import dev.FORE.utils.KeyUtils;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1269;
/*    */ import net.minecraft.class_1657;
/*    */ 
/*    */ public final class KeyPearl extends Module {
/* 18 */   private final BindSetting activateKey = new BindSetting((CharSequence)EncryptedString.of("Activate Key"), -1, false);
/* 19 */   private final NumberSetting throwDelay = new NumberSetting((CharSequence)EncryptedString.of("Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/* 20 */   private final BooleanSetting switchBack = new BooleanSetting((CharSequence)EncryptedString.of("Switch Back"), true);
/* 21 */   private final NumberSetting switchBackDelay = (new NumberSetting((CharSequence)EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 0.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("Delay after throwing pearl before switching back"));
/*    */   private boolean isActivated;
/*    */   private boolean hasThrown;
/*    */   private int currentThrowDelay;
/*    */   private int previousSlot;
/*    */   private int currentSwitchBackDelay;
/*    */   
/*    */   public KeyPearl() {
/* 29 */     super((CharSequence)EncryptedString.of("Key Pearl"), (CharSequence)EncryptedString.of("Switches to an ender pearl and throws it when you press a bind"), -1, Category.MISC);
/* 30 */     addsettings(new Setting[] { (Setting)this.activateKey, (Setting)this.throwDelay, (Setting)this.switchBack, (Setting)this.switchBackDelay });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 35 */     resetState();
/* 36 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 41 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {
/* 46 */     if (this.mc.field_1755 != null) {
/*    */       return;
/*    */     }
/* 49 */     if (KeyUtils.isKeyPressed(this.activateKey.getValue())) {
/* 50 */       this.isActivated = true;
/*    */     }
/* 52 */     if (this.isActivated) {
/* 53 */       if (this.previousSlot == -1) {
/* 54 */         this.previousSlot = (this.mc.field_1724.method_31548()).field_7545;
/*    */       }
/* 56 */       InventoryUtil.swap(class_1802.field_8634);
/* 57 */       if (this.currentThrowDelay < this.throwDelay.getIntValue()) {
/* 58 */         this.currentThrowDelay++;
/*    */         return;
/*    */       } 
/* 61 */       if (!this.hasThrown) {
/* 62 */         class_1269 interactItem = this.mc.field_1761.method_2919((class_1657)this.mc.field_1724, class_1268.field_5808);
/* 63 */         if (interactItem.method_23665() && interactItem.method_23666()) {
/* 64 */           this.mc.field_1724.method_6104(class_1268.field_5808);
/*    */         }
/* 66 */         this.hasThrown = true;
/*    */       } 
/* 68 */       if (this.switchBack.getValue()) {
/* 69 */         handleSwitchBack();
/*    */       } else {
/* 71 */         resetState();
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private void handleSwitchBack() {
/* 77 */     if (this.currentSwitchBackDelay < this.switchBackDelay.getIntValue()) {
/* 78 */       this.currentSwitchBackDelay++;
/*    */       return;
/*    */     } 
/* 81 */     InventoryUtil.swap(this.previousSlot);
/* 82 */     resetState();
/*    */   }
/*    */   
/*    */   private void resetState() {
/* 86 */     this.previousSlot = -1;
/* 87 */     this.currentThrowDelay = 0;
/* 88 */     this.currentSwitchBackDelay = 0;
/* 89 */     this.isActivated = false;
/* 90 */     this.hasThrown = false;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\KeyPearl.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */