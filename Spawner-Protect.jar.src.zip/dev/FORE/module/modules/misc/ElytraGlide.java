/*     */ package dev.FORE.module.modules.misc;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.PreItemUseEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import net.minecraft.class_1304;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_304;
/*     */ 
/*     */ public final class ElytraGlide extends Module {
/*     */   private boolean shouldStartFlying;
/*     */   private int jumpTimer;
/*  16 */   private int originalSlot = -1;
/*     */   private boolean hasRightClicked;
/*     */   private boolean hasJumped;
/*     */   private boolean shouldStartElytraFlight;
/*     */   
/*     */   public ElytraGlide() {
/*  22 */     super((CharSequence)EncryptedString.of("Elytra Glide"), (CharSequence)EncryptedString.of("Automatically starts flying when right-clicking firework rocket while standing still"), -1, Category.MISC);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  27 */     super.onEnable();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  33 */     if (this.mc.field_1724 != null) {
/*  34 */       class_304.method_1416(this.mc.field_1690.field_1903.method_1429(), false);
/*     */     }
/*  36 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  41 */     if (this.mc.field_1755 != null) {
/*     */       return;
/*     */     }
/*  44 */     if (this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  49 */     if (!this.mc.field_1724.method_31548().method_7372(class_1304.field_6174.method_5927()).method_31574(class_1802.field_8833)) {
/*  50 */       resetState();
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  55 */     if (this.jumpTimer > 0) {
/*  56 */       this.jumpTimer--;
/*  57 */       if (this.jumpTimer == 0) {
/*  58 */         class_304.method_1416(this.mc.field_1690.field_1903.method_1429(), false);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  63 */     if (this.mc.field_1724.method_6047().method_31574(class_1802.field_8639) && this.mc.field_1690.field_1904
/*  64 */       .method_1434() && !this.hasRightClicked) {
/*     */ 
/*     */       
/*  67 */       this.hasRightClicked = true;
/*     */ 
/*     */       
/*  70 */       if (this.mc.field_1724.method_24828() && !this.mc.field_1724.method_6128()) {
/*  71 */         this.shouldStartFlying = true;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  76 */     if (!this.mc.field_1690.field_1904.method_1434()) {
/*  77 */       this.hasRightClicked = false;
/*     */     }
/*     */ 
/*     */     
/*  81 */     if (this.shouldStartFlying)
/*     */     {
/*  83 */       if (this.mc.field_1724.method_24828()) {
/*     */         
/*  85 */         class_304.method_1416(this.mc.field_1690.field_1903.method_1429(), true);
/*  86 */         this.jumpTimer = 3;
/*  87 */         this.hasJumped = true;
/*  88 */         this.shouldStartFlying = false;
/*  89 */         this.shouldStartElytraFlight = true;
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  94 */     if (this.shouldStartElytraFlight && this.hasJumped && !this.mc.field_1724.method_24828() && !this.mc.field_1724.method_6128()) {
/*     */       
/*  96 */       class_304.method_1416(this.mc.field_1690.field_1903.method_1429(), true);
/*  97 */       this.jumpTimer = 2;
/*  98 */       this.shouldStartElytraFlight = false;
/*  99 */       this.hasJumped = false;
/*     */     } 
/*     */ 
/*     */     
/* 103 */     if (this.mc.field_1724.method_6128()) {
/* 104 */       resetState();
/*     */     }
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onPreItemUse(PreItemUseEvent event) {
/* 110 */     if (this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 115 */     if (this.mc.field_1724.method_31548().method_7372(class_1304.field_6174.method_5927()).method_31574(class_1802.field_8833) && this.mc.field_1724
/* 116 */       .method_6047().method_31574(class_1802.field_8639)) {
/*     */ 
/*     */       
/* 119 */       if (this.originalSlot == -1) {
/* 120 */         this.originalSlot = (this.mc.field_1724.method_31548()).field_7545;
/*     */       }
/*     */ 
/*     */       
/* 124 */       if (!this.mc.field_1724.method_6128()) {
/* 125 */         this.shouldStartFlying = true;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resetState() {
/* 131 */     this.shouldStartFlying = false;
/* 132 */     this.jumpTimer = 0;
/* 133 */     this.originalSlot = -1;
/* 134 */     this.hasRightClicked = false;
/* 135 */     this.hasJumped = false;
/* 136 */     this.shouldStartElytraFlight = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\ElytraGlide.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */