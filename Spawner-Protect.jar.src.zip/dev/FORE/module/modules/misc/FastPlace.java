/*    */ package dev.FORE.module.modules.misc;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.PostItemUseEvent;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_9334;
/*    */ 
/*    */ public class FastPlace extends Module {
/* 14 */   private final BooleanSetting onlyXP = new BooleanSetting("Only XP", false);
/* 15 */   private final BooleanSetting allowBlocks = new BooleanSetting("Blocks", true);
/* 16 */   private final BooleanSetting allowItems = new BooleanSetting("Items", true);
/* 17 */   private final NumberSetting useDelay = new NumberSetting("Delay", 0.0D, 10.0D, 0.0D, 1.0D);
/*    */   
/*    */   public FastPlace() {
/* 20 */     super((CharSequence)EncryptedString.of("Fast Place"), (CharSequence)EncryptedString.of("Spams use action."), -1, Category.MISC);
/* 21 */     addsettings(new Setting[] { (Setting)this.onlyXP, (Setting)this.allowBlocks, (Setting)this.allowItems, (Setting)this.useDelay });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 26 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 31 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onPostItemUse(PostItemUseEvent postItemUseEvent) {
/* 36 */     class_1799 mainHandStack = this.mc.field_1724.method_6047();
/* 37 */     class_1799 offHandStack = this.mc.field_1724.method_6079();
/* 38 */     class_1792 mainHandItem = mainHandStack.method_7909();
/* 39 */     class_1792 offHandItem = this.mc.field_1724.method_6079().method_7909();
/* 40 */     if (!mainHandStack.method_31574(class_1802.field_8287) && !offHandStack.method_31574(class_1802.field_8287) && this.onlyXP.getValue()) {
/*    */       return;
/*    */     }
/* 43 */     if (!this.onlyXP.getValue()) {
/* 44 */       if (mainHandItem instanceof net.minecraft.class_1747 || offHandItem instanceof net.minecraft.class_1747) {
/* 45 */         if (!this.allowBlocks.getValue()) {
/*    */           return;
/*    */         }
/* 48 */       } else if (!this.allowItems.getValue()) {
/*    */         return;
/*    */       } 
/*    */     }
/* 52 */     if (mainHandItem.method_57347().method_57829(class_9334.field_50075) != null) {
/*    */       return;
/*    */     }
/* 55 */     if (offHandItem.method_57347().method_57829(class_9334.field_50075) != null) {
/*    */       return;
/*    */     }
/* 58 */     if (mainHandStack.method_31574(class_1802.field_23141) || mainHandStack.method_31574(class_1802.field_8801) || offHandStack.method_31574(class_1802.field_23141) || offHandStack.method_31574(class_1802.field_8801)) {
/*    */       return;
/*    */     }
/* 61 */     if (mainHandItem instanceof net.minecraft.class_1811 || offHandItem instanceof net.minecraft.class_1811) {
/*    */       return;
/*    */     }
/* 64 */     postItemUseEvent.cooldown = this.useDelay.getIntValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\FastPlace.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */