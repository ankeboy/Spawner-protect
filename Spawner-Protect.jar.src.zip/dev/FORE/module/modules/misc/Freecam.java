/*     */ package dev.FORE.module.modules.misc;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.KeyEvent;
/*     */ import dev.FORE.event.events.MouseScrolledEvent;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.KeyUtils;
/*     */ import dev.FORE.utils.Utils;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_5498;
/*     */ import org.joml.Vector3d;
/*     */ import org.joml.Vector3dc;
/*     */ 
/*     */ public final class Freecam extends Module {
/*  22 */   private final NumberSetting speed = new NumberSetting((CharSequence)EncryptedString.of("Speed"), 1.0D, 10.0D, 1.0D, 0.1D);
/*  23 */   public final Vector3d currentPosition = new Vector3d();
/*  24 */   public final Vector3d previousPosition = new Vector3d();
/*  25 */   private final Vector3d velocity = new Vector3d();
/*     */   
/*     */   private class_5498 currentPerspective;
/*     */   
/*     */   private double movementSpeed;
/*     */   public float yaw;
/*     */   public float pitch;
/*     */   public float previousYaw;
/*     */   public float previousPitch;
/*     */   private boolean isMovingForward;
/*     */   private boolean isMovingBackward;
/*     */   private boolean isMovingRight;
/*     */   private boolean isMovingLeft;
/*     */   private boolean isMovingUp;
/*     */   private boolean isMovingDown;
/*     */   public static Freecam instance;
/*     */   
/*     */   public Freecam() {
/*  43 */     super((CharSequence)EncryptedString.of("Freecam"), (CharSequence)EncryptedString.of("Move freely with smooth camera"), -1, Category.MISC);
/*  44 */     addsettings(new Setting[] { (Setting)this.speed });
/*  45 */     instance = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  50 */     if (this.mc.field_1724 == null) {
/*  51 */       toggle();
/*     */       
/*     */       return;
/*     */     } 
/*  55 */     this.mc.field_1690.method_42454().method_41748(Double.valueOf(0.0D));
/*  56 */     this.mc.field_1690.method_42448().method_41748(Boolean.valueOf(false));
/*     */     
/*  58 */     this.yaw = this.mc.field_1724.method_36454();
/*  59 */     this.pitch = this.mc.field_1724.method_36455();
/*  60 */     this.currentPerspective = this.mc.field_1690.method_31044();
/*  61 */     this.movementSpeed = this.speed.getValue();
/*     */     
/*  63 */     Utils.copyVector(this.currentPosition, this.mc.field_1773.method_19418().method_19326());
/*  64 */     Utils.copyVector(this.previousPosition, this.mc.field_1773.method_19418().method_19326());
/*     */     
/*  66 */     if (this.mc.field_1690.method_31044() == class_5498.field_26666) {
/*  67 */       this.yaw += 180.0F;
/*  68 */       this.pitch *= -1.0F;
/*     */     } 
/*     */     
/*  71 */     this.previousYaw = this.yaw;
/*  72 */     this.previousPitch = this.pitch;
/*     */     
/*  74 */     this.isMovingForward = this.mc.field_1690.field_1894.method_1434();
/*  75 */     this.isMovingBackward = this.mc.field_1690.field_1881.method_1434();
/*  76 */     this.isMovingRight = this.mc.field_1690.field_1849.method_1434();
/*  77 */     this.isMovingLeft = this.mc.field_1690.field_1913.method_1434();
/*  78 */     this.isMovingUp = this.mc.field_1690.field_1903.method_1434();
/*  79 */     this.isMovingDown = this.mc.field_1690.field_1832.method_1434();
/*     */     
/*  81 */     resetMovementKeys();
/*     */     
/*  83 */     if (this.mc.field_1724 != null) {
/*  84 */       this.mc.field_1724.field_5960 = true;
/*     */     }
/*     */     
/*  87 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  92 */     resetMovementKeys();
/*  93 */     this.previousPosition.set((Vector3dc)this.currentPosition);
/*  94 */     this.previousYaw = this.yaw;
/*  95 */     this.previousPitch = this.pitch;
/*     */     
/*  97 */     if (this.mc.field_1724 != null) {
/*  98 */       this.mc.field_1724.field_5960 = false;
/*     */     }
/*     */     
/* 101 */     if (this.currentPerspective != null) {
/* 102 */       this.mc.field_1690.method_31043(this.currentPerspective);
/*     */     }
/*     */     
/* 105 */     super.onDisable();
/*     */   }
/*     */   
/*     */   private void resetMovementKeys() {
/* 109 */     this.mc.field_1690.field_1894.method_23481(false);
/* 110 */     this.mc.field_1690.field_1881.method_23481(false);
/* 111 */     this.mc.field_1690.field_1849.method_23481(false);
/* 112 */     this.mc.field_1690.field_1913.method_23481(false);
/* 113 */     this.mc.field_1690.field_1903.method_23481(false);
/* 114 */     this.mc.field_1690.field_1832.method_23481(false);
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   private void handleTickEvent(TickEvent tickEvent) {
/* 119 */     if (this.mc.field_1719 != null && this.mc.field_1719.method_5757()) {
/* 120 */       (this.mc.method_1560()).field_5960 = true;
/*     */     }
/*     */     
/* 123 */     if (this.mc.field_1724 != null) {
/* 124 */       this.mc.field_1724.field_5960 = true;
/*     */     }
/*     */ 
/*     */     
/* 128 */     if (!this.currentPerspective.method_31034()) {
/* 129 */       this.mc.field_1690.method_31043(class_5498.field_26664);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   private void handleRenderTick(Render3DEvent event) {
/* 135 */     float partialTicks = 0.016666668F;
/*     */     
/* 137 */     class_243 forward = class_243.method_1030(0.0F, this.yaw);
/* 138 */     class_243 right = class_243.method_1030(0.0F, this.yaw + 90.0F);
/*     */     
/* 140 */     double targetX = 0.0D, targetY = 0.0D, targetZ = 0.0D;
/* 141 */     double speed = this.movementSpeed * (this.mc.field_1690.field_1867.method_1434() ? 1.0D : 0.5D);
/*     */     
/* 143 */     if (this.isMovingForward) { targetX += forward.field_1352 * speed; targetZ += forward.field_1350 * speed; }
/* 144 */      if (this.isMovingBackward) { targetX -= forward.field_1352 * speed; targetZ -= forward.field_1350 * speed; }
/* 145 */      if (this.isMovingRight) { targetX += right.field_1352 * speed; targetZ += right.field_1350 * speed; }
/* 146 */      if (this.isMovingLeft) { targetX -= right.field_1352 * speed; targetZ -= right.field_1350 * speed; }
/* 147 */      if (this.isMovingUp) targetY += speed; 
/* 148 */     if (this.isMovingDown) targetY -= speed;
/*     */     
/* 150 */     double accel = 0.2D;
/* 151 */     this.velocity.x += (targetX - this.velocity.x) * accel;
/* 152 */     this.velocity.y += (targetY - this.velocity.y) * accel;
/* 153 */     this.velocity.z += (targetZ - this.velocity.z) * accel;
/*     */     
/* 155 */     this.previousPosition.set((Vector3dc)this.currentPosition);
/* 156 */     this.currentPosition.add(this.velocity.x * partialTicks, this.velocity.y * partialTicks, this.velocity.z * partialTicks);
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onKey(KeyEvent keyEvent) {
/* 161 */     if (KeyUtils.isKeyPressed(292))
/*     */       return; 
/* 163 */     boolean handled = true;
/* 164 */     if (this.mc.field_1690.field_1894.method_1417(keyEvent.key, 0))
/* 165 */     { this.isMovingForward = (keyEvent.mode != 0); this.mc.field_1690.field_1894.method_23481(false); }
/* 166 */     else if (this.mc.field_1690.field_1881.method_1417(keyEvent.key, 0))
/* 167 */     { this.isMovingBackward = (keyEvent.mode != 0); this.mc.field_1690.field_1881.method_23481(false); }
/* 168 */     else if (this.mc.field_1690.field_1849.method_1417(keyEvent.key, 0))
/* 169 */     { this.isMovingRight = (keyEvent.mode != 0); this.mc.field_1690.field_1849.method_23481(false); }
/* 170 */     else if (this.mc.field_1690.field_1913.method_1417(keyEvent.key, 0))
/* 171 */     { this.isMovingLeft = (keyEvent.mode != 0); this.mc.field_1690.field_1913.method_23481(false); }
/* 172 */     else if (this.mc.field_1690.field_1903.method_1417(keyEvent.key, 0))
/* 173 */     { this.isMovingUp = (keyEvent.mode != 0); this.mc.field_1690.field_1903.method_23481(false); }
/* 174 */     else if (this.mc.field_1690.field_1832.method_1417(keyEvent.key, 0))
/* 175 */     { this.isMovingDown = (keyEvent.mode != 0); this.mc.field_1690.field_1832.method_23481(false); }
/* 176 */     else { handled = false; }
/*     */     
/* 178 */     if (handled) keyEvent.cancel(); 
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   private void handleMouseScrolledEvent(MouseScrolledEvent mouseScrolledEvent) {
/* 183 */     if (this.mc.field_1755 == null) {
/* 184 */       this.movementSpeed += mouseScrolledEvent.amount * 0.25D * this.movementSpeed;
/* 185 */       if (this.movementSpeed < 0.1D) this.movementSpeed = 0.1D; 
/* 186 */       mouseScrolledEvent.cancel();
/*     */     } 
/*     */   }
/*     */   
/*     */   public static Freecam getInstance() {
/* 191 */     if (instance == null) {
/* 192 */       instance = new Freecam();
/*     */     }
/* 194 */     return instance;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void updateRotation(double deltaYaw, double deltaPitch) {
/* 200 */     this.previousYaw = this.yaw;
/* 201 */     this.previousPitch = this.pitch;
/* 202 */     this.yaw = (float)(this.yaw + deltaYaw);
/* 203 */     this.pitch = (float)(this.pitch + deltaPitch);
/* 204 */     this.pitch = class_3532.method_15363(this.pitch, -90.0F, 90.0F);
/*     */   }
/*     */   
/*     */   public double getInterpolatedX(float partialTicks) {
/* 208 */     return class_3532.method_16436(partialTicks, this.previousPosition.x, this.currentPosition.x);
/*     */   }
/*     */   public double getInterpolatedY(float partialTicks) {
/* 211 */     return class_3532.method_16436(partialTicks, this.previousPosition.y, this.currentPosition.y);
/*     */   }
/*     */   public double getInterpolatedZ(float partialTicks) {
/* 214 */     return class_3532.method_16436(partialTicks, this.previousPosition.z, this.currentPosition.z);
/*     */   }
/*     */   public double getInterpolatedYaw(float partialTicks) {
/* 217 */     return class_3532.method_16439(partialTicks, this.previousYaw, this.yaw);
/*     */   }
/*     */   public double getInterpolatedPitch(float partialTicks) {
/* 220 */     return class_3532.method_16439(partialTicks, this.previousPitch, this.pitch);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\misc\Freecam.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */