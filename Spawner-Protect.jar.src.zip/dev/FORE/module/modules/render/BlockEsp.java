/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.ChunkDataEvent;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BlocksSetting;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.BlockUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import java.awt.Color;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_2826;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ public final class BlockEsp extends Module {
/*  32 */   private final BlocksSetting blocks = new BlocksSetting((CharSequence)EncryptedString.of("Blocks"), new net.minecraft.class_2248[0]); public static BlockEsp instance;
/*  33 */   private final BooleanSetting tracers = new BooleanSetting((CharSequence)EncryptedString.of("Tracers"), true);
/*  34 */   private final NumberSetting alpha = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 1.0D, 255.0D, 125.0D, 1.0D);
/*  35 */   private final NumberSetting red = new NumberSetting((CharSequence)EncryptedString.of("Red"), 0.0D, 255.0D, 255.0D, 1.0D);
/*  36 */   private final NumberSetting green = new NumberSetting((CharSequence)EncryptedString.of("Green"), 0.0D, 255.0D, 0.0D, 1.0D);
/*  37 */   private final NumberSetting blue = new NumberSetting((CharSequence)EncryptedString.of("Blue"), 0.0D, 255.0D, 0.0D, 1.0D);
/*     */   
/*  39 */   private final ConcurrentHashMap<Long, Set<class_2338>> cachedBlocks = new ConcurrentHashMap<>();
/*  40 */   private final ExecutorService executor = Executors.newFixedThreadPool(3);
/*  41 */   private final Set<Long> scanningChunks = ConcurrentHashMap.newKeySet();
/*     */   private volatile boolean needsRescan = false;
/*  43 */   private int tickCounter = 0;
/*     */   
/*     */   public BlockEsp() {
/*  46 */     super((CharSequence)EncryptedString.of("Block Esp"), (CharSequence)EncryptedString.of("Highlights selected blocks through walls"), -1, Category.RENDER);
/*  47 */     addsettings(new Setting[] { (Setting)this.blocks, (Setting)this.tracers, (Setting)this.alpha, (Setting)this.red, (Setting)this.green, (Setting)this.blue });
/*  48 */     instance = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  53 */     super.onEnable();
/*  54 */     this.cachedBlocks.clear();
/*  55 */     this.scanningChunks.clear();
/*  56 */     this.needsRescan = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  61 */     super.onDisable();
/*  62 */     this.cachedBlocks.clear();
/*  63 */     this.scanningChunks.clear();
/*     */   }
/*     */   
/*     */   public static BlockEsp getInstance() {
/*  67 */     if (instance == null) {
/*  68 */       instance = new BlockEsp();
/*     */     }
/*  70 */     return instance;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  75 */     if (this.mc.field_1687 == null || this.blocks.size() == 0)
/*     */       return; 
/*  77 */     this.tickCounter++;
/*     */ 
/*     */     
/*  80 */     if (this.needsRescan || this.tickCounter % 100 == 0) {
/*  81 */       this.needsRescan = false;
/*  82 */       scanAllChunks();
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onChunkData(ChunkDataEvent event) {
/*  88 */     if (event.getChunk() instanceof class_2818) {
/*  89 */       scanChunk((class_2818)event.getChunk());
/*     */     }
/*     */   }
/*     */   
/*     */   private void scanAllChunks() {
/*  94 */     if (this.mc.field_1687 == null)
/*     */       return; 
/*  96 */     for (class_2818 chunk : BlockUtil.getLoadedChunks().toList()) {
/*  97 */       scanChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   private void scanChunk(class_2818 chunk) {
/* 102 */     if (chunk == null || this.blocks.size() == 0)
/*     */       return; 
/* 104 */     long chunkKey = chunk.method_12004().method_8324();
/*     */ 
/*     */     
/* 107 */     if (!this.scanningChunks.add(Long.valueOf(chunkKey))) {
/*     */       return;
/*     */     }
/*     */     
/* 111 */     this.executor.submit(() -> {
/*     */           try {
/*     */             Set<class_2338> foundBlocks = ConcurrentHashMap.newKeySet();
/*     */             
/*     */             class_1923 chunkPos = chunk.method_12004();
/*     */             
/*     */             int startX = chunkPos.method_8326();
/*     */             
/*     */             int startZ = chunkPos.method_8328();
/*     */             
/*     */             class_2826[] sections = chunk.method_12006();
/*     */             
/*     */             int minSection = this.mc.field_1687.method_32891();
/*     */             
/*     */             for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
/*     */               class_2826 section = sections[sectionIndex];
/*     */               
/*     */               if (section != null && !section.method_38292()) {
/*     */                 int sectionY = (minSection + sectionIndex) * 16;
/*     */                 
/*     */                 for (int x = 0; x < 16; x++) {
/*     */                   for (int z = 0; z < 16; z++) {
/*     */                     for (int y = 0; y < 16; y++) {
/*     */                       class_2680 state = section.method_12254(x, y, z);
/*     */                       
/*     */                       if (this.blocks.contains(state.method_26204())) {
/*     */                         class_2338 pos = new class_2338(startX + x, sectionY + y, startZ + z);
/*     */                         foundBlocks.add(pos);
/*     */                       } 
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             if (foundBlocks.isEmpty()) {
/*     */               this.cachedBlocks.remove(Long.valueOf(chunkKey));
/*     */             } else {
/*     */               this.cachedBlocks.put(Long.valueOf(chunkKey), foundBlocks);
/*     */             } 
/* 150 */           } catch (Exception exception) {
/*     */           
/*     */           } finally {
/*     */             this.scanningChunks.remove(Long.valueOf(chunkKey));
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent event) {
/* 160 */     if (this.blocks.size() == 0 || this.cachedBlocks.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 164 */     class_4184 cam = RenderUtils.getCamera();
/* 165 */     if (cam == null)
/*     */       return; 
/* 167 */     class_243 camPos = RenderUtils.getCameraPos();
/* 168 */     class_4587 matrices = event.matrixStack;
/*     */     
/* 170 */     matrices.method_22903();
/* 171 */     matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
/* 172 */     matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
/* 173 */     matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*     */     
/* 175 */     Color blockColor = new Color(this.red.getIntValue(), this.green.getIntValue(), this.blue.getIntValue(), this.alpha.getIntValue());
/* 176 */     Color tracerColor = new Color(this.red.getIntValue(), this.green.getIntValue(), this.blue.getIntValue(), 255);
/*     */ 
/*     */     
/* 179 */     for (Set<class_2338> blockSet : this.cachedBlocks.values()) {
/* 180 */       if (blockSet == null)
/*     */         continue; 
/* 182 */       for (class_2338 blockPos : blockSet) {
/* 183 */         if (blockPos == null) {
/*     */           continue;
/*     */         }
/* 186 */         double distSq = this.mc.field_1724.method_5649(blockPos.method_10263() + 0.5D, blockPos.method_10264() + 0.5D, blockPos.method_10260() + 0.5D);
/* 187 */         if (distSq > 10000.0D)
/*     */           continue; 
/* 189 */         RenderUtils.renderFilledBox(matrices, blockPos
/*     */             
/* 191 */             .method_10263() + 0.1F, blockPos
/* 192 */             .method_10264() + 0.05F, blockPos
/* 193 */             .method_10260() + 0.1F, blockPos
/* 194 */             .method_10263() + 0.9F, blockPos
/* 195 */             .method_10264() + 0.85F, blockPos
/* 196 */             .method_10260() + 0.9F, blockColor);
/*     */ 
/*     */ 
/*     */         
/* 200 */         if (this.tracers.getValue() && this.mc.field_1765 != null) {
/* 201 */           RenderUtils.renderLine(matrices, tracerColor, this.mc.field_1765
/*     */ 
/*     */               
/* 204 */               .method_17784(), new class_243(blockPos
/* 205 */                 .method_10263() + 0.5D, blockPos.method_10264() + 0.5D, blockPos.method_10260() + 0.5D));
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 211 */     matrices.method_22909();
/*     */   }
/*     */   
/*     */   public BlocksSetting getBlocksSetting() {
/* 215 */     return this.blocks;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\BlockEsp.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */