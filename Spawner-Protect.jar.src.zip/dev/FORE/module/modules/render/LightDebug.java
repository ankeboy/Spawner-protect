/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.ChunkDataEvent;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.BlockUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import java.awt.Color;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2791;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_2826;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ public final class LightDebug
/*     */   extends Module {
/*  34 */   private final NumberSetting maxYLevel = (new NumberSetting((CharSequence)EncryptedString.of("Max Y level"), -64.0D, 64.0D, 4.0D, 1.0D))
/*  35 */     .setDescription((CharSequence)EncryptedString.of("Only track blocks at or below this Y level"));
/*     */ 
/*     */   
/*  38 */   private final NumberSetting minLightLevel = (new NumberSetting((CharSequence)EncryptedString.of("Min light level"), 0.0D, 15.0D, 10.0D, 1.0D))
/*  39 */     .setDescription((CharSequence)EncryptedString.of("Highlight blocks at or above this light level"));
/*     */   
/*  41 */   private final NumberSetting maxAlpha = (new NumberSetting((CharSequence)EncryptedString.of("Max alpha"), 40.0D, 255.0D, 200.0D, 1.0D))
/*  42 */     .setDescription((CharSequence)EncryptedString.of("Maximum opacity used when a block has maximum light"));
/*     */   
/*  44 */   private final NumberSetting rescanDelay = (new NumberSetting((CharSequence)EncryptedString.of("Rescan delay (ticks)"), 5.0D, 200.0D, 100.0D, 1.0D))
/*  45 */     .setDescription((CharSequence)EncryptedString.of("How often to rescan all loaded chunks"));
/*     */ 
/*     */   
/*  48 */   private final ConcurrentHashMap<Long, Map<class_2338, Integer>> cachedLightBlocks = new ConcurrentHashMap<>();
/*  49 */   private final ExecutorService executor = Executors.newFixedThreadPool(3);
/*  50 */   private final Set<Long> scanningChunks = ConcurrentHashMap.newKeySet();
/*     */   private volatile boolean needsRescan = false;
/*  52 */   private int tickCounter = 0;
/*     */   
/*     */   public LightDebug() {
/*  55 */     super((CharSequence)EncryptedString.of("Light debug"), (CharSequence)EncryptedString.of("Highlights bright blocks underground"), -1, Category.RENDER);
/*  56 */     addsettings(new Setting[] { (Setting)this.maxYLevel, (Setting)this.minLightLevel, (Setting)this.maxAlpha, (Setting)this.rescanDelay });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  61 */     super.onDisable();
/*  62 */     this.cachedLightBlocks.clear();
/*  63 */     this.scanningChunks.clear();
/*  64 */     this.needsRescan = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  69 */     super.onEnable();
/*  70 */     this.cachedLightBlocks.clear();
/*  71 */     this.scanningChunks.clear();
/*  72 */     this.needsRescan = true;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  77 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
/*  78 */       this.cachedLightBlocks.clear();
/*  79 */       this.scanningChunks.clear();
/*     */       
/*     */       return;
/*     */     } 
/*  83 */     this.tickCounter++;
/*  84 */     int delay = Math.max(5, this.rescanDelay.getIntValue());
/*     */ 
/*     */     
/*  87 */     if (this.needsRescan || this.tickCounter >= delay) {
/*  88 */       this.tickCounter = 0;
/*  89 */       this.needsRescan = false;
/*  90 */       scanAllChunks();
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onChunkData(ChunkDataEvent event) {
/*  96 */     class_2791 class_2791 = event.getChunk(); if (class_2791 instanceof class_2818) { class_2818 worldChunk = (class_2818)class_2791;
/*  97 */       scanChunk(worldChunk); }
/*     */   
/*     */   }
/*     */   
/*     */   private void scanAllChunks() {
/* 102 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null)
/*     */       return; 
/* 104 */     for (class_2818 chunk : BlockUtil.getLoadedChunks().toList()) {
/* 105 */       scanChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   private void scanChunk(class_2818 chunk) {
/* 110 */     if (chunk == null)
/*     */       return; 
/* 112 */     long chunkKey = chunk.method_12004().method_8324();
/*     */ 
/*     */     
/* 115 */     if (!this.scanningChunks.add(Long.valueOf(chunkKey))) {
/*     */       return;
/*     */     }
/*     */     
/* 119 */     this.executor.submit(() -> {
/*     */           try {
/*     */             int bottomY = this.mc.field_1687.method_31607();
/*     */             
/*     */             int topY = this.mc.field_1687.method_31600();
/*     */             
/*     */             int yLimit = class_3532.method_15340((int)Math.round(this.maxYLevel.getValue()), bottomY, topY);
/*     */             
/*     */             int minLight = class_3532.method_15340(this.minLightLevel.getIntValue(), 0, 15);
/*     */             
/*     */             Map<class_2338, Integer> found = new ConcurrentHashMap<>();
/*     */             
/*     */             class_1923 chunkPos = chunk.method_12004();
/*     */             
/*     */             int startX = chunkPos.method_8326();
/*     */             
/*     */             int startZ = chunkPos.method_8328();
/*     */             
/*     */             class_2826[] sections = chunk.method_12006();
/*     */             
/*     */             int minSection = this.mc.field_1687.method_32891();
/*     */             
/*     */             for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
/*     */               class_2826 section = sections[sectionIndex];
/*     */               
/*     */               if (section != null && !section.method_38292()) {
/*     */                 int sectionY = (minSection + sectionIndex) * 16;
/*     */                 if (sectionY <= yLimit) {
/*     */                   for (int x = 0; x < 16; x++) {
/*     */                     for (int z = 0; z < 16; z++) {
/*     */                       for (int y = 0; y < 16; y++) {
/*     */                         int worldY = sectionY + y;
/*     */                         if (worldY <= yLimit) {
/*     */                           class_2680 state = section.method_12254(x, y, z);
/*     */                           if (!state.method_26215()) {
/*     */                             class_2338 pos = new class_2338(startX + x, worldY, startZ + z);
/*     */                             int lightLevel = this.mc.field_1687.method_22339(pos);
/*     */                             if (lightLevel >= minLight) {
/*     */                               found.put(pos.method_10062(), Integer.valueOf(lightLevel));
/*     */                             }
/*     */                           } 
/*     */                         } 
/*     */                       } 
/*     */                     } 
/*     */                   } 
/*     */                 }
/*     */               } 
/*     */             } 
/*     */             if (found.isEmpty()) {
/*     */               this.cachedLightBlocks.remove(Long.valueOf(chunkKey));
/*     */             } else {
/*     */               this.cachedLightBlocks.put(Long.valueOf(chunkKey), found);
/*     */             } 
/* 172 */           } catch (Exception exception) {
/*     */           
/*     */           } finally {
/*     */             this.scanningChunks.remove(Long.valueOf(chunkKey));
/*     */           } 
/*     */         });
/*     */   }
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent event) {
/* 181 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null || this.cachedLightBlocks.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 185 */     class_4184 camera = RenderUtils.getCamera();
/* 186 */     if (camera == null) {
/*     */       return;
/*     */     }
/*     */     
/* 190 */     class_4587 matrices = event.matrixStack;
/* 191 */     class_243 camPos = RenderUtils.getCameraPos();
/*     */     
/* 193 */     matrices.method_22903();
/* 194 */     matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
/* 195 */     matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
/* 196 */     matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*     */     
/* 198 */     int alphaCap = class_3532.method_15340((int)Math.round(this.maxAlpha.getValue()), 0, 255);
/*     */     
/* 200 */     for (Map<class_2338, Integer> blockMap : this.cachedLightBlocks.values()) {
/* 201 */       if (blockMap == null || blockMap.isEmpty())
/*     */         continue; 
/* 203 */       for (Map.Entry<class_2338, Integer> entry : blockMap.entrySet()) {
/* 204 */         class_2338 pos = entry.getKey();
/* 205 */         int light = ((Integer)entry.getValue()).intValue();
/*     */ 
/*     */         
/* 208 */         float lightFactor = class_3532.method_15363(light / 15.0F, 0.0F, 1.0F);
/* 209 */         int alpha = class_3532.method_15340((int)(lightFactor * alphaCap), 20, alphaCap);
/* 210 */         Color color = new Color(255, 255, 0, alpha);
/*     */         
/* 212 */         RenderUtils.renderFilledBox(matrices, pos
/*     */             
/* 214 */             .method_10263(), pos
/* 215 */             .method_10264(), pos
/* 216 */             .method_10260(), (pos
/* 217 */             .method_10263() + 1), (pos
/* 218 */             .method_10264() + 1), (pos
/* 219 */             .method_10260() + 1), color);
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 225 */     matrices.method_22909();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\LightDebug.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */