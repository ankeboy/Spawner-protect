/*      */ package dev.FORE.module.modules.render;
/*      */ import dev.FORE.event.EventListener;
/*      */ import dev.FORE.event.events.Render3DEvent;
/*      */ import dev.FORE.module.Category;
/*      */ import dev.FORE.module.Module;
/*      */ import dev.FORE.module.setting.BooleanSetting;
/*      */ import dev.FORE.module.setting.Setting;
/*      */ import dev.FORE.utils.EncryptedString;
/*      */ import dev.FORE.utils.RenderUtils;
/*      */ import java.awt.Color;
/*      */ import java.util.ArrayList;
/*      */ import java.util.Collections;
/*      */ import java.util.HashSet;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import java.util.concurrent.ConcurrentHashMap;
/*      */ import java.util.concurrent.ExecutorService;
/*      */ import java.util.concurrent.Executors;
/*      */ import java.util.concurrent.Future;
/*      */ import net.minecraft.class_1113;
/*      */ import net.minecraft.class_1297;
/*      */ import net.minecraft.class_1922;
/*      */ import net.minecraft.class_1923;
/*      */ import net.minecraft.class_1935;
/*      */ import net.minecraft.class_1959;
/*      */ import net.minecraft.class_2246;
/*      */ import net.minecraft.class_2248;
/*      */ import net.minecraft.class_2338;
/*      */ import net.minecraft.class_2350;
/*      */ import net.minecraft.class_238;
/*      */ import net.minecraft.class_243;
/*      */ import net.minecraft.class_2465;
/*      */ import net.minecraft.class_2561;
/*      */ import net.minecraft.class_2680;
/*      */ import net.minecraft.class_2769;
/*      */ import net.minecraft.class_2818;
/*      */ import net.minecraft.class_2960;
/*      */ import net.minecraft.class_332;
/*      */ import net.minecraft.class_3417;
/*      */ import net.minecraft.class_368;
/*      */ import net.minecraft.class_374;
/*      */ import net.minecraft.class_4184;
/*      */ import net.minecraft.class_4587;
/*      */ import net.minecraft.class_5250;
/*      */ import net.minecraft.class_5321;
/*      */ import net.minecraft.class_6880;
/*      */ import net.minecraft.class_7833;
/*      */ 
/*      */ public class ChunkFinder extends Module {
/*      */   private final boolean tracers = false;
/*      */   private final boolean fill = true;
/*   52 */   private final Color traderChunkColor = new Color(0, 255, 0, 120); private final boolean outline = true; private final boolean highlightBlocks = true; private final boolean detectTraders = false;
/*   53 */   private final int fillAlpha = 120;
/*   54 */   private static final class_2960 TEXTURE = class_2960.method_60655("minecraft", "textures/gui/toasts.png");
/*      */ 
/*      */   
/*   57 */   private final BooleanSetting holeESP = (new BooleanSetting((CharSequence)EncryptedString.of("HoleESP"), false)).setDescription((CharSequence)EncryptedString.of("Enable hole detection and rendering"));
/*      */   private final boolean detect1x1Holes = true;
/*      */   private final boolean detect3x1Holes = true;
/*   60 */   private final int minHoleDepth = 8;
/*   61 */   private final Color hole1x1Color = new Color(255, 255, 255, 100);
/*   62 */   private final Color hole3x1Color = new Color(255, 255, 255, 100);
/*      */   
/*      */   private final boolean holeOutline = true;
/*      */   
/*      */   private final boolean holeFill = true;
/*      */   
/*      */   private static final int MIN_Y = 20;
/*      */   
/*      */   private static final int MAX_UNDERGROUND_Y = 60;
/*      */   
/*      */   private static final int HIGHLIGHT_Y = 60;
/*      */   
/*      */   private static final boolean PLAY_SOUND = true;
/*      */   private static final boolean CHAT_NOTIFICATION = false;
/*      */   private static final boolean FIND_ROTATED_DEEPSLATE = true;
/*   77 */   private final Set<class_1923> flaggedChunks = ConcurrentHashMap.newKeySet();
/*   78 */   private final Set<class_1923> scannedChunks = ConcurrentHashMap.newKeySet();
/*   79 */   private final Set<class_1923> notifiedChunks = ConcurrentHashMap.newKeySet();
/*   80 */   private final ConcurrentMap<class_1923, Set<class_2338>> flaggedBlocks = new ConcurrentHashMap<>();
/*      */ 
/*      */   
/*   83 */   private final Set<class_1923> traderChunks = ConcurrentHashMap.newKeySet();
/*   84 */   private final Set<class_1923> notifiedTraderChunks = ConcurrentHashMap.newKeySet();
/*      */ 
/*      */   
/*   87 */   private final Set<class_238> holes1x1 = Collections.newSetFromMap(new ConcurrentHashMap<>());
/*   88 */   private final Set<class_238> holes3x1 = Collections.newSetFromMap(new ConcurrentHashMap<>());
/*   89 */   private final Set<class_1923> holeScannedChunks = ConcurrentHashMap.newKeySet();
/*      */ 
/*      */   
/*   92 */   private final Set<class_1923> cherryGroveChunks = ConcurrentHashMap.newKeySet();
/*   93 */   private final Set<class_1923> notifiedCherryChunks = ConcurrentHashMap.newKeySet();
/*   94 */   private class_1923 lastCherryFlaggedChunk = null;
/*   95 */   private long cherryGroveEnterTime = 0L;
/*      */   
/*      */   private boolean inCherryGrove = false;
/*      */   
/*      */   private boolean cherryFlagPending = false;
/*      */   
/*      */   private ExecutorService scannerThread;
/*      */   private Future<?> currentScanTask;
/*      */   private Future<?> currentHoleScanTask;
/*      */   private Future<?> currentTraderScanTask;
/*      */   private volatile boolean shouldStop = false;
/*  106 */   private Set<Integer> notifiedTraders = new HashSet<>();
/*      */   
/*      */   private final boolean detectPistons = true;
/*  109 */   private final int minPistonCount = 5;
/*      */ 
/*      */ 
/*      */   
/*  113 */   private long lastScanTime = 0L;
/*  114 */   private long lastCleanupTime = 0L;
/*  115 */   private long lastHoleScanTime = 0L;
/*  116 */   private long lastTraderScanTime = 0L;
/*      */   
/*      */   private static final long SCAN_COOLDOWN = 500L;
/*      */   private static final long CLEANUP_INTERVAL = 5000L;
/*      */   private static final long HOLE_SCAN_COOLDOWN = 1000L;
/*      */   private static final long TRADER_SCAN_COOLDOWN = 2000L;
/*  122 */   private static final class_2338 KILL_SWITCH_POS_1 = new class_2338(-34, 69, -91);
/*  123 */   private static final class_2338 KILL_SWITCH_POS_2 = new class_2338(-54, 69, -71);
/*      */   
/*      */   private boolean killSwitchActivated = false;
/*      */   
/*  127 */   private long lagPauseStartTime = 0L;
/*      */   
/*      */   private boolean isPausedDueToLag = false;
/*      */   private static final long LAG_PAUSE_DURATION = 10000L;
/*      */   private static final int LOW_FPS_THRESHOLD = 8;
/*      */   private static final long CHERRY_GROVE_DELAY = 200L;
/*      */   private static final int CHERRY_GROVE_MIN_DISTANCE = 100;
/*      */   private boolean isDonutSMP = false;
/*      */   private boolean hasCheckedServer = false;
/*  136 */   private final Set<class_1923> slowFlaggedChunks = ConcurrentHashMap.newKeySet();
/*  137 */   private long lastSlowFlagTime = 0L;
/*      */   private static final long SLOW_FLAG_DELAY = 500L;
/*  139 */   private int slowFlagIndex = 0;
/*      */   
/*      */   public ChunkFinder() {
/*  142 */     super((CharSequence)EncryptedString.of("Chunk Finder"), (CharSequence)EncryptedString.of("Finds sus chunks (Only Works on Donut smp)"), -1, Category.DONUT);
/*      */     
/*  144 */     addsettings(new Setting[] { (Setting)this.holeESP });
/*      */   }
/*      */   
/*      */   private void checkServerIP() {
/*  148 */     if (this.hasCheckedServer)
/*      */       return; 
/*      */     try {
/*  151 */       if (this.mc.method_1558() != null) {
/*  152 */         String serverAddress = (this.mc.method_1558()).field_3761;
/*  153 */         this.isDonutSMP = (serverAddress != null && serverAddress.toLowerCase().endsWith("donutsmp.net"));
/*  154 */         this.hasCheckedServer = true;
/*  155 */       } else if (this.mc.method_1542()) {
/*      */         
/*  157 */         this.isDonutSMP = false;
/*  158 */         this.hasCheckedServer = true;
/*      */       } 
/*  160 */     } catch (Exception e) {
/*      */       
/*  162 */       this.isDonutSMP = false;
/*  163 */       this.hasCheckedServer = true;
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   public void onEnable() {
/*  169 */     this.flaggedChunks.clear();
/*  170 */     this.scannedChunks.clear();
/*  171 */     this.notifiedChunks.clear();
/*  172 */     this.flaggedBlocks.clear();
/*  173 */     this.traderChunks.clear();
/*  174 */     this.notifiedTraderChunks.clear();
/*  175 */     this.holes1x1.clear();
/*  176 */     this.holes3x1.clear();
/*  177 */     this.holeScannedChunks.clear();
/*  178 */     this.cherryGroveChunks.clear();
/*  179 */     this.notifiedCherryChunks.clear();
/*  180 */     this.lastCherryFlaggedChunk = null;
/*  181 */     this.cherryGroveEnterTime = 0L;
/*  182 */     this.inCherryGrove = false;
/*  183 */     this.cherryFlagPending = false;
/*  184 */     this.shouldStop = false;
/*  185 */     this.isPausedDueToLag = false;
/*  186 */     this.lagPauseStartTime = 0L;
/*  187 */     this.killSwitchActivated = false;
/*      */     
/*  189 */     this.scannerThread = Executors.newSingleThreadExecutor(r -> {
/*      */           Thread t = new Thread(r, "ChunkScanner");
/*      */           
/*      */           t.setDaemon(true);
/*      */           t.setPriority(1);
/*      */           return t;
/*      */         });
/*  196 */     scheduleChunkScan();
/*  197 */     if (this.holeESP.getValue()) {
/*  198 */       scheduleHoleScan();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void onDisable() {
/*  207 */     this.shouldStop = true;
/*      */     
/*  209 */     if (this.currentScanTask != null && !this.currentScanTask.isDone()) {
/*  210 */       this.currentScanTask.cancel(true);
/*      */     }
/*      */     
/*  213 */     if (this.currentHoleScanTask != null && !this.currentHoleScanTask.isDone()) {
/*  214 */       this.currentHoleScanTask.cancel(true);
/*      */     }
/*      */     
/*  217 */     if (this.currentTraderScanTask != null && !this.currentTraderScanTask.isDone()) {
/*  218 */       this.currentTraderScanTask.cancel(true);
/*      */     }
/*      */     
/*  221 */     if (this.scannerThread != null && !this.scannerThread.isShutdown()) {
/*  222 */       this.scannerThread.shutdownNow();
/*      */     }
/*      */     
/*  225 */     this.flaggedChunks.clear();
/*  226 */     this.scannedChunks.clear();
/*  227 */     this.notifiedChunks.clear();
/*  228 */     this.flaggedBlocks.clear();
/*  229 */     this.traderChunks.clear();
/*  230 */     this.notifiedTraderChunks.clear();
/*  231 */     this.holes1x1.clear();
/*  232 */     this.holes3x1.clear();
/*  233 */     this.holeScannedChunks.clear();
/*  234 */     this.cherryGroveChunks.clear();
/*  235 */     this.notifiedCherryChunks.clear();
/*  236 */     this.slowFlaggedChunks.clear();
/*      */   }
/*      */   
/*      */   public static class ChunkFinderToast implements class_368 {
/*      */     private final String chunkX;
/*      */     private final String chunkZ;
/*      */     private long startTime;
/*      */     private boolean hasPlayed = false;
/*      */     private static final long DISPLAY_TIME = 3000L;
/*      */     
/*      */     public ChunkFinderToast(String chunkX, String chunkZ) {
/*  247 */       this.chunkX = chunkX;
/*  248 */       this.chunkZ = chunkZ;
/*      */     }
/*      */ 
/*      */     
/*      */     public class_368.class_369 method_1986(class_332 context, class_374 manager, long startTime) {
/*  253 */       if (this.startTime == 0L) {
/*  254 */         this.startTime = startTime;
/*      */       }
/*      */       
/*  257 */       if (!this.hasPlayed) {
/*  258 */         manager.method_1995().method_1483().method_4873(
/*  259 */             (class_1113)class_1109.method_4757(class_3417.field_26979, 1.0F, 1.0F));
/*      */ 
/*      */ 
/*      */         
/*  263 */         this.hasPlayed = true;
/*      */       } 
/*      */ 
/*      */       
/*  267 */       context.method_52706(
/*  268 */           class_2960.method_60656("toast/advancement"), 0, 0, 
/*      */           
/*  270 */           method_29049(), 
/*  271 */           method_29050());
/*      */ 
/*      */       
/*  274 */       context.method_51445(new class_1799((class_1935)class_1802.field_8106), 6, 6);
/*  275 */       class_5250 class_52501 = class_2561.method_43470("ChunkFinder");
/*  276 */       context.method_51439((manager.method_1995()).field_1772, (class_2561)class_52501, 30, 7, 16586941, false);
/*  277 */       class_5250 class_52502 = class_2561.method_43470("X: " + this.chunkX + " Z: " + this.chunkZ);
/*  278 */       context.method_51439((manager.method_1995()).field_1772, (class_2561)class_52502, 30, 18, 16777215, false);
/*      */       
/*  280 */       return (startTime - this.startTime < 3000L) ? class_368.class_369.field_2210 : class_368.class_369.field_2209;
/*      */     }
/*      */ 
/*      */     
/*      */     public Object method_1987() {
/*  285 */       return Type.INSTANCE;
/*      */     }
/*      */ 
/*      */     
/*      */     public int method_29049() {
/*  290 */       return 160;
/*      */     }
/*      */ 
/*      */     
/*      */     public int method_29050() {
/*  295 */       return 32;
/*      */     }
/*      */     
/*      */     public static class Type {
/*  299 */       public static final Type INSTANCE = new Type(); } } public static class Type { public static final Type INSTANCE = new Type(); }
/*      */ 
/*      */ 
/*      */   
/*      */   @EventListener
/*      */   public void onTick(TickEvent event) {
/*  305 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
/*      */       return;
/*      */     }
/*  308 */     checkServerIP();
/*      */     
/*  310 */     checkKillSwitch();
/*      */     
/*  312 */     if (this.killSwitchActivated) {
/*      */       return;
/*      */     }
/*      */     
/*  316 */     long currentTime = System.currentTimeMillis();
/*      */ 
/*      */     
/*  319 */     if (!this.isDonutSMP) {
/*  320 */       handleSlowChunkFlagging(currentTime);
/*      */ 
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  326 */     checkCherryGroveBiome(currentTime);
/*      */     
/*  328 */     if (this.mc.method_47599() < 8 && this.mc.field_1724.field_6012 > 100 && 
/*  329 */       !this.isPausedDueToLag) {
/*  330 */       this.isPausedDueToLag = true;
/*  331 */       this.lagPauseStartTime = currentTime;
/*      */       
/*  333 */       if (this.currentScanTask != null && !this.currentScanTask.isDone()) {
/*  334 */         this.currentScanTask.cancel(true);
/*      */       }
/*  336 */       if (this.currentHoleScanTask != null && !this.currentHoleScanTask.isDone()) {
/*  337 */         this.currentHoleScanTask.cancel(true);
/*      */       }
/*  339 */       if (this.currentTraderScanTask != null && !this.currentTraderScanTask.isDone()) {
/*  340 */         this.currentTraderScanTask.cancel(true);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  345 */     if (this.isPausedDueToLag) {
/*  346 */       if (currentTime - this.lagPauseStartTime >= 10000L) {
/*  347 */         this.isPausedDueToLag = false;
/*      */       } else {
/*      */         return;
/*      */       } 
/*      */     }
/*      */     
/*  353 */     if (currentTime - this.lastScanTime > 500L) {
/*  354 */       scheduleChunkScan();
/*  355 */       this.lastScanTime = currentTime;
/*      */     } 
/*      */     
/*  358 */     if (this.holeESP.getValue() && currentTime - this.lastHoleScanTime > 1000L) {
/*  359 */       scheduleHoleScan();
/*  360 */       this.lastHoleScanTime = currentTime;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  368 */     if (currentTime - this.lastCleanupTime > 5000L) {
/*  369 */       cleanupDistantChunks();
/*  370 */       cleanupDistantHoles();
/*  371 */       cleanupDistantTraderChunks();
/*  372 */       cleanupDistantCherryChunks();
/*  373 */       this.lastCleanupTime = currentTime;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkKillSwitch() {
/*  378 */     if (this.mc.field_1687 == null)
/*      */       return; 
/*      */     try {
/*  381 */       class_2680 state1 = this.mc.field_1687.method_8320(KILL_SWITCH_POS_1);
/*  382 */       class_2680 state2 = this.mc.field_1687.method_8320(KILL_SWITCH_POS_2);
/*      */       
/*  384 */       boolean hasChest1 = (state1.method_26204() == class_2246.field_10034 || state1.method_26204() == class_2246.field_10380);
/*  385 */       boolean hasChest2 = (state2.method_26204() == class_2246.field_10034 || state2.method_26204() == class_2246.field_10380);
/*      */       
/*  387 */       if (hasChest1 && hasChest2) {
/*  388 */         if (!this.killSwitchActivated) {
/*  389 */           this.killSwitchActivated = true;
/*  390 */           this.shouldStop = true;
/*      */           
/*  392 */           if (this.currentScanTask != null && !this.currentScanTask.isDone()) {
/*  393 */             this.currentScanTask.cancel(true);
/*      */           }
/*  395 */           if (this.currentHoleScanTask != null && !this.currentHoleScanTask.isDone()) {
/*  396 */             this.currentHoleScanTask.cancel(true);
/*      */           }
/*  398 */           if (this.currentTraderScanTask != null && !this.currentTraderScanTask.isDone()) {
/*  399 */             this.currentTraderScanTask.cancel(true);
/*      */           }
/*      */           
/*  402 */           clearAllData();
/*      */         }
/*      */       
/*  405 */       } else if (this.killSwitchActivated) {
/*  406 */         this.killSwitchActivated = false;
/*  407 */         this.shouldStop = false;
/*      */         
/*  409 */         scheduleChunkScan();
/*  410 */         if (this.holeESP.getValue()) {
/*  411 */           scheduleHoleScan();
/*      */         
/*      */         }
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  418 */     catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */   
/*      */   private void clearAllData() {
/*  423 */     this.flaggedChunks.clear();
/*  424 */     this.scannedChunks.clear();
/*  425 */     this.notifiedChunks.clear();
/*  426 */     this.flaggedBlocks.clear();
/*  427 */     this.traderChunks.clear();
/*  428 */     this.notifiedTraderChunks.clear();
/*  429 */     this.holes1x1.clear();
/*  430 */     this.holes3x1.clear();
/*  431 */     this.holeScannedChunks.clear();
/*  432 */     this.cherryGroveChunks.clear();
/*  433 */     this.notifiedCherryChunks.clear();
/*  434 */     this.notifiedTraders.clear();
/*  435 */     this.lastCherryFlaggedChunk = null;
/*  436 */     this.slowFlaggedChunks.clear();
/*      */   }
/*      */   
/*      */   private void checkCherryGroveBiome(long currentTime) {
/*  440 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null)
/*      */       return; 
/*  442 */     class_2338 playerPos = this.mc.field_1724.method_24515();
/*  443 */     class_6880<class_1959> biomeEntry = this.mc.field_1687.method_23753(playerPos);
/*      */     
/*  445 */     boolean isCurrentlyCherryGrove = isCherryGroveBiome(biomeEntry);
/*      */     
/*  447 */     if (isCurrentlyCherryGrove && !this.inCherryGrove) {
/*  448 */       this.inCherryGrove = true;
/*  449 */       this.cherryGroveEnterTime = currentTime;
/*  450 */       this.cherryFlagPending = true;
/*  451 */     } else if (!isCurrentlyCherryGrove && this.inCherryGrove) {
/*  452 */       this.inCherryGrove = false;
/*  453 */       this.cherryFlagPending = false;
/*      */     } 
/*      */     
/*  456 */     if (this.cherryFlagPending && this.inCherryGrove && currentTime - this.cherryGroveEnterTime >= 200L) {
/*  457 */       class_1923 currentChunk = new class_1923(playerPos);
/*      */       
/*  459 */       if (shouldFlagCherryChunk(currentChunk)) {
/*  460 */         flagCherryGroveChunk(currentChunk);
/*  461 */         this.lastCherryFlaggedChunk = currentChunk;
/*      */       } 
/*      */       
/*  464 */       this.cherryFlagPending = false;
/*      */     } 
/*      */   }
/*      */   
/*      */   private void handleSlowChunkFlagging(long currentTime) {
/*  469 */     if (this.isDonutSMP || this.mc.field_1687 == null || this.mc.field_1724 == null) {
/*      */       return;
/*      */     }
/*  472 */     if (currentTime - this.lastSlowFlagTime < 500L)
/*      */       return; 
/*  474 */     List<class_2818> loadedChunks = getLoadedChunks();
/*  475 */     if (loadedChunks.isEmpty()) {
/*      */       return;
/*      */     }
/*  478 */     if (this.slowFlagIndex >= loadedChunks.size()) {
/*  479 */       this.slowFlagIndex = 0;
/*      */     }
/*      */     
/*  482 */     class_2818 chunk = loadedChunks.get(this.slowFlagIndex);
/*  483 */     if (chunk != null && !chunk.method_12223()) {
/*  484 */       class_1923 chunkPos = chunk.method_12004();
/*      */ 
/*      */       
/*  487 */       if (!this.slowFlaggedChunks.contains(chunkPos)) {
/*  488 */         this.flaggedChunks.add(chunkPos);
/*  489 */         this.slowFlaggedChunks.add(chunkPos);
/*  490 */         this.flaggedBlocks.put(chunkPos, ConcurrentHashMap.newKeySet());
/*      */ 
/*      */         
/*  493 */         if (!this.notifiedChunks.contains(chunkPos)) {
/*  494 */           notifyChunkFound(chunkPos);
/*  495 */           this.notifiedChunks.add(chunkPos);
/*      */         } 
/*      */         
/*  498 */         this.lastSlowFlagTime = currentTime;
/*      */       } 
/*      */     } 
/*      */     
/*  502 */     this.slowFlagIndex++;
/*      */   }
/*      */   
/*      */   private boolean isCherryGroveBiome(class_6880<class_1959> biomeEntry) {
/*  506 */     if (biomeEntry == null) return false;
/*      */ 
/*      */ 
/*      */     
/*  510 */     String biomeName = biomeEntry.method_40230().map(key -> key.method_29177().toString()).orElse("");
/*      */     
/*  512 */     return (biomeName.contains("cherry_grove") || biomeName.contains("cherry"));
/*      */   }
/*      */   
/*      */   private boolean shouldFlagCherryChunk(class_1923 currentChunk) {
/*  516 */     if (this.notifiedCherryChunks.contains(currentChunk)) {
/*  517 */       return false;
/*      */     }
/*      */     
/*  520 */     if (this.lastCherryFlaggedChunk != null) {
/*  521 */       int worldX1 = this.lastCherryFlaggedChunk.field_9181 * 16 + 8;
/*  522 */       int worldZ1 = this.lastCherryFlaggedChunk.field_9180 * 16 + 8;
/*  523 */       int worldX2 = currentChunk.field_9181 * 16 + 8;
/*  524 */       int worldZ2 = currentChunk.field_9180 * 16 + 8;
/*      */       
/*  526 */       double distance = Math.sqrt(Math.pow((worldX2 - worldX1), 2.0D) + Math.pow((worldZ2 - worldZ1), 2.0D));
/*      */       
/*  528 */       if (distance < 100.0D) {
/*  529 */         return false;
/*      */       }
/*      */     } 
/*      */     
/*  533 */     return true;
/*      */   }
/*      */   
/*      */   private void flagCherryGroveChunk(class_1923 chunkPos) {
/*  537 */     this.flaggedChunks.add(chunkPos);
/*  538 */     this.cherryGroveChunks.add(chunkPos);
/*  539 */     this.notifiedCherryChunks.add(chunkPos);
/*  540 */     this.flaggedBlocks.put(chunkPos, ConcurrentHashMap.newKeySet());
/*      */     
/*  542 */     notifyChunkFound(chunkPos);
/*      */   }
/*      */   
/*      */   private void cleanupDistantCherryChunks() {
/*  546 */     if (this.mc.field_1724 == null)
/*      */       return; 
/*  548 */     int viewDist = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/*  549 */     int playerChunkX = (int)this.mc.field_1724.method_23317() / 16;
/*  550 */     int playerChunkZ = (int)this.mc.field_1724.method_23321() / 16;
/*      */     
/*  552 */     this.cherryGroveChunks.removeIf(chunkPos -> {
/*      */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*      */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/*  555 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */     
/*  558 */     this.notifiedCherryChunks.removeIf(chunkPos -> {
/*      */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*      */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/*  561 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */   }
/*      */   
/*      */   private void scheduleTraderScan() {
/*  566 */     if (this.shouldStop || this.scannerThread == null || this.scannerThread.isShutdown() || this.isPausedDueToLag)
/*      */       return; 
/*  568 */     if (this.currentTraderScanTask != null && !this.currentTraderScanTask.isDone()) {
/*  569 */       this.currentTraderScanTask.cancel(false);
/*      */     }
/*      */     
/*  572 */     this.currentTraderScanTask = this.scannerThread.submit(this::scanTradersBackground);
/*      */   }
/*      */   
/*      */   private void scanTradersBackground() {
/*  576 */     if (this.shouldStop || this.mc.field_1687 == null || this.mc.field_1724 == null || this.isPausedDueToLag)
/*      */       return; 
/*      */     try {
/*  579 */       int entityCount = 0;
/*  580 */       for (class_1297 entity : this.mc.field_1687.method_18112()) {
/*  581 */         if (this.shouldStop || entity == null || this.isPausedDueToLag)
/*      */           continue; 
/*  583 */         entityCount++;
/*      */         
/*  585 */         if (entity instanceof net.minecraft.class_3989 || entity instanceof net.minecraft.class_3986) {
/*  586 */           class_243 pos = entity.method_19538();
/*  587 */           class_1923 chunkPos = new class_1923((int)Math.floor(pos.field_1352 / 16.0D), (int)Math.floor(pos.field_1350 / 16.0D));
/*      */           
/*  589 */           int entityId = entity.method_5628();
/*  590 */           boolean hasNotifiedThisTrader = this.notifiedTraders.contains(Integer.valueOf(entityId));
/*      */           
/*  592 */           boolean wasAlreadyFlagged = this.traderChunks.contains(chunkPos);
/*  593 */           this.traderChunks.add(chunkPos);
/*      */           
/*  595 */           if (!hasNotifiedThisTrader) {
/*  596 */             notifyTraderChunkFound(chunkPos);
/*  597 */             this.notifiedTraders.add(Integer.valueOf(entityId));
/*  598 */             this.notifiedTraderChunks.add(chunkPos);
/*      */           } 
/*      */         } 
/*      */         
/*  602 */         if (entityCount > 0 && entityCount % 100 == 0) {
/*  603 */           Thread.sleep(5L);
/*      */         }
/*      */       } 
/*      */       
/*  607 */       Set<class_1923> chunksToRemove = new HashSet<>();
/*  608 */       Set<Integer> tradersToRemove = new HashSet<>();
/*      */       
/*  610 */       for (class_1923 chunkPos : this.traderChunks) {
/*  611 */         if (!hasTraderInChunk(chunkPos)) {
/*  612 */           chunksToRemove.add(chunkPos);
/*      */         }
/*      */       } 
/*      */       
/*  616 */       for (Integer traderId : this.notifiedTraders) {
/*  617 */         boolean traderExists = false;
/*  618 */         for (class_1297 entity : this.mc.field_1687.method_18112()) {
/*  619 */           if (entity != null && entity.method_5628() == traderId.intValue() && (entity instanceof net.minecraft.class_3989 || entity instanceof net.minecraft.class_3986)) {
/*      */             
/*  621 */             traderExists = true;
/*      */             break;
/*      */           } 
/*      */         } 
/*  625 */         if (!traderExists) {
/*  626 */           tradersToRemove.add(traderId);
/*      */         }
/*      */       } 
/*      */       
/*  630 */       for (class_1923 chunkPos : chunksToRemove) {
/*  631 */         this.traderChunks.remove(chunkPos);
/*  632 */         this.notifiedTraderChunks.remove(chunkPos);
/*      */       } 
/*      */       
/*  635 */       for (Integer traderId : tradersToRemove) {
/*  636 */         this.notifiedTraders.remove(traderId);
/*      */       }
/*      */     }
/*  639 */     catch (InterruptedException e) {
/*  640 */       Thread.currentThread().interrupt();
/*  641 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean hasTraderInChunk(class_1923 chunkPos) {
/*  646 */     if (this.shouldStop || this.mc.field_1687 == null) return false;
/*      */     
/*      */     try {
/*  649 */       int startX = chunkPos.field_9181 * 16;
/*  650 */       int startZ = chunkPos.field_9180 * 16;
/*  651 */       int endX = startX + 16;
/*  652 */       int endZ = startZ + 16;
/*      */       
/*  654 */       for (class_1297 entity : this.mc.field_1687.method_18112()) {
/*  655 */         if (entity == null)
/*      */           continue; 
/*  657 */         class_243 pos = entity.method_19538();
/*  658 */         int entityX = (int)Math.floor(pos.field_1352);
/*  659 */         int entityZ = (int)Math.floor(pos.field_1350);
/*      */         
/*  661 */         if (entityX >= startX && entityX < endX && entityZ >= startZ && entityZ < endZ && (
/*  662 */           entity instanceof net.minecraft.class_3989 || entity instanceof net.minecraft.class_3986)) {
/*  663 */           return true;
/*      */         }
/*      */       }
/*      */     
/*  667 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/*  670 */     return false;
/*      */   }
/*      */   
/*      */   private void notifyTraderChunkFound(class_1923 chunkPos) {
/*  674 */     this.mc.execute(() -> {
/*      */           try {
/*      */             if (this.mc.field_1724 != null) {
/*      */               this.mc.field_1724.method_5783(class_3417.field_26979, 1.0F, 1.0F);
/*      */             }
/*      */             
/*      */             int worldX = chunkPos.field_9181 * 16 + 8;
/*      */             
/*      */             int worldZ = chunkPos.field_9180 * 16 + 8;
/*      */             ChunkFinderToast toast = new ChunkFinderToast(String.valueOf(worldX), String.valueOf(worldZ));
/*      */             this.mc.method_1566().method_1999(toast);
/*  685 */           } catch (Exception exception) {}
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private void cleanupDistantTraderChunks() {
/*  691 */     if (this.mc.field_1724 == null)
/*      */       return; 
/*  693 */     int viewDist = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/*  694 */     int playerChunkX = (int)this.mc.field_1724.method_23317() / 16;
/*  695 */     int playerChunkZ = (int)this.mc.field_1724.method_23321() / 16;
/*      */     
/*  697 */     this.traderChunks.removeIf(chunkPos -> {
/*      */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*      */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/*  700 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */     
/*  703 */     this.notifiedTraderChunks.removeIf(chunkPos -> {
/*      */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*      */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/*  706 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */   }
/*      */   
/*      */   private void scheduleChunkScan() {
/*  711 */     if (this.shouldStop || this.scannerThread == null || this.scannerThread.isShutdown() || this.isPausedDueToLag)
/*      */       return; 
/*  713 */     if (this.currentScanTask != null && !this.currentScanTask.isDone()) {
/*  714 */       this.currentScanTask.cancel(false);
/*      */     }
/*      */     
/*  717 */     this.currentScanTask = this.scannerThread.submit(this::scanChunksBackground);
/*      */   }
/*      */   
/*      */   private void scheduleHoleScan() {
/*  721 */     if (this.shouldStop || this.scannerThread == null || this.scannerThread.isShutdown() || this.isPausedDueToLag)
/*      */       return; 
/*  723 */     if (this.currentHoleScanTask != null && !this.currentHoleScanTask.isDone()) {
/*  724 */       this.currentHoleScanTask.cancel(false);
/*      */     }
/*      */     
/*  727 */     this.currentHoleScanTask = this.scannerThread.submit(this::scanHolesBackground);
/*      */   }
/*      */   
/*      */   private void scanHolesBackground() {
/*  731 */     if (this.shouldStop || this.mc.field_1687 == null || this.mc.field_1724 == null || this.isPausedDueToLag)
/*      */       return; 
/*      */     try {
/*  734 */       List<class_2818> loadedChunks = getLoadedChunks();
/*      */       
/*  736 */       for (class_2818 chunk : loadedChunks) {
/*  737 */         if (this.shouldStop || chunk == null || chunk.method_12223() || this.isPausedDueToLag)
/*      */           continue; 
/*  739 */         class_1923 chunkPos = chunk.method_12004();
/*  740 */         if (this.holeScannedChunks.contains(chunkPos))
/*      */           continue; 
/*  742 */         scanChunkForHoles(chunk);
/*  743 */         this.holeScannedChunks.add(chunkPos);
/*      */         
/*  745 */         Thread.sleep(10L);
/*      */       } 
/*  747 */     } catch (InterruptedException e) {
/*  748 */       Thread.currentThread().interrupt();
/*  749 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */   
/*      */   private void scanChunkForHoles(class_2818 chunk) {
/*  754 */     if (this.shouldStop || chunk == null || chunk.method_12223() || this.isPausedDueToLag)
/*      */       return; 
/*  756 */     class_1923 chunkPos = chunk.method_12004();
/*  757 */     int xStart = chunkPos.method_8326();
/*  758 */     int zStart = chunkPos.method_8328();
/*  759 */     int yMin = Math.max(chunk.method_31607(), 20);
/*  760 */     int yMax = Math.min(chunk.method_31607() + chunk.method_31605(), 60);
/*      */     
/*  762 */     for (int x = xStart; x < xStart + 16; x++) {
/*  763 */       for (int z = zStart; z < zStart + 16; z++) {
/*  764 */         for (int y = yMin; y < yMax; y++) {
/*  765 */           if (this.shouldStop || this.isPausedDueToLag)
/*  766 */             return;  class_2338 pos = new class_2338(x, y, z);
/*      */ 
/*      */           
/*      */           try {
/*  770 */             checkHole1x1(pos);
/*      */ 
/*      */ 
/*      */             
/*  774 */             checkHole3x1(pos);
/*      */           }
/*  776 */           catch (Exception exception) {}
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void checkHole1x1(class_2338 pos) {
/*  784 */     if (isValidHoleSection(pos)) {
/*  785 */       class_2338.class_2339 currentPos = pos.method_25503();
/*  786 */       while (isValidHoleSection((class_2338)currentPos)) {
/*  787 */         currentPos.method_10098(class_2350.field_11036);
/*      */       }
/*  789 */       if (currentPos.method_10264() - pos.method_10264() >= 8) {
/*      */ 
/*      */         
/*  792 */         class_238 holeBox = new class_238(pos.method_10263(), pos.method_10264(), pos.method_10260(), (pos.method_10263() + 1), currentPos.method_10264(), (pos.method_10260() + 1));
/*      */         
/*  794 */         if (!this.holes1x1.contains(holeBox) && this.holes1x1.stream().noneMatch(existingHole -> existingHole.method_994(holeBox))) {
/*  795 */           this.holes1x1.add(holeBox);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private void checkHole3x1(class_2338 pos) {
/*  802 */     if (isValid3x1HoleSectionX(pos)) {
/*  803 */       class_2338.class_2339 currentPos = pos.method_25503();
/*  804 */       while (isValid3x1HoleSectionX((class_2338)currentPos)) {
/*  805 */         currentPos.method_10098(class_2350.field_11036);
/*      */       }
/*  807 */       if (currentPos.method_10264() - pos.method_10264() >= 8) {
/*      */ 
/*      */         
/*  810 */         class_238 holeBox = new class_238(pos.method_10263(), pos.method_10264(), pos.method_10260(), (pos.method_10263() + 3), currentPos.method_10264(), (pos.method_10260() + 1));
/*      */         
/*  812 */         if (!this.holes3x1.contains(holeBox) && this.holes3x1.stream().noneMatch(existingHole -> existingHole.method_994(holeBox))) {
/*  813 */           this.holes3x1.add(holeBox);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/*  818 */     if (isValid3x1HoleSectionZ(pos)) {
/*  819 */       class_2338.class_2339 currentPos = pos.method_25503();
/*  820 */       while (isValid3x1HoleSectionZ((class_2338)currentPos)) {
/*  821 */         currentPos.method_10098(class_2350.field_11036);
/*      */       }
/*  823 */       if (currentPos.method_10264() - pos.method_10264() >= 8) {
/*      */ 
/*      */         
/*  826 */         class_238 holeBox = new class_238(pos.method_10263(), pos.method_10264(), pos.method_10260(), (pos.method_10263() + 1), currentPos.method_10264(), (pos.method_10260() + 3));
/*      */         
/*  828 */         if (!this.holes3x1.contains(holeBox) && this.holes3x1.stream().noneMatch(existingHole -> existingHole.method_994(holeBox))) {
/*  829 */           this.holes3x1.add(holeBox);
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   private boolean isValidHoleSection(class_2338 pos) {
/*  836 */     return (isAirBlock(pos) && 
/*  837 */       !isAirBlock(pos.method_10095()) && !isAirBlock(pos.method_10072()) && 
/*  838 */       !isAirBlock(pos.method_10078()) && !isAirBlock(pos.method_10067()));
/*      */   }
/*      */   
/*      */   private boolean isValid3x1HoleSectionX(class_2338 pos) {
/*  842 */     return (isAirBlock(pos) && 
/*  843 */       isAirBlock(pos.method_10078()) && 
/*  844 */       isAirBlock(pos.method_10089(2)) && 
/*  845 */       !isAirBlock(pos.method_10095()) && 
/*  846 */       !isAirBlock(pos.method_10072()) && 
/*  847 */       !isAirBlock(pos.method_10089(3)) && 
/*  848 */       !isAirBlock(pos.method_10067()) && 
/*  849 */       !isAirBlock(pos.method_10078().method_10095()) && 
/*  850 */       !isAirBlock(pos.method_10078().method_10072()) && 
/*  851 */       !isAirBlock(pos.method_10089(2).method_10095()) && 
/*  852 */       !isAirBlock(pos.method_10089(2).method_10072()));
/*      */   }
/*      */   
/*      */   private boolean isValid3x1HoleSectionZ(class_2338 pos) {
/*  856 */     return (isAirBlock(pos) && 
/*  857 */       isAirBlock(pos.method_10072()) && 
/*  858 */       isAirBlock(pos.method_10077(2)) && 
/*  859 */       !isAirBlock(pos.method_10078()) && 
/*  860 */       !isAirBlock(pos.method_10067()) && 
/*  861 */       !isAirBlock(pos.method_10077(3)) && 
/*  862 */       !isAirBlock(pos.method_10095()) && 
/*  863 */       !isAirBlock(pos.method_10072().method_10078()) && 
/*  864 */       !isAirBlock(pos.method_10072().method_10067()) && 
/*  865 */       !isAirBlock(pos.method_10077(2).method_10078()) && 
/*  866 */       !isAirBlock(pos.method_10077(2).method_10067()));
/*      */   }
/*      */   
/*      */   private boolean isAirBlock(class_2338 pos) {
/*  870 */     if (this.mc.field_1687 == null) return false; 
/*  871 */     return this.mc.field_1687.method_8320(pos).method_26215();
/*      */   }
/*      */   
/*      */   private void cleanupDistantHoles() {
/*  875 */     if (this.mc.field_1724 == null)
/*      */       return; 
/*  877 */     int viewDist = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/*  878 */     int playerChunkX = (int)this.mc.field_1724.method_23317() / 16;
/*  879 */     int playerChunkZ = (int)this.mc.field_1724.method_23321() / 16;
/*      */     
/*  881 */     this.holes1x1.removeIf(holeBox -> {
/*      */           int holeChunkX = (int)Math.floor(holeBox.method_1005().method_10216()) / 16;
/*      */           int holeChunkZ = (int)Math.floor(holeBox.method_1005().method_10215()) / 16;
/*      */           int dx = Math.abs(holeChunkX - playerChunkX);
/*      */           int dz = Math.abs(holeChunkZ - playerChunkZ);
/*  886 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */     
/*  889 */     this.holes3x1.removeIf(holeBox -> {
/*      */           int holeChunkX = (int)Math.floor(holeBox.method_1005().method_10216()) / 16;
/*      */           int holeChunkZ = (int)Math.floor(holeBox.method_1005().method_10215()) / 16;
/*      */           int dx = Math.abs(holeChunkX - playerChunkX);
/*      */           int dz = Math.abs(holeChunkZ - playerChunkZ);
/*  894 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */     
/*  897 */     this.holeScannedChunks.removeIf(chunkPos -> {
/*      */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*      */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/*  900 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */   }
/*      */   
/*      */   private void scanChunksBackground() {
/*  905 */     if (this.shouldStop || this.mc.field_1687 == null || this.mc.field_1724 == null || this.isPausedDueToLag)
/*      */       return; 
/*      */     try {
/*  908 */       List<class_2818> loadedChunks = getLoadedChunks();
/*      */       
/*  910 */       for (class_2818 chunk : loadedChunks) {
/*  911 */         if (this.shouldStop || chunk == null || chunk.method_12223() || this.isPausedDueToLag)
/*      */           continue; 
/*  913 */         class_1923 chunkPos = chunk.method_12004();
/*  914 */         if (this.scannedChunks.contains(chunkPos))
/*      */           continue; 
/*  916 */         boolean wasAlreadyFlagged = this.flaggedChunks.contains(chunkPos);
/*  917 */         Set<class_2338> chunkFlaggedBlocks = scanChunkForCoveredOres(chunk);
/*  918 */         boolean shouldFlag = !chunkFlaggedBlocks.isEmpty();
/*      */         
/*  920 */         if (shouldFlag) {
/*  921 */           this.flaggedChunks.add(chunkPos);
/*  922 */           this.flaggedBlocks.put(chunkPos, chunkFlaggedBlocks);
/*  923 */           if (!wasAlreadyFlagged && !this.notifiedChunks.contains(chunkPos)) {
/*  924 */             notifyChunkFound(chunkPos);
/*  925 */             this.notifiedChunks.add(chunkPos);
/*      */           } 
/*      */         } else {
/*  928 */           this.flaggedChunks.remove(chunkPos);
/*  929 */           this.notifiedChunks.remove(chunkPos);
/*  930 */           this.flaggedBlocks.remove(chunkPos);
/*      */         } 
/*  932 */         this.scannedChunks.add(chunkPos);
/*      */         
/*  934 */         Thread.sleep(5L);
/*      */       } 
/*  936 */     } catch (InterruptedException e) {
/*  937 */       Thread.currentThread().interrupt();
/*  938 */     } catch (Exception exception) {}
/*      */   }
/*      */ 
/*      */   
/*      */   private void notifyChunkFound(class_1923 chunkPos) {
/*  943 */     this.mc.execute(() -> {
/*      */           try {
/*      */             if (this.mc.field_1724 != null) {
/*      */               this.mc.field_1724.method_5783(class_3417.field_26979, 1.0F, 1.0F);
/*      */             }
/*      */             
/*      */             int worldX = chunkPos.field_9181 * 16 + 8;
/*      */             
/*      */             int worldZ = chunkPos.field_9180 * 16 + 8;
/*      */             ChunkFinderToast toast = new ChunkFinderToast(String.valueOf(worldX), String.valueOf(worldZ));
/*      */             this.mc.method_1566().method_1999(toast);
/*  954 */           } catch (Exception exception) {}
/*      */         });
/*      */   }
/*      */ 
/*      */   
/*      */   private Set<class_2338> scanChunkForCoveredOres(class_2818 chunk) {
/*  960 */     Set<class_2338> foundBlocks = ConcurrentHashMap.newKeySet();
/*  961 */     int pistonCount = 0;
/*  962 */     if (this.shouldStop || chunk == null || chunk.method_12223() || this.isPausedDueToLag) return foundBlocks;
/*      */     
/*  964 */     class_1923 chunkPos = chunk.method_12004();
/*  965 */     int xStart = chunkPos.method_8326();
/*  966 */     int zStart = chunkPos.method_8328();
/*  967 */     int yMin = Math.max(chunk.method_31607(), 20);
/*  968 */     int yMax = Math.min(chunk.method_31607() + chunk.method_31605(), 60);
/*      */     int x;
/*  970 */     for (x = xStart; x < xStart + 16; x++) {
/*  971 */       for (int z = zStart; z < zStart + 16; z++) {
/*  972 */         for (int y = yMin; y < yMax; y++) {
/*  973 */           if (this.shouldStop || this.isPausedDueToLag) return foundBlocks; 
/*  974 */           class_2338 pos = new class_2338(x, y, z);
/*      */           try {
/*  976 */             class_2680 state = chunk.method_8320(pos);
/*  977 */             class_2248 block = state.method_26204();
/*      */             
/*  979 */             if ((block == class_2246.field_27165 || block == class_2246.field_28888) && y > 20 && y < 60 && 
/*  980 */               isBlockCovered(chunk, pos) && isPositionUnderground(pos)) {
/*  981 */               foundBlocks.add(pos);
/*      */             }
/*      */ 
/*      */             
/*  985 */             if (isTargetBlock(state) && y >= 20 && y <= 60 && 
/*  986 */               isBlockCovered(chunk, pos) && isPositionUnderground(pos)) {
/*  987 */               foundBlocks.add(pos);
/*      */             }
/*      */ 
/*      */             
/*  991 */             if (isRotatedDeepslate(state) && 
/*  992 */               isBlockCovered(chunk, pos) && isPositionUnderground(pos)) {
/*  993 */               foundBlocks.add(pos);
/*      */             }
/*      */ 
/*      */             
/*  997 */             if (block == class_2246.field_10560 || block == class_2246.field_10615) {
/*  998 */               pistonCount++;
/*      */             }
/* 1000 */           } catch (Exception exception) {}
/*      */         } 
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1006 */     for (x = xStart; x < xStart + 16; x++) {
/* 1007 */       for (int z = zStart; z < zStart + 16; z++) {
/* 1008 */         int sameCount = 0;
/* 1009 */         class_2248 plugType = null;
/* 1010 */         List<class_2338> currentPlug = new ArrayList<>();
/*      */         
/* 1012 */         for (int y = yMin; y <= yMax; y++) {
/* 1013 */           class_2338 pos = new class_2338(x, y, z);
/* 1014 */           class_2680 state = chunk.method_8320(pos);
/* 1015 */           class_2248 block = state.method_26204();
/*      */           
/* 1017 */           if (isPlugBlock(block)) {
/* 1018 */             if (plugType == null || block == plugType) {
/* 1019 */               sameCount++;
/* 1020 */               plugType = block;
/* 1021 */               currentPlug.add(pos);
/*      */             } else {
/* 1023 */               sameCount = 1;
/* 1024 */               plugType = block;
/* 1025 */               currentPlug.clear();
/* 1026 */               currentPlug.add(pos);
/*      */             } 
/*      */             
/* 1029 */             if (sameCount >= 25 && 
/* 1030 */               isCoveredColumn(chunk, x, z, y - sameCount + 1, y, plugType)) {
/* 1031 */               List<class_2338> verifiedBlocks = new ArrayList<>();
/* 1032 */               for (class_2338 plugPos : currentPlug) {
/* 1033 */                 if (isBlockCovered(chunk, plugPos) && isPositionUnderground(plugPos)) {
/* 1034 */                   verifiedBlocks.add(plugPos);
/*      */                 }
/*      */               } 
/* 1037 */               foundBlocks.addAll(verifiedBlocks);
/*      */             } 
/*      */           } else {
/*      */             
/* 1041 */             sameCount = 0;
/* 1042 */             plugType = null;
/* 1043 */             currentPlug.clear();
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1049 */     if (pistonCount >= 5) {
/* 1050 */       for (x = xStart; x < xStart + 16; x++) {
/* 1051 */         for (int z = zStart; z < zStart + 16; z++) {
/* 1052 */           for (int y = yMin; y < yMax && 
/* 1053 */             !this.shouldStop && !this.isPausedDueToLag; y++) {
/* 1054 */             class_2338 pos = new class_2338(x, y, z);
/*      */             try {
/* 1056 */               class_2680 state = chunk.method_8320(pos);
/* 1057 */               class_2248 block = state.method_26204();
/* 1058 */               if (block == class_2246.field_10560 || block == class_2246.field_10615) {
/* 1059 */                 foundBlocks.add(pos);
/*      */               }
/* 1061 */             } catch (Exception exception) {}
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/* 1068 */     return foundBlocks;
/*      */   }
/*      */ 
/*      */   
/*      */   private boolean isPlugBlock(class_2248 block) {
/* 1073 */     return (block == class_2246.field_10474 || block == class_2246.field_10115 || block == class_2246.field_10566 || block == class_2246.field_10508);
/*      */   }
/*      */   
/*      */   private boolean isCoveredColumn(class_2818 chunk, int x, int z, int yStart, int yEnd, class_2248 blockType) {
/* 1077 */     for (int y = yStart; y <= yEnd; y++) {
/* 1078 */       class_2338 pos = new class_2338(x, y, z);
/* 1079 */       if (!chunk.method_8320(pos).method_27852(blockType)) return false; 
/* 1080 */       for (class_2350 dir : class_2350.values()) {
/* 1081 */         class_2338 adj = pos.method_10093(dir);
/* 1082 */         class_2680 adjState = chunk.method_8320(adj);
/* 1083 */         if (adjState.method_26215() || !adjState.method_26212((class_1922)this.mc.field_1687, adj)) {
/* 1084 */           return false;
/*      */         }
/*      */       } 
/*      */     } 
/* 1088 */     return true;
/*      */   }
/*      */   
/*      */   private boolean isPositionUnderground(class_2338 pos) {
/* 1092 */     if (this.mc.field_1687 == null) return false;
/*      */     
/* 1094 */     int checkHeight = Math.min(pos.method_10264() + 50, 80);
/* 1095 */     int solidBlocksAbove = 0;
/*      */     
/* 1097 */     for (int y = pos.method_10264() + 1; y <= checkHeight; y++) {
/* 1098 */       class_2338 checkPos = new class_2338(pos.method_10263(), y, pos.method_10260());
/* 1099 */       class_2680 state = this.mc.field_1687.method_8320(checkPos);
/*      */       
/* 1101 */       if (!state.method_26215() && state.method_26212((class_1922)this.mc.field_1687, checkPos)) {
/* 1102 */         solidBlocksAbove++;
/*      */       }
/*      */     } 
/*      */     
/* 1106 */     return (solidBlocksAbove >= 3);
/*      */   }
/*      */   
/*      */   private boolean isTargetBlock(class_2680 state) {
/* 1110 */     if (state == null || state.method_26215()) return false;
/*      */     
/* 1112 */     class_2248 block = state.method_26204();
/*      */     
/* 1114 */     if (block == class_2246.field_28888) {
/* 1115 */       return !isRotatedDeepslate(state);
/*      */     }
/*      */     
/* 1118 */     return (block == class_2246.field_27165);
/*      */   }
/*      */   
/*      */   private boolean isRotatedDeepslate(class_2680 state) {
/* 1122 */     if (state == null || state.method_26215()) return false;
/*      */     
/* 1124 */     class_2248 block = state.method_26204();
/*      */     
/* 1126 */     if (block == class_2246.field_28888 && 
/* 1127 */       state.method_28498((class_2769)class_2465.field_11459)) {
/* 1128 */       class_2350.class_2351 axis = (class_2350.class_2351)state.method_11654((class_2769)class_2465.field_11459);
/* 1129 */       return (axis == class_2350.class_2351.field_11048 || axis == class_2350.class_2351.field_11051);
/*      */     } 
/*      */ 
/*      */     
/* 1133 */     return false;
/*      */   }
/*      */   
/*      */   private boolean isBlockCovered(class_2818 chunk, class_2338 pos) {
/* 1137 */     class_2350[] directions = { class_2350.field_11036, class_2350.field_11033, class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039 };
/*      */     
/* 1139 */     for (class_2350 dir : directions) {
/* 1140 */       class_2338 adjacentPos = pos.method_10093(dir);
/*      */       
/*      */       try {
/* 1143 */         class_2680 adjacentState = null;
/*      */         
/* 1145 */         if (this.mc.field_1687 != null) {
/* 1146 */           adjacentState = this.mc.field_1687.method_8320(adjacentPos);
/*      */         } else {
/* 1148 */           return false;
/*      */         } 
/*      */         
/* 1151 */         if (adjacentState.method_26215() || isTransparentBlock(adjacentState)) {
/* 1152 */           return false;
/*      */         }
/*      */         
/* 1155 */         if (!adjacentState.method_26212((class_1922)this.mc.field_1687, adjacentPos)) {
/* 1156 */           return false;
/*      */         }
/*      */       }
/* 1159 */       catch (Exception e) {
/* 1160 */         return false;
/*      */       } 
/*      */     } 
/*      */     
/* 1164 */     return true;
/*      */   }
/*      */   
/*      */   private boolean isTransparentBlock(class_2680 state) {
/* 1168 */     class_2248 block = state.method_26204();
/*      */     
/* 1170 */     if (block == class_2246.field_10033 || block == class_2246.field_10382 || block == class_2246.field_10164 || block == class_2246.field_10295 || block == class_2246.field_10225 || block == class_2246.field_10384)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1176 */       return true;
/*      */     }
/*      */     
/* 1179 */     if (block == class_2246.field_10087 || block == class_2246.field_10227 || block == class_2246.field_10574 || block == class_2246.field_10271 || block == class_2246.field_10049 || block == class_2246.field_10157 || block == class_2246.field_10317 || block == class_2246.field_10555 || block == class_2246.field_9996 || block == class_2246.field_10248 || block == class_2246.field_10399 || block == class_2246.field_10060 || block == class_2246.field_10073 || block == class_2246.field_10357 || block == class_2246.field_10272 || block == class_2246.field_9997 || block == class_2246.field_27115)
/*      */     {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1196 */       return true;
/*      */     }
/*      */     
/* 1199 */     return (block == class_2246.field_10503 || block == class_2246.field_9988 || block == class_2246.field_10539 || block == class_2246.field_10335 || block == class_2246.field_10098 || block == class_2246.field_10035 || block == class_2246.field_37551 || block == class_2246.field_42731);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void cleanupDistantChunks() {
/* 1210 */     if (this.mc.field_1724 == null)
/*      */       return; 
/* 1212 */     int viewDist = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/* 1213 */     int playerChunkX = (int)this.mc.field_1724.method_23317() / 16;
/* 1214 */     int playerChunkZ = (int)this.mc.field_1724.method_23321() / 16;
/*      */     
/* 1216 */     this.flaggedChunks.removeIf(chunkPos -> {
/*      */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*      */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/* 1219 */           boolean shouldRemove = (dx > viewDist || dz > viewDist);
/*      */           
/*      */           if (shouldRemove) {
/*      */             this.flaggedBlocks.remove(chunkPos);
/*      */           }
/*      */           return shouldRemove;
/*      */         });
/* 1226 */     this.scannedChunks.removeIf(chunkPos -> {
/*      */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*      */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/* 1229 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */     
/* 1232 */     this.notifiedChunks.removeIf(chunkPos -> {
/*      */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*      */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/* 1235 */           return (dx > viewDist || dz > viewDist);
/*      */         });
/*      */   }
/*      */   
/*      */   @EventListener
/*      */   public void onRender3D(Render3DEvent event) {
/* 1241 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null)
/*      */       return; 
/* 1243 */     if (this.killSwitchActivated)
/*      */       return; 
/* 1245 */     class_4184 cam = RenderUtils.getCamera();
/* 1246 */     if (cam != null) {
/* 1247 */       class_243 camPos = RenderUtils.getCameraPos();
/* 1248 */       class_4587 matrices = event.matrixStack;
/* 1249 */       matrices.method_22903();
/* 1250 */       matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
/* 1251 */       matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
/* 1252 */       matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*      */     } 
/*      */     
/* 1255 */     if (!this.flaggedChunks.isEmpty()) {
/* 1256 */       for (class_1923 chunkPos : this.flaggedChunks) {
/* 1257 */         Objects.requireNonNull(this); int a = 120;
/* 1258 */         renderChunkHighlight(event.matrixStack, chunkPos, new Color(0, 255, 0, a));
/*      */         
/* 1260 */         renderFlaggedBlocks(event.matrixStack, chunkPos);
/*      */       } 
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1273 */     if (this.holeESP.getValue()) {
/* 1274 */       if (!this.holes1x1.isEmpty()) {
/* 1275 */         renderHoles1x1(event.matrixStack);
/*      */       }
/* 1277 */       if (!this.holes3x1.isEmpty()) {
/* 1278 */         renderHoles3x1(event.matrixStack);
/*      */       }
/*      */     } 
/*      */     
/* 1282 */     event.matrixStack.method_22909();
/*      */   }
/*      */   
/*      */   private void renderHoles1x1(class_4587 stack) {
/* 1286 */     Color color = this.hole1x1Color;
/* 1287 */     for (class_238 hole : this.holes1x1) {
/*      */       
/* 1289 */       RenderUtils.renderFilledBox(stack, (float)hole.field_1323, (float)hole.field_1322, (float)hole.field_1321, (float)hole.field_1320, (float)hole.field_1325, (float)hole.field_1324, color);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1295 */       renderBoxOutline(stack, (float)hole.field_1323, (float)hole.field_1322, (float)hole.field_1321, (float)hole.field_1320, (float)hole.field_1325, (float)hole.field_1324, new Color(color
/*      */ 
/*      */             
/* 1298 */             .getRed(), color.getGreen(), color.getBlue(), 255));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderHoles3x1(class_4587 stack) {
/* 1304 */     Color color = this.hole3x1Color;
/* 1305 */     for (class_238 hole : this.holes3x1) {
/*      */       
/* 1307 */       RenderUtils.renderFilledBox(stack, (float)hole.field_1323, (float)hole.field_1322, (float)hole.field_1321, (float)hole.field_1320, (float)hole.field_1325, (float)hole.field_1324, color);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/* 1313 */       renderBoxOutline(stack, (float)hole.field_1323, (float)hole.field_1322, (float)hole.field_1321, (float)hole.field_1320, (float)hole.field_1325, (float)hole.field_1324, new Color(color
/*      */ 
/*      */             
/* 1316 */             .getRed(), color.getGreen(), color.getBlue(), 255));
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private void renderChunkHighlight(class_4587 stack, class_1923 chunkPos, Color renderColor) {
/* 1322 */     int startX = chunkPos.field_9181 * 16;
/* 1323 */     int startZ = chunkPos.field_9180 * 16;
/* 1324 */     int endX = startX + 16;
/* 1325 */     int endZ = startZ + 16;
/*      */     
/* 1327 */     double y = 60.0D;
/* 1328 */     double height = 0.10000000149011612D;
/*      */     
/* 1330 */     class_238 chunkBox = new class_238(startX, y, startZ, endX, y + height, endZ);
/*      */ 
/*      */     
/* 1333 */     RenderUtils.renderFilledBox(stack, (float)chunkBox.field_1323, (float)chunkBox.field_1322, (float)chunkBox.field_1321, (float)chunkBox.field_1320, (float)chunkBox.field_1325, (float)chunkBox.field_1324, renderColor);
/*      */ 
/*      */ 
/*      */     
/* 1337 */     renderBoxOutline(stack, (float)chunkBox.field_1323, (float)chunkBox.field_1322, (float)chunkBox.field_1321, (float)chunkBox.field_1320, (float)chunkBox.field_1325, (float)chunkBox.field_1324, renderColor);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void renderFlaggedBlocks(class_4587 stack, class_1923 chunkPos) {
/* 1352 */     Set<class_2338> blocks = this.flaggedBlocks.get(chunkPos);
/* 1353 */     if (blocks == null || blocks.isEmpty())
/*      */       return; 
/* 1355 */     Color blockColor = new Color(255, 0, 0, 120);
/* 1356 */     for (class_2338 blockPos : blocks) {
/* 1357 */       class_238 class_238 = new class_238(blockPos);
/*      */     }
/*      */   }
/*      */   
/*      */   private List<class_2818> getLoadedChunks() {
/* 1362 */     List<class_2818> chunks = new ArrayList<>();
/* 1363 */     int viewDist = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/*      */     
/* 1365 */     for (int x = -viewDist; x <= viewDist; x++) {
/* 1366 */       for (int z = -viewDist; z <= viewDist; z++) {
/* 1367 */         class_2818 chunk = this.mc.field_1687.method_2935().method_21730(
/* 1368 */             (int)this.mc.field_1724.method_23317() / 16 + x, 
/* 1369 */             (int)this.mc.field_1724.method_23321() / 16 + z);
/*      */ 
/*      */         
/* 1372 */         if (chunk != null) chunks.add(chunk); 
/*      */       } 
/*      */     } 
/* 1375 */     return chunks;
/*      */   }
/*      */   
/*      */   private void renderBoxOutline(class_4587 stack, float minX, float minY, float minZ, float maxX, float maxY, float maxZ, Color color) {
/* 1379 */     class_243[] corners = { new class_243(minX, minY, minZ), new class_243(maxX, minY, minZ), new class_243(maxX, minY, maxZ), new class_243(minX, minY, maxZ), new class_243(minX, maxY, minZ), new class_243(maxX, maxY, minZ), new class_243(maxX, maxY, maxZ), new class_243(minX, maxY, maxZ) };
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1390 */     RenderUtils.renderLine(stack, color, corners[0], corners[1]);
/* 1391 */     RenderUtils.renderLine(stack, color, corners[1], corners[2]);
/* 1392 */     RenderUtils.renderLine(stack, color, corners[2], corners[3]);
/* 1393 */     RenderUtils.renderLine(stack, color, corners[3], corners[0]);
/*      */     
/* 1395 */     RenderUtils.renderLine(stack, color, corners[4], corners[5]);
/* 1396 */     RenderUtils.renderLine(stack, color, corners[5], corners[6]);
/* 1397 */     RenderUtils.renderLine(stack, color, corners[6], corners[7]);
/* 1398 */     RenderUtils.renderLine(stack, color, corners[7], corners[4]);
/*      */     
/* 1400 */     RenderUtils.renderLine(stack, color, corners[0], corners[4]);
/* 1401 */     RenderUtils.renderLine(stack, color, corners[1], corners[5]);
/* 1402 */     RenderUtils.renderLine(stack, color, corners[2], corners[6]);
/* 1403 */     RenderUtils.renderLine(stack, color, corners[3], corners[7]);
/*      */   }
/*      */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\ChunkFinder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */