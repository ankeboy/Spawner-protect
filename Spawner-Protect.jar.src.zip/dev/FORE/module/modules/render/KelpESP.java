/*     */ package dev.FORE.module.modules.render;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import java.awt.Color;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ public final class KelpESP extends Module {
/*  25 */   private final NumberSetting range = new NumberSetting((CharSequence)EncryptedString.of("Range"), 10.0D, 100.0D, 50.0D, 1.0D);
/*  26 */   private final NumberSetting alpha = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 50.0D, 255.0D, 150.0D, 1.0D);
/*  27 */   private final BooleanSetting showHeight = (new BooleanSetting((CharSequence)EncryptedString.of("Show Height"), true)).setDescription((CharSequence)EncryptedString.of("Shows the height of the kelp"));
/*  28 */   private final BooleanSetting onlyTallest = (new BooleanSetting((CharSequence)EncryptedString.of("Only Tallest"), true)).setDescription((CharSequence)EncryptedString.of("Only highlights the tallest kelp in each cluster"));
/*  29 */   private final BooleanSetting onlySurfaceKelp = (new BooleanSetting((CharSequence)EncryptedString.of("Only Surface Kelp"), true)).setDescription((CharSequence)EncryptedString.of("Only highlights kelp that reaches the water surface"));
/*  30 */   private final NumberSetting minSurfaceHeight = (new NumberSetting((CharSequence)EncryptedString.of("Min Surface Height"), 1.0D, 20.0D, 3.0D, 1.0D)).setDescription((CharSequence)EncryptedString.of("Minimum height for kelp to be considered surface-reaching"));
/*     */   
/*  32 */   private final Map<class_2338, Integer> kelpHeights = new HashMap<>();
/*  33 */   private final Map<class_2338, Integer> waterSurfaceLevels = new HashMap<>();
/*  34 */   private final Set<class_2338> processedClusters = new HashSet<>();
/*     */   
/*     */   public KelpESP() {
/*  37 */     super((CharSequence)EncryptedString.of("Kelp ESP"), (CharSequence)EncryptedString.of("Highlights kelp that reaches the water surface for base finding"), -1, Category.RENDER);
/*  38 */     this.range.setDescription((CharSequence)EncryptedString.of("Range to search for kelp"));
/*  39 */     this.alpha.setDescription((CharSequence)EncryptedString.of("Transparency of the ESP"));
/*  40 */     addsettings(new Setting[] { (Setting)this.range, (Setting)this.alpha, (Setting)this.showHeight, (Setting)this.onlyTallest, (Setting)this.onlySurfaceKelp, (Setting)this.minSurfaceHeight });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  45 */     super.onEnable();
/*  46 */     this.kelpHeights.clear();
/*  47 */     this.waterSurfaceLevels.clear();
/*  48 */     this.processedClusters.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  53 */     super.onDisable();
/*  54 */     this.kelpHeights.clear();
/*  55 */     this.waterSurfaceLevels.clear();
/*  56 */     this.processedClusters.clear();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent event) {
/*  61 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
/*     */       return;
/*     */     }
/*  64 */     scanForKelp();
/*     */ 
/*     */     
/*  67 */     class_4184 cam = RenderUtils.getCamera();
/*  68 */     if (cam != null) {
/*  69 */       class_243 camPos = RenderUtils.getCameraPos();
/*  70 */       class_4587 matrices = event.matrixStack;
/*  71 */       matrices.method_22903();
/*  72 */       matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
/*  73 */       matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
/*  74 */       matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*     */     } 
/*     */ 
/*     */     
/*  78 */     for (Map.Entry<class_2338, Integer> entry : this.kelpHeights.entrySet()) {
/*  79 */       class_2338 pos = entry.getKey();
/*  80 */       int height = ((Integer)entry.getValue()).intValue();
/*     */ 
/*     */       
/*  83 */       if (this.onlySurfaceKelp.getValue() && !reachesWaterSurface(pos, height)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/*  88 */       if (this.onlyTallest.getValue() && !isTallestInCluster(pos, height)) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/*  93 */       Color color = getKelpColor(height);
/*     */ 
/*     */       
/*  96 */       RenderUtils.renderFilledBox(event.matrixStack, pos
/*     */           
/*  98 */           .method_10263(), pos.method_10264(), pos.method_10260(), (pos
/*  99 */           .method_10263() + 1), (pos.method_10264() + 1), (pos.method_10260() + 1), color);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 104 */       RenderUtils.renderLine(event.matrixStack, color, new class_243(pos
/*     */ 
/*     */             
/* 107 */             .method_10263(), pos.method_10264(), pos.method_10260()), new class_243((pos
/* 108 */             .method_10263() + 1), (pos.method_10264() + 1), (pos.method_10260() + 1)));
/*     */ 
/*     */ 
/*     */       
/* 112 */       if (this.showHeight.getValue()) {
/* 113 */         String heightText = String.valueOf(height);
/* 114 */         class_243 class_243 = new class_243(pos.method_10263() + 0.5D, pos.method_10264() + 1.5D, pos.method_10260() + 0.5D);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 119 */     event.matrixStack.method_22909();
/*     */   }
/*     */   
/*     */   private void scanForKelp() {
/* 123 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null)
/*     */       return; 
/* 125 */     this.kelpHeights.clear();
/* 126 */     this.waterSurfaceLevels.clear();
/* 127 */     this.processedClusters.clear();
/*     */     
/* 129 */     class_2338 playerPos = this.mc.field_1724.method_24515();
/* 130 */     int range = this.range.getIntValue();
/*     */     
/* 132 */     for (int x = -range; x <= range; x++) {
/* 133 */       for (int z = -range; z <= range; z++) {
/* 134 */         for (int y = -20; y <= 20; y++) {
/* 135 */           class_2338 pos = playerPos.method_10069(x, y, z);
/* 136 */           class_2680 state = this.mc.field_1687.method_8320(pos);
/*     */           
/* 138 */           if (state.method_26204() instanceof net.minecraft.class_2393) {
/* 139 */             int height = getKelpHeight(pos);
/* 140 */             if (height > 0) {
/* 141 */               this.kelpHeights.put(pos, Integer.valueOf(height));
/*     */ 
/*     */               
/* 144 */               int surfaceLevel = findWaterSurfaceLevel(pos);
/* 145 */               this.waterSurfaceLevels.put(pos, Integer.valueOf(surfaceLevel));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private int getKelpHeight(class_2338 pos) {
/* 154 */     if (this.mc.field_1687 == null) return 0;
/*     */     
/* 156 */     int height = 0;
/* 157 */     class_2338 currentPos = pos;
/*     */ 
/*     */     
/* 160 */     while (this.mc.field_1687.method_8320(currentPos).method_26204() instanceof net.minecraft.class_2393) {
/* 161 */       height++;
/* 162 */       currentPos = currentPos.method_10084();
/*     */ 
/*     */       
/* 165 */       if (height > 25)
/*     */         break; 
/*     */     } 
/* 168 */     return height;
/*     */   }
/*     */   
/*     */   private int findWaterSurfaceLevel(class_2338 kelpBase) {
/* 172 */     if (this.mc.field_1687 == null) return kelpBase.method_10264();
/*     */ 
/*     */     
/* 175 */     class_2338 currentPos = kelpBase;
/*     */ 
/*     */     
/* 178 */     while (currentPos.method_10264() < 320) {
/* 179 */       class_2680 state = this.mc.field_1687.method_8320(currentPos);
/*     */ 
/*     */       
/* 182 */       if (state.method_26215()) {
/* 183 */         return currentPos.method_10264();
/*     */       }
/*     */ 
/*     */       
/* 187 */       if (!state.method_26227().method_15769() && 
/* 188 */         !(state.method_26204() instanceof net.minecraft.class_2393) && state
/* 189 */         .method_26204() != class_2246.field_10376 && state
/* 190 */         .method_26204() != class_2246.field_10238) {
/* 191 */         return currentPos.method_10264();
/*     */       }
/*     */       
/* 194 */       currentPos = currentPos.method_10084();
/*     */     } 
/*     */     
/* 197 */     return kelpBase.method_10264();
/*     */   }
/*     */   
/*     */   private boolean reachesWaterSurface(class_2338 kelpBase, int kelpHeight) {
/* 201 */     Integer surfaceLevel = this.waterSurfaceLevels.get(kelpBase);
/* 202 */     if (surfaceLevel == null) return false;
/*     */ 
/*     */     
/* 205 */     int kelpTop = kelpBase.method_10264() + kelpHeight - 1;
/*     */ 
/*     */     
/* 208 */     boolean reachesSurface = (kelpTop >= surfaceLevel.intValue() - 1);
/*     */ 
/*     */     
/* 211 */     boolean meetsMinHeight = (kelpHeight >= this.minSurfaceHeight.getIntValue());
/*     */     
/* 213 */     return (reachesSurface && meetsMinHeight);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isTallestInCluster(class_2338 pos, int height) {
/* 218 */     for (int x = -3; x <= 3; x++) {
/* 219 */       for (int z = -3; z <= 3; z++) {
/* 220 */         class_2338 checkPos = pos.method_10069(x, 0, z);
/* 221 */         Integer checkHeight = this.kelpHeights.get(checkPos);
/* 222 */         if (checkHeight != null && checkHeight.intValue() > height) {
/* 223 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/* 227 */     return true;
/*     */   }
/*     */   
/*     */   private Color getKelpColor(int height) {
/*     */     int red;
/*     */     int green;
/*     */     int blue;
/* 234 */     if (height <= 5) {
/*     */       
/* 236 */       red = 0;
/* 237 */       green = 255;
/* 238 */       blue = 0;
/* 239 */     } else if (height <= 10) {
/*     */       
/* 241 */       red = 255;
/* 242 */       green = 255;
/* 243 */       blue = 0;
/* 244 */     } else if (height <= 15) {
/*     */       
/* 246 */       red = 255;
/* 247 */       green = 165;
/* 248 */       blue = 0;
/*     */     } else {
/*     */       
/* 251 */       red = 255;
/* 252 */       green = 0;
/* 253 */       blue = 0;
/*     */     } 
/*     */     
/* 256 */     return new Color(red, green, blue, this.alpha.getIntValue());
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\KelpESP.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */