/*     */ package dev.FORE.module.modules.render;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.PacketSendEvent;
/*     */ import dev.FORE.event.events.Render2DEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.ColorUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1309;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2824;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_640;
/*     */ 
/*     */ public final class TargetHUD extends Module {
/*  28 */   private final NumberSetting xPosition = new NumberSetting((CharSequence)EncryptedString.of("X"), 0.0D, 1920.0D, 500.0D, 1.0D);
/*  29 */   private final NumberSetting yPosition = new NumberSetting((CharSequence)EncryptedString.of("Y"), 0.0D, 1080.0D, 500.0D, 1.0D);
/*  30 */   private final BooleanSetting timeoutEnabled = (new BooleanSetting((CharSequence)EncryptedString.of("Timeout"), true)).setDescription((CharSequence)EncryptedString.of("Target hud will disappear after 10 seconds"));
/*  31 */   private final NumberSetting fadeSpeed = (new NumberSetting((CharSequence)EncryptedString.of("Fade Speed"), 5.0D, 30.0D, 15.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("Speed of animations"));
/*  32 */   private final Color primaryColor = new Color(255, 50, 100);
/*  33 */   private final Color backgroundColor = new Color(0, 0, 0, 175);
/*  34 */   private long lastAttackTime = 0L;
/*  35 */   public static float fadeProgress = 1.0F;
/*  36 */   private float currentHealth = 0.0F;
/*     */   private TargetHUDHandler hudHandler;
/*     */   
/*     */   public TargetHUD() {
/*  40 */     super((CharSequence)EncryptedString.of("Target HUD"), (CharSequence)EncryptedString.of("Displays detailed information about your target with style"), -1, Category.RENDER);
/*  41 */     addsettings(new Setting[] { (Setting)this.xPosition, (Setting)this.yPosition, (Setting)this.timeoutEnabled, (Setting)this.fadeSpeed });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  46 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  51 */     super.onDisable();
/*     */   }
/*     */   @EventListener
/*     */   public void onRender2D(Render2DEvent render2DEvent) {
/*     */     float targetFade;
/*  56 */     class_332 drawContext = render2DEvent.context;
/*  57 */     int xPos = this.xPosition.getIntValue();
/*  58 */     int yPos = this.yPosition.getIntValue();
/*  59 */     float fadeSpeed = this.fadeSpeed.getFloatValue();
/*  60 */     Color primaryColor = this.primaryColor;
/*  61 */     Color backgroundColor = this.backgroundColor;
/*  62 */     RenderUtils.unscaledProjection();
/*  63 */     boolean hasTarget = (this.mc.field_1724.method_6052() != null && this.mc.field_1724.method_6052() instanceof class_1657 && this.mc.field_1724.method_6052().method_5805());
/*  64 */     boolean notTimedOut = (!this.timeoutEnabled.getValue() || System.currentTimeMillis() - this.lastAttackTime <= 10000L);
/*     */     
/*  66 */     if (hasTarget && notTimedOut) {
/*  67 */       targetFade = 0.0F;
/*     */     } else {
/*  69 */       targetFade = 1.0F;
/*     */     } 
/*  71 */     fadeProgress = RenderUtils.fast(fadeProgress, targetFade, fadeSpeed);
/*  72 */     if (fadeProgress < 0.99F && hasTarget) {
/*  73 */       class_1309 target = this.mc.field_1724.method_6052();
/*  74 */       class_640 playerListEntry = this.mc.method_1562().method_2871(target.method_5667());
/*  75 */       class_4587 matrices = drawContext.method_51448();
/*  76 */       matrices.method_22903();
/*  77 */       float fadeAmount = 1.0F - fadeProgress;
/*  78 */       float scaleAmount = 0.8F + 0.2F * fadeAmount;
/*  79 */       matrices.method_46416(xPos, yPos, 0.0F);
/*  80 */       matrices.method_22905(scaleAmount, scaleAmount, 1.0F);
/*  81 */       matrices.method_46416(-xPos, -yPos, 0.0F);
/*  82 */       this.currentHealth = RenderUtils.fast(this.currentHealth, target.method_6032() + target.method_6067(), fadeSpeed * 0.5F);
/*  83 */       a(drawContext, xPos, yPos, (class_1657)target, playerListEntry, fadeAmount, primaryColor, backgroundColor);
/*  84 */       matrices.method_22909();
/*     */     } 
/*  86 */     RenderUtils.scaledProjection();
/*     */   }
/*     */   
/*     */   private void a(class_332 drawContext, int n, int n2, class_1657 playerEntity, class_640 playerListEntry, float n3, Color color, Color color2) {
/*  90 */     class_4587 matrices = drawContext.method_51448();
/*  91 */     RenderUtils.renderRoundedQuad(matrices, new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(50.0F * n3)), (n - 5), (n2 - 5), (n + 300 + 5), (n2 + 180 + 5), 15.0D, 15.0D, 15.0D, 15.0D, 30.0D);
/*  92 */     RenderUtils.renderRoundedQuad(matrices, new Color(color2.getRed(), color2.getGreen(), color2.getBlue(), (int)(color2.getAlpha() * n3)), n, n2, (n + 300), (n2 + 180), 10.0D, 10.0D, 10.0D, 10.0D, 20.0D);
/*  93 */     Color color3 = new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(color.getAlpha() * n3));
/*  94 */     RenderUtils.renderRoundedQuad(matrices, color3, (n + 20), n2, (n + 300 - 20), (n2 + 3), 0.0D, 0.0D, 0.0D, 0.0D, 10.0D);
/*  95 */     RenderUtils.renderRoundedQuad(matrices, color3, (n + 20), (n2 + 180 - 3), (n + 300 - 20), (n2 + 180), 0.0D, 0.0D, 0.0D, 0.0D, 10.0D);
/*  96 */     if (playerListEntry != null) {
/*  97 */       String s2; Color color4; RenderUtils.renderRoundedQuad(matrices, new Color(30, 30, 30, (int)(200.0F * n3)), (n + 15), (n2 + 15), (n + 85), (n2 + 85), 5.0D, 5.0D, 5.0D, 5.0D, 10.0D);
/*  98 */       class_7532.method_44443(drawContext, playerListEntry.method_52810().comp_1626(), n + 25, n2 + 25, 50);
/*  99 */       TextRenderer.drawString(playerEntity.method_5477().getString(), drawContext, n + 100, n2 + 25, ColorUtil.a((int)((float)(System.currentTimeMillis() % 1000L) / 1000.0F), 1).getRGB());
/* 100 */       TextRenderer.drawString("" + MathUtil.roundToNearest(playerEntity.method_5739((class_1297)this.mc.field_1724), 1.0D) + " blocks away", drawContext, n + 100, n2 + 45, Color.WHITE.getRGB());
/* 101 */       RenderUtils.renderRoundedQuad(matrices, new Color(60, 60, 60, (int)(200.0F * n3)), (n + 15), (n2 + 95), (n + 300 - 15), (n2 + 110), 5.0D, 5.0D, 5.0D, 5.0D, 10.0D);
/* 102 */       float b = this.currentHealth / playerEntity.method_6063();
/* 103 */       float n4 = 270.0F * Math.min(1.0F, b);
/* 104 */       RenderUtils.renderRoundedQuad(matrices, a(b * (float)(0.800000011920929D + 0.20000000298023224D * Math.sin(System.currentTimeMillis() / 300.0D)), n3), (n + 15), (n2 + 95), (n + 15 + (int)n4), (n2 + 110), 5.0D, 5.0D, 5.0D, 5.0D, 10.0D);
/* 105 */       String s = "" + Math.round(this.currentHealth) + "/" + Math.round(this.currentHealth) + " HP";
/* 106 */       TextRenderer.drawString(s, drawContext, n + 15 + (int)n4 / 2 - TextRenderer.getWidth(s) / 2, n2 + 95, Color.WHITE.getRGB());
/* 107 */       int n5 = n2 + 120;
/* 108 */       a(drawContext, n + 15, n5, 80, 45, "PING", "" + playerListEntry.method_2959() + "ms", a(playerListEntry.method_2959(), n3), color3, n3);
/*     */       
/* 110 */       if (playerListEntry != null) {
/* 111 */         s2 = "PLAYER";
/*     */       } else {
/* 113 */         s2 = "BOT";
/*     */       } 
/*     */       
/* 116 */       if (playerListEntry != null) {
/* 117 */         color4 = new Color(100, 255, 100, (int)(255.0F * n3));
/*     */       } else {
/* 119 */         color4 = new Color(255, 100, 100, (int)(255.0F * n3));
/*     */       } 
/* 121 */       a(drawContext, n + 100 + 5, n5, 80, 45, "TYPE", s2, color4, color3, n3);
/* 122 */       if (playerEntity.field_6235 > 0) {
/* 123 */         a(drawContext, n + 200 + 5, n5, 80, 45, "HURT", "" + playerEntity.field_6235, b(playerEntity.field_6235, n3), color3, n3);
/*     */       } else {
/* 125 */         a(drawContext, n + 200 + 5, n5, 80, 45, "HURT", "No", new Color(150, 150, 150, (int)(255.0F * n3)), color3, n3);
/*     */       } 
/*     */     } else {
/* 128 */       TextRenderer.drawString("BOT DETECTED", drawContext, n + 150 - TextRenderer.getWidth("BOT DETECTED") / 2, n2 + 90, (new Color(255, 50, 50)).getRGB());
/*     */     } 
/*     */   }
/*     */   
/*     */   private void a(class_332 drawContext, int n, int n2, int n3, int n4, String s, String s2, Color color, Color color2, float n5) {
/* 133 */     class_4587 matrices = drawContext.method_51448();
/* 134 */     RenderUtils.renderRoundedQuad(matrices, color2, n, n2, (n + n3), (n2 + 3), 3.0D, 3.0D, 0.0D, 0.0D, 6.0D);
/* 135 */     RenderUtils.renderRoundedQuad(matrices, new Color(30, 30, 30, (int)(200.0F * n5)), n, (n2 + 3), (n + n3), (n2 + n4), 0.0D, 0.0D, 3.0D, 3.0D, 6.0D);
/* 136 */     TextRenderer.drawString(s, drawContext, n + n3 / 2 - TextRenderer.getWidth(s) / 2, n2 + 5, (new Color(200, 200, 200, (int)(255.0F * n5))).getRGB());
/* 137 */     TextRenderer.drawString(s2, drawContext, n + n3 / 2 - TextRenderer.getWidth(s2) / 2, n2 + n4 - 17, color.getRGB());
/*     */   }
/*     */   
/*     */   private Color a(float n, float n2) {
/*     */     Color color;
/* 142 */     if (n > 0.75F) {
/* 143 */       color = ColorUtil.a(new Color(100, 255, 100), new Color(255, 255, 100), (1.0F - n) * 4.0F);
/* 144 */     } else if (n > 0.25F) {
/* 145 */       color = ColorUtil.a(new Color(255, 255, 100), new Color(255, 100, 100), (0.75F - n) * 2.0F);
/*     */     } else {
/*     */       float n3;
/* 148 */       if (n < 0.1F) {
/* 149 */         n3 = (float)(0.699999988079071D + 0.30000001192092896D * Math.sin(System.currentTimeMillis() / 200.0D));
/*     */       } else {
/* 151 */         n3 = 1.0F;
/*     */       } 
/* 153 */       color = new Color((int)(255.0F * n3), (int)(100.0F * n3), (int)(100.0F * n3));
/*     */     } 
/* 155 */     return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(color.getAlpha() * n2));
/*     */   }
/*     */   
/*     */   private Color a(int n, float n2) {
/*     */     Color color;
/* 160 */     if (n < 50) {
/* 161 */       color = new Color(100, 255, 100);
/* 162 */     } else if (n < 100) {
/* 163 */       color = ColorUtil.a(new Color(100, 255, 100), new Color(255, 255, 100), (n - 50) / 50.0F);
/* 164 */     } else if (n < 200) {
/* 165 */       color = ColorUtil.a(new Color(255, 255, 100), new Color(255, 150, 50), (n - 100) / 100.0F);
/*     */     } else {
/* 167 */       color = ColorUtil.a(new Color(255, 150, 50), new Color(255, 80, 80), Math.min(1.0F, (n - 200) / 300.0F));
/*     */     } 
/* 169 */     return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(color.getAlpha() * n2));
/*     */   }
/*     */   
/*     */   private Color b(int n, float n2) {
/* 173 */     double n3 = 0.699999988079071D + 0.30000001192092896D * Math.sin(System.currentTimeMillis() / 150.0D);
/* 174 */     float min = Math.min(1.0F, n / 10.0F);
/* 175 */     Color color = new Color(255, (int)(50.0F + 100.0F * (1.0F - min)), (int)(50.0F + 100.0F * (1.0F - min)));
/* 176 */     return new Color((int)(color.getRed() * (float)n3), (int)(color.getGreen() * (float)n3), (int)(color.getBlue() * (float)n3), (int)(255.0F * n2));
/*     */   }
/*     */   
/*     */   private void renderInfoBox(class_332 drawContext, int xPos, int yPos, int width, int height, String title, String value, Color color, Color borderColor, float fadeAmount) {
/* 180 */     class_4587 matrices = drawContext.method_51448();
/* 181 */     RenderUtils.renderRoundedQuad(matrices, borderColor, xPos, yPos, (xPos + width), (yPos + 3), 3.0D, 3.0D, 0.0D, 0.0D, 6.0D);
/* 182 */     RenderUtils.renderRoundedQuad(matrices, new Color(30, 30, 30, (int)(200.0F * fadeAmount)), xPos, (yPos + 3), (xPos + width), (yPos + height), 0.0D, 0.0D, 3.0D, 3.0D, 6.0D);
/* 183 */     TextRenderer.drawString(title, drawContext, xPos + width / 2 - TextRenderer.getWidth(title) / 2, yPos + 5, (new Color(200, 200, 200, (int)(255.0F * fadeAmount))).getRGB());
/* 184 */     TextRenderer.drawString(value, drawContext, xPos + width / 2 - TextRenderer.getWidth(value) / 2, yPos + height - 17, color.getRGB());
/*     */   }
/*     */   
/*     */   private Color getHealthColor(float healthPercent, float fadeAmount) {
/*     */     Color color;
/* 189 */     if (healthPercent > 0.75F) {
/* 190 */       color = ColorUtil.a(new Color(100, 255, 100), new Color(255, 255, 100), (1.0F - healthPercent) * 4.0F);
/* 191 */     } else if (healthPercent > 0.25F) {
/* 192 */       color = ColorUtil.a(new Color(255, 255, 100), new Color(255, 100, 100), (0.75F - healthPercent) * 2.0F);
/*     */     } else {
/*     */       float pulseIntensity;
/* 195 */       if (healthPercent < 0.1F) {
/* 196 */         pulseIntensity = (float)(0.699999988079071D + 0.30000001192092896D * Math.sin(System.currentTimeMillis() / 200.0D));
/*     */       } else {
/* 198 */         pulseIntensity = 1.0F;
/*     */       } 
/* 200 */       color = new Color((int)(255.0F * pulseIntensity), (int)(100.0F * pulseIntensity), (int)(100.0F * pulseIntensity));
/*     */     } 
/* 202 */     return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(color.getAlpha() * fadeAmount));
/*     */   }
/*     */   
/*     */   private Color getPingColor(int ping, float fadeAmount) {
/*     */     Color color;
/* 207 */     if (ping < 50) {
/* 208 */       color = new Color(100, 255, 100);
/* 209 */     } else if (ping < 100) {
/* 210 */       color = ColorUtil.a(new Color(100, 255, 100), new Color(255, 255, 100), (ping - 50) / 50.0F);
/* 211 */     } else if (ping < 200) {
/* 212 */       color = ColorUtil.a(new Color(255, 255, 100), new Color(255, 150, 50), (ping - 100) / 100.0F);
/*     */     } else {
/* 214 */       color = ColorUtil.a(new Color(255, 150, 50), new Color(255, 80, 80), Math.min(1.0F, (ping - 200) / 300.0F));
/*     */     } 
/* 216 */     return new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)(color.getAlpha() * fadeAmount));
/*     */   }
/*     */   
/*     */   private Color getHurtColor(int hurtTime, float fadeAmount) {
/* 220 */     double pulseIntensity = 0.699999988079071D + 0.30000001192092896D * Math.sin(System.currentTimeMillis() / 150.0D);
/* 221 */     float hurtIntensity = Math.min(1.0F, hurtTime / 10.0F);
/* 222 */     Color color = new Color(255, (int)(50.0F + 100.0F * (1.0F - hurtIntensity)), (int)(50.0F + 100.0F * (1.0F - hurtIntensity)));
/* 223 */     return new Color((int)(color.getRed() * (float)pulseIntensity), (int)(color.getGreen() * (float)pulseIntensity), (int)(color.getBlue() * (float)pulseIntensity), (int)(255.0F * fadeAmount));
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onPacketSend(PacketSendEvent packetEvent) {
/* 228 */     class_2596 class_2596 = packetEvent.getPacket(); if (class_2596 instanceof class_2824) { class_2824 playerInteractEntityC2SPacket = (class_2824)class_2596;
/* 229 */       if (this.hudHandler == null) {
/* 230 */         this.hudHandler = new TargetHUDHandler(this);
/*     */       }
/* 232 */       if (this.hudHandler.isAttackPacket(playerInteractEntityC2SPacket))
/* 233 */         this.lastAttackTime = System.currentTimeMillis();  }
/*     */   
/*     */   }
/*     */   
/*     */   public static class TargetHUDHandler
/*     */   {
/* 239 */     public static final class_310 MC = class_310.method_1551();
/*     */     final TargetHUD this$0;
/*     */     
/*     */     TargetHUDHandler(TargetHUD this$0) {
/* 243 */       this.this$0 = this$0;
/*     */     }
/*     */     
/*     */     public boolean isAttackPacket(class_2824 playerInteractEntityC2SPacket) {
/*     */       String string;
/*     */       try {
/* 249 */         string = playerInteractEntityC2SPacket.toString();
/* 250 */         if (string.contains("ATTACK")) {
/* 251 */           return true;
/*     */         }
/* 253 */       } catch (Exception ex) {
/* 254 */         return (MC.field_1724 != null && MC.field_1724.method_6052() != null && MC.field_1724.method_6052() instanceof class_1657);
/*     */       } 
/*     */       try {
/* 257 */         if (MC.field_1724 == null || MC.field_1724.method_6052() == null || !(MC.field_1724.method_6052() instanceof class_1657)) {
/* 258 */           return false;
/*     */         }
/* 260 */         boolean contains = string.contains(class_1268.field_5808.toString());
/* 261 */         boolean contains2 = string.contains("INTERACT_AT");
/* 262 */         if (contains && contains2) {
/* 263 */           return true;
/*     */         }
/* 265 */       } catch (Exception ex2) {
/* 266 */         return (MC.field_1724 != null && MC.field_1724.method_6052() != null && MC.field_1724.method_6052() instanceof class_1657);
/*     */       } 
/*     */       try {
/* 269 */         return (MC.field_1724.field_6252 && MC.field_1724.method_6052() != null);
/* 270 */       } catch (Exception exception) {
/*     */         
/* 272 */         return (MC.field_1724 != null && MC.field_1724.method_6052() != null && MC.field_1724.method_6052() instanceof class_1657);
/*     */       } 
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\TargetHUD.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */