/*     */ package dev.FORE.module.modules.render;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.module.setting.StringSetting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.PingUtil;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2583;
/*     */ import net.minecraft.class_266;
/*     */ import net.minecraft.class_269;
/*     */ import net.minecraft.class_274;
/*     */ import net.minecraft.class_5250;
/*     */ import net.minecraft.class_5251;
/*     */ import net.minecraft.class_8646;
/*     */ import net.minecraft.class_9014;
/*     */ import net.minecraft.class_9015;
/*     */ 
/*     */ public final class ScoreboardModule extends Module {
/*     */   private static final String OBJECTIVE_NAME = "fore_scoreboard";
/*     */   private class_266 customObjective;
/*  26 */   private final StringSetting Money = new StringSetting((CharSequence)EncryptedString.of("Money"), "61M"); private class_266 originalObjective; private boolean wasEnabled = false;
/*  27 */   private final StringSetting Shards = new StringSetting((CharSequence)EncryptedString.of("Shards"), "61");
/*  28 */   private final StringSetting Kills = new StringSetting((CharSequence)EncryptedString.of("Kills"), "61");
/*  29 */   private final StringSetting Deaths = new StringSetting((CharSequence)EncryptedString.of("Deaths"), "61");
/*  30 */   private final StringSetting Keyall = new StringSetting((CharSequence)EncryptedString.of("Key All"), "6m 1s");
/*  31 */   private final StringSetting Playtime = new StringSetting((CharSequence)EncryptedString.of("Playtime"), "6h 1m");
/*  32 */   private final StringSetting Team = new StringSetting((CharSequence)EncryptedString.of("Team"), "4E Team");
/*  33 */   private final StringSetting Title = new StringSetting((CharSequence)EncryptedString.of("Title"), "Protected by 4E");
/*  34 */   private final StringSetting Region = new StringSetting((CharSequence)EncryptedString.of("Region"), "Protected by 4E");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private final Boolean enabled = Boolean.valueOf(true);
/*     */ 
/*     */   
/*     */   public ScoreboardModule() {
/*  45 */     super((CharSequence)EncryptedString.of("Fake Stats"), (CharSequence)EncryptedString.of("Custom scoreboard overlay"), -1, Category.RENDER);
/*  46 */     addsettings(new Setting[] { (Setting)this.Money, (Setting)this.Shards, (Setting)this.Kills, (Setting)this.Deaths, (Setting)this.Keyall, (Setting)this.Playtime, (Setting)this.Team, (Setting)this.Title, (Setting)this.Region });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  51 */     super.onEnable();
/*  52 */     this.wasEnabled = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  57 */     super.onDisable();
/*  58 */     restoreOriginalScoreboard();
/*  59 */     this.wasEnabled = false;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  64 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null)
/*     */       return; 
/*  66 */     if (this.enabled.booleanValue() && isEnabled()) {
/*  67 */       updateCustomScoreboard();
/*  68 */     } else if (this.wasEnabled) {
/*  69 */       restoreOriginalScoreboard();
/*  70 */       this.wasEnabled = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateCustomScoreboard() {
/*  75 */     class_269 scoreboard = this.mc.field_1687.method_8428();
/*     */ 
/*     */     
/*  78 */     if (this.originalObjective == null) {
/*  79 */       this.originalObjective = scoreboard.method_1189(class_8646.field_45157);
/*     */     }
/*     */ 
/*     */     
/*  83 */     if (this.customObjective == null) {
/*     */       
/*  85 */       class_266 existing = scoreboard.method_1170("fore_scoreboard");
/*  86 */       if (existing != null) {
/*  87 */         scoreboard.method_1194(existing);
/*     */       }
/*     */       
/*  90 */       this.customObjective = scoreboard.method_1168("fore_scoreboard", class_274.field_1468, 
/*     */ 
/*     */           
/*  93 */           parseGradientText("  Protected by 4E  ", "#007CF9", "#00C6F9"), class_274.class_275.field_1472, true, null);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     scoreboard.method_1158(class_8646.field_45157, this.customObjective);
/*     */ 
/*     */     
/* 104 */     scoreboard.method_1194(this.customObjective);
/* 105 */     this.customObjective = scoreboard.method_1168("fore_scoreboard", class_274.field_1468, 
/*     */ 
/*     */         
/* 108 */         parseGradientText("  Protected by 4E  ", "#007CF9", "#00C6F9"), class_274.class_275.field_1472, true, null);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 113 */     scoreboard.method_1158(class_8646.field_45157, this.customObjective);
/*     */ 
/*     */     
/* 116 */     List<class_2561> lines = getScoreboardLines();
/* 117 */     for (int i = 0; i < lines.size(); i++) {
/* 118 */       class_2561 lineText = lines.get(i);
/*     */       
/* 120 */       String invisibleId = "§" + i + "§r";
/* 121 */       class_9015 holder = class_9015.method_55422(invisibleId);
/*     */       
/* 123 */       class_9014 score = scoreboard.method_1180(holder, this.customObjective);
/* 124 */       score.method_55410(lines.size() - i);
/* 125 */       score.method_55411(lineText);
/*     */     } 
/*     */     
/* 128 */     String Formatedtitle = "   " + this.Title.getValue() + "   ";
/*     */ 
/*     */ 
/*     */     
/* 132 */     this.customObjective.method_1121(parseGradientText(Formatedtitle, "#007CF9", "#00C6F9"));
/*     */   }
/*     */   
/*     */   private List<class_2561> getScoreboardLines() {
/* 136 */     List<class_2561> lines = new ArrayList<>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 142 */     lines.add(class_2561.method_43470(" "));
/*     */ 
/*     */     
/* 145 */     lines.add(class_2561.method_43470("")
/* 146 */         .method_10852((class_2561)class_2561.method_43470("$ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(64512)).method_10982(Boolean.valueOf(true))))
/* 147 */         .method_10852((class_2561)class_2561.method_43470("Money ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215))))
/* 148 */         .method_10852((class_2561)class_2561.method_43470(this.Money.getValue()).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(64512)))));
/*     */ 
/*     */     
/* 151 */     lines.add(class_2561.method_43470("")
/* 152 */         .method_10852((class_2561)class_2561.method_43470("★ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(10683385))))
/* 153 */         .method_10852((class_2561)class_2561.method_43470("Shards ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215))))
/* 154 */         .method_10852((class_2561)class_2561.method_43470(this.Shards.getValue()).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(10683385)))));
/*     */ 
/*     */     
/* 157 */     lines.add(class_2561.method_43470("")
/* 158 */         .method_10852((class_2561)class_2561.method_43470("🗡 ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16515072))))
/* 159 */         .method_10852((class_2561)class_2561.method_43470("Kills ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215))))
/* 160 */         .method_10852((class_2561)class_2561.method_43470(this.Kills.getValue()).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16515072)))));
/*     */ 
/*     */     
/* 163 */     lines.add(class_2561.method_43470("")
/* 164 */         .method_10852((class_2561)class_2561.method_43470("☠ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16348675))))
/* 165 */         .method_10852((class_2561)class_2561.method_43470("Deaths ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215))))
/* 166 */         .method_10852((class_2561)class_2561.method_43470(this.Deaths.getValue()).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16348675)))));
/*     */ 
/*     */     
/* 169 */     lines.add(class_2561.method_43470("")
/* 170 */         .method_10852((class_2561)class_2561.method_43470("⌛ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236))))
/* 171 */         .method_10852((class_2561)class_2561.method_43470("Keyall ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215))))
/* 172 */         .method_10852((class_2561)class_2561.method_43470(this.Keyall.getValue()).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236)))));
/*     */ 
/*     */     
/* 175 */     lines.add(class_2561.method_43470("")
/* 176 */         .method_10852((class_2561)class_2561.method_43470("⌚ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16573184))))
/* 177 */         .method_10852((class_2561)class_2561.method_43470("Playtime ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215))))
/* 178 */         .method_10852((class_2561)class_2561.method_43470(this.Playtime.getValue()).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16573184)))));
/*     */     
/* 180 */     lines.add(class_2561.method_43470("")
/* 181 */         .method_10852((class_2561)class_2561.method_43470("🪓 ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236))))
/* 182 */         .method_10852((class_2561)class_2561.method_43470("Team ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(16777215))))
/* 183 */         .method_10852((class_2561)class_2561.method_43470(this.Team.getValue()).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236)))));
/*     */     
/* 185 */     lines.add(class_2561.method_43470(" "));
/*     */ 
/*     */     
/* 188 */     lines.add(class_2561.method_43470("")
/* 189 */         .method_10852((class_2561)class_2561.method_43470(this.Region.getValue() + " (").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(11053224))))
/* 190 */         .method_10852((class_2561)class_2561.method_43470(PingUtil.getPingString().toString()).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(42236))))
/* 191 */         .method_10852((class_2561)class_2561.method_43470(")").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(11053224)))));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 196 */     return lines;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void restoreOriginalScoreboard() {
/* 202 */     if (this.mc.field_1687 == null)
/*     */       return; 
/* 204 */     class_269 scoreboard = this.mc.field_1687.method_8428();
/*     */ 
/*     */     
/* 207 */     if (this.customObjective != null) {
/* 208 */       scoreboard.method_1194(this.customObjective);
/* 209 */       this.customObjective = null;
/*     */     } 
/*     */ 
/*     */     
/* 213 */     if (this.originalObjective != null) {
/* 214 */       scoreboard.method_1158(class_8646.field_45157, this.originalObjective);
/* 215 */       this.originalObjective = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   private class_2561 parseGradientText(String text, String startHex, String endHex) {
/* 220 */     if (text.isEmpty()) return (class_2561)class_2561.method_43470("");
/*     */     
/* 222 */     Color startColor = Color.decode(startHex);
/* 223 */     Color endColor = Color.decode(endHex);
/*     */     
/* 225 */     class_5250 result = class_2561.method_43470("");
/*     */     
/* 227 */     for (int i = 0; i < text.length(); i++) {
/* 228 */       float progress = (text.length() > 1) ? (i / (text.length() - 1)) : 0.0F;
/* 229 */       Color interpolated = ColorUtil.a(startColor, endColor, progress);
/*     */       
/* 231 */       int rgb = interpolated.getRed() << 16 | interpolated.getGreen() << 8 | interpolated.getBlue();
/*     */       
/* 233 */       result.method_10852((class_2561)class_2561.method_43470(String.valueOf(text.charAt(i)))
/* 234 */           .method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(rgb)).method_10982(Boolean.valueOf(true))));
/*     */     } 
/*     */     
/* 237 */     return (class_2561)result;
/*     */   }
/*     */   
/*     */   private String formatColoredText(String text, String hex) {
/* 241 */     Color color = Color.decode(hex);
/* 242 */     StringBuilder result = new StringBuilder();
/*     */     
/* 244 */     for (int i = 0; i < text.length(); i++) {
/* 245 */       result.append(formatMinecraftColor(color));
/* 246 */       result.append(text.charAt(i));
/*     */     } 
/*     */     
/* 249 */     return result.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   private String formatMinecraftColor(Color color) {
/* 254 */     String hex = String.format("%02x%02x%02x", new Object[] { Integer.valueOf(color.getRed()), Integer.valueOf(color.getGreen()), Integer.valueOf(color.getBlue()) });
/* 255 */     StringBuilder result = new StringBuilder("§x");
/* 256 */     for (char c : hex.toCharArray()) {
/* 257 */       result.append("§").append(c);
/*     */     }
/* 259 */     return result.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\ScoreboardModule.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */