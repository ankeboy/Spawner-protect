/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.ChunkDataEvent;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.BlockUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import java.awt.Color;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import java.util.concurrent.ExecutorService;
/*     */ import java.util.concurrent.Executors;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_2741;
/*     */ import net.minecraft.class_2769;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_2826;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ public final class SuspiciousEsp
/*     */   extends Module
/*     */ {
/*     */   public static SuspiciousEsp instance;
/*  40 */   private final BooleanSetting wanderingTraders = new BooleanSetting((CharSequence)EncryptedString.of("Wandering Traders"), true);
/*  41 */   private final BooleanSetting villagers = new BooleanSetting((CharSequence)EncryptedString.of("Villagers"), true);
/*  42 */   private final BooleanSetting llamas = new BooleanSetting((CharSequence)EncryptedString.of("Llamas"), true);
/*  43 */   private final BooleanSetting pillagers = new BooleanSetting((CharSequence)EncryptedString.of("Pillagers"), true);
/*  44 */   private final BooleanSetting deepslate = new BooleanSetting((CharSequence)EncryptedString.of("Deepslate"), true);
/*  45 */   private final BooleanSetting kelp = new BooleanSetting((CharSequence)EncryptedString.of("Kelp"), true);
/*     */   
/*  47 */   private final NumberSetting deepslateMinY = new NumberSetting((CharSequence)EncryptedString.of("Deepslate Min Y"), -64.0D, 320.0D, 8.0D, 1.0D);
/*  48 */   private final NumberSetting deepslateMaxY = new NumberSetting((CharSequence)EncryptedString.of("Deepslate Max Y"), -64.0D, 320.0D, 128.0D, 1.0D);
/*     */   
/*  50 */   private final NumberSetting alpha = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 1.0D, 255.0D, 100.0D, 1.0D);
/*  51 */   private final BooleanSetting tracers = new BooleanSetting((CharSequence)EncryptedString.of("Tracers"), false);
/*     */   
/*  53 */   private final ConcurrentHashMap<Long, Set<class_2338>> cachedDeepslate = new ConcurrentHashMap<>();
/*  54 */   private final ConcurrentHashMap<Long, Set<class_2338>> cachedKelp = new ConcurrentHashMap<>();
/*  55 */   private final ExecutorService executor = Executors.newFixedThreadPool(3);
/*  56 */   private final Set<Long> scanningChunks = ConcurrentHashMap.newKeySet();
/*     */   private volatile boolean needsRescan = false;
/*  58 */   private int tickCounter = 0;
/*     */   
/*     */   public SuspiciousEsp() {
/*  61 */     super((CharSequence)EncryptedString.of("Suspicious Esp"), (CharSequence)EncryptedString.of("Highlights suspicious structures and entities"), -1, Category.RENDER);
/*  62 */     addsettings(new Setting[] { (Setting)this.wanderingTraders, (Setting)this.villagers, (Setting)this.llamas, (Setting)this.pillagers, (Setting)this.deepslate, (Setting)this.kelp, (Setting)this.deepslateMinY, (Setting)this.deepslateMaxY, (Setting)this.alpha, (Setting)this.tracers });
/*     */ 
/*     */     
/*  65 */     instance = this;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  70 */     super.onEnable();
/*  71 */     this.cachedDeepslate.clear();
/*  72 */     this.cachedKelp.clear();
/*  73 */     this.scanningChunks.clear();
/*  74 */     this.needsRescan = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  79 */     super.onDisable();
/*  80 */     this.cachedDeepslate.clear();
/*  81 */     this.cachedKelp.clear();
/*  82 */     this.scanningChunks.clear();
/*     */   }
/*     */   
/*     */   public static SuspiciousEsp getInstance() {
/*  86 */     if (instance == null) {
/*  87 */       instance = new SuspiciousEsp();
/*     */     }
/*  89 */     return instance;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  94 */     if (this.mc.field_1687 == null)
/*     */       return; 
/*  96 */     this.tickCounter++;
/*     */ 
/*     */     
/*  99 */     if (this.needsRescan || this.tickCounter % 100 == 0) {
/* 100 */       this.needsRescan = false;
/* 101 */       scanAllChunks();
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onChunkData(ChunkDataEvent event) {
/* 107 */     if (event.getChunk() instanceof class_2818) {
/* 108 */       scanChunk((class_2818)event.getChunk());
/*     */     }
/*     */   }
/*     */   
/*     */   private void scanAllChunks() {
/* 113 */     if (this.mc.field_1687 == null)
/*     */       return; 
/* 115 */     for (class_2818 chunk : BlockUtil.getLoadedChunks().toList()) {
/* 116 */       scanChunk(chunk);
/*     */     }
/*     */   }
/*     */   
/*     */   private void scanChunk(class_2818 chunk) {
/* 121 */     if (chunk == null || (!this.deepslate.getValue() && !this.kelp.getValue()))
/*     */       return; 
/* 123 */     long chunkKey = chunk.method_12004().method_8324();
/*     */     
/* 125 */     if (!this.scanningChunks.add(Long.valueOf(chunkKey))) {
/*     */       return;
/*     */     }
/*     */     
/* 129 */     this.executor.submit(() -> {
/*     */           try {
/*     */             Set<class_2338> foundDeepslate = ConcurrentHashMap.newKeySet();
/*     */             
/*     */             Set<class_2338> foundKelp = ConcurrentHashMap.newKeySet();
/*     */             
/*     */             class_1923 chunkPos = chunk.method_12004();
/*     */             
/*     */             int startX = chunkPos.method_8326();
/*     */             
/*     */             int startZ = chunkPos.method_8328();
/*     */             
/*     */             class_2826[] sections = chunk.method_12006();
/*     */             
/*     */             int minSection = this.mc.field_1687.method_32891();
/*     */             
/*     */             int minY = this.deepslateMinY.getIntValue();
/*     */             
/*     */             int maxY = this.deepslateMaxY.getIntValue();
/*     */             
/*     */             for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
/*     */               class_2826 section = sections[sectionIndex];
/*     */               
/*     */               if (section != null && !section.method_38292()) {
/*     */                 int sectionY = (minSection + sectionIndex) * 16;
/*     */                 
/*     */                 for (int x = 0; x < 16; x++) {
/*     */                   for (int z = 0; z < 16; z++) {
/*     */                     for (int y = 0; y < 16; y++) {
/*     */                       class_2680 state = section.method_12254(x, y, z);
/*     */                       
/*     */                       class_2338 pos = new class_2338(startX + x, sectionY + y, startZ + z);
/*     */                       
/*     */                       if (this.deepslate.getValue() && pos.method_10264() >= minY && pos.method_10264() <= maxY && isRotatedDeepslate(state)) {
/*     */                         foundDeepslate.add(pos);
/*     */                       }
/*     */                       
/*     */                       if (this.kelp.getValue() && (state.method_26204() instanceof net.minecraft.class_2393 || state.method_26204() instanceof net.minecraft.class_2391) && isFullHeightKelp(chunk, pos)) {
/*     */                         foundKelp.add(pos);
/*     */                       }
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */             
/*     */             if (foundDeepslate.isEmpty()) {
/*     */               this.cachedDeepslate.remove(Long.valueOf(chunkKey));
/*     */             } else {
/*     */               this.cachedDeepslate.put(Long.valueOf(chunkKey), foundDeepslate);
/*     */             } 
/*     */             
/*     */             if (foundKelp.isEmpty()) {
/*     */               this.cachedKelp.remove(Long.valueOf(chunkKey));
/*     */             } else {
/*     */               this.cachedKelp.put(Long.valueOf(chunkKey), foundKelp);
/*     */             } 
/* 186 */           } catch (Exception exception) {
/*     */           
/*     */           } finally {
/*     */             this.scanningChunks.remove(Long.valueOf(chunkKey));
/*     */           } 
/*     */         });
/*     */   }
/*     */   
/*     */   private boolean isRotatedDeepslate(class_2680 state) {
/* 195 */     if (state.method_26204() == class_2246.field_28888) {
/*     */       
/*     */       try {
/* 198 */         if (state.method_28501().stream().anyMatch(prop -> prop.method_11899().equals("axis"))) {
/* 199 */           String axis = ((class_2350.class_2351)state.method_11654((class_2769)class_2741.field_12496)).toString();
/* 200 */           return !axis.equals("y");
/*     */         } 
/* 202 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */     
/* 206 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isFullHeightKelp(class_2818 chunk, class_2338 startPos) {
/* 211 */     class_2338.class_2339 pos = startPos.method_25503();
/*     */     
/* 213 */     for (int i = 0; i < 64; ) {
/* 214 */       pos.method_10100(0, 1, 0);
/* 215 */       class_2680 aboveState = chunk.method_8320((class_2338)pos);
/*     */ 
/*     */       
/* 218 */       if (aboveState.method_26215()) {
/* 219 */         class_2680 belowAir = chunk.method_8320(pos.method_10074());
/* 220 */         return (belowAir.method_26204() == class_2246.field_10382);
/*     */       } 
/*     */ 
/*     */       
/* 224 */       if (aboveState.method_26204() instanceof net.minecraft.class_2393 || aboveState.method_26204() instanceof net.minecraft.class_2391) {
/*     */         i++;
/*     */         
/*     */         continue;
/*     */       } 
/* 229 */       if (aboveState.method_26204() == class_2246.field_10382) {
/* 230 */         return true;
/*     */       }
/*     */ 
/*     */       
/* 234 */       return false;
/*     */     } 
/*     */     
/* 237 */     return false;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent event) {
/* 242 */     if (this.mc.field_1687 == null)
/*     */       return; 
/* 244 */     class_4184 cam = RenderUtils.getCamera();
/* 245 */     if (cam == null)
/*     */       return; 
/* 247 */     class_243 camPos = RenderUtils.getCameraPos();
/* 248 */     class_4587 matrices = event.matrixStack;
/*     */     
/* 250 */     matrices.method_22903();
/* 251 */     matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
/* 252 */     matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
/* 253 */     matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*     */     
/* 255 */     int alphaValue = this.alpha.getIntValue();
/*     */ 
/*     */     
/* 258 */     if (this.wanderingTraders.getValue() || this.villagers.getValue() || this.llamas.getValue() || this.pillagers.getValue()) {
/* 259 */       for (class_1297 entity : this.mc.field_1687.method_18112()) {
/* 260 */         if (entity == null)
/*     */           continue; 
/* 262 */         boolean shouldRender = false;
/* 263 */         Color entityColor = Color.WHITE;
/*     */         
/* 265 */         if (this.wanderingTraders.getValue() && entity instanceof net.minecraft.class_3989) {
/* 266 */           shouldRender = true;
/* 267 */           entityColor = new Color(0, 255, 255, alphaValue);
/* 268 */         } else if (this.villagers.getValue() && entity instanceof net.minecraft.class_1646) {
/* 269 */           shouldRender = true;
/* 270 */           entityColor = new Color(0, 255, 0, alphaValue);
/* 271 */         } else if (this.llamas.getValue() && entity instanceof net.minecraft.class_1501) {
/* 272 */           shouldRender = true;
/* 273 */           entityColor = new Color(255, 255, 0, alphaValue);
/* 274 */         } else if (this.pillagers.getValue() && entity instanceof net.minecraft.class_1604) {
/* 275 */           shouldRender = true;
/* 276 */           entityColor = new Color(255, 0, 0, alphaValue);
/*     */         } 
/*     */         
/* 279 */         if (shouldRender) {
/* 280 */           double distSq = this.mc.field_1724.method_5649(entity.method_23317(), entity.method_23318(), entity.method_23321());
/* 281 */           if (distSq > 10000.0D)
/*     */             continue; 
/* 283 */           class_238 box = entity.method_5829();
/* 284 */           RenderUtils.renderFilledBox(matrices, 
/*     */               
/* 286 */               (float)(box.field_1323 - entity.method_23317() + entity.method_23317()), 
/* 287 */               (float)(box.field_1322 - entity.method_23318() + entity.method_23318()), 
/* 288 */               (float)(box.field_1321 - entity.method_23321() + entity.method_23321()), 
/* 289 */               (float)(box.field_1320 - entity.method_23317() + entity.method_23317()), 
/* 290 */               (float)(box.field_1325 - entity.method_23318() + entity.method_23318()), 
/* 291 */               (float)(box.field_1324 - entity.method_23321() + entity.method_23321()), entityColor);
/*     */ 
/*     */ 
/*     */           
/* 295 */           if (this.tracers.getValue() && this.mc.field_1765 != null) {
/* 296 */             RenderUtils.renderLine(matrices, new Color(entityColor
/*     */                   
/* 298 */                   .getRed(), entityColor.getGreen(), entityColor.getBlue(), 255), this.mc.field_1765
/* 299 */                 .method_17784(), entity
/* 300 */                 .method_19538());
/*     */           }
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 308 */     if (this.deepslate.getValue()) {
/* 309 */       Color deepslateColor = new Color(128, 128, 128, alphaValue);
/* 310 */       renderBlockCache(matrices, this.cachedDeepslate, deepslateColor);
/*     */     } 
/*     */ 
/*     */     
/* 314 */     if (this.kelp.getValue()) {
/* 315 */       Color kelpColor = new Color(0, 200, 100, alphaValue);
/* 316 */       renderBlockCache(matrices, this.cachedKelp, kelpColor);
/*     */     } 
/*     */     
/* 319 */     matrices.method_22909();
/*     */   }
/*     */   
/*     */   private void renderBlockCache(class_4587 matrices, ConcurrentHashMap<Long, Set<class_2338>> cache, Color color) {
/* 323 */     for (Set<class_2338> blockSet : cache.values()) {
/* 324 */       if (blockSet == null)
/*     */         continue; 
/* 326 */       for (class_2338 blockPos : blockSet) {
/* 327 */         if (blockPos == null)
/*     */           continue; 
/* 329 */         double distSq = this.mc.field_1724.method_5649(blockPos.method_10263() + 0.5D, blockPos.method_10264() + 0.5D, blockPos.method_10260() + 0.5D);
/* 330 */         if (distSq > 10000.0D)
/*     */           continue; 
/* 332 */         RenderUtils.renderFilledBox(matrices, blockPos
/*     */             
/* 334 */             .method_10263() + 0.1F, blockPos
/* 335 */             .method_10264() + 0.05F, blockPos
/* 336 */             .method_10260() + 0.1F, blockPos
/* 337 */             .method_10263() + 0.9F, blockPos
/* 338 */             .method_10264() + 0.85F, blockPos
/* 339 */             .method_10260() + 0.9F, color);
/*     */ 
/*     */ 
/*     */         
/* 343 */         if (this.tracers.getValue() && this.mc.field_1765 != null)
/* 344 */           RenderUtils.renderLine(matrices, new Color(color
/*     */                 
/* 346 */                 .getRed(), color.getGreen(), color.getBlue(), 255), this.mc.field_1765
/* 347 */               .method_17784(), new class_243(blockPos
/* 348 */                 .method_10263() + 0.5D, blockPos.method_10264() + 0.5D, blockPos.method_10260() + 0.5D)); 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\SuspiciousEsp.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */