/*     */ package dev.FORE.module.modules.render;
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.Render2DEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.TextRenderer;
/*     */ import java.awt.Color;
/*     */ import java.text.SimpleDateFormat;
/*     */ import java.util.Date;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import net.minecraft.class_332;
/*     */ 
/*     */ public final class HUD extends Module {
/*  22 */   private static final CharSequence watermarkText = (CharSequence)EncryptedString.of("4E");
/*  23 */   private static final SimpleDateFormat timeFormatter = new SimpleDateFormat("HH:mm:ss");
/*     */ 
/*     */   
/*  26 */   private static final Color BG_PRIMARY = new Color(18, 18, 22, 165);
/*  27 */   private static final Color BG_SECONDARY = new Color(24, 24, 28, 185);
/*  28 */   private static final Color TEXT_PRIMARY = new Color(245, 245, 250, 240);
/*  29 */   private static final Color TEXT_SECONDARY = new Color(165, 165, 175, 210);
/*  30 */   private static final Color ACCENT_BASE = new Color(99, 102, 241);
/*     */   
/*  32 */   private final Map<Module, Float> moduleAnimations = new HashMap<>();
/*  33 */   private long lastFrameTime = System.currentTimeMillis();
/*  34 */   private float globalRainbowOffset = 0.0F;
/*     */ 
/*     */   
/*  37 */   private final BooleanSetting showWatermark = new BooleanSetting((CharSequence)EncryptedString.of("Watermark"), true);
/*  38 */   private final BooleanSetting showInfo = new BooleanSetting((CharSequence)EncryptedString.of("Info"), true);
/*  39 */   private final BooleanSetting showModules = new BooleanSetting("Modules", true);
/*  40 */   private final BooleanSetting showTime = new BooleanSetting("Time", true);
/*  41 */   private final BooleanSetting showCoordinates = new BooleanSetting("Coordinates", true);
/*  42 */   private final BooleanSetting showCompass = new BooleanSetting("Compass", true);
/*  43 */   private final NumberSetting colorRed = new NumberSetting("Color Red", 0.0D, 255.0D, 255.0D, 1.0D);
/*  44 */   private final NumberSetting colorGreen = new NumberSetting("Color Green", 0.0D, 255.0D, 130.0D, 1.0D);
/*  45 */   private final NumberSetting colorBlue = new NumberSetting("Color Blue", 0.0D, 255.0D, 255.0D, 1.0D);
/*  46 */   private final BooleanSetting rainbow = new BooleanSetting("Rainbow", false);
/*  47 */   private final NumberSetting rainbowSpeed = new NumberSetting("Rainbow Speed", 0.1D, 5.0D, 1.0D, 0.1D);
/*  48 */   private final NumberSetting rainbowSaturation = new NumberSetting("Rainbow Saturation", 0.3D, 1.0D, 0.8D, 0.05D);
/*  49 */   private final NumberSetting rainbowBrightness = new NumberSetting("Rainbow Brightness", 0.5D, 1.0D, 0.95D, 0.05D);
/*  50 */   private final BooleanSetting glow = new BooleanSetting("Glow", true);
/*  51 */   private final BooleanSetting animations = new BooleanSetting("Animations", true);
/*  52 */   private final NumberSetting animationSpeed = new NumberSetting("Animation Speed", 1.0D, 3.0D, 1.0D, 0.1D);
/*     */   
/*     */   public HUD() {
/*  55 */     super((CharSequence)EncryptedString.of("HUD"), (CharSequence)EncryptedString.of("Modern universal HUD"), -1, Category.RENDER);
/*  56 */     addsettings(new Setting[] { (Setting)this.showWatermark, (Setting)this.showInfo, (Setting)this.showModules, (Setting)this.showTime, (Setting)this.showCoordinates, (Setting)this.showCompass, (Setting)this.colorRed, (Setting)this.colorGreen, (Setting)this.colorBlue, (Setting)this.rainbow, (Setting)this.rainbowSpeed, (Setting)this.rainbowSaturation, (Setting)this.rainbowBrightness, (Setting)this.glow, (Setting)this.animations, (Setting)this.animationSpeed });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListener
/*     */   public void onRender2D(Render2DEvent event) {
/*  66 */     if (this.mc.field_1755 != DonutBBC.INSTANCE.GUI) {
/*  67 */       updateAnimations();
/*     */       
/*  69 */       class_332 ctx = event.context;
/*  70 */       int width = this.mc.method_22683().method_4480();
/*  71 */       int height = this.mc.method_22683().method_4507();
/*     */       
/*  73 */       RenderUtils.unscaledProjection();
/*     */       
/*  75 */       if (this.showWatermark.getValue()) {
/*  76 */         renderWatermark(ctx, width);
/*     */       }
/*     */       
/*  79 */       if (this.showInfo.getValue() && this.mc.field_1724 != null) {
/*  80 */         renderInfo(ctx);
/*     */       }
/*     */       
/*  83 */       if (this.showCoordinates.getValue() && this.mc.field_1724 != null) {
/*  84 */         renderCoordinates(ctx, height);
/*     */       }
/*     */       
/*  87 */       if (this.showCompass.getValue() && this.mc.field_1724 != null) {
/*  88 */         renderCompass(ctx, width);
/*     */       }
/*     */       
/*  91 */       if (this.showModules.getValue()) {
/*  92 */         renderModules(ctx, width);
/*     */       }
/*     */       
/*  95 */       RenderUtils.scaledProjection();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateAnimations() {
/* 100 */     long currentTime = System.currentTimeMillis();
/* 101 */     float delta = Math.min((float)(currentTime - this.lastFrameTime) / 16.67F, 3.0F);
/* 102 */     this.lastFrameTime = currentTime;
/*     */ 
/*     */     
/* 105 */     this.globalRainbowOffset = (float)(currentTime * this.rainbowSpeed.getValue() % 360000.0D) / 1000.0F;
/*     */     
/* 107 */     if (this.animations.getValue()) {
/* 108 */       List<Module> enabledModules = DonutBBC.INSTANCE.getModuleManager().b();
/* 109 */       this.moduleAnimations.keySet().removeIf(m -> !enabledModules.contains(m));
/*     */       
/* 111 */       float speed = 0.08F * this.animationSpeed.getFloatValue();
/* 112 */       for (Module module : enabledModules) {
/* 113 */         float current = ((Float)this.moduleAnimations.getOrDefault(module, Float.valueOf(0.0F))).floatValue();
/* 114 */         this.moduleAnimations.put(module, Float.valueOf(Math.min(current + speed * delta, 1.0F)));
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderWatermark(class_332 ctx, int width) {
/* 120 */     String watermark = watermarkText.toString();
/* 121 */     String time = this.showTime.getValue() ? timeFormatter.format(new Date()) : null;
/*     */     
/* 123 */     int y = 16;
/* 124 */     int padding = 14;
/*     */     
/* 126 */     int watermarkWidth = TextRenderer.getWidth(watermark);
/* 127 */     int boxWidth = watermarkWidth + padding * 2;
/* 128 */     int boxHeight = 30;
/* 129 */     int x = width / 2 - boxWidth / 2;
/*     */ 
/*     */     
/* 132 */     Color accentColor = getAccentColor(0.0F);
/* 133 */     renderModernBox(ctx, x, y, boxWidth, boxHeight, accentColor, true);
/*     */     
/* 135 */     Color textColor = this.rainbow.getValue() ? getSyncedRainbowColor(0.2F) : TEXT_PRIMARY;
/* 136 */     drawCenteredText(ctx, watermark, x + boxWidth / 2, y + boxHeight / 2 - 5, textColor);
/*     */ 
/*     */     
/* 139 */     if (time != null) {
/* 140 */       int timeWidth = TextRenderer.getWidth(time);
/* 141 */       int timeBoxWidth = timeWidth + padding * 2;
/* 142 */       int timeBoxHeight = 24;
/* 143 */       int timeX = width / 2 - timeBoxWidth / 2;
/* 144 */       int timeY = y + boxHeight + 8;
/*     */       
/* 146 */       Color timeAccent = getAccentColor(0.15F);
/* 147 */       renderModernBox(ctx, timeX, timeY, timeBoxWidth, timeBoxHeight, timeAccent, false);
/*     */       
/* 149 */       Color timeColor = this.rainbow.getValue() ? getSyncedRainbowColor(0.35F) : TEXT_SECONDARY;
/* 150 */       drawCenteredText(ctx, time, timeX + timeBoxWidth / 2, timeY + timeBoxHeight / 2 - 5, timeColor);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderInfo(class_332 ctx) {
/* 155 */     int x = 16;
/* 156 */     int y = 16;
/* 157 */     int spacing = 8;
/*     */ 
/*     */ 
/*     */     
/* 161 */     String[] infoItems = { "FPS " + this.mc.method_47599(), this.mc.field_1724.method_5477().getString() };
/*     */ 
/*     */     
/* 164 */     for (int i = 0; i < infoItems.length; i++) {
/* 165 */       String item = infoItems[i];
/* 166 */       int textWidth = TextRenderer.getWidth(item);
/* 167 */       int boxWidth = textWidth + 20;
/* 168 */       int boxHeight = 26;
/* 169 */       int currentY = y + (boxHeight + spacing) * i;
/*     */       
/* 171 */       Color accent = getAccentColor(i * 0.1F);
/* 172 */       renderModernBox(ctx, x, currentY, boxWidth, boxHeight, accent, false);
/*     */ 
/*     */       
/* 175 */       Color barColor = this.rainbow.getValue() ? getSyncedRainbowColor(i * 0.1F + 0.05F) : accent;
/* 176 */       RenderUtils.renderRoundedQuad(ctx.method_51448(), barColor, (x + 3), (currentY + 3), (x + 5), (currentY + boxHeight - 3), 1.0D, 1.0D);
/*     */ 
/*     */       
/* 179 */       Color textColor = this.rainbow.getValue() ? getSyncedRainbowColor(i * 0.1F + 0.1F) : TEXT_PRIMARY;
/* 180 */       drawText(ctx, item, x + 10, currentY + boxHeight / 2 - 5, textColor);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderCoordinates(class_332 ctx, int height) {
/* 185 */     if (this.mc.field_1724 == null)
/*     */       return; 
/* 187 */     int x = 16;
/* 188 */     int y = height - 54;
/*     */     
/* 190 */     String coords = String.format("%.0f %.0f %.0f", new Object[] {
/* 191 */           Double.valueOf(this.mc.field_1724.method_23317()), Double.valueOf(this.mc.field_1724.method_23318()), Double.valueOf(this.mc.field_1724.method_23321())
/*     */         });
/* 193 */     String dimension = getDimensionCoords();
/* 194 */     String secondLine = dimension.isEmpty() ? getDimensionName() : dimension;
/*     */     
/* 196 */     int maxWidth = Math.max(TextRenderer.getWidth(coords), TextRenderer.getWidth(secondLine));
/* 197 */     int boxWidth = maxWidth + 24;
/* 198 */     int boxHeight = 42;
/*     */     
/* 200 */     Color accent = getAccentColor(0.5F);
/* 201 */     renderModernBox(ctx, x, y, boxWidth, boxHeight, accent, false);
/*     */ 
/*     */     
/* 204 */     Color iconColor = this.rainbow.getValue() ? getSyncedRainbowColor(0.55F) : accent;
/* 205 */     RenderUtils.renderRoundedQuad(ctx.method_51448(), iconColor, (x + 6), (y + 6), (x + 10), (y + 10), 2.0D, 2.0D);
/*     */ 
/*     */     
/* 208 */     Color coordsColor = this.rainbow.getValue() ? getSyncedRainbowColor(0.6F) : TEXT_PRIMARY;
/* 209 */     Color dimColor = this.rainbow.getValue() ? getSyncedRainbowColor(0.65F) : TEXT_SECONDARY;
/*     */     
/* 211 */     drawText(ctx, coords, x + 14, y + 7, coordsColor);
/* 212 */     drawText(ctx, secondLine, x + 14, y + 25, dimColor);
/*     */   }
/*     */   
/*     */   private void renderCompass(class_332 ctx, int width) {
/* 216 */     if (this.mc.field_1724 == null)
/*     */       return; 
/* 218 */     int compassWidth = 220;
/* 219 */     int compassHeight = 34;
/* 220 */     int x = width / 2 - compassWidth / 2;
/* 221 */     int y = 90;
/*     */     
/* 223 */     Color accent = getAccentColor(0.7F);
/* 224 */     renderModernBox(ctx, x, y, compassWidth, compassHeight, accent, false);
/*     */     
/* 226 */     float yaw = (this.mc.field_1724.method_36454() % 360.0F + 360.0F) % 360.0F;
/* 227 */     String[] directions = { "S", "SW", "W", "NW", "N", "NE", "E", "SE", "S" };
/* 228 */     float[] angles = { 0.0F, 45.0F, 90.0F, 135.0F, 180.0F, 225.0F, 270.0F, 315.0F, 360.0F };
/*     */     
/* 230 */     int centerX = x + compassWidth / 2;
/* 231 */     int centerY = y + compassHeight / 2;
/*     */     
/* 233 */     for (int i = 0; i < directions.length; i++) {
/* 234 */       float angle = angles[i];
/* 235 */       float offset = angle - yaw;
/*     */       
/* 237 */       for (; offset > 180.0F; offset -= 360.0F);
/* 238 */       for (; offset < -180.0F; offset += 360.0F);
/*     */       
/* 240 */       int dirX = centerX - (int)(offset * 1.5F);
/*     */       
/* 242 */       if (dirX >= x + 15 && dirX <= x + compassWidth - 15) {
/*     */         Color dirColor;
/* 244 */         float distance = Math.abs(offset);
/* 245 */         float alpha = Math.max(0.0F, 1.0F - distance / 90.0F);
/* 246 */         boolean isCardinal = (i % 2 == 0);
/*     */ 
/*     */         
/* 249 */         if (this.rainbow.getValue()) {
/* 250 */           dirColor = getSyncedRainbowColor(0.75F + i * 0.03F);
/*     */         }
/* 252 */         else if (distance < 5.0F) {
/* 253 */           dirColor = ACCENT_BASE;
/* 254 */         } else if (isCardinal) {
/* 255 */           dirColor = TEXT_PRIMARY;
/*     */         } else {
/* 257 */           dirColor = TEXT_SECONDARY;
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 265 */         Color finalColor = new Color(dirColor.getRed(), dirColor.getGreen(), dirColor.getBlue(), (int)(dirColor.getAlpha() * alpha));
/*     */ 
/*     */         
/* 268 */         int textWidth = TextRenderer.getWidth(directions[i]);
/* 269 */         int textX = dirX - textWidth / 2;
/* 270 */         int textY = centerY - 5;
/*     */         
/* 272 */         TextRenderer.drawString(directions[i], ctx, textX, textY, finalColor.getRGB());
/*     */         
/* 274 */         if (distance < 2.0F) {
/* 275 */           Color indicatorColor = this.rainbow.getValue() ? getSyncedRainbowColor(0.8F) : accent;
/* 276 */           RenderUtils.renderRoundedQuad(ctx.method_51448(), indicatorColor, (centerX - 1), (y + 5), (centerX + 1), (y + 9), 1.0D, 1.0D);
/*     */           
/* 278 */           RenderUtils.renderRoundedQuad(ctx.method_51448(), indicatorColor, (centerX - 1), (y + compassHeight - 9), (centerX + 1), (y + compassHeight - 5), 1.0D, 1.0D);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderModules(class_332 ctx, int width) {
/* 285 */     List<Module> modules = getSortedModules();
/* 286 */     if (modules.isEmpty())
/*     */       return; 
/* 288 */     int y = 16;
/* 289 */     int rightMargin = 16;
/* 290 */     int spacing = 6;
/*     */     
/* 292 */     for (int i = 0; i < modules.size(); i++) {
/* 293 */       Module module = modules.get(i);
/* 294 */       String name = module.getName().toString();
/*     */       
/* 296 */       float animation = this.animations.getValue() ? ((Float)this.moduleAnimations.getOrDefault(module, Float.valueOf(0.0F))).floatValue() : 1.0F;
/* 297 */       if (animation >= 0.01F) {
/*     */         
/* 299 */         int textWidth = TextRenderer.getWidth(name);
/* 300 */         int padding = 14;
/* 301 */         int boxWidth = (int)((textWidth + padding * 2) * animation);
/* 302 */         int boxHeight = 24;
/* 303 */         int x = width - boxWidth - rightMargin;
/*     */         
/* 305 */         Color accent = getAccentColor(i * 0.05F);
/* 306 */         renderModernBox(ctx, x, y, boxWidth, boxHeight, accent, false);
/*     */ 
/*     */         
/* 309 */         Color textColor = this.rainbow.getValue() ? getSyncedRainbowColor(i * 0.05F + 0.04F) : TEXT_PRIMARY;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 314 */         Color finalTextColor = new Color(textColor.getRed(), textColor.getGreen(), textColor.getBlue(), (int)(textColor.getAlpha() * animation));
/*     */ 
/*     */         
/* 317 */         drawText(ctx, name, x + padding / 2, y + boxHeight / 2 - 5, finalTextColor);
/*     */         
/* 319 */         y += (int)((boxHeight + spacing) * animation);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   private void renderModernBox(class_332 ctx, int x, int y, int width, int height, Color accent, boolean emphasized) {
/* 324 */     int radius = 6;
/*     */ 
/*     */     
/* 327 */     Color bgColor = emphasized ? BG_SECONDARY : BG_PRIMARY;
/* 328 */     RenderUtils.renderRoundedQuad(ctx.method_51448(), bgColor, x, y, (x + width), (y + height), radius, radius);
/*     */ 
/*     */ 
/*     */     
/* 332 */     if (this.glow.getValue()) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 337 */       Color glowColor = new Color(accent.getRed(), accent.getGreen(), accent.getBlue(), emphasized ? 45 : 25);
/*     */       
/* 339 */       RenderUtils.renderRoundedQuad(ctx.method_51448(), glowColor, (x - 2), (y - 2), (x + width + 2), (y + height + 2), (radius + 2), (radius + 2));
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 344 */     Color highlight = new Color(255, 255, 255, emphasized ? 20 : 12);
/* 345 */     RenderUtils.renderRoundedQuad(ctx.method_51448(), highlight, (x + 1), y, (x + width - 1), (y + 1), radius, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   private void drawText(class_332 ctx, String text, int x, int y, Color color) {
/* 350 */     TextRenderer.drawString(text, ctx, x, y, color.getRGB());
/*     */   }
/*     */   
/*     */   private void drawCenteredText(class_332 ctx, String text, int centerX, int y, Color color) {
/* 354 */     int textWidth = TextRenderer.getWidth(text);
/* 355 */     TextRenderer.drawString(text, ctx, centerX - textWidth / 2, y, color.getRGB());
/*     */   }
/*     */   
/*     */   private Color getAccentColor(float offset) {
/* 359 */     if (this.rainbow.getValue()) {
/* 360 */       return getSyncedRainbowColor(offset);
/*     */     }
/* 362 */     return new Color(this.colorRed
/* 363 */         .getIntValue(), this.colorGreen
/* 364 */         .getIntValue(), this.colorBlue
/* 365 */         .getIntValue());
/*     */   }
/*     */ 
/*     */   
/*     */   private Color getSyncedRainbowColor(float offset) {
/* 370 */     float hue = (this.globalRainbowOffset + offset * 360.0F) % 360.0F / 360.0F;
/* 371 */     float saturation = this.rainbowSaturation.getFloatValue();
/* 372 */     float brightness = this.rainbowBrightness.getFloatValue();
/*     */     
/* 374 */     return Color.getHSBColor(hue, saturation, brightness);
/*     */   }
/*     */   
/*     */   private String getDimensionName() {
/* 378 */     if (this.mc.field_1687 == null) return ""; 
/* 379 */     String dimension = this.mc.field_1687.method_27983().method_29177().method_12832();
/* 380 */     return dimension.contains("nether") ? "Nether" : (
/* 381 */       dimension.contains("end") ? "End" : "Overworld");
/*     */   }
/*     */   
/*     */   private String getDimensionCoords() {
/* 385 */     if (this.mc.field_1687 == null) return ""; 
/* 386 */     String dimension = this.mc.field_1687.method_27983().method_29177().method_12832();
/*     */     
/* 388 */     if (dimension.contains("nether"))
/* 389 */       return String.format("OW %.0f %.0f", new Object[] { Double.valueOf(this.mc.field_1724.method_23317() * 8.0D), Double.valueOf(this.mc.field_1724.method_23321() * 8.0D) }); 
/* 390 */     if (dimension.contains("overworld")) {
/* 391 */       return String.format("Nether %.0f %.0f", new Object[] { Double.valueOf(this.mc.field_1724.method_23317() / 8.0D), Double.valueOf(this.mc.field_1724.method_23321() / 8.0D) });
/*     */     }
/* 393 */     return "";
/*     */   }
/*     */   
/*     */   private List<Module> getSortedModules() {
/* 397 */     List<Module> modules = DonutBBC.INSTANCE.getModuleManager().b();
/* 398 */     return modules.stream()
/* 399 */       .sorted((a, b) -> Integer.compare(TextRenderer.getWidth(b.getName()), TextRenderer.getWidth(a.getName())))
/*     */ 
/*     */ 
/*     */       
/* 403 */       .toList();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\HUD.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */