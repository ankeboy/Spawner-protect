/*    */ package dev.FORE.module.modules.render;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ 
/*    */ public final class SwingSpeed extends Module {
/*  9 */   private final NumberSetting swingSpeed = (new NumberSetting((CharSequence)EncryptedString.of("Swing Speed"), 1.0D, 20.0D, 6.0D, 1.0D))
/* 10 */     .setDescription((CharSequence)EncryptedString.of("Speed of hand swinging animation"));
/*    */   
/*    */   public SwingSpeed() {
/* 13 */     super((CharSequence)EncryptedString.of("Swing Speed"), 
/* 14 */         (CharSequence)EncryptedString.of("Modifies the speed of hand swinging animation"), -1, Category.RENDER);
/*    */ 
/*    */     
/* 17 */     addsettings(new Setting[] { (Setting)this.swingSpeed });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 22 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 27 */     super.onDisable();
/*    */   }
/*    */   
/*    */   public NumberSetting getSwingSpeed() {
/* 31 */     return this.swingSpeed;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\SwingSpeed.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */