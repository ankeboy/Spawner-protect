/*     */ package dev.FORE.module.modules.render;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.modules.client.DonutBBC;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_286;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ import net.minecraft.class_9779;
/*     */ import org.joml.Matrix4f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public final class PlayerESP extends Module {
/*  28 */   private final NumberSetting alpha = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 0.0D, 255.0D, 100.0D, 1.0D);
/*  29 */   private final NumberSetting lineWidth = new NumberSetting((CharSequence)EncryptedString.of("Line width"), 1.0D, 10.0D, 1.0D, 1.0D);
/*  30 */   private final BooleanSetting tracers = (new BooleanSetting((CharSequence)EncryptedString.of("Tracers"), false)).setDescription((CharSequence)EncryptedString.of("Draws a line from your player to the other"));
/*     */   
/*     */   public PlayerESP() {
/*  33 */     super((CharSequence)EncryptedString.of("Player ESP"), (CharSequence)EncryptedString.of("Renders players through walls"), -1, Category.RENDER);
/*  34 */     addsettings(new Setting[] { (Setting)this.alpha, (Setting)this.lineWidth, (Setting)this.tracers });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  39 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  44 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent render3DEvent) {
/*  49 */     for (Object next : this.mc.field_1687.method_18456()) {
/*  50 */       if (next != this.mc.field_1724) {
/*  51 */         class_4184 camera = RenderUtils.getCamera();
/*  52 */         if (camera != null) {
/*  53 */           class_4587 matrixStack = render3DEvent.matrixStack;
/*  54 */           render3DEvent.matrixStack.method_22903();
/*  55 */           class_243 pos = RenderUtils.getCameraPos();
/*  56 */           matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
/*  57 */           matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
/*  58 */           matrixStack.method_22904(-pos.field_1352, -pos.field_1351, -pos.field_1350);
/*     */         } 
/*  60 */         double lerpX = class_3532.method_16436(class_9779.field_51956.method_60637(true), ((class_1657)next).field_6014, ((class_1657)next).method_23317());
/*  61 */         double lerpY = class_3532.method_16436(class_9779.field_51956.method_60637(true), ((class_1657)next).field_6036, ((class_1657)next).method_23318());
/*  62 */         double lerpZ = class_3532.method_16436(class_9779.field_51956.method_60637(true), ((class_1657)next).field_5969, ((class_1657)next).method_23321());
/*  63 */         RenderUtils.renderFilledBox(render3DEvent.matrixStack, (float)lerpX - ((class_1657)next).method_17681() / 2.0F, (float)lerpY, (float)lerpZ - ((class_1657)next).method_17681() / 2.0F, (float)lerpX + ((class_1657)next).method_17681() / 2.0F, (float)lerpY + ((class_1657)next).method_17682(), (float)lerpZ + ((class_1657)next).method_17681() / 2.0F, Utils.getMainColor(this.alpha.getIntValue(), 1).brighter());
/*  64 */         if (this.tracers.getValue()) {
/*  65 */           RenderUtils.renderLine(render3DEvent.matrixStack, Utils.getMainColor(255, 1), this.mc.field_1765.method_17784(), ((class_1657)next).method_30950(class_9779.field_51956.method_60637(true)));
/*     */         }
/*  67 */         render3DEvent.matrixStack.method_22909();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderPlayerOutline(class_1657 playerEntity, Color color, class_4587 matrixStack) {
/*  73 */     float red = color.brighter().getRed() / 255.0F;
/*  74 */     float green = color.brighter().getGreen() / 255.0F;
/*  75 */     float blue = color.brighter().getBlue() / 255.0F;
/*  76 */     float alpha = color.brighter().getAlpha() / 255.0F;
/*  77 */     class_4184 camera = this.mc.field_1773.method_19418();
/*  78 */     class_243 subtract = playerEntity.method_30950(class_9779.field_51956.method_60637(true)).method_1020(camera.method_19326());
/*  79 */     float offsetX = (float)subtract.field_1352;
/*  80 */     float offsetY = (float)subtract.field_1351;
/*  81 */     float offsetZ = (float)subtract.field_1350;
/*  82 */     double radians = Math.toRadians((camera.method_19330() + 90.0F));
/*  83 */     double sinOffset = Math.sin(radians) * playerEntity.method_17681() / 1.7D;
/*  84 */     double cosOffset = Math.cos(radians) * playerEntity.method_17681() / 1.7D;
/*  85 */     matrixStack.method_22903();
/*  86 */     Matrix4f positionMatrix = matrixStack.method_23760().method_23761();
/*  87 */     RenderSystem.setShader(class_757::method_34540);
/*  88 */     if (DonutBBC.enableMSAA.getValue()) {
/*  89 */       GL11.glEnable(32925);
/*  90 */       GL11.glEnable(2848);
/*  91 */       GL11.glHint(3154, 4354);
/*     */     } 
/*  93 */     GL11.glDepthFunc(519);
/*  94 */     RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/*  95 */     RenderSystem.defaultBlendFunc();
/*  96 */     RenderSystem.enableBlend();
/*  97 */     GL11.glLineWidth(this.lineWidth.getIntValue());
/*  98 */     class_287 begin = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
/*  99 */     begin.method_22918(positionMatrix, offsetX + (float)sinOffset, offsetY, offsetZ + (float)cosOffset).method_22915(red, green, blue, alpha);
/* 100 */     begin.method_22918(positionMatrix, offsetX - (float)sinOffset, offsetY, offsetZ - (float)cosOffset).method_22915(red, green, blue, alpha);
/* 101 */     begin.method_22918(positionMatrix, offsetX - (float)sinOffset, offsetY, offsetZ - (float)cosOffset).method_22915(red, green, blue, alpha);
/* 102 */     begin.method_22918(positionMatrix, offsetX - (float)sinOffset, offsetY + playerEntity.method_17682(), offsetZ - (float)cosOffset).method_22915(red, green, blue, alpha);
/* 103 */     begin.method_22918(positionMatrix, offsetX - (float)sinOffset, offsetY + playerEntity.method_17682(), offsetZ - (float)cosOffset).method_22915(red, green, blue, alpha);
/* 104 */     begin.method_22918(positionMatrix, offsetX + (float)sinOffset, offsetY + playerEntity.method_17682(), offsetZ + (float)cosOffset).method_22915(red, green, blue, alpha);
/* 105 */     begin.method_22918(positionMatrix, offsetX + (float)sinOffset, offsetY + playerEntity.method_17682(), offsetZ + (float)cosOffset).method_22915(red, green, blue, alpha);
/* 106 */     begin.method_22918(positionMatrix, offsetX + (float)sinOffset, offsetY, offsetZ + (float)cosOffset).method_22915(red, green, blue, alpha);
/* 107 */     begin.method_22918(positionMatrix, offsetX + (float)sinOffset, offsetY, offsetZ + (float)cosOffset).method_22915(red, green, blue, alpha);
/* 108 */     class_286.method_43433(begin.method_60800());
/* 109 */     GL11.glDepthFunc(515);
/* 110 */     GL11.glLineWidth(1.0F);
/* 111 */     RenderSystem.disableBlend();
/* 112 */     if (DonutBBC.enableMSAA.getValue()) {
/* 113 */       GL11.glDisable(2848);
/* 114 */       GL11.glDisable(32925);
/*     */     } 
/* 116 */     matrixStack.method_22909();
/*     */   }
/*     */   
/*     */   private Color getColorWithAlpha(int a) {
/* 120 */     int f = DonutBBC.redColor.getIntValue();
/* 121 */     int f2 = DonutBBC.greenColor.getIntValue();
/* 122 */     int f3 = DonutBBC.blueColor.getIntValue();
/* 123 */     if (DonutBBC.enableRainbowEffect.getValue()) {
/* 124 */       return ColorUtil.a(1, a);
/*     */     }
/* 126 */     return new Color(f, f2, f3, a);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\PlayerESP.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */