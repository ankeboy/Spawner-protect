/*    */ package dev.FORE.module.modules.render;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_7833;
/*    */ 
/*    */ public final class Animations extends Module {
/* 12 */   private final BooleanSetting enabled = (new BooleanSetting((CharSequence)EncryptedString.of("Enabled"), true)).setDescription((CharSequence)EncryptedString.of("Enable custom item animations"));
/* 13 */   private final NumberSetting swingSpeed = (new NumberSetting((CharSequence)EncryptedString.of("Swing Speed"), 1.0D, 10.0D, 1.0D, 0.1D)).setDescription((CharSequence)EncryptedString.of("Speed of item swinging animation"));
/* 14 */   private final NumberSetting scale = (new NumberSetting((CharSequence)EncryptedString.of("Scale"), 0.5D, 2.0D, 1.0D, 0.1D)).setDescription((CharSequence)EncryptedString.of("Scale of held items"));
/* 15 */   private final NumberSetting xOffset = (new NumberSetting((CharSequence)EncryptedString.of("X Offset"), -1.0D, 1.0D, 0.0D, 0.1D)).setDescription((CharSequence)EncryptedString.of("Horizontal offset of held items"));
/* 16 */   private final NumberSetting yOffset = (new NumberSetting((CharSequence)EncryptedString.of("Y Offset"), -1.0D, 1.0D, 0.0D, 0.1D)).setDescription((CharSequence)EncryptedString.of("Vertical offset of held items"));
/* 17 */   private final NumberSetting zOffset = (new NumberSetting((CharSequence)EncryptedString.of("Z Offset"), -1.0D, 1.0D, 0.0D, 0.1D)).setDescription((CharSequence)EncryptedString.of("Depth offset of held items"));
/*    */   
/*    */   public Animations() {
/* 20 */     super((CharSequence)EncryptedString.of("Animations"), (CharSequence)EncryptedString.of("Custom item animations and transformations"), -1, Category.RENDER);
/* 21 */     addsettings(new Setting[] { (Setting)this.enabled, (Setting)this.swingSpeed, (Setting)this.scale, (Setting)this.xOffset, (Setting)this.yOffset, (Setting)this.zOffset });
/*    */   }
/*    */   
/*    */   public boolean shouldAnimate() {
/* 25 */     return (isEnabled() && this.enabled.getValue());
/*    */   }
/*    */ 
/*    */   
/*    */   public void applyTransformations(class_4587 matrices, float swingProgress) {
/* 30 */     matrices.method_22903();
/*    */ 
/*    */     
/* 33 */     float scaleValue = this.scale.getFloatValue();
/* 34 */     matrices.method_22905(scaleValue, scaleValue, scaleValue);
/*    */ 
/*    */     
/* 37 */     matrices.method_46416(this.xOffset.getFloatValue(), this.yOffset.getFloatValue(), this.zOffset.getFloatValue());
/*    */ 
/*    */     
/* 40 */     float swingSpeedValue = this.swingSpeed.getFloatValue();
/* 41 */     float swingAngle = swingProgress * swingSpeedValue * 90.0F;
/* 42 */     matrices.method_22907(class_7833.field_40718.rotationDegrees(swingAngle));
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\Animations.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */