/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class NoRender
/*     */   extends Module
/*     */ {
/*  28 */   private final BooleanSetting rain = (new BooleanSetting((CharSequence)EncryptedString.of("Rain"), true)).setDescription((CharSequence)EncryptedString.of("Disables rain rendering"));
/*  29 */   private final BooleanSetting snow = (new BooleanSetting((CharSequence)EncryptedString.of("Snow"), true)).setDescription((CharSequence)EncryptedString.of("Disables snow rendering"));
/*  30 */   private final BooleanSetting thunder = (new BooleanSetting((CharSequence)EncryptedString.of("Thunder"), true)).setDescription((CharSequence)EncryptedString.of("Disables thunder rendering"));
/*  31 */   private final BooleanSetting clouds = (new BooleanSetting((CharSequence)EncryptedString.of("Clouds"), false)).setDescription((CharSequence)EncryptedString.of("Disables cloud rendering"));
/*  32 */   private final BooleanSetting fog = (new BooleanSetting((CharSequence)EncryptedString.of("Fog"), false)).setDescription((CharSequence)EncryptedString.of("Disables fog rendering"));
/*     */ 
/*     */   
/*  35 */   private final BooleanSetting fire = (new BooleanSetting((CharSequence)EncryptedString.of("Fire"), false)).setDescription((CharSequence)EncryptedString.of("Disables fire rendering"));
/*  36 */   private final BooleanSetting water = (new BooleanSetting((CharSequence)EncryptedString.of("Water"), false)).setDescription((CharSequence)EncryptedString.of("Disables water rendering"));
/*  37 */   private final BooleanSetting lava = (new BooleanSetting((CharSequence)EncryptedString.of("Lava"), false)).setDescription((CharSequence)EncryptedString.of("Disables lava rendering"));
/*  38 */   private final BooleanSetting portal = (new BooleanSetting((CharSequence)EncryptedString.of("Portal"), false)).setDescription((CharSequence)EncryptedString.of("Disables portal rendering"));
/*  39 */   private final BooleanSetting barrier = (new BooleanSetting((CharSequence)EncryptedString.of("Barrier"), true)).setDescription((CharSequence)EncryptedString.of("Disables barrier block rendering"));
/*  40 */   private final BooleanSetting structureVoid = (new BooleanSetting((CharSequence)EncryptedString.of("Structure Void"), true)).setDescription((CharSequence)EncryptedString.of("Disables structure void rendering"));
/*     */ 
/*     */   
/*  43 */   private final BooleanSetting armorStands = (new BooleanSetting((CharSequence)EncryptedString.of("Armor Stands"), false)).setDescription((CharSequence)EncryptedString.of("Disables armor stand rendering"));
/*  44 */   private final BooleanSetting itemFrames = (new BooleanSetting((CharSequence)EncryptedString.of("Item Frames"), false)).setDescription((CharSequence)EncryptedString.of("Disables item frame rendering"));
/*  45 */   private final BooleanSetting paintings = (new BooleanSetting((CharSequence)EncryptedString.of("Paintings"), false)).setDescription((CharSequence)EncryptedString.of("Disables painting rendering"));
/*  46 */   private final BooleanSetting enderman = (new BooleanSetting((CharSequence)EncryptedString.of("Enderman"), false)).setDescription((CharSequence)EncryptedString.of("Disables enderman rendering"));
/*  47 */   private final BooleanSetting guardian = (new BooleanSetting((CharSequence)EncryptedString.of("Guardian"), false)).setDescription((CharSequence)EncryptedString.of("Disables guardian rendering"));
/*  48 */   private final BooleanSetting slime = (new BooleanSetting((CharSequence)EncryptedString.of("Slime"), false)).setDescription((CharSequence)EncryptedString.of("Disables slime rendering"));
/*     */ 
/*     */   
/*  51 */   private final BooleanSetting particles = (new BooleanSetting((CharSequence)EncryptedString.of("Particles"), false)).setDescription((CharSequence)EncryptedString.of("Disables particle rendering"));
/*  52 */   private final BooleanSetting explosions = (new BooleanSetting((CharSequence)EncryptedString.of("Explosions"), false)).setDescription((CharSequence)EncryptedString.of("Disables explosion particle rendering"));
/*  53 */   private final BooleanSetting smoke = (new BooleanSetting((CharSequence)EncryptedString.of("Smoke"), false)).setDescription((CharSequence)EncryptedString.of("Disables smoke particle rendering"));
/*     */ 
/*     */   
/*  56 */   private final BooleanSetting pumpkinBlur = (new BooleanSetting((CharSequence)EncryptedString.of("Pumpkin Blur"), true)).setDescription((CharSequence)EncryptedString.of("Disables pumpkin blur overlay"));
/*  57 */   private final BooleanSetting vignette = (new BooleanSetting((CharSequence)EncryptedString.of("Vignette"), false)).setDescription((CharSequence)EncryptedString.of("Disables vignette overlay"));
/*  58 */   private final BooleanSetting hurtCam = (new BooleanSetting((CharSequence)EncryptedString.of("Hurt Camera"), false)).setDescription((CharSequence)EncryptedString.of("Disables hurt camera effect"));
/*  59 */   private final BooleanSetting totemAnimation = (new BooleanSetting((CharSequence)EncryptedString.of("Totem Animation"), false)).setDescription((CharSequence)EncryptedString.of("Disables totem animation"));
/*  60 */   private final BooleanSetting noSwing = (new BooleanSetting((CharSequence)EncryptedString.of("No Swing"), false)).setDescription((CharSequence)EncryptedString.of("Disables hand swinging animation"));
/*     */ 
/*     */   
/*  63 */   private final NumberSetting entityDistance = new NumberSetting((CharSequence)EncryptedString.of("Entity Distance"), 0.0D, 1000.0D, 64.0D, 1.0D);
/*  64 */   private final NumberSetting blockDistance = new NumberSetting((CharSequence)EncryptedString.of("Block Distance"), 0.0D, 1000.0D, 128.0D, 1.0D);
/*     */   
/*     */   public NoRender() {
/*  67 */     super((CharSequence)EncryptedString.of("NoRender"), (CharSequence)EncryptedString.of("Disables various rendering elements to improve performance"), -1, Category.RENDER);
/*     */ 
/*     */     
/*  70 */     this.entityDistance.setDescription((CharSequence)EncryptedString.of("Maximum distance to render entities"));
/*  71 */     this.blockDistance.setDescription((CharSequence)EncryptedString.of("Maximum distance to render blocks"));
/*     */     
/*  73 */     addsettings(new Setting[] { (Setting)this.rain, (Setting)this.snow, (Setting)this.thunder, (Setting)this.clouds, (Setting)this.fog, (Setting)this.fire, (Setting)this.water, (Setting)this.lava, (Setting)this.portal, (Setting)this.barrier, (Setting)this.structureVoid, (Setting)this.armorStands, (Setting)this.itemFrames, (Setting)this.paintings, (Setting)this.enderman, (Setting)this.guardian, (Setting)this.slime, (Setting)this.particles, (Setting)this.explosions, (Setting)this.smoke, (Setting)this.pumpkinBlur, (Setting)this.vignette, (Setting)this.hurtCam, (Setting)this.totemAnimation, (Setting)this.noSwing, (Setting)this.entityDistance, (Setting)this.blockDistance });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  85 */     if (this.mc.field_1687 == null) {
/*     */       return;
/*     */     }
/*  88 */     if (this.rain.getValue()) {
/*  89 */       this.mc.field_1687.method_8519(0.0F);
/*     */     }
/*     */     
/*  92 */     if (this.snow.getValue()) {
/*  93 */       this.mc.field_1687.method_8496(0.0F);
/*     */     }
/*     */     
/*  96 */     if (this.thunder.getValue()) {
/*  97 */       this.mc.field_1687.method_8496(0.0F);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent event) {
/* 107 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/* 110 */     class_4184 cam = this.mc.field_1773.method_19418();
/* 111 */     if (cam != null) {
/* 112 */       class_243 camPos = cam.method_19326();
/* 113 */       class_4587 matrices = event.matrixStack;
/* 114 */       matrices.method_22903();
/* 115 */       matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
/* 116 */       matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
/* 117 */       matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*     */     } 
/*     */ 
/*     */     
/* 121 */     double entityDist = this.entityDistance.getValue();
/* 122 */     double blockDist = this.blockDistance.getValue();
/*     */     
/* 124 */     for (class_1297 entity : this.mc.field_1687.method_18112()) {
/* 125 */       double distance = this.mc.field_1724.method_5739(entity);
/*     */ 
/*     */       
/* 128 */       if (distance > entityDist) {
/*     */         continue;
/*     */       }
/*     */ 
/*     */       
/* 133 */       if (this.armorStands.getValue() && entity instanceof net.minecraft.class_1531) {
/*     */         continue;
/*     */       }
/*     */       
/* 137 */       if (this.itemFrames.getValue() && entity instanceof net.minecraft.class_1533) {
/*     */         continue;
/*     */       }
/*     */       
/* 141 */       if (this.paintings.getValue() && entity instanceof net.minecraft.class_1534) {
/*     */         continue;
/*     */       }
/*     */       
/* 145 */       if (this.enderman.getValue() && entity instanceof net.minecraft.class_1560) {
/*     */         continue;
/*     */       }
/*     */       
/* 149 */       if (this.guardian.getValue() && entity instanceof net.minecraft.class_1577) {
/*     */         continue;
/*     */       }
/*     */       
/* 153 */       if (!this.slime.getValue() || entity instanceof net.minecraft.class_1621);
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     event.matrixStack.method_22909();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean shouldRenderRain() {
/* 166 */     return !this.rain.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderSnow() {
/* 170 */     return !this.snow.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderThunder() {
/* 174 */     return !this.thunder.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderClouds() {
/* 178 */     return !this.clouds.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderFog() {
/* 182 */     return !this.fog.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderFire() {
/* 186 */     return !this.fire.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderWater() {
/* 190 */     return !this.water.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderLava() {
/* 194 */     return !this.lava.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderPortal() {
/* 198 */     return !this.portal.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderBarrier() {
/* 202 */     return !this.barrier.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderStructureVoid() {
/* 206 */     return !this.structureVoid.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderPumpkinBlur() {
/* 210 */     return !this.pumpkinBlur.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderVignette() {
/* 214 */     return !this.vignette.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderHurtCam() {
/* 218 */     return !this.hurtCam.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderTotemAnimation() {
/* 222 */     return !this.totemAnimation.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderParticles() {
/* 226 */     return !this.particles.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderExplosions() {
/* 230 */     return !this.explosions.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderSmoke() {
/* 234 */     return !this.smoke.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderSwing() {
/* 238 */     return !this.noSwing.getValue();
/*     */   }
/*     */   
/*     */   public boolean shouldRenderEntity(class_1297 entity) {
/* 242 */     if (entity == null) return true;
/*     */ 
/*     */     
/* 245 */     if (this.armorStands.getValue() && entity instanceof net.minecraft.class_1531) {
/* 246 */       return false;
/*     */     }
/*     */     
/* 249 */     if (this.itemFrames.getValue() && entity instanceof net.minecraft.class_1533) {
/* 250 */       return false;
/*     */     }
/*     */     
/* 253 */     if (this.paintings.getValue() && entity instanceof net.minecraft.class_1534) {
/* 254 */       return false;
/*     */     }
/*     */     
/* 257 */     if (this.enderman.getValue() && entity instanceof net.minecraft.class_1560) {
/* 258 */       return false;
/*     */     }
/*     */     
/* 261 */     if (this.guardian.getValue() && entity instanceof net.minecraft.class_1577) {
/* 262 */       return false;
/*     */     }
/*     */     
/* 265 */     if (this.slime.getValue() && entity instanceof net.minecraft.class_1621) {
/* 266 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 270 */     if (this.mc.field_1724 != null) {
/* 271 */       double distance = this.mc.field_1724.method_5739(entity);
/* 272 */       if (distance > this.entityDistance.getValue()) {
/* 273 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 277 */     return true;
/*     */   }
/*     */   
/*     */   public boolean shouldRenderBlock(class_2680 state, class_2338 pos) {
/* 281 */     if (state == null) return true;
/*     */ 
/*     */     
/* 284 */     if (this.fire.getValue() && state.method_26204() == class_2246.field_10036) {
/* 285 */       return false;
/*     */     }
/*     */     
/* 288 */     if (this.water.getValue() && state.method_26204() == class_2246.field_10382) {
/* 289 */       return false;
/*     */     }
/*     */     
/* 292 */     if (this.lava.getValue() && state.method_26204() == class_2246.field_10164) {
/* 293 */       return false;
/*     */     }
/*     */     
/* 296 */     if (this.portal.getValue() && state.method_26204() == class_2246.field_10316) {
/* 297 */       return false;
/*     */     }
/*     */     
/* 300 */     if (this.barrier.getValue() && state.method_26204() == class_2246.field_10499) {
/* 301 */       return false;
/*     */     }
/*     */     
/* 304 */     if (this.structureVoid.getValue() && state.method_26204() == class_2246.field_10369) {
/* 305 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 309 */     if (this.mc.field_1724 != null) {
/* 310 */       double distance = this.mc.field_1724.method_24515().method_10262((class_2382)pos);
/* 311 */       if (distance > this.blockDistance.getValue() * this.blockDistance.getValue()) {
/* 312 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 316 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\NoRender.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */