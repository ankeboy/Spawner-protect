/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import net.minecraft.class_1109;
/*     */ import net.minecraft.class_1113;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1935;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3417;
/*     */ import net.minecraft.class_368;
/*     */ import net.minecraft.class_374;
/*     */ import net.minecraft.class_5250;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkFinderToast
/*     */   implements class_368
/*     */ {
/*     */   private final String chunkX;
/*     */   private final String chunkZ;
/*     */   private long startTime;
/*     */   private boolean hasPlayed = false;
/*     */   private static final long DISPLAY_TIME = 3000L;
/*     */   
/*     */   public ChunkFinderToast(String chunkX, String chunkZ) {
/* 247 */     this.chunkX = chunkX;
/* 248 */     this.chunkZ = chunkZ;
/*     */   }
/*     */ 
/*     */   
/*     */   public class_368.class_369 method_1986(class_332 context, class_374 manager, long startTime) {
/* 253 */     if (this.startTime == 0L) {
/* 254 */       this.startTime = startTime;
/*     */     }
/*     */     
/* 257 */     if (!this.hasPlayed) {
/* 258 */       manager.method_1995().method_1483().method_4873(
/* 259 */           (class_1113)class_1109.method_4757(class_3417.field_26979, 1.0F, 1.0F));
/*     */ 
/*     */ 
/*     */       
/* 263 */       this.hasPlayed = true;
/*     */     } 
/*     */ 
/*     */     
/* 267 */     context.method_52706(
/* 268 */         class_2960.method_60656("toast/advancement"), 0, 0, 
/*     */         
/* 270 */         method_29049(), 
/* 271 */         method_29050());
/*     */ 
/*     */     
/* 274 */     context.method_51445(new class_1799((class_1935)class_1802.field_8106), 6, 6);
/* 275 */     class_5250 class_52501 = class_2561.method_43470("ChunkFinder");
/* 276 */     context.method_51439((manager.method_1995()).field_1772, (class_2561)class_52501, 30, 7, 16586941, false);
/* 277 */     class_5250 class_52502 = class_2561.method_43470("X: " + this.chunkX + " Z: " + this.chunkZ);
/* 278 */     context.method_51439((manager.method_1995()).field_1772, (class_2561)class_52502, 30, 18, 16777215, false);
/*     */     
/* 280 */     return (startTime - this.startTime < 3000L) ? class_368.class_369.field_2210 : class_368.class_369.field_2209;
/*     */   }
/*     */ 
/*     */   
/*     */   public Object method_1987() {
/* 285 */     return Type.INSTANCE;
/*     */   }
/*     */ 
/*     */   
/*     */   public int method_29049() {
/* 290 */     return 160;
/*     */   }
/*     */ 
/*     */   
/*     */   public int method_29050() {
/* 295 */     return 32;
/*     */   }
/*     */   
/*     */   public static class Type {
/* 299 */     public static final Type INSTANCE = new Type();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\ChunkFinder$ChunkFinderToast.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */