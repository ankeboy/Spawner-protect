/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.ChunkDataEvent;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import java.awt.Color;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.ConcurrentHashMap;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2791;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChunkChecker
/*     */   extends Module
/*     */ {
/*     */   private final boolean fill = true;
/*     */   private final boolean outline = true;
/*  29 */   private final int fillAlpha = 120;
/*     */   
/*     */   private static final int HIGHLIGHT_Y = 60;
/*  32 */   private final Set<class_1923> flaggedChunks = ConcurrentHashMap.newKeySet();
/*  33 */   private final Set<class_1923> playerLoadedChunks = ConcurrentHashMap.newKeySet();
/*     */   
/*     */   public ChunkChecker() {
/*  36 */     super((CharSequence)EncryptedString.of("ChunkChecker"), (CharSequence)EncryptedString.of("Detects chunks loaded before player enters them"), -1, Category.RENDER);
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  41 */     this.flaggedChunks.clear();
/*  42 */     this.playerLoadedChunks.clear();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  47 */     this.flaggedChunks.clear();
/*  48 */     this.playerLoadedChunks.clear();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  53 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/*  56 */     int viewDist = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/*  57 */     class_1923 playerChunk = this.mc.field_1724.method_31476();
/*     */ 
/*     */     
/*  60 */     for (int x = -viewDist; x <= viewDist; x++) {
/*  61 */       for (int z = -viewDist; z <= viewDist; z++) {
/*  62 */         class_1923 chunkPos = new class_1923(playerChunk.field_9181 + x, playerChunk.field_9180 + z);
/*  63 */         this.playerLoadedChunks.add(chunkPos);
/*     */ 
/*     */ 
/*     */         
/*  67 */         this.flaggedChunks.remove(chunkPos);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  72 */     cleanupDistantChunks();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onChunkData(ChunkDataEvent event) {
/*  77 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null)
/*     */       return; 
/*  79 */     class_2791 chunk = event.getChunk();
/*  80 */     if (chunk == null || !(chunk instanceof net.minecraft.class_2818))
/*     */       return; 
/*  82 */     class_1923 chunkPos = chunk.method_12004();
/*  83 */     int viewDist = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/*  84 */     class_1923 playerChunk = this.mc.field_1724.method_31476();
/*     */ 
/*     */     
/*  87 */     int dx = Math.abs(chunkPos.field_9181 - playerChunk.field_9181);
/*  88 */     int dz = Math.abs(chunkPos.field_9180 - playerChunk.field_9180);
/*     */ 
/*     */ 
/*     */     
/*  92 */     if (dx > viewDist || dz > viewDist) {
/*     */       
/*  94 */       this.flaggedChunks.add(chunkPos);
/*     */     }
/*     */     else {
/*     */       
/*  98 */       this.flaggedChunks.remove(chunkPos);
/*  99 */       this.playerLoadedChunks.add(chunkPos);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void cleanupDistantChunks() {
/* 104 */     if (this.mc.field_1724 == null)
/*     */       return; 
/* 106 */     int viewDist = ((Integer)this.mc.field_1690.method_42503().method_41753()).intValue();
/* 107 */     int playerChunkX = (int)this.mc.field_1724.method_23317() / 16;
/* 108 */     int playerChunkZ = (int)this.mc.field_1724.method_23321() / 16;
/*     */     
/* 110 */     this.flaggedChunks.removeIf(chunkPos -> {
/*     */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*     */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/* 113 */           return (dx > viewDist * 2 || dz > viewDist * 2);
/*     */         });
/*     */     
/* 116 */     this.playerLoadedChunks.removeIf(chunkPos -> {
/*     */           int dx = Math.abs(chunkPos.field_9181 - playerChunkX);
/*     */           int dz = Math.abs(chunkPos.field_9180 - playerChunkZ);
/* 119 */           return (dx > viewDist * 2 || dz > viewDist * 2);
/*     */         });
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent event) {
/* 125 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null)
/*     */       return; 
/* 127 */     if (this.flaggedChunks.isEmpty())
/*     */       return; 
/* 129 */     class_4184 cam = RenderUtils.getCamera();
/* 130 */     if (cam != null) {
/* 131 */       class_243 camPos = RenderUtils.getCameraPos();
/* 132 */       class_4587 matrices = event.matrixStack;
/* 133 */       matrices.method_22903();
/* 134 */       matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
/* 135 */       matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
/* 136 */       matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*     */     } 
/*     */     
/* 139 */     for (class_1923 chunkPos : this.flaggedChunks) {
/* 140 */       int a = 120;
/* 141 */       renderChunkHighlight(event.matrixStack, chunkPos, new Color(255, 0, 0, a));
/*     */     } 
/*     */     
/* 144 */     event.matrixStack.method_22909();
/*     */   }
/*     */   
/*     */   private void renderChunkHighlight(class_4587 stack, class_1923 chunkPos, Color renderColor) {
/* 148 */     int startX = chunkPos.field_9181 * 16;
/* 149 */     int startZ = chunkPos.field_9180 * 16;
/* 150 */     int endX = startX + 16;
/* 151 */     int endZ = startZ + 16;
/*     */     
/* 153 */     double y = 60.0D;
/* 154 */     double height = 0.10000000149011612D;
/*     */     
/* 156 */     class_238 chunkBox = new class_238(startX, y, startZ, endX, y + height, endZ);
/*     */ 
/*     */     
/* 159 */     RenderUtils.renderFilledBox(stack, (float)chunkBox.field_1323, (float)chunkBox.field_1322, (float)chunkBox.field_1321, (float)chunkBox.field_1320, (float)chunkBox.field_1325, (float)chunkBox.field_1324, renderColor);
/*     */ 
/*     */ 
/*     */     
/* 163 */     renderBoxOutline(stack, (float)chunkBox.field_1323, (float)chunkBox.field_1322, (float)chunkBox.field_1321, (float)chunkBox.field_1320, (float)chunkBox.field_1325, (float)chunkBox.field_1324, renderColor);
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderBoxOutline(class_4587 stack, float minX, float minY, float minZ, float maxX, float maxY, float maxZ, Color color) {
/* 168 */     class_243[] corners = { new class_243(minX, minY, minZ), new class_243(maxX, minY, minZ), new class_243(maxX, minY, maxZ), new class_243(minX, minY, maxZ), new class_243(minX, maxY, minZ), new class_243(maxX, maxY, minZ), new class_243(maxX, maxY, maxZ), new class_243(minX, maxY, maxZ) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 179 */     RenderUtils.renderLine(stack, color, corners[0], corners[1]);
/* 180 */     RenderUtils.renderLine(stack, color, corners[1], corners[2]);
/* 181 */     RenderUtils.renderLine(stack, color, corners[2], corners[3]);
/* 182 */     RenderUtils.renderLine(stack, color, corners[3], corners[0]);
/*     */     
/* 184 */     RenderUtils.renderLine(stack, color, corners[4], corners[5]);
/* 185 */     RenderUtils.renderLine(stack, color, corners[5], corners[6]);
/* 186 */     RenderUtils.renderLine(stack, color, corners[6], corners[7]);
/* 187 */     RenderUtils.renderLine(stack, color, corners[7], corners[4]);
/*     */     
/* 189 */     RenderUtils.renderLine(stack, color, corners[0], corners[4]);
/* 190 */     RenderUtils.renderLine(stack, color, corners[1], corners[5]);
/* 191 */     RenderUtils.renderLine(stack, color, corners[2], corners[6]);
/* 192 */     RenderUtils.renderLine(stack, color, corners[3], corners[7]);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\ChunkChecker.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */