/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1551;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ public final class TridentESP extends Module {
/*  23 */   private final NumberSetting range = new NumberSetting((CharSequence)EncryptedString.of("Range"), 10.0D, 200.0D, 100.0D, 1.0D);
/*  24 */   private final NumberSetting alpha = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 50.0D, 255.0D, 200.0D, 1.0D);
/*  25 */   private final BooleanSetting showDistance = (new BooleanSetting((CharSequence)EncryptedString.of("Show Distance"), true)).setDescription((CharSequence)EncryptedString.of("Shows distance to the drowned"));
/*  26 */   private final BooleanSetting showHealth = (new BooleanSetting((CharSequence)EncryptedString.of("Show Health"), true)).setDescription((CharSequence)EncryptedString.of("Shows health of the drowned"));
/*  27 */   private final BooleanSetting onlyTrident = (new BooleanSetting((CharSequence)EncryptedString.of("Only Trident"), true)).setDescription((CharSequence)EncryptedString.of("Only highlights drowned with tridents"));
/*     */   
/*     */   public TridentESP() {
/*  30 */     super((CharSequence)EncryptedString.of("Trident ESP"), (CharSequence)EncryptedString.of("Highlights drowned with tridents"), -1, Category.RENDER);
/*  31 */     this.range.setDescription((CharSequence)EncryptedString.of("Range to search for drowned"));
/*  32 */     this.alpha.setDescription((CharSequence)EncryptedString.of("Transparency of the ESP"));
/*  33 */     addsettings(new Setting[] { (Setting)this.range, (Setting)this.alpha, (Setting)this.showDistance, (Setting)this.showHealth, (Setting)this.onlyTrident });
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent event) {
/*  38 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
/*     */       return;
/*     */     }
/*  41 */     class_4184 cam = RenderUtils.getCamera();
/*  42 */     if (cam != null) {
/*  43 */       class_243 camPos = RenderUtils.getCameraPos();
/*  44 */       class_4587 matrices = event.matrixStack;
/*  45 */       matrices.method_22903();
/*  46 */       matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
/*  47 */       matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
/*  48 */       matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*     */     } 
/*     */ 
/*     */     
/*  52 */     for (class_1297 entity : this.mc.field_1687.method_18112()) {
/*  53 */       if (entity instanceof class_1551) { class_1551 drowned = (class_1551)entity;
/*     */         
/*  55 */         if (this.onlyTrident.getValue() && !hasTrident(drowned)) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/*  60 */         double distance = this.mc.field_1724.method_5739((class_1297)drowned);
/*  61 */         if (distance > this.range.getValue()) {
/*     */           continue;
/*     */         }
/*     */ 
/*     */         
/*  66 */         Color color = getDrownedColor(drowned, distance);
/*     */ 
/*     */         
/*  69 */         float width = drowned.method_17681();
/*  70 */         float height = drowned.method_17682();
/*  71 */         double x = drowned.method_23317();
/*  72 */         double y = drowned.method_23318();
/*  73 */         double z = drowned.method_23321();
/*     */ 
/*     */         
/*  76 */         RenderUtils.renderFilledBox(event.matrixStack, (float)(x - (width / 2.0F)), (float)y, (float)(z - (width / 2.0F)), (float)(x + (width / 2.0F)), (float)(y + height), (float)(z + (width / 2.0F)), color);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  84 */         RenderUtils.renderLine(event.matrixStack, color, new class_243(x - (width / 2.0F), y, z - (width / 2.0F)), new class_243(x + (width / 2.0F), y + height, z + (width / 2.0F)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  92 */         renderEntityOutline(event.matrixStack, x, y, z, width, height, color); }
/*     */     
/*     */     } 
/*     */     
/*  96 */     event.matrixStack.method_22909();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean hasTrident(class_1551 drowned) {
/* 101 */     class_1799 mainHand = drowned.method_6047();
/* 102 */     if (mainHand.method_7909() == class_1802.field_8547) {
/* 103 */       return true;
/*     */     }
/*     */ 
/*     */     
/* 107 */     class_1799 offHand = drowned.method_6079();
/* 108 */     if (offHand.method_7909() == class_1802.field_8547) {
/* 109 */       return true;
/*     */     }
/*     */     
/* 112 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private Color getDrownedColor(class_1551 drowned, double distance) {
/* 117 */     int red = 255;
/* 118 */     int green = 0;
/* 119 */     int blue = 0;
/*     */ 
/*     */     
/* 122 */     double distanceFactor = Math.max(0.0D, 1.0D - distance / this.range.getValue());
/* 123 */     red = (int)(255.0D * distanceFactor);
/* 124 */     green = (int)(50.0D * distanceFactor);
/* 125 */     blue = (int)(50.0D * distanceFactor);
/*     */ 
/*     */     
/* 128 */     float healthPercent = drowned.method_6032() / drowned.method_6063();
/* 129 */     if (healthPercent < 0.5F) {
/*     */       
/* 131 */       red = (int)(255.0D * distanceFactor);
/* 132 */       green = (int)(165.0D * distanceFactor);
/* 133 */       blue = 0;
/*     */     } 
/*     */     
/* 136 */     return new Color(red, green, blue, this.alpha.getIntValue());
/*     */   }
/*     */ 
/*     */   
/*     */   private void renderEntityOutline(class_4587 matrices, double x, double y, double z, float width, float height, Color color) {
/* 141 */     RenderUtils.renderLine(matrices, color, new class_243(x - (width / 2.0F), y, z - (width / 2.0F)), new class_243(x - (width / 2.0F), y + height, z - (width / 2.0F)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 148 */     RenderUtils.renderLine(matrices, color, new class_243(x + (width / 2.0F), y, z - (width / 2.0F)), new class_243(x + (width / 2.0F), y + height, z - (width / 2.0F)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 155 */     RenderUtils.renderLine(matrices, color, new class_243(x - (width / 2.0F), y, z + (width / 2.0F)), new class_243(x - (width / 2.0F), y + height, z + (width / 2.0F)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 162 */     RenderUtils.renderLine(matrices, color, new class_243(x + (width / 2.0F), y, z + (width / 2.0F)), new class_243(x + (width / 2.0F), y + height, z + (width / 2.0F)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 170 */     RenderUtils.renderLine(matrices, color, new class_243(x - (width / 2.0F), y + height, z - (width / 2.0F)), new class_243(x + (width / 2.0F), y + height, z - (width / 2.0F)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 177 */     RenderUtils.renderLine(matrices, color, new class_243(x + (width / 2.0F), y + height, z - (width / 2.0F)), new class_243(x + (width / 2.0F), y + height, z + (width / 2.0F)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 184 */     RenderUtils.renderLine(matrices, color, new class_243(x + (width / 2.0F), y + height, z + (width / 2.0F)), new class_243(x - (width / 2.0F), y + height, z + (width / 2.0F)));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 191 */     RenderUtils.renderLine(matrices, color, new class_243(x - (width / 2.0F), y + height, z + (width / 2.0F)), new class_243(x - (width / 2.0F), y + height, z - (width / 2.0F)));
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\TridentESP.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */