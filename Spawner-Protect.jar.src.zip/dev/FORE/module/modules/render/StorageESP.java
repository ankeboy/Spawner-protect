/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.BlockUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.RenderUtils;
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2586;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ public final class StorageESP extends Module {
/*  23 */   private final NumberSetting alpha = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 1.0D, 255.0D, 125.0D, 1.0D);
/*  24 */   private final BooleanSetting tracers = (new BooleanSetting((CharSequence)EncryptedString.of("Tracers"), false)).setDescription((CharSequence)EncryptedString.of("Draws a line from your player to the storage block"));
/*  25 */   private final BooleanSetting chests = new BooleanSetting((CharSequence)EncryptedString.of("Chests"), true);
/*  26 */   private final BooleanSetting enderChests = new BooleanSetting((CharSequence)EncryptedString.of("Ender Chests"), true);
/*  27 */   private final BooleanSetting spawners = new BooleanSetting((CharSequence)EncryptedString.of("Spawners"), true);
/*  28 */   private final BooleanSetting shulkerBoxes = new BooleanSetting((CharSequence)EncryptedString.of("Shulker Boxes"), true);
/*  29 */   private final BooleanSetting furnaces = new BooleanSetting((CharSequence)EncryptedString.of("Furnaces"), true);
/*  30 */   private final BooleanSetting barrels = new BooleanSetting((CharSequence)EncryptedString.of("Barrels"), true);
/*  31 */   private final BooleanSetting enchant = new BooleanSetting((CharSequence)EncryptedString.of("Enchanting Tables"), true);
/*  32 */   private final BooleanSetting pistons = new BooleanSetting((CharSequence)EncryptedString.of("Pistons"), true);
/*     */   
/*     */   public StorageESP() {
/*  35 */     super((CharSequence)EncryptedString.of("Storage ESP"), (CharSequence)EncryptedString.of("Renders storage blocks through walls"), -1, Category.RENDER);
/*  36 */     addsettings(new Setting[] { (Setting)this.alpha, (Setting)this.tracers, (Setting)this.chests, (Setting)this.enderChests, (Setting)this.spawners, (Setting)this.shulkerBoxes, (Setting)this.furnaces, (Setting)this.barrels, (Setting)this.enchant, (Setting)this.pistons });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  41 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  46 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent render3DEvent) {
/*  51 */     renderStorages(render3DEvent);
/*     */   }
/*     */   
/*     */   private Color getBlockEntityColor(class_2586 blockEntity, int a) {
/*  55 */     if (blockEntity instanceof net.minecraft.class_2646 && this.chests.getValue()) {
/*  56 */       return new Color(200, 91, 0, a);
/*     */     }
/*  58 */     if (blockEntity instanceof net.minecraft.class_2595 && this.chests.getValue()) {
/*  59 */       return new Color(156, 91, 0, a);
/*     */     }
/*  61 */     if (blockEntity instanceof net.minecraft.class_2611 && this.enderChests.getValue()) {
/*  62 */       return new Color(117, 0, 255, a);
/*     */     }
/*  64 */     if (blockEntity instanceof net.minecraft.class_2636 && this.spawners.getValue()) {
/*  65 */       return new Color(138, 126, 166, a);
/*     */     }
/*  67 */     if (blockEntity instanceof net.minecraft.class_2627 && this.shulkerBoxes.getValue()) {
/*  68 */       return new Color(134, 0, 158, a);
/*     */     }
/*  70 */     if (blockEntity instanceof net.minecraft.class_3866 && this.furnaces.getValue()) {
/*  71 */       return new Color(125, 125, 125, a);
/*     */     }
/*  73 */     if (blockEntity instanceof net.minecraft.class_3719 && this.barrels.getValue()) {
/*  74 */       return new Color(255, 140, 140, a);
/*     */     }
/*  76 */     if (blockEntity instanceof net.minecraft.class_2605 && this.enchant.getValue()) {
/*  77 */       return new Color(80, 80, 255, a);
/*     */     }
/*  79 */     if (blockEntity instanceof net.minecraft.class_2669 && this.pistons.getValue()) {
/*  80 */       return new Color(35, 226, 0, a);
/*     */     }
/*  82 */     return new Color(255, 255, 255, 0);
/*     */   }
/*     */   
/*     */   private void renderStorages(Render3DEvent event) {
/*  86 */     class_4184 cam = RenderUtils.getCamera();
/*  87 */     if (cam != null) {
/*  88 */       class_243 camPos = RenderUtils.getCameraPos();
/*  89 */       class_4587 matrices = event.matrixStack;
/*  90 */       matrices.method_22903();
/*  91 */       matrices.method_22907(class_7833.field_40714.rotationDegrees(cam.method_19329()));
/*  92 */       matrices.method_22907(class_7833.field_40716.rotationDegrees(cam.method_19330() + 180.0F));
/*  93 */       matrices.method_22904(-camPos.field_1352, -camPos.field_1351, -camPos.field_1350);
/*     */     } 
/*     */     
/*  96 */     for (class_2818 chunk : BlockUtil.getLoadedChunks().toList()) {
/*  97 */       for (class_2338 blockPos : chunk.method_12021()) {
/*  98 */         class_2586 blockEntity = this.mc.field_1687.method_8321(blockPos);
/*     */         
/* 100 */         RenderUtils.renderFilledBox(event.matrixStack, blockPos.method_10263() + 0.1F, blockPos.method_10264() + 0.05F, blockPos.method_10260() + 0.1F, blockPos.method_10263() + 0.9F, blockPos.method_10264() + 0.85F, blockPos.method_10260() + 0.9F, getBlockEntityColor(blockEntity, this.alpha.getIntValue()));
/*     */         
/* 102 */         if (this.tracers.getValue()) {
/* 103 */           RenderUtils.renderLine(event.matrixStack, getBlockEntityColor(blockEntity, 255), this.mc.field_1765.method_17784(), new class_243(blockPos.method_10263() + 0.5D, blockPos.method_10264() + 0.5D, blockPos.method_10260() + 0.5D));
/*     */         }
/*     */       } 
/*     */     } 
/* 107 */     class_4587 matrixStack = event.matrixStack;
/* 108 */     matrixStack.method_22909();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\StorageESP.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */