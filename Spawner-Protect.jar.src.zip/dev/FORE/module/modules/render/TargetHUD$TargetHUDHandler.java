/*     */ package dev.FORE.module.modules.render;
/*     */ 
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_2824;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class TargetHUDHandler
/*     */ {
/* 239 */   public static final class_310 MC = class_310.method_1551();
/*     */   final TargetHUD this$0;
/*     */   
/*     */   TargetHUDHandler(TargetHUD this$0) {
/* 243 */     this.this$0 = this$0;
/*     */   }
/*     */   
/*     */   public boolean isAttackPacket(class_2824 playerInteractEntityC2SPacket) {
/*     */     String string;
/*     */     try {
/* 249 */       string = playerInteractEntityC2SPacket.toString();
/* 250 */       if (string.contains("ATTACK")) {
/* 251 */         return true;
/*     */       }
/* 253 */     } catch (Exception ex) {
/* 254 */       return (MC.field_1724 != null && MC.field_1724.method_6052() != null && MC.field_1724.method_6052() instanceof net.minecraft.class_1657);
/*     */     } 
/*     */     try {
/* 257 */       if (MC.field_1724 == null || MC.field_1724.method_6052() == null || !(MC.field_1724.method_6052() instanceof net.minecraft.class_1657)) {
/* 258 */         return false;
/*     */       }
/* 260 */       boolean contains = string.contains(class_1268.field_5808.toString());
/* 261 */       boolean contains2 = string.contains("INTERACT_AT");
/* 262 */       if (contains && contains2) {
/* 263 */         return true;
/*     */       }
/* 265 */     } catch (Exception ex2) {
/* 266 */       return (MC.field_1724 != null && MC.field_1724.method_6052() != null && MC.field_1724.method_6052() instanceof net.minecraft.class_1657);
/*     */     } 
/*     */     try {
/* 269 */       return (MC.field_1724.field_6252 && MC.field_1724.method_6052() != null);
/* 270 */     } catch (Exception exception) {
/*     */       
/* 272 */       return (MC.field_1724 != null && MC.field_1724.method_6052() != null && MC.field_1724.method_6052() instanceof net.minecraft.class_1657);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\render\TargetHUD$TargetHUDHandler.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */