/*     */ package dev.FORE.module.modules.combat;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.modules.client.Friends;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_3966;
/*     */ 
/*     */ public class TriggerBot
/*     */   extends Module {
/*  21 */   private final NumberSetting delay = (new NumberSetting((CharSequence)EncryptedString.of("Delay"), 0.0D, 20.0D, 10.0D, 1.0D))
/*  22 */     .setDescription((CharSequence)EncryptedString.of("Delay in ticks between attacks (20 ticks = 1 second)."));
/*     */   
/*  24 */   private final BooleanSetting playersOnly = (new BooleanSetting((CharSequence)EncryptedString.of("Players Only"), true))
/*  25 */     .setDescription((CharSequence)EncryptedString.of("Only attack players."));
/*     */   
/*  27 */   private final BooleanSetting ignoreFriends = (new BooleanSetting((CharSequence)EncryptedString.of("Ignore Friends"), true))
/*  28 */     .setDescription((CharSequence)EncryptedString.of("Don't attack friends."));
/*     */   
/*  30 */   private final BooleanSetting requireWeapon = (new BooleanSetting((CharSequence)EncryptedString.of("Require Weapon"), false))
/*  31 */     .setDescription((CharSequence)EncryptedString.of("Only attack when holding a weapon."));
/*     */   
/*  33 */   private int attackTimer = 0;
/*     */   private TapResetMacro tapResetMacro;
/*     */   
/*     */   public TriggerBot() {
/*  37 */     super((CharSequence)EncryptedString.of("TriggerBot"), 
/*  38 */         (CharSequence)EncryptedString.of("Automatically attacks entities you are looking at."), -1, Category.COMBAT);
/*     */ 
/*     */     
/*  41 */     addsettings(new Setting[] { (Setting)this.delay, (Setting)this.playersOnly, (Setting)this.ignoreFriends, (Setting)this.requireWeapon });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  46 */     this.attackTimer = 0;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   private void onTick(TickEvent event) {
/*  51 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
/*     */       return;
/*     */     }
/*  54 */     if (this.attackTimer > 0) {
/*  55 */       this.attackTimer--;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  60 */     class_239 hitResult = this.mc.field_1765;
/*     */     
/*  62 */     if (hitResult == null || hitResult.method_17783() != class_239.class_240.field_1331) {
/*     */       return;
/*     */     }
/*     */     
/*  66 */     class_3966 entityHit = (class_3966)hitResult;
/*  67 */     class_1297 target = entityHit.method_17782();
/*     */ 
/*     */     
/*  70 */     if (!isValidTarget(target)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  75 */     if (this.requireWeapon.getValue() && !isHoldingWeapon()) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  80 */     if (this.mc.field_1724.method_7261(0.5F) < 1.0F) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  85 */     this.mc.field_1761.method_2918((class_1657)this.mc.field_1724, target);
/*  86 */     this.mc.field_1724.method_6104(class_1268.field_5808);
/*  87 */     triggerTapReset(target);
/*     */ 
/*     */     
/*  90 */     this.attackTimer = (int)this.delay.getValue();
/*     */   }
/*     */   private void triggerTapReset(class_1297 target) {
/*     */     class_1657 player;
/*  94 */     if (target instanceof class_1657) { player = (class_1657)target; }
/*     */     else
/*     */     { return; }
/*     */     
/*  98 */     TapResetMacro macro = getTapResetMacro();
/*  99 */     if (macro != null) {
/* 100 */       macro.triggerExternalTap(player);
/*     */     }
/*     */   }
/*     */   
/*     */   private TapResetMacro getTapResetMacro() {
/* 105 */     if (this.tapResetMacro == null && DonutBBC.INSTANCE != null && DonutBBC.INSTANCE.getModuleManager() != null) {
/* 106 */       Module module = DonutBBC.INSTANCE.getModuleManager().getModuleByClass(TapResetMacro.class);
/* 107 */       if (module instanceof TapResetMacro) { TapResetMacro macro = (TapResetMacro)module;
/* 108 */         this.tapResetMacro = macro; }
/*     */     
/*     */     } 
/* 111 */     return this.tapResetMacro;
/*     */   }
/*     */   
/*     */   private boolean isValidTarget(class_1297 entity) {
/* 115 */     if (entity == null || !entity.method_5805()) {
/* 116 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 120 */     if (!(entity instanceof net.minecraft.class_1309)) {
/* 121 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 125 */     if (entity == this.mc.field_1724) {
/* 126 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 130 */     if (this.playersOnly.getValue() && !(entity instanceof class_1657)) {
/* 131 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 135 */     if (Friends.getInstance().isEnabled())
/*     */     {
/*     */ 
/*     */       
/* 139 */       if (this.ignoreFriends.getValue() && entity instanceof class_1657) {
/* 140 */         class_1657 player = (class_1657)entity;
/* 141 */         if (Friends.getInstance().getFriends().contains(player.method_5477().getString()) && 
/* 142 */           Friends.getInstance().Shouldnottriggerbot()) {
/* 143 */           return false;
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 150 */     return true;
/*     */   }
/*     */   
/*     */   private boolean isHoldingWeapon() {
/* 154 */     if (this.mc.field_1724.method_6047().method_7960()) {
/* 155 */       return false;
/*     */     }
/*     */     
/* 158 */     String itemName = this.mc.field_1724.method_6047().method_7909().toString().toLowerCase();
/*     */     
/* 160 */     return (itemName.contains("sword") || itemName
/* 161 */       .contains("axe") || itemName
/* 162 */       .contains("trident") || itemName
/* 163 */       .contains("mace"));
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\TriggerBot.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */