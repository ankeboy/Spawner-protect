/*     */ package dev.FORE.module.modules.combat;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.AttackEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EnchantmentUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.InventoryUtil;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1893;
/*     */ 
/*     */ public final class MaceSwap extends Module {
/*  19 */   private final BooleanSetting enableWindBurst = new BooleanSetting((CharSequence)EncryptedString.of("Wind Burst"), true);
/*  20 */   private final BooleanSetting enableBreach = new BooleanSetting((CharSequence)EncryptedString.of("Breach"), true);
/*  21 */   private final BooleanSetting onlySword = new BooleanSetting((CharSequence)EncryptedString.of("Only Sword"), false);
/*  22 */   private final BooleanSetting onlyAxe = new BooleanSetting((CharSequence)EncryptedString.of("Only Axe"), false);
/*  23 */   private final BooleanSetting switchBack = new BooleanSetting((CharSequence)EncryptedString.of("Switch Back"), true);
/*  24 */   private final NumberSetting switchDelay = new NumberSetting((CharSequence)EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  25 */   private final BooleanSetting debug = new BooleanSetting((CharSequence)EncryptedString.of("Debug"), false);
/*     */   private boolean isSwitching;
/*     */   private int previousSlot;
/*     */   private int currentSwitchDelay;
/*     */   
/*     */   public MaceSwap() {
/*  31 */     super((CharSequence)EncryptedString.of("Mace Swap"), (CharSequence)EncryptedString.of("Switches to a mace when attacking."), -1, Category.COMBAT);
/*  32 */     addsettings(new Setting[] { (Setting)this.enableWindBurst, (Setting)this.enableBreach, (Setting)this.onlySword, (Setting)this.onlyAxe, (Setting)this.switchBack, (Setting)this.switchDelay, (Setting)this.debug });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  37 */     resetState();
/*  38 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  43 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  48 */     if (this.mc.field_1755 != null) {
/*     */       return;
/*     */     }
/*  51 */     if (this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/*  54 */     if (this.isSwitching) {
/*  55 */       if (this.switchBack.getValue()) {
/*  56 */         performSwitchBack();
/*     */       } else {
/*  58 */         resetState();
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onAttack(AttackEvent attackEvent) {
/*  65 */     if (this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/*     */     
/*  69 */     if (this.debug.getValue()) {
/*  70 */       System.out.println("[MaceSwap] Attack event triggered");
/*     */     }
/*     */     
/*  73 */     if (!isValidWeapon()) {
/*  74 */       if (this.debug.getValue()) {
/*  75 */         System.out.println("[MaceSwap] Invalid weapon - not a sword or axe");
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/*  80 */     if (this.previousSlot == -1) {
/*  81 */       this.previousSlot = (this.mc.field_1724.method_31548()).field_7545;
/*  82 */       if (this.debug.getValue()) {
/*  83 */         System.out.println("[MaceSwap] Stored previous slot: " + this.previousSlot);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  88 */     boolean swapped = false;
/*     */ 
/*     */     
/*  91 */     if (this.enableWindBurst.getValue() || this.enableBreach.getValue()) {
/*  92 */       swapped = InventoryUtil.swapStack(itemStack -> {
/*     */             if (itemStack.method_7960()) {
/*     */               return false;
/*     */             }
/*     */             
/*     */             boolean hasWindBurst = false;
/*     */             boolean hasBreach = false;
/*     */             if (this.enableWindBurst.getValue()) {
/*     */               hasWindBurst = EnchantmentUtil.hasEnchantment(itemStack, class_1893.field_50159);
/*     */             }
/*     */             if (this.enableBreach.getValue()) {
/*     */               hasBreach = EnchantmentUtil.hasEnchantment(itemStack, class_1893.field_50158);
/*     */             }
/* 105 */             return (hasWindBurst || hasBreach);
/*     */           });
/*     */       
/* 108 */       if (this.debug.getValue()) {
/* 109 */         System.out.println("[MaceSwap] Tried to swap to enchanted weapon: " + swapped);
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 114 */     if (!swapped) {
/* 115 */       swapped = InventoryUtil.swapItem(item -> (item instanceof net.minecraft.class_1829 || item instanceof net.minecraft.class_1743));
/*     */       
/* 117 */       if (this.debug.getValue()) {
/* 118 */         System.out.println("[MaceSwap] Tried to swap to any weapon: " + swapped);
/*     */       }
/*     */     } 
/*     */     
/* 122 */     if (swapped) {
/* 123 */       this.isSwitching = true;
/* 124 */       if (this.debug.getValue()) {
/* 125 */         System.out.println("[MaceSwap] Successfully swapped to weapon");
/*     */       }
/*     */     }
/* 128 */     else if (this.debug.getValue()) {
/* 129 */       System.out.println("[MaceSwap] Failed to find suitable weapon to swap to");
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean isValidWeapon() {
/* 135 */     class_1792 item = this.mc.field_1724.method_6047().method_7909();
/*     */     
/* 137 */     if (this.onlySword.getValue() && this.onlyAxe.getValue()) {
/* 138 */       return (item instanceof net.minecraft.class_1829 || item instanceof net.minecraft.class_1743);
/*     */     }
/*     */     
/* 141 */     if (this.onlySword.getValue()) {
/* 142 */       return item instanceof net.minecraft.class_1829;
/*     */     }
/*     */     
/* 145 */     if (this.onlyAxe.getValue()) {
/* 146 */       return item instanceof net.minecraft.class_1743;
/*     */     }
/*     */ 
/*     */     
/* 150 */     return (item instanceof net.minecraft.class_1829 || item instanceof net.minecraft.class_1743);
/*     */   }
/*     */   
/*     */   private void performSwitchBack() {
/* 154 */     if (this.currentSwitchDelay < this.switchDelay.getIntValue()) {
/* 155 */       this.currentSwitchDelay++;
/*     */       
/*     */       return;
/*     */     } 
/* 159 */     if (this.debug.getValue()) {
/* 160 */       System.out.println("[MaceSwap] Switching back to slot: " + this.previousSlot);
/*     */     }
/*     */     
/* 163 */     InventoryUtil.swap(this.previousSlot);
/* 164 */     resetState();
/*     */   }
/*     */   
/*     */   private void resetState() {
/* 168 */     this.previousSlot = -1;
/* 169 */     this.currentSwitchDelay = 0;
/* 170 */     this.isSwitching = false;
/*     */     
/* 172 */     if (this.debug.getValue())
/* 173 */       System.out.println("[MaceSwap] Reset state"); 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\MaceSwap.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */