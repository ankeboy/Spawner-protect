/*    */ package dev.FORE.module.modules.combat;
/*    */ 
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TargetMarginEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ 
/*    */ public final class Hitbox extends Module {
/* 13 */   private final NumberSetting expand = new NumberSetting((CharSequence)EncryptedString.of("Expand"), 0.0D, 2.0D, 0.5D, 0.05D);
/* 14 */   private final BooleanSetting enableRender = new BooleanSetting("Enable Render", true);
/*    */   
/*    */   public Hitbox() {
/* 17 */     super((CharSequence)EncryptedString.of("HitBox"), (CharSequence)EncryptedString.of("Expands a player's hitbox."), -1, Category.COMBAT);
/* 18 */     addsettings(new Setting[] { (Setting)this.enableRender, (Setting)this.expand });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 23 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 28 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTargetMargin(TargetMarginEvent targetMarginEvent) {
/* 33 */     if (targetMarginEvent.entity instanceof net.minecraft.class_1657) {
/* 34 */       targetMarginEvent.cir.setReturnValue(Float.valueOf((float)this.expand.getValue()));
/*    */     }
/*    */   }
/*    */   
/*    */   public double getHitboxExpansion() {
/* 39 */     if (!this.enableRender.getValue()) {
/* 40 */       return 0.0D;
/*    */     }
/* 42 */     return this.expand.getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\Hitbox.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */