/*    */ package dev.FORE.module.modules.combat;
/*    */ 
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import dev.FORE.utils.MathUtil;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1657;
/*    */ 
/*    */ public class AutoJumpReset extends Module {
/* 13 */   private final NumberSetting jumpResetChance = new NumberSetting("Jump Reset Chance", 1.0D, 100.0D, 75.0D, 1.0D);
/* 14 */   private final NumberSetting combatRange = new NumberSetting("Combat Range", 1.0D, 10.0D, 6.0D, 0.5D);
/*    */   
/*    */   public AutoJumpReset() {
/* 17 */     super((CharSequence)EncryptedString.of("Auto Jump Reset"), (CharSequence)EncryptedString.of("Automatically jumps on hit"), -1, Category.COMBAT);
/* 18 */     addsettings(new Setting[] { (Setting)this.jumpResetChance, (Setting)this.combatRange });
/*    */   }
/*    */   
/*    */   public void onTick() {
/* 22 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null)
/* 23 */       return;  if (this.mc.field_1724.method_5715())
/* 24 */       return;  if (this.mc.field_1724.method_6101())
/* 25 */       return;  if (!this.mc.field_1724.method_24828())
/* 26 */       return;  if (this.mc.field_1724.field_6250 == 0.0F && this.mc.field_1724.field_6212 == 0.0F)
/* 27 */       return;  if (this.mc.field_1724.method_5681())
/* 28 */       return;  if (this.mc.field_1724.method_5771())
/* 29 */       return;  if (!isInCombat()) {
/*    */       return;
/*    */     }
/* 32 */     if (MathUtil.randomInt(0, 100) <= this.jumpResetChance.getIntValue()) {
/* 33 */       this.mc.field_1724.method_6043();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private boolean isInCombat() {
/* 43 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null) {
/* 44 */       return false;
/*    */     }
/*    */     
/* 47 */     float range = this.combatRange.getFloatValue();
/*    */ 
/*    */     
/* 50 */     for (class_1657 player : this.mc.field_1687.method_18456()) {
/*    */       
/* 52 */       if (player == this.mc.field_1724) {
/*    */         continue;
/*    */       }
/* 55 */       if (player.method_31481() || player.method_29504()) {
/*    */         continue;
/*    */       }
/* 58 */       if (this.mc.field_1724.method_5739((class_1297)player) <= range) {
/* 59 */         return true;
/*    */       }
/*    */     } 
/*    */     
/* 63 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\AutoJumpReset.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */