/*    */ package dev.FORE.module.modules.combat;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.PacketReceiveEvent;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.imixin.IEntityVelocityUpdateS2CPacket;
/*    */ import dev.FORE.imixin.IVec3d;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2743;
/*    */ 
/*    */ public class Velocity extends Module {
/* 18 */   public final BooleanSetting knockback = (new BooleanSetting("Knockback", true))
/* 19 */     .setDescription((CharSequence)EncryptedString.of("Modifies the amount of knockback you take from attacks."));
/*    */   
/* 21 */   public final NumberSetting knockbackHorizontal = (new NumberSetting((CharSequence)EncryptedString.of("Knockback Horizontal"), 0.0D, 1.0D, 0.0D, 0.01D))
/* 22 */     .setDescription((CharSequence)EncryptedString.of("How much horizontal knockback you will take."));
/*    */   
/* 24 */   public final NumberSetting knockbackVertical = (new NumberSetting((CharSequence)EncryptedString.of("Knockback Vertical"), 0.0D, 1.0D, 0.0D, 0.01D))
/* 25 */     .setDescription((CharSequence)EncryptedString.of("How much vertical knockback you will take."));
/*    */   
/* 27 */   public final BooleanSetting explosions = (new BooleanSetting("Explosions", true))
/* 28 */     .setDescription((CharSequence)EncryptedString.of("Modifies your knockback from explosions."));
/*    */   
/* 30 */   public final NumberSetting explosionsHorizontal = (new NumberSetting((CharSequence)EncryptedString.of("Explosions Horizontal"), 0.0D, 1.0D, 0.0D, 0.01D))
/* 31 */     .setDescription((CharSequence)EncryptedString.of("How much velocity you will take from explosions horizontally."));
/*    */   
/* 33 */   public final NumberSetting explosionsVertical = (new NumberSetting((CharSequence)EncryptedString.of("Explosions Vertical"), 0.0D, 1.0D, 0.0D, 0.01D))
/* 34 */     .setDescription((CharSequence)EncryptedString.of("How much velocity you will take from explosions vertically."));
/*    */   
/* 36 */   public final BooleanSetting liquids = (new BooleanSetting("Liquids", true))
/* 37 */     .setDescription((CharSequence)EncryptedString.of("Modifies the amount you are pushed by flowing liquids."));
/*    */   
/* 39 */   public final NumberSetting liquidsHorizontal = (new NumberSetting((CharSequence)EncryptedString.of("Liquids Horizontal"), 0.0D, 1.0D, 0.0D, 0.01D))
/* 40 */     .setDescription((CharSequence)EncryptedString.of("How much velocity you will take from liquids horizontally."));
/*    */   
/* 42 */   public final NumberSetting liquidsVertical = (new NumberSetting((CharSequence)EncryptedString.of("Liquids Vertical"), 0.0D, 1.0D, 0.0D, 0.01D))
/* 43 */     .setDescription((CharSequence)EncryptedString.of("How much velocity you will take from liquids vertically."));
/*    */   
/* 45 */   public final BooleanSetting entityPush = (new BooleanSetting("Entity Push", true))
/* 46 */     .setDescription((CharSequence)EncryptedString.of("Modifies the amount you are pushed by entities."));
/*    */   
/* 48 */   public final NumberSetting entityPushAmount = (new NumberSetting((CharSequence)EncryptedString.of("Entity Push Amount"), 0.0D, 1.0D, 0.0D, 0.01D))
/* 49 */     .setDescription((CharSequence)EncryptedString.of("How much you will be pushed."));
/*    */   
/* 51 */   public final BooleanSetting blocks = (new BooleanSetting("Blocks", true))
/* 52 */     .setDescription((CharSequence)EncryptedString.of("Prevents you from being pushed out of blocks."));
/*    */   
/* 54 */   public final BooleanSetting sinking = (new BooleanSetting("Sinking", false))
/* 55 */     .setDescription((CharSequence)EncryptedString.of("Prevents you from sinking in liquids."));
/*    */   
/* 57 */   public final BooleanSetting fishing = (new BooleanSetting("Fishing", false))
/* 58 */     .setDescription((CharSequence)EncryptedString.of("Prevents you from being pulled by fishing rods."));
/*    */   
/*    */   public Velocity() {
/* 61 */     super((CharSequence)EncryptedString.of("Velocity"), (CharSequence)EncryptedString.of("Prevents you from being moved by external forces."), -1, Category.COMBAT);
/* 62 */     addsettings(new Setting[] { (Setting)this.knockback, (Setting)this.knockbackHorizontal, (Setting)this.knockbackVertical, (Setting)this.explosions, (Setting)this.explosionsHorizontal, (Setting)this.explosionsVertical, (Setting)this.liquids, (Setting)this.liquidsHorizontal, (Setting)this.liquidsVertical, (Setting)this.entityPush, (Setting)this.entityPushAmount, (Setting)this.blocks, (Setting)this.sinking, (Setting)this.fishing });
/*    */   }
/*    */ 
/*    */   
/*    */   @EventListener
/*    */   private void onTick(TickEvent event) {
/* 68 */     if (!this.sinking.getValue())
/* 69 */       return;  if (this.mc.field_1690.field_1903.method_1434() || this.mc.field_1690.field_1832.method_1434())
/*    */       return; 
/* 71 */     if ((this.mc.field_1724.method_5799() || this.mc.field_1724.method_5771()) && (this.mc.field_1724.method_18798()).field_1351 < 0.0D) {
/* 72 */       ((IVec3d)this.mc.field_1724.method_18798()).setY(0.0D);
/*    */     }
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   private void onPacketReceive(PacketReceiveEvent event) {
/* 78 */     if (this.knockback.getValue()) { class_2596 class_2596 = event.packet; if (class_2596 instanceof class_2743) { class_2743 packet = (class_2743)class_2596; if (packet
/* 79 */           .method_11818() == this.mc.field_1724.method_5628()) {
/* 80 */           IEntityVelocityUpdateS2CPacket iPacket = (IEntityVelocityUpdateS2CPacket)packet;
/* 81 */           class_243 packetVel = iPacket.getVelocity();
/* 82 */           double velX = (packetVel.method_10216() - (this.mc.field_1724.method_18798()).field_1352) * this.knockbackHorizontal.getValue();
/* 83 */           double velY = (packetVel.method_10214() - (this.mc.field_1724.method_18798()).field_1351) * this.knockbackVertical.getValue();
/* 84 */           double velZ = (packetVel.method_10215() - (this.mc.field_1724.method_18798()).field_1350) * this.knockbackHorizontal.getValue();
/* 85 */           iPacket.setVelocity(new class_243(velX + 
/* 86 */                 (this.mc.field_1724.method_18798()).field_1352, velY + (this.mc.field_1724.method_18798()).field_1351, velZ + (this.mc.field_1724.method_18798()).field_1350));
/*    */         }  }
/*    */        }
/*    */   
/*    */   }
/*    */   public double getHorizontal(NumberSetting setting) {
/* 92 */     return isEnabled() ? setting.getValue() : 1.0D;
/*    */   }
/*    */   
/*    */   public double getVertical(NumberSetting setting) {
/* 96 */     return isEnabled() ? setting.getValue() : 1.0D;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\Velocity.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */