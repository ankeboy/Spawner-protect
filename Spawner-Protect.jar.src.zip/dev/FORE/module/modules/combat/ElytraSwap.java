/*     */ package dev.FORE.module.modules.combat;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BindSetting;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.InventoryUtil;
/*     */ import dev.FORE.utils.KeyUtils;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1304;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1713;
/*     */ import net.minecraft.class_1738;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1802;
/*     */ 
/*     */ public final class ElytraSwap extends Module {
/*  23 */   private final BindSetting activateKey = new BindSetting((CharSequence)EncryptedString.of("Activate Key"), 71, false);
/*  24 */   private final NumberSetting swapDelay = new NumberSetting((CharSequence)EncryptedString.of("Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  25 */   private final BooleanSetting switchBack = new BooleanSetting((CharSequence)EncryptedString.of("Switch Back"), true);
/*  26 */   private final NumberSetting switchDelay = new NumberSetting((CharSequence)EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  27 */   private final BooleanSetting moveToSlot = (new BooleanSetting((CharSequence)EncryptedString.of("Move to slot"), true)).setDescription("If elytra is not in hotbar it will move it from inventory to preferred slot");
/*  28 */   private final NumberSetting elytraSlot = (new NumberSetting((CharSequence)EncryptedString.of("Elytra Slot"), 1.0D, 9.0D, 9.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("Your preferred elytra slot"));
/*     */   private boolean isSwapping;
/*     */   private boolean isSwinging;
/*     */   private boolean isItemSwapped;
/*     */   private int swapCounter;
/*     */   private int switchCounter;
/*     */   private int activationCooldown;
/*     */   private int originalSlot;
/*     */   
/*     */   public ElytraSwap() {
/*  38 */     super((CharSequence)EncryptedString.of("Elytra Swap"), (CharSequence)EncryptedString.of("Seamlessly swap between an Elytra and a Chestplate with a configurable keybinding"), -1, Category.COMBAT);
/*  39 */     addsettings(new Setting[] { (Setting)this.activateKey, (Setting)this.swapDelay, (Setting)this.switchBack, (Setting)this.switchDelay, (Setting)this.moveToSlot, (Setting)this.elytraSlot });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  44 */     resetState();
/*  45 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  50 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  55 */     if (this.mc.field_1755 != null) {
/*     */       return;
/*     */     }
/*  58 */     if (this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/*  61 */     if (this.activationCooldown > 0) {
/*  62 */       this.activationCooldown--;
/*  63 */     } else if (KeyUtils.isKeyPressed(this.activateKey.getValue())) {
/*  64 */       this.isSwapping = true;
/*  65 */       this.activationCooldown = 4;
/*     */     } 
/*  67 */     if (this.isSwapping) {
/*  68 */       Predicate<class_1792> itemPredicate; if (this.originalSlot == -1) {
/*  69 */         this.originalSlot = (this.mc.field_1724.method_31548()).field_7545;
/*     */       }
/*  71 */       if (this.swapCounter < this.swapDelay.getIntValue()) {
/*  72 */         this.swapCounter++;
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  77 */       if (this.mc.field_1724.method_31548().method_7372(class_1304.field_6174.method_5927()).method_31574(class_1802.field_8833)) {
/*  78 */         itemPredicate = (item -> (item instanceof class_1738 && ((class_1738)item).method_7685() == class_1304.field_6174));
/*     */       } else {
/*  80 */         itemPredicate = (item -> item.equals(class_1802.field_8833));
/*     */       } 
/*     */       
/*  83 */       if (!this.isItemSwapped) {
/*  84 */         if (!InventoryUtil.swapItem(itemPredicate)) {
/*  85 */           if (!this.moveToSlot.getValue()) {
/*  86 */             resetState();
/*     */             
/*     */             return;
/*     */           } 
/*  90 */           this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 9, this.elytraSlot.getIntValue() - 1, class_1713.field_7791, (class_1657)this.mc.field_1724);
/*  91 */           this.swapCounter = 0;
/*     */           return;
/*     */         } 
/*  94 */         this.isItemSwapped = true;
/*     */       } 
/*     */       
/*  97 */       if (!this.isSwinging) {
/*  98 */         this.mc.field_1761.method_2919((class_1657)this.mc.field_1724, class_1268.field_5808);
/*  99 */         this.mc.field_1724.method_6104(class_1268.field_5808);
/* 100 */         this.isSwinging = true;
/*     */       } 
/* 102 */       if (this.switchBack.getValue()) {
/* 103 */         handleSwitchBack();
/*     */       } else {
/* 105 */         resetState();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleSwitchBack() {
/* 111 */     if (this.switchCounter < this.switchDelay.getIntValue()) {
/* 112 */       this.switchCounter++;
/*     */       return;
/*     */     } 
/* 115 */     InventoryUtil.swap(this.originalSlot);
/* 116 */     resetState();
/*     */   }
/*     */   
/*     */   private void resetState() {
/* 120 */     this.originalSlot = -1;
/* 121 */     this.switchCounter = 0;
/* 122 */     this.swapCounter = 0;
/* 123 */     this.isSwapping = false;
/* 124 */     this.isSwinging = false;
/* 125 */     this.isItemSwapped = false;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\ElytraSwap.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */