/*     */ package dev.FORE.module.modules.combat;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.modules.client.Friends;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1299;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_3532;
/*     */ import org.joml.Vector3d;
/*     */ 
/*     */ public class AimAssist
/*     */   extends Module
/*     */ {
/*  23 */   private final class_1299 entities = class_1299.field_6097;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  32 */   private final NumberSetting range = (new NumberSetting((CharSequence)EncryptedString.of("Range"), 0.0D, 10.0D, 5.0D, 0.1D)).getValue((CharSequence)EncryptedString.of("The range at which an entity can be targeted."));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  44 */   private final NumberSetting fov = (new NumberSetting((CharSequence)EncryptedString.of("Fov"), 0.0D, 360.0D, 360.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("Will only aim entities in the fov."));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  54 */   private final BooleanSetting ignoreWalls = new BooleanSetting("Ignore walls", true);
/*     */ 
/*     */   
/*  57 */   private final BooleanSetting instantLook = new BooleanSetting("Instant look", false);
/*  58 */   private final NumberSetting speed = (new NumberSetting((CharSequence)EncryptedString.of("Speed"), 0.0D, 20.0D, 5.0D, 0.1D)).getValue((CharSequence)EncryptedString.of("How fast to aim at the entity."));
/*  59 */   private final BooleanSetting aimAtHead = new BooleanSetting("Aim at head", false);
/*     */   
/*  61 */   private final Vector3d vec3d1 = new Vector3d();
/*     */   private class_1297 target;
/*     */   
/*     */   public AimAssist() {
/*  65 */     super((CharSequence)EncryptedString.of("Aim Assist"), (CharSequence)EncryptedString.of("When you get close to a player your aim sticks to the player."), -1, Category.COMBAT);
/*  66 */     addsettings(new Setting[] { (Setting)this.range, (Setting)this.fov, (Setting)this.ignoreWalls, (Setting)this.instantLook, (Setting)this.speed, (Setting)this.aimAtHead });
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   private void onTick(TickEvent event) {
/*     */     class_1657 class_1657;
/*  72 */     if (this.mc.field_1687 == null || this.mc.field_1724 == null)
/*     */       return; 
/*  74 */     class_1297 best = null;
/*  75 */     double bestDistSq = Double.MAX_VALUE;
/*     */     
/*  77 */     for (class_1657 p : this.mc.field_1687.method_18456()) {
/*  78 */       if (p == this.mc.field_1724 || 
/*  79 */         !p.method_5805() || 
/*  80 */         !Friends.getInstance().shouldAttack(p))
/*     */         continue; 
/*  82 */       double distSq = p.method_5858((class_1297)this.mc.field_1724);
/*  83 */       if (distSq > this.range.getValue() * this.range.getValue())
/*     */         continue; 
/*  85 */       if (!isInFov((class_1297)p, this.fov.getValue()))
/*     */         continue; 
/*  87 */       if (!this.ignoreWalls.getValue() && !this.mc.field_1724.method_6057((class_1297)p))
/*     */         continue; 
/*  89 */       if (distSq < bestDistSq) {
/*  90 */         bestDistSq = distSq;
/*  91 */         class_1657 = p;
/*     */       } 
/*     */     } 
/*     */     
/*  95 */     this.target = (class_1297)class_1657;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   private void onRender(Render3DEvent event) {
/* 100 */     if (this.mc.field_1724 == null || this.target == null)
/* 101 */       return;  if (this.target != null) aim(this.target, event.tickDelta, this.instantLook.getValue()); 
/*     */   }
/*     */   
/*     */   private void aim(class_1297 target, double delta, boolean instant) {
/* 105 */     class_243 lerp = getEntityLerpedPos(target, (float)delta);
/* 106 */     this.vec3d1.set(lerp.field_1352, lerp.field_1351, lerp.field_1350);
/*     */     
/* 108 */     if (this.aimAtHead.getValue()) { this.vec3d1.add(0.0D, target.method_18381(target.method_18376()), 0.0D); }
/* 109 */     else { this.vec3d1.add(0.0D, (target.method_18381(target.method_18376()) / 2.0F), 0.0D); }
/*     */     
/* 111 */     double deltaX = this.vec3d1.x - this.mc.field_1724.method_23317();
/* 112 */     double deltaZ = this.vec3d1.z - this.mc.field_1724.method_23321();
/* 113 */     double deltaY = this.vec3d1.y - this.mc.field_1724.method_23318() + this.mc.field_1724.method_18381(this.mc.field_1724.method_18376());
/*     */ 
/*     */     
/* 116 */     double angle = Math.toDegrees(Math.atan2(deltaZ, deltaX)) - 90.0D;
/*     */ 
/*     */ 
/*     */     
/* 120 */     if (instant) {
/* 121 */       this.mc.field_1724.method_36456((float)angle);
/*     */     } else {
/* 123 */       double deltaAngle = class_3532.method_15338(angle - this.mc.field_1724.method_36454());
/* 124 */       double toRotate = this.speed.getValue() * ((deltaAngle >= 0.0D) ? true : -1) * delta;
/* 125 */       if ((toRotate >= 0.0D && toRotate > deltaAngle) || (toRotate < 0.0D && toRotate < deltaAngle))
/* 126 */         toRotate = deltaAngle; 
/* 127 */       this.mc.field_1724.method_36456(this.mc.field_1724.method_36454() + (float)toRotate);
/*     */     } 
/*     */ 
/*     */     
/* 131 */     double idk = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
/* 132 */     angle = -Math.toDegrees(Math.atan2(deltaY, idk));
/*     */     
/* 134 */     if (instant) {
/* 135 */       this.mc.field_1724.method_36457((float)angle);
/*     */     } else {
/* 137 */       double deltaAngle = class_3532.method_15338(angle - this.mc.field_1724.method_36455());
/* 138 */       double toRotate = this.speed.getValue() * ((deltaAngle >= 0.0D) ? true : -1) * delta;
/* 139 */       if ((toRotate >= 0.0D && toRotate > deltaAngle) || (toRotate < 0.0D && toRotate < deltaAngle))
/* 140 */         toRotate = deltaAngle; 
/* 141 */       this.mc.field_1724.method_36457(this.mc.field_1724.method_36455() + (float)toRotate);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String getInfoString() {
/* 147 */     return (this.target != null) ? this.target.method_5477().getString() : null;
/*     */   }
/*     */   
/*     */   private boolean isInFov(class_1297 entity, double fovDeg) {
/* 151 */     double dx = entity.method_23317() - this.mc.field_1724.method_23317();
/* 152 */     double dz = entity.method_23321() - this.mc.field_1724.method_23321();
/* 153 */     double targetYaw = Math.toDegrees(Math.atan2(dz, dx)) - 90.0D;
/* 154 */     double diff = class_3532.method_15338(targetYaw - this.mc.field_1724.method_36454());
/* 155 */     return (Math.abs(diff) <= fovDeg / 2.0D);
/*     */   }
/*     */   
/*     */   private class_243 getEntityLerpedPos(class_1297 entity, float tickDelta) {
/*     */     try {
/* 160 */       return entity.method_30950(tickDelta);
/* 161 */     } catch (Throwable t) {
/* 162 */       return entity.method_19538();
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\AimAssist.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */