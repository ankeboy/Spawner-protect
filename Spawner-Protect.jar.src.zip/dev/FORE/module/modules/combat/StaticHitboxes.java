/*    */ package dev.FORE.module.modules.combat;
/*    */ 
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TargetPoseEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_4050;
/*    */ 
/*    */ public final class StaticHitboxes extends Module {
/*    */   public StaticHitboxes() {
/* 13 */     super((CharSequence)EncryptedString.of("Static HitBoxes"), (CharSequence)EncryptedString.of("Expands a Player's Hitbox"), -1, Category.COMBAT);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 18 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 23 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTargetPose(TargetPoseEvent targetPoseEvent) {
/* 28 */     if (isEnabled() && targetPoseEvent.entity instanceof class_1657 && !((class_1657)targetPoseEvent.entity).method_7340())
/* 29 */       targetPoseEvent.cir.setReturnValue(class_4050.field_18076); 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\StaticHitboxes.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */