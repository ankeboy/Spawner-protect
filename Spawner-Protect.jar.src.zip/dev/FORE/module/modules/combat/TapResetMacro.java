/*    */ package dev.FORE.module.modules.combat;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.AttackEvent;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_239;
/*    */ import net.minecraft.class_3966;
/*    */ 
/*    */ public class TapResetMacro extends Module {
/* 17 */   private final BooleanSetting sTap = (new BooleanSetting((CharSequence)EncryptedString.of("S-Tap"), true))
/* 18 */     .setDescription((CharSequence)EncryptedString.of("Briefly presses S after hitting a player."));
/*    */   
/* 20 */   private final NumberSetting tapDuration = (new NumberSetting((CharSequence)EncryptedString.of("Tap Duration"), 10.0D, 500.0D, 100.0D, 1.0D))
/* 21 */     .setDescription((CharSequence)EncryptedString.of("Length of the tap in milliseconds."));
/*    */   
/*    */   private long tapTime;
/*    */   private boolean tapping;
/*    */   
/*    */   public TapResetMacro() {
/* 27 */     super((CharSequence)EncryptedString.of("Auto W Tap"), (CharSequence)EncryptedString.of("Performs an S-tap after connecting a hit."), -1, Category.COMBAT);
/* 28 */     addsettings(new Setting[] { (Setting)this.sTap, (Setting)this.tapDuration });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 33 */     stopTap();
/* 34 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   private void onAttack(AttackEvent event) {
/* 39 */     if (!canTap())
/* 40 */       return;  class_1657 target = getLookedAtPlayer();
/* 41 */     if (target == null)
/*    */       return; 
/* 43 */     startTap();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   private void onTick(TickEvent event) {
/* 48 */     if (!this.tapping || this.mc.field_1690 == null)
/*    */       return; 
/* 50 */     if (System.currentTimeMillis() - this.tapTime >= this.tapDuration.getLongValue()) {
/* 51 */       stopTap();
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void triggerExternalTap(class_1657 target) {
/* 59 */     if (!canTap() || target == null || !target.method_5805() || target == this.mc.field_1724)
/* 60 */       return;  startTap();
/*    */   }
/*    */   
/*    */   private boolean canTap() {
/* 64 */     return (isEnabled() && this.sTap.getValue() && this.mc.field_1724 != null && this.mc.field_1690 != null);
/*    */   }
/*    */   
/*    */   private class_1657 getLookedAtPlayer() {
/* 68 */     class_239 hitResult = this.mc.field_1765;
/* 69 */     if (hitResult instanceof class_3966) { class_3966 entityHitResult = (class_3966)hitResult;
/* 70 */       class_1297 target = entityHitResult.method_17782();
/* 71 */       if (target instanceof class_1657) { class_1657 player = (class_1657)target; if (target != this.mc.field_1724 && target.method_5805()) {
/* 72 */           return player;
/*    */         } }
/*    */        }
/*    */     
/* 76 */     class_1297 class_1297 = this.mc.field_1692; if (class_1297 instanceof class_1657) { class_1657 player = (class_1657)class_1297; if (player != this.mc.field_1724 && player.method_5805()) {
/* 77 */         return player;
/*    */       } }
/*    */     
/* 80 */     return null;
/*    */   }
/*    */   
/*    */   private void startTap() {
/* 84 */     this.tapTime = System.currentTimeMillis();
/* 85 */     this.tapping = true;
/* 86 */     this.mc.field_1690.field_1881.method_23481(true);
/*    */   }
/*    */   
/*    */   private void stopTap() {
/* 90 */     this.tapping = false;
/* 91 */     if (this.mc.field_1690 != null)
/* 92 */       this.mc.field_1690.field_1881.method_23481(false); 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\combat\TapResetMacro.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */