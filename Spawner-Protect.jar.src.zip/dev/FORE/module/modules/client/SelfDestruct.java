/*     */ package dev.FORE.module.modules.client;
/*     */ 
/*     */ import com.sun.jna.Memory;
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.module.setting.StringSetting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.Utils;
/*     */ import java.io.File;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.InputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.nio.file.CopyOption;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.StandardCopyOption;
/*     */ import net.minecraft.class_2561;
/*     */ 
/*     */ public final class SelfDestruct extends Module {
/*     */   public static boolean isActive = false;
/*     */   public static boolean hasSelfDestructed = false;
/*  25 */   private final BooleanSetting replaceMod = (new BooleanSetting((CharSequence)EncryptedString.of("Replace Mod"), true)).setDescription((CharSequence)EncryptedString.of("Replaces the mod with the specified JAR file"));
/*  26 */   private final BooleanSetting saveLastModified = (new BooleanSetting((CharSequence)EncryptedString.of("Save Last Modified"), true)).setDescription((CharSequence)EncryptedString.of("Saves the last modified date after self destruct"));
/*  27 */   private final StringSetting replaceUrl = new StringSetting((CharSequence)EncryptedString.of("Replace URL"), "https://cdn.modrinth.com/data/8shC1gFX/versions/sXO3idkS/BetterF3-11.0.1-Fabric-1.21.jar");
/*     */ 
/*     */   
/*     */   public SelfDestruct() {
/*  31 */     super((CharSequence)EncryptedString.of("Self Destruct"), (CharSequence)EncryptedString.of("Removes the client from your game |Credits to Argon for deletion|"), -1, Category.CLIENT);
/*  32 */     addsettings(new Setting[] { (Setting)this.replaceMod, (Setting)this.saveLastModified, (Setting)this.replaceUrl });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  37 */     isActive = true;
/*  38 */     hasSelfDestructed = true;
/*     */ 
/*     */     
/*     */     try {
/*  42 */       Thread.sleep(100L);
/*  43 */     } catch (InterruptedException interruptedException) {}
/*     */ 
/*     */ 
/*     */     
/*  47 */     DonutBBC.INSTANCE.getModuleManager().getModuleByClass(DonutBBC.class).toggle(false);
/*  48 */     toggle(false);
/*  49 */     DonutBBC.INSTANCE.getConfigManager().shutdown();
/*  50 */     if (this.mc.field_1755 instanceof dev.FORE.gui.ClickGUI) {
/*  51 */       DonutBBC.INSTANCE.shouldPreventClose = false;
/*  52 */       this.mc.field_1755.method_25419();
/*     */     } 
/*     */ 
/*     */     
/*  56 */     if (this.replaceMod.getValue()) {
/*  57 */       scheduleModReplacement();
/*     */     }
/*     */ 
/*     */     
/*  61 */     for (Module module : DonutBBC.INSTANCE.getModuleManager().c()) {
/*  62 */       module.toggle(false);
/*  63 */       module.setName(null);
/*  64 */       module.setDescription(null);
/*  65 */       for (Setting setting : module.getSettings()) {
/*  66 */         setting.getDescription(null);
/*  67 */         setting.setDescription(null);
/*  68 */         if (!(setting instanceof StringSetting))
/*  69 */           continue;  ((StringSetting)setting).setValue(null);
/*     */       } 
/*  71 */       module.getSettings().clear();
/*     */     } 
/*     */ 
/*     */     
/*  75 */     if (this.saveLastModified.getValue()) {
/*  76 */       DonutBBC.INSTANCE.resetModifiedDate();
/*     */     }
/*     */ 
/*     */     
/*  80 */     Thread memoryCleanupThread = new Thread(() -> {
/*     */           Runtime runtime = Runtime.getRuntime();
/*     */           for (int i = 0; i <= 10; i++) {
/*     */             runtime.gc();
/*     */             try {
/*     */               Thread.sleep((100 * i));
/*     */               Memory.purge();
/*     */               Memory.disposeAll();
/*  88 */             } catch (InterruptedException interruptedException) {
/*     */             
/*  90 */             } catch (Exception exception) {}
/*     */           } 
/*     */         }"MemoryCleanup");
/*     */ 
/*     */     
/*  95 */     memoryCleanupThread.setDaemon(true);
/*  96 */     memoryCleanupThread.start();
/*     */ 
/*     */     
/*  99 */     if (this.mc.field_1724 != null) {
/* 100 */       this.mc.field_1724.method_43496((class_2561)class_2561.method_43470("§c§l[SelfDestruct] §rClient has been cleared. Game will continue running."));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void scheduleModReplacement() {
/* 106 */     Thread replacementThread = new Thread(() -> {
/*     */           try {
/*     */             String downloadUrl = this.replaceUrl.getValue();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             File currentJar = Utils.getCurrentJarPath();
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (currentJar == null || !currentJar.exists() || !currentJar.isFile()) {
/*     */               return;
/*     */             }
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             File tempFile = new File(currentJar.getParentFile(), currentJar.getName() + ".tmp");
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             if (downloadModFile(downloadUrl, tempFile)) {
/*     */               Runtime.getRuntime().addShutdownHook(new Thread((), "ModReplacementHook"));
/*     */             }
/* 133 */           } catch (Exception exception) {}
/*     */         }"ModReplacementDownload");
/*     */ 
/*     */ 
/*     */     
/* 138 */     replacementThread.setDaemon(true);
/* 139 */     replacementThread.start();
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean downloadModFile(String downloadUrl, File targetFile) {
/*     */     try {
/* 145 */       URL url = new URL(downloadUrl);
/* 146 */       HttpURLConnection connection = (HttpURLConnection)url.openConnection();
/* 147 */       connection.setRequestMethod("GET");
/* 148 */       connection.setConnectTimeout(10000);
/* 149 */       connection.setReadTimeout(30000);
/* 150 */       connection.setInstanceFollowRedirects(true);
/*     */ 
/*     */       
/* 153 */       int responseCode = connection.getResponseCode();
/* 154 */       if (responseCode != 200) {
/* 155 */         connection.disconnect();
/* 156 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 160 */       InputStream inputStream = connection.getInputStream(); 
/* 161 */       try { FileOutputStream outputStream = new FileOutputStream(targetFile);
/*     */         
/* 163 */         try { byte[] buffer = new byte[8192];
/*     */           
/*     */           int bytesRead;
/* 166 */           while ((bytesRead = inputStream.read(buffer)) != -1) {
/* 167 */             outputStream.write(buffer, 0, bytesRead);
/*     */           }
/*     */           
/* 170 */           outputStream.flush();
/* 171 */           outputStream.close(); } catch (Throwable throwable) { try { outputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }  if (inputStream != null) inputStream.close();  } catch (Throwable throwable) { if (inputStream != null)
/*     */           try { inputStream.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/* 173 */        connection.disconnect();
/* 174 */       return true;
/*     */     }
/* 176 */     catch (Exception e) {
/*     */       
/* 178 */       return false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\client\SelfDestruct.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */