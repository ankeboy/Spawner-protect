/*    */ package dev.FORE.module.modules.client;
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.module.setting.StringSetting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ 
/*    */ public final class ConfigDebug extends Module {
/* 12 */   private final BooleanSetting testBoolean = (new BooleanSetting((CharSequence)EncryptedString.of("Test Boolean"), false))
/* 13 */     .setDescription((CharSequence)EncryptedString.of("Test boolean setting"));
/*    */   
/* 15 */   private final NumberSetting testNumber = (new NumberSetting((CharSequence)EncryptedString.of("Test Number"), 1.0D, 100.0D, 50.0D, 1.0D))
/* 16 */     .setDescription((CharSequence)EncryptedString.of("Test number setting"));
/*    */   
/* 18 */   private final StringSetting testString = (new StringSetting((CharSequence)EncryptedString.of("Test String"), "Default Value"))
/* 19 */     .setDescription((CharSequence)EncryptedString.of("Test string setting"));
/*    */   
/*    */   public ConfigDebug() {
/* 22 */     super((CharSequence)EncryptedString.of("Config Debug"), 
/* 23 */         (CharSequence)EncryptedString.of("Debug module for testing config saving"), -1, Category.CLIENT);
/*    */ 
/*    */     
/* 26 */     addsettings(new Setting[] { (Setting)this.testBoolean, (Setting)this.testNumber, (Setting)this.testString });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 31 */     System.out.println("[ConfigDebug] Module enabled - testing config saving...");
/*    */ 
/*    */     
/* 34 */     this.testBoolean.setValue(true);
/* 35 */     this.testNumber.getValue(75.0D);
/* 36 */     this.testString.setValue("Test Value Changed");
/*    */ 
/*    */     
/* 39 */     DonutBBC.INSTANCE.getConfigManager().manualSave();
/*    */     
/* 41 */     System.out.println("[ConfigDebug] Config save test completed. Check console for results.");
/*    */ 
/*    */     
/* 44 */     toggle();
/*    */   }
/*    */   
/*    */   public void onDisable() {}
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\client\ConfigDebug.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */