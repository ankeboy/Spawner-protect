/*    */ package dev.FORE.module.modules.client;
/*    */ 
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.FriendsSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import java.util.List;
/*    */ import net.minecraft.class_1657;
/*    */ 
/*    */ public final class Friends
/*    */   extends Module {
/*    */   public static Friends instance;
/* 15 */   private final FriendsSetting list = new FriendsSetting((CharSequence)EncryptedString.of("Friends"));
/* 16 */   private final BooleanSetting shouldnotusetriggerbotonfriend = new BooleanSetting((CharSequence)EncryptedString.of("Dont TriggerBot"), true);
/* 17 */   private final BooleanSetting shouldnotusekillauraonfriend = new BooleanSetting((CharSequence)EncryptedString.of("Dont Killaura/AimAssist"), true);
/*    */ 
/*    */   
/*    */   public Friends() {
/* 21 */     super((CharSequence)EncryptedString.of("Friends"), (CharSequence)EncryptedString.of("To add some friends if u have any"), -1, Category.CLIENT);
/* 22 */     addsettings(new Setting[] { (Setting)this.list });
/*    */ 
/*    */     
/* 25 */     instance = this;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 31 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 36 */     super.onDisable();
/*    */   }
/*    */ 
/*    */   
/*    */   public static Friends getInstance() {
/* 41 */     if (instance == null) {
/* 42 */       instance = new Friends();
/*    */     }
/* 44 */     return instance;
/*    */   }
/*    */   public List<String> getFriends() {
/* 47 */     return this.list.getFriends();
/*    */   }
/*    */   
/*    */   public boolean shouldAttack(class_1657 entity) {
/* 51 */     if (!this.shouldnotusekillauraonfriend.getValue()) {
/* 52 */       String playerName = entity.method_5477().getString();
/* 53 */       return !this.list.isFriend(playerName);
/*    */     } 
/* 55 */     return true;
/*    */   }
/*    */   
/*    */   public boolean Shouldnottriggerbot() {
/* 59 */     return this.shouldnotusetriggerbotonfriend.getValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\client\Friends.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */