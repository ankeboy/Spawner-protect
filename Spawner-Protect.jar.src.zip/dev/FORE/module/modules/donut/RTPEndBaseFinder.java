/*     */ package dev.FORE.module.modules.donut;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.module.setting.StringSetting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.embed.DiscordWebhook;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Objects;
/*     */ import java.util.Set;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import java.util.concurrent.Executors;
/*     */ import java.util.concurrent.TimeUnit;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2586;
/*     */ import net.minecraft.class_2591;
/*     */ import net.minecraft.class_2661;
/*     */ import net.minecraft.class_2818;
/*     */ 
/*     */ public final class RTPEndBaseFinder extends Module {
/*  29 */   private final NumberSetting minimumStorageCount = (new NumberSetting((CharSequence)EncryptedString.of("Minimum Storage Count"), 1.0D, 100.0D, 4.0D, 1.0D))
/*  30 */     .setDescription((CharSequence)EncryptedString.of("The minimum amount of storage blocks in a chunk to record the chunk (spawners ignore this limit)"));
/*     */   
/*  32 */   private final BooleanSetting criticalSpawner = (new BooleanSetting((CharSequence)EncryptedString.of("Critical Spawner"), true))
/*  33 */     .setDescription((CharSequence)EncryptedString.of("Mark chunk as stash even if only a single spawner is found"));
/*     */   
/*  35 */   private final NumberSetting rtpInterval = (new NumberSetting((CharSequence)EncryptedString.of("RTP Interval"), 5.0D, 60.0D, 10.0D, 1.0D))
/*  36 */     .setDescription((CharSequence)EncryptedString.of("Interval between RTP commands in seconds"));
/*     */   
/*  38 */   private final BooleanSetting disconnectOnBaseFind = (new BooleanSetting((CharSequence)EncryptedString.of("Disconnect on Base Find"), true))
/*  39 */     .setDescription((CharSequence)EncryptedString.of("Automatically disconnect when a base is found"));
/*     */   
/*  41 */   private final BooleanSetting lookDown = (new BooleanSetting((CharSequence)EncryptedString.of("Look Down"), true))
/*  42 */     .setDescription((CharSequence)EncryptedString.of("Automatically look down to avoid enderman aggro"));
/*     */   
/*  44 */   private final BooleanSetting sendNotifications = (new BooleanSetting((CharSequence)EncryptedString.of("Notifications"), true))
/*  45 */     .setDescription((CharSequence)EncryptedString.of("Sends Minecraft notifications when new stashes are found"));
/*     */   
/*  47 */   private final BooleanSetting enableWebhook = (new BooleanSetting((CharSequence)EncryptedString.of("Webhook"), false))
/*  48 */     .setDescription((CharSequence)EncryptedString.of("Send webhook notifications when stashes are found"));
/*     */   
/*  50 */   private final StringSetting webhookUrl = (new StringSetting((CharSequence)EncryptedString.of("Webhook URL"), ""))
/*  51 */     .setDescription((CharSequence)EncryptedString.of("Discord webhook URL"));
/*     */   
/*  53 */   private final BooleanSetting selfPing = (new BooleanSetting((CharSequence)EncryptedString.of("Self Ping"), false))
/*  54 */     .setDescription((CharSequence)EncryptedString.of("Ping yourself in the webhook message"));
/*     */   
/*  56 */   private final StringSetting discordId = (new StringSetting((CharSequence)EncryptedString.of("Discord ID"), ""))
/*  57 */     .setDescription((CharSequence)EncryptedString.of("Your Discord user ID for pinging"));
/*     */ 
/*     */   
/*  60 */   private final NumberSetting scanInterval = (new NumberSetting((CharSequence)EncryptedString.of("Scan Interval"), 1.0D, 20.0D, 5.0D, 1.0D))
/*  61 */     .setDescription((CharSequence)EncryptedString.of("Interval between chunk scans in ticks (higher = less lag)"));
/*     */   
/*  63 */   private final NumberSetting maxChunksPerScan = (new NumberSetting((CharSequence)EncryptedString.of("Max Chunks Per Scan"), 1.0D, 10.0D, 3.0D, 1.0D))
/*  64 */     .setDescription((CharSequence)EncryptedString.of("Maximum chunks to scan per tick (lower = less lag)"));
/*     */   
/*  66 */   private final BooleanSetting enableSpawnerCheck = (new BooleanSetting((CharSequence)EncryptedString.of("Enable Spawner Check"), true))
/*  67 */     .setDescription((CharSequence)EncryptedString.of("Check for spawners (disable for maximum performance)"));
/*     */   
/*  69 */   public List<EndStashChunk> foundStashes = new ArrayList<>();
/*  70 */   private final Set<class_1923> processedChunks = new HashSet<>();
/*  71 */   private long lastRtpTime = 0L;
/*  72 */   private Float originalPitch = null;
/*     */ 
/*     */   
/*  75 */   private int scanTickCounter = 0;
/*  76 */   private final Queue<class_1923> chunksToScan = new LinkedList<>();
/*  77 */   private final Set<class_1923> chunksInQueue = new HashSet<>();
/*  78 */   private long lastPerformanceCheck = 0L;
/*  79 */   private int chunksScannedThisSecond = 0;
/*     */   
/*     */   public RTPEndBaseFinder() {
/*  82 */     super((CharSequence)EncryptedString.of("RTP End Base Finder"), 
/*  83 */         (CharSequence)EncryptedString.of("Continuously RTPs to the End and searches for stashes"), -1, Category.DONUT);
/*     */ 
/*     */     
/*  86 */     addsettings(new Setting[] { (Setting)this.minimumStorageCount, (Setting)this.criticalSpawner, (Setting)this.rtpInterval, (Setting)this.disconnectOnBaseFind, (Setting)this.lookDown, (Setting)this.sendNotifications, (Setting)this.enableWebhook, (Setting)this.webhookUrl, (Setting)this.selfPing, (Setting)this.discordId, (Setting)this.scanInterval, (Setting)this.maxChunksPerScan, (Setting)this.enableSpawnerCheck });
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  93 */     this.foundStashes.clear();
/*  94 */     this.processedChunks.clear();
/*  95 */     this.lastRtpTime = 0L;
/*  96 */     this.scanTickCounter = 0;
/*  97 */     this.chunksToScan.clear();
/*  98 */     this.chunksInQueue.clear();
/*     */     
/* 100 */     if (this.lookDown.getValue() && this.mc.field_1724 != null) {
/* 101 */       this.originalPitch = Float.valueOf(this.mc.field_1724.method_36455());
/*     */     }
/*     */     
/* 104 */     System.out.println("Started RTP End Base Finder");
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 109 */     this.processedChunks.clear();
/* 110 */     this.chunksToScan.clear();
/* 111 */     this.chunksInQueue.clear();
/*     */     
/* 113 */     if (this.originalPitch != null && this.mc.field_1724 != null) {
/* 114 */       this.mc.field_1724.method_36457(this.originalPitch.floatValue());
/* 115 */       this.originalPitch = null;
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent tickEvent) {
/* 121 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
/* 122 */       if (isEnabled()) {
/* 123 */         toggle();
/*     */       }
/*     */       
/*     */       return;
/*     */     } 
/* 128 */     if (this.lookDown.getValue()) {
/* 129 */       this.mc.field_1724.method_36457(90.0F);
/*     */     }
/*     */     
/* 132 */     long currentTime = System.currentTimeMillis();
/* 133 */     if (currentTime - this.lastRtpTime >= this.rtpInterval.getIntValue() * 1000L) {
/* 134 */       this.mc.field_1724.field_3944.method_45730("rtp end");
/* 135 */       this.lastRtpTime = currentTime;
/*     */     } 
/*     */ 
/*     */     
/* 139 */     this.scanTickCounter++;
/* 140 */     if (this.scanTickCounter >= this.scanInterval.getIntValue()) {
/* 141 */       this.scanTickCounter = 0;
/* 142 */       updateChunkQueue();
/* 143 */       scanQueuedChunks();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void updateChunkQueue() {
/* 148 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
/*     */       return;
/*     */     }
/* 151 */     for (class_2818 worldChunk : BlockUtil.getLoadedChunks().toList()) {
/* 152 */       class_1923 chunkPos = worldChunk.method_12004();
/* 153 */       if (!this.processedChunks.contains(chunkPos) && !this.chunksInQueue.contains(chunkPos)) {
/* 154 */         this.chunksToScan.offer(chunkPos);
/* 155 */         this.chunksInQueue.add(chunkPos);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scanQueuedChunks() {
/* 161 */     int chunksScanned = 0;
/* 162 */     int maxChunks = this.maxChunksPerScan.getIntValue();
/*     */     
/* 164 */     while (!this.chunksToScan.isEmpty() && chunksScanned < maxChunks) {
/* 165 */       class_1923 chunkPos = this.chunksToScan.poll();
/* 166 */       this.chunksInQueue.remove(chunkPos);
/*     */       
/* 168 */       if (chunkPos != null && this.mc.field_1687.method_8393(chunkPos.field_9181, chunkPos.field_9180)) {
/* 169 */         class_2818 worldChunk = this.mc.field_1687.method_8497(chunkPos.field_9181, chunkPos.field_9180);
/* 170 */         if (worldChunk != null) {
/* 171 */           scanSingleChunk(worldChunk);
/*     */         }
/*     */       } 
/*     */       
/* 175 */       chunksScanned++;
/* 176 */       this.chunksScannedThisSecond++;
/*     */     } 
/*     */ 
/*     */     
/* 180 */     long currentTime = System.currentTimeMillis();
/* 181 */     if (currentTime - this.lastPerformanceCheck >= 1000L) {
/* 182 */       if (this.chunksScannedThisSecond > 0) {
/* 183 */         System.out.println("[RTPEndBaseFinder] Performance: " + this.chunksScannedThisSecond + " chunks scanned in last second");
/*     */       }
/* 185 */       this.chunksScannedThisSecond = 0;
/* 186 */       this.lastPerformanceCheck = currentTime;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void scanSingleChunk(class_2818 worldChunk) {
/* 191 */     class_1923 chunkPos = worldChunk.method_12004();
/* 192 */     if (this.processedChunks.contains(chunkPos))
/*     */       return; 
/* 194 */     EndStashChunk chunk = new EndStashChunk(chunkPos);
/* 195 */     boolean hasSpawner = false;
/*     */ 
/*     */     
/* 198 */     if (this.enableSpawnerCheck.getValue()) {
/* 199 */       for (class_2586 blockEntity : worldChunk.method_12214().values()) {
/* 200 */         if (blockEntity instanceof net.minecraft.class_2636) {
/* 201 */           chunk.spawners++;
/* 202 */           hasSpawner = true;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 207 */       if (!hasSpawner && this.criticalSpawner.getValue()) {
/* 208 */         hasSpawner = quickSpawnerCheck(worldChunk);
/* 209 */         if (hasSpawner) {
/* 210 */           chunk.spawners++;
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 216 */     for (class_2586 blockEntity : worldChunk.method_12214().values()) {
/* 217 */       class_2591<?> type = blockEntity.method_11017();
/*     */       
/* 219 */       if (isStorageBlock(type)) {
/* 220 */         if (blockEntity instanceof net.minecraft.class_2595) {
/* 221 */           chunk.chests++; continue;
/* 222 */         }  if (blockEntity instanceof net.minecraft.class_3719) {
/* 223 */           chunk.barrels++; continue;
/* 224 */         }  if (blockEntity instanceof net.minecraft.class_2627) {
/* 225 */           chunk.shulkers++; continue;
/* 226 */         }  if (blockEntity instanceof net.minecraft.class_2611) {
/* 227 */           chunk.enderChests++; continue;
/* 228 */         }  if (blockEntity instanceof net.minecraft.class_2609) {
/* 229 */           chunk.furnaces++; continue;
/* 230 */         }  if (blockEntity instanceof net.minecraft.class_2601) {
/* 231 */           chunk.dispensersDroppers++; continue;
/* 232 */         }  if (blockEntity instanceof net.minecraft.class_2614) {
/* 233 */           chunk.hoppers++;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 238 */     boolean isStash = false;
/* 239 */     boolean isCriticalSpawner = false;
/* 240 */     String detectionReason = "";
/*     */     
/* 242 */     if (this.criticalSpawner.getValue() && hasSpawner) {
/* 243 */       isStash = true;
/* 244 */       isCriticalSpawner = true;
/* 245 */       detectionReason = "Spawner(s) detected (Critical mode)";
/* 246 */     } else if (chunk.getTotalNonSpawner() >= this.minimumStorageCount.getIntValue()) {
/* 247 */       isStash = true;
/* 248 */       detectionReason = "Storage threshold reached (" + chunk.getTotalNonSpawner() + " blocks)";
/*     */     } 
/*     */     
/* 251 */     if (isStash) {
/* 252 */       this.processedChunks.add(chunkPos);
/*     */       
/* 254 */       EndStashChunk prevChunk = null;
/* 255 */       int existingIndex = this.foundStashes.indexOf(chunk);
/*     */       
/* 257 */       if (existingIndex < 0) {
/* 258 */         this.foundStashes.add(chunk);
/*     */       } else {
/* 260 */         prevChunk = this.foundStashes.set(existingIndex, chunk);
/*     */       } 
/*     */       
/* 263 */       if (this.sendNotifications.getValue() && (!chunk.equals(prevChunk) || !chunk.countsEqual(prevChunk))) {
/* 264 */         String stashType = isCriticalSpawner ? "End spawner base" : "End stash";
/* 265 */         System.out.println("Found " + stashType + " at " + chunk.x + ", " + chunk.z + ". " + detectionReason);
/*     */       } 
/*     */       
/* 268 */       if (this.enableWebhook.getValue() && (!chunk.equals(prevChunk) || !chunk.countsEqual(prevChunk))) {
/* 269 */         sendWebhookNotification(chunk, isCriticalSpawner, detectionReason);
/*     */       }
/*     */       
/* 272 */       if (this.disconnectOnBaseFind.getValue()) {
/* 273 */         String stashTypeForDisconnect = isCriticalSpawner ? "End spawner base" : "End stash";
/* 274 */         disconnectPlayer(stashTypeForDisconnect, chunk);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean quickSpawnerCheck(class_2818 worldChunk) {
/* 281 */     class_1923 chunkPos = worldChunk.method_12004();
/* 282 */     int xStart = chunkPos.method_8326();
/* 283 */     int zStart = chunkPos.method_8328();
/*     */ 
/*     */     
/* 286 */     int[] checkY = { 8, 16, 24, 32, 40, 48, 56, 64 };
/* 287 */     int[] checkX = { 2, 6, 10, 14 };
/* 288 */     int[] checkZ = { 2, 6, 10, 14 };
/*     */     
/* 290 */     for (int y : checkY) {
/* 291 */       for (int x : checkX) {
/* 292 */         for (int z : checkZ) {
/* 293 */           class_2338 pos = new class_2338(xStart + x, y, zStart + z);
/*     */           try {
/* 295 */             if (this.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10260) {
/* 296 */               return true;
/*     */             }
/* 298 */           } catch (Exception exception) {}
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 304 */     return false;
/*     */   }
/*     */   
/*     */   private boolean isStorageBlock(class_2591<?> type) {
/* 308 */     return (type == class_2591.field_11914 || type == class_2591.field_16411 || type == class_2591.field_11896 || type == class_2591.field_11901 || type == class_2591.field_11903 || type == class_2591.field_16415 || type == class_2591.field_16414 || type == class_2591.field_11887 || type == class_2591.field_11899 || type == class_2591.field_11888);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void disconnectPlayer(String stashType, EndStashChunk chunk) {
/* 321 */     System.out.println("Disconnecting due to " + stashType + " found at " + chunk.x + ", " + chunk.z);
/*     */     
/* 323 */     toggle();
/*     */     
/* 325 */     Executors.newSingleThreadScheduledExecutor().schedule(() -> { if (this.mc.field_1724 != null) this.mc.field_1724.field_3944.method_52781(new class_2661((class_2561)class_2561.method_43470("END STASH FOUND AT " + chunk.x + ", " + chunk.z + "!")));  }1L, TimeUnit.SECONDS);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void sendWebhookNotification(EndStashChunk chunk, boolean isCriticalSpawner, String detectionReason) {
/* 335 */     String url = this.webhookUrl.getValue().trim();
/* 336 */     if (url.isEmpty()) {
/* 337 */       System.out.println("Webhook URL not configured!");
/*     */       
/*     */       return;
/*     */     } 
/* 341 */     CompletableFuture.runAsync(() -> {
/*     */           try {
/*     */             String serverInfo = (this.mc.method_1558() != null) ? (this.mc.method_1558()).field_3761 : "Unknown Server";
/*     */             
/*     */             String messageContent = "";
/*     */             
/*     */             if (this.selfPing.getValue() && !this.discordId.getValue().trim().isEmpty()) {
/*     */               messageContent = String.format("<@%s>", new Object[] { this.discordId.getValue().trim() });
/*     */             }
/*     */             
/*     */             String stashType = isCriticalSpawner ? "End Spawner Base" : "End Stash";
/*     */             
/*     */             String description = String.format("%s found at End coordinates %d, %d!", new Object[] { stashType, Integer.valueOf(chunk.x), Integer.valueOf(chunk.z) });
/*     */             
/*     */             StringBuilder itemsFound = new StringBuilder();
/*     */             
/*     */             int totalItems = 0;
/*     */             
/*     */             if (chunk.chests > 0) {
/*     */               itemsFound.append("Chests: ").append(chunk.chests).append("\\n");
/*     */               
/*     */               totalItems += chunk.chests;
/*     */             } 
/*     */             
/*     */             if (chunk.barrels > 0) {
/*     */               itemsFound.append("Barrels: ").append(chunk.barrels).append("\\n");
/*     */               
/*     */               totalItems += chunk.barrels;
/*     */             } 
/*     */             
/*     */             if (chunk.shulkers > 0) {
/*     */               itemsFound.append("Shulker Boxes: ").append(chunk.shulkers).append("\\n");
/*     */               totalItems += chunk.shulkers;
/*     */             } 
/*     */             if (chunk.enderChests > 0) {
/*     */               itemsFound.append("Ender Chests: ").append(chunk.enderChests).append("\\n");
/*     */               totalItems += chunk.enderChests;
/*     */             } 
/*     */             if (chunk.furnaces > 0) {
/*     */               itemsFound.append("Furnaces: ").append(chunk.furnaces).append("\\n");
/*     */               totalItems += chunk.furnaces;
/*     */             } 
/*     */             if (chunk.dispensersDroppers > 0) {
/*     */               itemsFound.append("Dispensers/Droppers: ").append(chunk.dispensersDroppers).append("\\n");
/*     */               totalItems += chunk.dispensersDroppers;
/*     */             } 
/*     */             if (chunk.hoppers > 0) {
/*     */               itemsFound.append("Hoppers: ").append(chunk.hoppers).append("\\n");
/*     */               totalItems += chunk.hoppers;
/*     */             } 
/*     */             if (isCriticalSpawner) {
/*     */               itemsFound.append("Spawners: Present\\n");
/*     */             }
/*     */             DiscordWebhook webhook = new DiscordWebhook(url);
/*     */             webhook.setUsername("RTP End-Stashfinder");
/*     */             webhook.setAvatarUrl("https://imgur.com/a/21cFemF.png");
/*     */             webhook.setContent(messageContent);
/*     */             DiscordWebhook.EmbedObject embed = new DiscordWebhook.EmbedObject();
/*     */             embed.setTitle("🌌 End Stashfinder Alert");
/*     */             embed.setDescription(description);
/*     */             embed.setColor(new Color(isCriticalSpawner ? 9830144 : 8388736));
/*     */             embed.addField("Detection Reason", detectionReason, false);
/*     */             embed.addField("Total Items Found", String.valueOf(totalItems), false);
/*     */             embed.addField("Items Breakdown", itemsFound.toString(), false);
/*     */             embed.addField("End Coordinates", "" + chunk.x + ", " + chunk.x, true);
/*     */             embed.addField("Server", serverInfo, true);
/*     */             embed.addField("Time", "<t:" + System.currentTimeMillis() / 1000L + ":R>", true);
/*     */             embed.setFooter("RTP End-Stashfinder", null);
/*     */             webhook.addEmbed(embed);
/*     */             webhook.execute();
/*     */             System.out.println("Webhook notification sent successfully");
/* 412 */           } catch (Throwable e) {
/*     */             System.out.println("Failed to send webhook: " + e.getMessage());
/*     */           } 
/*     */         });
/*     */   }
/*     */   public static class EndStashChunk { public class_1923 chunkPos;
/*     */     public transient int x;
/*     */     public transient int z;
/*     */     public int chests;
/*     */     public int barrels;
/*     */     
/*     */     public EndStashChunk(class_1923 chunkPos) {
/* 424 */       this.chunkPos = chunkPos;
/* 425 */       calculatePos();
/*     */     }
/*     */     public int shulkers; public int enderChests; public int furnaces; public int dispensersDroppers; public int hoppers; public int spawners;
/*     */     public void calculatePos() {
/* 429 */       this.x = this.chunkPos.field_9181 * 16 + 8;
/* 430 */       this.z = this.chunkPos.field_9180 * 16 + 8;
/*     */     }
/*     */     
/*     */     public int getTotal() {
/* 434 */       return this.chests + this.barrels + this.shulkers + this.enderChests + this.furnaces + this.dispensersDroppers + this.hoppers + this.spawners;
/*     */     }
/*     */     
/*     */     public int getTotalNonSpawner() {
/* 438 */       return this.chests + this.barrels + this.shulkers + this.enderChests + this.furnaces + this.dispensersDroppers + this.hoppers;
/*     */     }
/*     */     
/*     */     public boolean countsEqual(EndStashChunk c) {
/* 442 */       if (c == null) return false; 
/* 443 */       return (this.chests == c.chests && this.barrels == c.barrels && this.shulkers == c.shulkers && this.enderChests == c.enderChests && this.furnaces == c.furnaces && this.dispensersDroppers == c.dispensersDroppers && this.hoppers == c.hoppers && this.spawners == c.spawners);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     public boolean equals(Object o) {
/* 451 */       if (this == o) return true; 
/* 452 */       if (o == null || getClass() != o.getClass()) return false; 
/* 453 */       EndStashChunk chunk = (EndStashChunk)o;
/* 454 */       return Objects.equals(this.chunkPos, chunk.chunkPos);
/*     */     }
/*     */ 
/*     */     
/*     */     public int hashCode() {
/* 459 */       return Objects.hash(new Object[] { this.chunkPos });
/*     */     } }
/*     */ 
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\RTPEndBaseFinder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */