/*    */ package dev.FORE.module.modules.donut;
/*    */ 
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.EntitySpawnEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import java.util.ArrayList;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1299;
/*    */ 
/*    */ public final class AntiTrap
/*    */   extends Module {
/*    */   public AntiTrap() {
/* 15 */     super((CharSequence)EncryptedString.of("Anti Trap"), (CharSequence)EncryptedString.of("Module that helps you escape Polish traps"), -1, Category.DONUT);
/* 16 */     addsettings(new dev.FORE.module.setting.Setting[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 21 */     removeTrapEntities();
/* 22 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 27 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onEntitySpawn(EntitySpawnEvent entitySpawnEvent) {
/* 32 */     if (isTrapEntity(entitySpawnEvent.packet.method_11169())) {
/* 33 */       entitySpawnEvent.cancel();
/*    */     }
/*    */   }
/*    */   
/*    */   private void removeTrapEntities() {
/* 38 */     if (this.mc.field_1687 == null) {
/*    */       return;
/*    */     }
/* 41 */     ArrayList<class_1297> trapEntities = new ArrayList<>();
/* 42 */     this.mc.field_1687.method_18112().forEach(entity -> {
/*    */           if (entity != null && isTrapEntity(entity.method_5864())) {
/*    */             trapEntities.add(entity);
/*    */           }
/*    */         });
/* 47 */     trapEntities.forEach(trapEntity -> {
/*    */           if (!trapEntity.method_31481()) {
/*    */             trapEntity.method_5650(class_1297.class_5529.field_26999);
/*    */           }
/*    */         });
/*    */   }
/*    */   
/*    */   private boolean isTrapEntity(class_1299<?> entityType) {
/* 55 */     return (entityType != null && (entityType.equals(class_1299.field_6131) || entityType.equals(class_1299.field_6126)));
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\AntiTrap.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */