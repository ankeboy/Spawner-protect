/*    */ package dev.FORE.module.modules.donut;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.modules.misc.NameProtect;
/*    */ import dev.FORE.utils.ColorUtil;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import java.awt.Color;
/*    */ import net.minecraft.class_2561;
/*    */ import net.minecraft.class_2583;
/*    */ import net.minecraft.class_5250;
/*    */ import net.minecraft.class_5251;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class MediaSpoof
/*    */   extends Module
/*    */ {
/*    */   public static MediaSpoof instance;
/*    */   public String Goodstring;
/*    */   
/*    */   public MediaSpoof() {
/* 30 */     super((CharSequence)EncryptedString.of("Media Spoof"), (CharSequence)EncryptedString.of("Makes u media if ur on donut"), -1, Category.MISC);
/*    */ 
/*    */     
/* 33 */     instance = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 38 */     super.onEnable();
/* 39 */     this.Goodstring = "📹+";
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 44 */     super.onDisable();
/*    */     
/* 46 */     this.Goodstring = "";
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {
/* 51 */     if (DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(NameProtect.class).isEnabled() && 
/* 52 */       isEnabled()) {
/* 53 */       this.Goodstring = "📹+";
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private class_2561 parseGradientText(String text, String startHex, String endHex) {
/* 64 */     if (text.isEmpty()) return (class_2561)class_2561.method_43470("");
/*    */     
/* 66 */     Color startColor = Color.decode(startHex);
/* 67 */     Color endColor = Color.decode(endHex);
/*    */     
/* 69 */     class_5250 result = class_2561.method_43470("");
/*    */     
/* 71 */     for (int i = 0; i < text.length(); i++) {
/* 72 */       float progress = (text.length() > 1) ? (i / (text.length() - 1)) : 0.0F;
/* 73 */       Color interpolated = ColorUtil.a(startColor, endColor, progress);
/*    */       
/* 75 */       int rgb = interpolated.getRed() << 16 | interpolated.getGreen() << 8 | interpolated.getBlue();
/*    */       
/* 77 */       result.method_10852((class_2561)class_2561.method_43470(String.valueOf(text.charAt(i)))
/* 78 */           .method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(rgb)).method_10982(Boolean.valueOf(true))));
/*    */     } 
/*    */     
/* 81 */     return (class_2561)result;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static MediaSpoof getInstance() {
/* 87 */     if (instance == null) {
/* 88 */       instance = new MediaSpoof();
/*    */     }
/* 90 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\MediaSpoof.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */