/*      */ package dev.FORE.module.modules.donut;
/*      */ 
/*      */ import dev.FORE.AI.MiningState;
/*      */ import dev.FORE.AI.PathScanner;
/*      */ import dev.FORE.AI.SafetyValidator;
/*      */ import net.minecraft.class_2350;
/*      */ 


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\TunnelBase$1.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */