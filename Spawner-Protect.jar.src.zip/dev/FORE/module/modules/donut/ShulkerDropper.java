/*    */ package dev.FORE.module.modules.donut;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1703;
/*    */ import net.minecraft.class_1713;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2846;
/*    */ 
/*    */ public final class ShulkerDropper extends Module {
/* 18 */   private final NumberSetting delay = new NumberSetting((CharSequence)EncryptedString.of("Delay"), 0.0D, 20.0D, 1.0D, 1.0D);
/* 19 */   private int delayCounter = 0;
/*    */   
/*    */   public ShulkerDropper() {
/* 22 */     super((CharSequence)EncryptedString.of("Shulker Dropper"), (CharSequence)EncryptedString.of("Goes to shop buys shulkers and drops automatically"), -1, Category.DONUT);
/* 23 */     addsettings(new Setting[] { (Setting)this.delay });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 28 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 33 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {
/* 38 */     if (this.mc.field_1724 == null) {
/*    */       return;
/*    */     }
/* 41 */     if (this.delayCounter > 0) {
/* 42 */       this.delayCounter--;
/*    */       return;
/*    */     } 
/* 45 */     class_1703 currentScreenHandler = this.mc.field_1724.field_7512;
/* 46 */     if (!(this.mc.field_1724.field_7512 instanceof class_1707)) {
/* 47 */       this.mc.method_1562().method_45730("shop");
/* 48 */       this.delayCounter = 20;
/*    */       return;
/*    */     } 
/* 51 */     if (((class_1707)currentScreenHandler).method_17388() != 3) {
/*    */       return;
/*    */     }
/* 54 */     if (currentScreenHandler.method_7611(11).method_7677().method_31574(class_1802.field_20399) && currentScreenHandler.method_7611(11).method_7677().method_7947() == 1) {
/* 55 */       this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 11, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 56 */       this.delayCounter = 20;
/*    */       return;
/*    */     } 
/* 59 */     if (currentScreenHandler.method_7611(17).method_7677().method_31574(class_1802.field_8545)) {
/* 60 */       this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 17, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 61 */       this.delayCounter = 20;
/*    */       return;
/*    */     } 
/* 64 */     if (currentScreenHandler.method_7611(13).method_7677().method_31574(class_1802.field_8545)) {
/* 65 */       this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 23, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 66 */       this.delayCounter = this.delay.getIntValue();
/* 67 */       this.mc.field_1724.field_3944.method_52787((class_2596)new class_2846(class_2846.class_2847.field_12970, class_2338.field_10980, class_2350.field_11033));
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\ShulkerDropper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */