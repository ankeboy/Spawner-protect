/*    */ package dev.FORE.module.modules.donut;
/*    */ 
/*    */ import dev.FORE.module.Category;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NonStackableItemsSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_310;
/*    */ 
/*    */ public final class ShearsToElytra
/*    */   extends Module
/*    */ {
/*    */   public static ShearsToElytra instance;
/* 17 */   private final BooleanSetting changeTexture = new BooleanSetting((CharSequence)EncryptedString.of("Change Texture"), true);
/* 18 */   private final BooleanSetting changeName = new BooleanSetting((CharSequence)EncryptedString.of("Change Name"), true);
/* 19 */   public final NonStackableItemsSetting items = new NonStackableItemsSetting(
/* 20 */       (CharSequence)EncryptedString.of("Items"), new class_1792[] { class_1802.field_8868, class_1802.field_42716 });
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public ShearsToElytra() {
/* 26 */     super((CharSequence)EncryptedString.of("Fake Elytra"), (CharSequence)EncryptedString.of("Makes selected items appear as elytra."), -1, Category.DONUT);
/* 27 */     addsettings(new Setting[] { (Setting)this.changeTexture, (Setting)this.changeName, (Setting)this.items });
/*    */     
/* 29 */     instance = this;
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 34 */     super.onEnable();
/* 35 */     refreshModels();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 40 */     super.onDisable();
/* 41 */     refreshModels();
/*    */   }
/*    */   
/*    */   private void refreshModels() {
/* 45 */     class_310 mc = class_310.method_1551();
/* 46 */     if (mc != null && mc.method_1480() != null) {
/* 47 */       mc.method_1480().method_4012().method_3310();
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean shouldChangeTexture() {
/* 52 */     return (isEnabled() && this.changeTexture.getValue());
/*    */   }
/*    */   
/*    */   public boolean shouldChangeName() {
/* 56 */     return (isEnabled() && this.changeName.getValue());
/*    */   }
/*    */   
/*    */   public boolean shouldChangeItem(class_1792 item) {
/* 60 */     return (isEnabled() && this.items.contains(item));
/*    */   }
/*    */   
/*    */   public static ShearsToElytra getInstance() {
/* 64 */     if (instance == null) {
/* 65 */       instance = new ShearsToElytra();
/*    */     }
/* 67 */     return instance;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\ShearsToElytra.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */