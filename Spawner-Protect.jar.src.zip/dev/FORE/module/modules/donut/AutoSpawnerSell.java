/*     */ package dev.FORE.module.modules.donut;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1703;
/*     */ import net.minecraft.class_1707;
/*     */ import net.minecraft.class_1713;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_1836;
/*     */ import net.minecraft.class_1937;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_304;
/*     */ import net.minecraft.class_3675;
/*     */ 
/*     */ public final class AutoSpawnerSell extends Module {
/*  23 */   private final NumberSetting dropDelay = (new NumberSetting((CharSequence)EncryptedString.of("Drop Delay"), 0.0D, 120.0D, 30.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("How often it should start dropping bones in minutes"));
/*  24 */   private final NumberSetting pageAmount = (new NumberSetting((CharSequence)EncryptedString.of("Page Amount"), 1.0D, 10.0D, 2.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("How many pages should it drop before selling"));
/*  25 */   private final NumberSetting pageSwitchDelay = (new NumberSetting((CharSequence)EncryptedString.of("Page Switch Delay"), 0.0D, 720.0D, 4.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("How often it should switch pages in seconds"));
/*  26 */   private final NumberSetting delay = (new NumberSetting((CharSequence)EncryptedString.of("delay"), 0.0D, 20.0D, 1.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("What should be delay in ticks"));
/*     */   private int delayCounter;
/*     */   private int pageCounter;
/*     */   private boolean isProcessing;
/*     */   private boolean isSelling;
/*     */   private boolean isPageSwitching;
/*     */   
/*     */   public AutoSpawnerSell() {
/*  34 */     super((CharSequence)EncryptedString.of("Auto Spawner Sell"), (CharSequence)EncryptedString.of("Automatically drops bones from spawner and sells them"), -1, Category.DONUT);
/*  35 */     addsettings(new Setting[] { (Setting)this.dropDelay, (Setting)this.pageAmount, (Setting)this.pageSwitchDelay, (Setting)this.delay });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  40 */     super.onEnable();
/*  41 */     this.delayCounter = 20;
/*  42 */     this.isProcessing = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  47 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  52 */     if (this.delayCounter > 0) {
/*  53 */       this.delayCounter--;
/*     */       return;
/*     */     } 
/*  56 */     if (this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/*  59 */     if (this.pageCounter >= this.pageAmount.getIntValue()) {
/*  60 */       this.isSelling = true;
/*  61 */       this.pageCounter = 0;
/*  62 */       this.delayCounter = 40;
/*     */       return;
/*     */     } 
/*  65 */     if (this.isSelling) {
/*  66 */       class_1703 currentScreenHandler = this.mc.field_1724.field_7512;
/*  67 */       if (!(this.mc.field_1724.field_7512 instanceof class_1707)) {
/*  68 */         this.mc.method_1562().method_45730("order " + getOrderCommand());
/*  69 */         this.delayCounter = 20;
/*     */         return;
/*     */       } 
/*  72 */       if (((class_1707)currentScreenHandler).method_17388() == 6) {
/*  73 */         class_1799 stack = currentScreenHandler.method_7611(47).method_7677();
/*  74 */         if (stack.method_31574(class_1802.field_8162)) {
/*  75 */           this.delayCounter = 2;
/*  76 */           this.mc.field_1724.method_7346();
/*     */           return;
/*     */         } 
/*  79 */         for (Object next : stack.method_7950(class_1792.class_9635.method_59528((class_1937)this.mc.field_1687), (class_1657)this.mc.field_1724, (class_1836)class_1836.field_41070)) {
/*  80 */           String string = next.toString();
/*  81 */           if (string.contains("Most Money Per Item") && (((class_2561)next).method_10866().toString().contains("white") || string.contains("white"))) {
/*  82 */             this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 47, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
/*  83 */             this.delayCounter = 5;
/*     */             return;
/*     */           } 
/*     */         } 
/*  87 */         for (int i = 0; i < 44; i++) {
/*  88 */           if (currentScreenHandler.method_7611(i).method_7677().method_31574(getInventoryItem())) {
/*  89 */             this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, i, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
/*  90 */             this.delayCounter = 10;
/*     */             return;
/*     */           } 
/*     */         } 
/*  94 */         this.delayCounter = 40;
/*  95 */         this.mc.field_1724.method_7346();
/*  96 */       } else if (((class_1707)currentScreenHandler).method_17388() == 4) {
/*  97 */         int emptySlotCount = InventoryUtil.getSlot(class_1802.field_8162);
/*  98 */         if (emptySlotCount <= 0) {
/*  99 */           this.mc.field_1724.method_7346();
/* 100 */           this.delayCounter = 10;
/*     */           return;
/*     */         } 
/* 103 */         if (this.isPageSwitching && emptySlotCount == 36) {
/* 104 */           this.isPageSwitching = false;
/* 105 */           this.mc.field_1724.method_7346();
/*     */           return;
/*     */         } 
/* 108 */         class_1792 targetItem = getInventoryItem();
/*     */         while (true) {
/* 110 */           int slotIndex = 36;
/* 111 */           class_1792 item = ((class_1799)this.mc.field_1724.field_7512.method_7602().get(36)).method_7909();
/* 112 */           if (item != class_1802.field_8162 && item == targetItem) {
/* 113 */             this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 36, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
/* 114 */             this.delayCounter = this.delay.getIntValue();
/* 115 */             if (this.delay.getIntValue() != 0) {
/*     */               break;
/*     */             }
/*     */           }
/*     */         
/*     */         } 
/* 121 */       } else if (((class_1707)currentScreenHandler).method_17388() == 3) {
/* 122 */         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 15, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
/* 123 */         this.isPageSwitching = true;
/* 124 */         this.delayCounter = 10;
/*     */       } 
/*     */     } else {
/* 127 */       class_1703 fishHook = this.mc.field_1724.field_7512;
/* 128 */       if (!(this.mc.field_1724.field_7512 instanceof class_1707)) {
/* 129 */         class_304.method_1420(class_3675.class_307.field_1672.method_1447(1));
/* 130 */         this.delayCounter = 20;
/*     */         return;
/*     */       } 
/* 133 */       if (fishHook.method_7611(15).method_7677().method_31574(class_1802.field_8581)) {
/* 134 */         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 15, 1, class_1713.field_7794, (class_1657)this.mc.field_1724);
/* 135 */         this.delayCounter = 10;
/*     */         return;
/*     */       } 
/* 138 */       if (this.mc.field_1724.field_7512.method_7611(13).method_7677().method_31574(class_1802.field_8398)) {
/* 139 */         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 11, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 140 */         this.delayCounter = 20;
/*     */         return;
/*     */       } 
/* 143 */       if (!this.mc.field_1724.field_7512.method_7611(53).method_7677().method_31574(class_1802.field_8695)) {
/* 144 */         this.mc.field_1724.method_7346();
/* 145 */         this.delayCounter = 20;
/*     */         return;
/*     */       } 
/* 148 */       if (this.mc.field_1724.field_7512.method_7611(48).method_7677().method_31574(class_1802.field_8107)) {
/* 149 */         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 48, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 150 */         this.delayCounter = 20;
/*     */         return;
/*     */       } 
/* 153 */       boolean b2 = true;
/* 154 */       for (int k = 0; k < 45; k++) {
/* 155 */         if (!this.mc.field_1724.field_7512.method_7611(k).method_7677().method_31574(class_1802.field_8606)) {
/* 156 */           b2 = false;
/*     */           break;
/*     */         } 
/*     */       } 
/* 160 */       if (b2) {
/* 161 */         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 52, 1, class_1713.field_7795, (class_1657)this.mc.field_1724);
/* 162 */         this.isProcessing = true;
/* 163 */         this.delayCounter = this.pageSwitchDelay.getIntValue() * 20;
/* 164 */         this.pageCounter++;
/* 165 */       } else if (this.isProcessing) {
/* 166 */         this.isProcessing = false;
/* 167 */         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 50, 0, class_1713.field_7790, (class_1657)this.mc.field_1724);
/* 168 */         this.delayCounter = 20;
/*     */       } else {
/* 170 */         this.isProcessing = false;
/* 171 */         if (this.pageCounter != 0) {
/* 172 */           this.pageCounter = 0;
/* 173 */           this.isSelling = true;
/* 174 */           this.delayCounter = 40;
/*     */           return;
/*     */         } 
/* 177 */         this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, 45, 1, class_1713.field_7795, (class_1657)this.mc.field_1724);
/* 178 */         this.delayCounter = 1200 * this.dropDelay.getIntValue();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private class_1792 getInventoryItem() {
/* 184 */     for (int i = 0; i < 35; i++) {
/* 185 */       class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
/* 186 */       if (!stack.method_31574(class_1802.field_8162)) {
/* 187 */         return stack.method_7909();
/*     */       }
/*     */     } 
/* 190 */     return class_1802.field_8162;
/*     */   }
/*     */   
/*     */   private String getOrderCommand() {
/* 194 */     class_1792 j = getInventoryItem();
/* 195 */     if (j.equals(class_1802.field_8606)) {
/* 196 */       return "Bones";
/*     */     }
/* 198 */     return j.method_7848().getString();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\AutoSpawnerSell.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */