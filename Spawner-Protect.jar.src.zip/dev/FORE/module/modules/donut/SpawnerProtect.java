/*     */ package dev.FORE.module.modules.donut;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.mixin.PlayerInventoryAccessorMixin;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.module.setting.StringSetting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import java.io.IOException;
/*     */ import java.net.URI;
/*     */ import java.net.http.HttpClient;
/*     */ import java.net.http.HttpRequest;
/*     */ import java.net.http.HttpResponse;
/*     */ import java.util.ArrayList;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2382;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2561;
/*     */ import net.minecraft.class_2596;
/*     */ import net.minecraft.class_2846;
/*     */ import net.minecraft.class_2848;
/*     */ 
/*     */ public final class SpawnerProtect extends Module {
/*  33 */   private final NumberSetting detectionRadius = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 1.0D, 32.0D, 11.0D, 1.0D);
/*     */   
/*  35 */   private final NumberSetting breakDelay = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 1.0D, 20.0D, 5.0D, 1.0D);
/*     */   
/*  37 */   int silkTouchSlot = 0;
/*     */   
/*  39 */   private final String noSilkTouchMessage = "You Need To Have Silk Touch Pickaxe";
/*     */ 
/*     */   
/*  42 */   private final String noSpawnersMessage = "No spawners found in detection range!";
/*     */ 
/*     */   
/*  45 */   private final BooleanSetting enableWebhook = new BooleanSetting((CharSequence)EncryptedString.of("Discord Notification"), true);
/*     */   
/*  47 */   private final StringSetting webhookUrl = new StringSetting((CharSequence)EncryptedString.of("Webhook"), "");
/*     */ 
/*     */ 
/*     */   
/*  51 */   private List<class_2338> detectedSpawners = new ArrayList<>();
/*  52 */   private class_2338 currentTarget = null;
/*  53 */   private int breakingTicks = 0;
/*  54 */   private int silkTouchSlotIndex = -1;
/*  55 */   private int originalSlot = -1;
/*     */   private boolean isSneaking = false;
/*     */   private boolean isBreaking = false;
/*  58 */   private int delayTicks = 0;
/*     */   private boolean hasCheckedInitialRequirements = false;
/*     */   private boolean isBreakingBlock = false;
/*  61 */   private int breakProgress = 0; private boolean playerDetected = false;
/*  62 */   private String detectedPlayerName = null;
/*     */   public SpawnerProtect() {
/*  64 */     super((CharSequence)EncryptedString.of("Spawner Protetion"), (CharSequence)EncryptedString.of("It breakes your spawners and puts them in the enderchest if player is nearby"), -1, Category.DONUT);
/*  65 */     addsettings(new Setting[] { (Setting)this.detectionRadius, (Setting)this.breakDelay, (Setting)this.enableWebhook, (Setting)this.webhookUrl });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  70 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null) {
/*  71 */       toggle();
/*     */       
/*     */       return;
/*     */     } 
/*  75 */     this.detectedSpawners.clear();
/*  76 */     this.currentTarget = null;
/*  77 */     this.breakingTicks = 0;
/*  78 */     this.silkTouchSlotIndex = -1;
/*  79 */     this.originalSlot = -1;
/*  80 */     this.isSneaking = false;
/*  81 */     this.isBreaking = false;
/*  82 */     this.delayTicks = 0;
/*  83 */     this.hasCheckedInitialRequirements = false;
/*  84 */     this.isBreakingBlock = false;
/*  85 */     this.breakProgress = 0;
/*  86 */     this.playerDetected = false;
/*  87 */     this.detectedPlayerName = null;
/*     */     
/*  89 */     this.silkTouchSlotIndex = findSilkTouchPickaxe();
/*  90 */     if (this.silkTouchSlotIndex == -1) {
/*  91 */       String kickMessage = new String("You Need To Have Silk Touch Pickaxe".getBytes());
/*  92 */       if (this.detectedPlayerName != null) {
/*  93 */         kickMessage = "Player detected: " + this.detectedPlayerName;
/*     */       }
/*  95 */       kickPlayerAndDisable(kickMessage);
/*     */       
/*     */       return;
/*     */     } 
/*  99 */     this.hasCheckedInitialRequirements = true;
/*     */     
/* 101 */     scanForSpawners();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/* 106 */     if (this.isSneaking && this.mc.field_1724 != null) {
/* 107 */       this.mc.field_1724.method_5660(false);
/* 108 */       this.isSneaking = false;
/*     */     } 
/*     */     
/* 111 */     if (this.isBreakingBlock && this.currentTarget != null) {
/* 112 */       this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12971, this.currentTarget, class_2350.field_11036));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 117 */       this.isBreakingBlock = false;
/*     */     } 
/*     */     
/* 120 */     if (this.originalSlot >= 0 && this.originalSlot < 9 && this.mc.field_1724 != null) {
/* 121 */       PlayerInventoryAccessorMixin inventoryAccessor = (PlayerInventoryAccessorMixin)this.mc.field_1724.method_31548();
/* 122 */       inventoryAccessor.setSelectedSlot(this.originalSlot);
/*     */     } 
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   private void onTick(TickEvent event) {
/* 128 */     if (this.mc.field_1724 == null || this.mc.field_1687 == null)
/*     */       return; 
/* 130 */     if (!this.hasCheckedInitialRequirements) {
/* 131 */       if (!checkInitialRequirements()) {
/*     */         return;
/*     */       }
/* 134 */       scanForSpawners();
/*     */       
/* 136 */       this.hasCheckedInitialRequirements = true;
/*     */     } 
/*     */     
/* 139 */     if (this.delayTicks > 0) {
/* 140 */       this.delayTicks--;
/*     */       
/*     */       return;
/*     */     } 
/* 144 */     boolean currentPlayerDetected = checkForOtherPlayers();
/*     */     
/* 146 */     if (!currentPlayerDetected) {
/* 147 */       scanForSpawners();
/* 148 */       this.playerDetected = false;
/* 149 */       this.detectedPlayerName = null;
/* 150 */       if (this.isSneaking) {
/* 151 */         this.mc.field_1724.method_5660(false);
/* 152 */         this.isSneaking = false;
/*     */       } 
/*     */       
/* 155 */       if (this.isBreaking) {
/* 156 */         this.isBreaking = false;
/* 157 */         this.currentTarget = null;
/* 158 */         if (this.isBreakingBlock) {
/* 159 */           this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12971, this.currentTarget, class_2350.field_11036));
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 164 */           this.isBreakingBlock = false;
/*     */         } 
/*     */       } 
/*     */       
/*     */       return;
/*     */     } 
/* 170 */     if (!this.playerDetected) {
/* 171 */       this.playerDetected = true;
/*     */     }
/*     */     
/* 174 */     setSneaking(true);
/*     */     
/* 176 */     if (this.detectedSpawners.isEmpty()) {
/* 177 */       scanForSpawners();
/*     */     }
/*     */     
/* 180 */     if (this.detectedSpawners.isEmpty()) {
/* 181 */       String kickMessage = "No spawners to protect! Player detected but nothing to save.";
/* 182 */       if (this.detectedPlayerName != null) {
/* 183 */         kickMessage = kickMessage + " | Player near: " + kickMessage;
/*     */       }
/* 185 */       kickPlayerAndDisable(kickMessage);
/*     */       
/*     */       return;
/*     */     } 
/* 189 */     PlayerInventoryAccessorMixin inventoryAccessor = (PlayerInventoryAccessorMixin)this.mc.field_1724.method_31548();
/* 190 */     if (inventoryAccessor.getSelectedSlot() != this.silkTouchSlotIndex) {
/* 191 */       this.originalSlot = inventoryAccessor.getSelectedSlot();
/* 192 */       inventoryAccessor.setSelectedSlot(this.silkTouchSlotIndex);
/*     */     } 
/*     */     
/* 195 */     processSpawnerBreaking();
/*     */     
/* 197 */     if (this.detectedSpawners.isEmpty() && this.currentTarget == null) {
/* 198 */       String kickMessage = "All spawners have been protected! Disconnecting for safety.";
/* 199 */       if (this.detectedPlayerName != null) {
/* 200 */         kickMessage = kickMessage + " | Player near: " + kickMessage;
/*     */       }
/* 202 */       kickPlayerAndDisable(kickMessage);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setSneaking(boolean sneak) {
/* 207 */     if (this.mc.field_1724 == null)
/*     */       return; 
/* 209 */     if (sneak) {
/* 210 */       this.mc.field_1724.method_5660(true);
/*     */       
/*     */       try {
/* 213 */         this.mc.method_1562().method_52787((class_2596)new class_2848((class_1297)this.mc.field_1724, class_2848.class_2849.field_12979));
/* 214 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/*     */       try {
/* 218 */         this.mc.field_1690.field_1832.method_23481(true);
/* 219 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 222 */       this.isSneaking = true;
/* 223 */     } else if (!sneak && this.isSneaking) {
/* 224 */       this.mc.field_1724.method_5660(false);
/*     */       
/*     */       try {
/* 227 */         this.mc.method_1562().method_52787((class_2596)new class_2848((class_1297)this.mc.field_1724, class_2848.class_2849.field_12984));
/* 228 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/*     */       try {
/* 232 */         this.mc.field_1690.field_1832.method_23481(false);
/* 233 */       } catch (Exception exception) {}
/*     */ 
/*     */       
/* 236 */       this.isSneaking = false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean checkInitialRequirements() {
/* 241 */     this.silkTouchSlotIndex = findSilkTouchPickaxe();
/* 242 */     if (this.silkTouchSlotIndex == -1) {
/* 243 */       String kickMessage = new String("You Need To Have Silk Touch Pickaxe".getBytes());
/* 244 */       if (this.detectedPlayerName != null) {
/* 245 */         kickMessage = kickMessage + " | Player near: " + kickMessage;
/*     */       }
/* 247 */       kickPlayerAndDisable(kickMessage);
/* 248 */       return false;
/*     */     } 
/* 250 */     return true;
/*     */   }
/*     */   
/*     */   private int findSilkTouchPickaxe() {
/* 254 */     int manualSlot = this.silkTouchSlot;
/*     */     
/* 256 */     if (manualSlot >= 1 && manualSlot <= 9) {
/* 257 */       int slotIndex = manualSlot - 1; class_1799 stack = this.mc.field_1724.method_31548().method_5438(slotIndex);
/*     */       
/* 259 */       if (isPickaxe(stack)) {
/* 260 */         return slotIndex;
/*     */       }
/*     */       
/* 263 */       return -1;
/*     */     } 
/*     */ 
/*     */     
/* 267 */     for (int i = 0; i < 9; i++) {
/* 268 */       class_1799 stack = this.mc.field_1724.method_31548().method_5438(i);
/*     */       
/* 270 */       if (isPickaxe(stack) && 
/* 271 */         stack.method_7942()) {
/* 272 */         String stackString = stack.toString().toLowerCase();
/* 273 */         if (stackString.contains("silk_touch") || stackString.contains("silktouch"))
/*     */         {
/* 275 */           return i;
/*     */         }
/*     */         
/*     */         try {
/* 279 */           String displayName = stack.method_7964().getString().toLowerCase();
/* 280 */           if (displayName.contains("silk") || displayName.contains("touch")) {
/* 281 */             return i;
/*     */           }
/* 283 */         } catch (Exception exception) {}
/*     */ 
/*     */         
/* 286 */         return i;
/*     */       } 
/*     */     } 
/*     */     
/* 290 */     return -1;
/*     */   }
/*     */   
/*     */   private boolean isPickaxe(class_1799 stack) {
/* 294 */     return (stack.method_7909() == class_1802.field_8647 || stack
/* 295 */       .method_7909() == class_1802.field_8387 || stack
/* 296 */       .method_7909() == class_1802.field_8403 || stack
/* 297 */       .method_7909() == class_1802.field_8335 || stack
/* 298 */       .method_7909() == class_1802.field_8377 || stack
/* 299 */       .method_7909() == class_1802.field_22024);
/*     */   }
/*     */   
/*     */   private boolean checkForOtherPlayers() {
/* 303 */     for (class_1657 player : this.mc.field_1687.method_18456()) {
/* 304 */       if (player != this.mc.field_1724 && !player.method_31481()) {
/* 305 */         this.detectedPlayerName = player.method_5477().getString();
/*     */         
/* 307 */         String alertMessage = "Player detected nearby: " + this.detectedPlayerName;
/* 308 */         sendWebhookMessage(alertMessage);
/* 309 */         return true;
/*     */       } 
/*     */     } 
/* 312 */     return false;
/*     */   }
/*     */   
/*     */   private void scanForSpawners() {
/* 316 */     this.detectedSpawners.clear();
/* 317 */     class_2338 playerPos = this.mc.field_1724.method_24515();
/* 318 */     int radius = this.detectionRadius.getIntValue();
/*     */     
/* 320 */     for (int x = -radius; x <= radius; x++) {
/* 321 */       for (int y = -radius; y <= radius; y++) {
/* 322 */         for (int z = -radius; z <= radius; z++) {
/* 323 */           class_2338 pos = playerPos.method_10069(x, y, z);
/* 324 */           if (this.mc.field_1687.method_8320(pos).method_26204() == class_2246.field_10260) {
/* 325 */             this.detectedSpawners.add(pos);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processSpawnerBreaking() {
/* 333 */     setSneaking(true);
/*     */     
/* 335 */     if (this.currentTarget == null) {
/* 336 */       if (this.detectedSpawners.isEmpty()) {
/*     */         return;
/*     */       }
/* 339 */       this.currentTarget = this.detectedSpawners.get(0);
/* 340 */       this.isBreaking = true;
/* 341 */       this.isBreakingBlock = false;
/* 342 */       this.breakingTicks = 0;
/* 343 */       this.breakProgress = 0;
/*     */     } 
/*     */     
/* 346 */     if (this.mc.field_1687.method_8320(this.currentTarget).method_26204() != class_2246.field_10260) {
/* 347 */       this.detectedSpawners.remove(this.currentTarget);
/* 348 */       this.currentTarget = null;
/* 349 */       this.isBreaking = false;
/* 350 */       this.isBreakingBlock = false;
/* 351 */       this.breakProgress = 0;
/*     */       
/* 353 */       this.delayTicks = this.breakDelay.getIntValue();
/*     */       
/*     */       return;
/*     */     } 
/* 357 */     if (this.isBreaking) {
/* 358 */       breakSpawner(this.currentTarget);
/* 359 */       this.breakingTicks++;
/*     */       
/* 361 */       if (this.breakingTicks > 200) {
/* 362 */         if (this.isBreakingBlock) {
/* 363 */           this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12971, this.currentTarget, class_2350.field_11036));
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 368 */           this.isBreakingBlock = false;
/*     */         } 
/*     */         
/* 371 */         this.detectedSpawners.remove(this.currentTarget);
/* 372 */         this.currentTarget = null;
/* 373 */         this.isBreaking = false;
/* 374 */         this.breakProgress = 0;
/* 375 */         this.delayTicks = this.breakDelay.getIntValue();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void breakSpawner(class_2338 pos) {
/* 381 */     setSneaking(true);
/*     */     
/* 383 */     class_243 blockCenter = class_243.method_24953((class_2382)pos);
/*     */     
/* 385 */     class_243 playerEyes = this.mc.field_1724.method_33571();
/* 386 */     class_243 direction = blockCenter.method_1020(playerEyes).method_1029();
/*     */     
/* 388 */     float yaw = (float)(Math.atan2(-direction.field_1352, direction.field_1350) * 180.0D / Math.PI);
/* 389 */     float pitch = (float)(Math.asin(-direction.field_1351) * 180.0D / Math.PI);
/* 390 */     this.mc.field_1724.method_36456(yaw);
/* 391 */     this.mc.field_1724.method_36457(pitch);
/*     */     
/* 393 */     class_2350 face = getClosestFace(pos, playerEyes);
/*     */     
/* 395 */     if (!this.isBreakingBlock) {
/* 396 */       this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12968, pos, face));
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 401 */       this.isBreakingBlock = true;
/* 402 */       this.breakProgress = 0;
/*     */     } 
/*     */     
/* 405 */     this.breakProgress++;
/*     */     
/* 407 */     this.mc.field_1724.method_6104(class_1268.field_5808);
/*     */     
/* 409 */     this.mc.field_1761.method_2902(pos, face);
/*     */     
/* 411 */     if (this.breakProgress >= 30) { this.mc.method_1562().method_52787((class_2596)new class_2846(class_2846.class_2847.field_12973, pos, face));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 417 */       this.mc.field_1761.method_2910(pos, face);
/*     */       
/* 419 */       this.isBreakingBlock = false;
/* 420 */       this.breakProgress = 0; }
/*     */   
/*     */   }
/*     */   
/*     */   private class_2350 getClosestFace(class_2338 blockPos, class_243 playerEyes) {
/* 425 */     class_243 blockCenter = class_243.method_24953((class_2382)blockPos);
/* 426 */     class_243 diff = playerEyes.method_1020(blockCenter);
/*     */     
/* 428 */     double absX = Math.abs(diff.field_1352);
/* 429 */     double absY = Math.abs(diff.field_1351);
/* 430 */     double absZ = Math.abs(diff.field_1350);
/*     */     
/* 432 */     if (absX > absY && absX > absZ)
/* 433 */       return (diff.field_1352 > 0.0D) ? class_2350.field_11034 : class_2350.field_11039; 
/* 434 */     if (absY > absZ) {
/* 435 */       return (diff.field_1351 > 0.0D) ? class_2350.field_11036 : class_2350.field_11033;
/*     */     }
/* 437 */     return (diff.field_1350 > 0.0D) ? class_2350.field_11035 : class_2350.field_11043;
/*     */   }
/*     */ 
/*     */   
/*     */   private void kickPlayerAndDisable(String message) {
/* 442 */     toggle();
/*     */ 
/*     */     
/* 445 */     if (this.enableWebhook.getValue() && !this.webhookUrl.getValue().isEmpty()) {
/* 446 */       sendWebhookMessage(message);
/*     */     }
/*     */     
/* 449 */     if (this.mc.method_1562() != null) {
/* 450 */       this.mc.method_1562().method_48296().method_10747((class_2561)class_2561.method_43470(message));
/* 451 */     } else if (this.mc.field_1687 != null) {
/* 452 */       this.mc.field_1687.method_8525();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void sendWebhookMessage(String message) {
/* 457 */     if (!this.enableWebhook.getValue() || this.webhookUrl.getValue().isEmpty())
/*     */       return; 
/* 459 */     CompletableFuture.runAsync(() -> {
/*     */           try {
/*     */             HttpClient client = HttpClient.newHttpClient();
/*     */ 
/*     */ 
/*     */             
/*     */             String jsonPayload = String.format("{\"content\":\"%s\"}", new Object[] { message.replace("\"", "\\\"") });
/*     */ 
/*     */             
/*     */             HttpRequest request = HttpRequest.newBuilder().uri(URI.create(this.webhookUrl.getValue())).header("Content-Type", "application/json").POST(HttpRequest.BodyPublishers.ofString(jsonPayload)).build();
/*     */ 
/*     */             
/*     */             client.send(request, HttpResponse.BodyHandlers.ofString());
/* 472 */           } catch (IOException|InterruptedException iOException) {}
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\SpawnerProtect.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */