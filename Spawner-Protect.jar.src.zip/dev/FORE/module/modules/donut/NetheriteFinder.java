/*     */ package dev.FORE.module.modules.donut;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.ChunkDataEvent;
/*     */ import dev.FORE.event.events.Render3DEvent;
/*     */ import dev.FORE.event.events.SetBlockStateEvent;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.meteorrejects.Ore;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.BitSet;
/*     */ import java.util.HashMap;
/*     */ import java.util.HashSet;
/*     */ import java.util.Iterator;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_1959;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2791;
/*     */ import net.minecraft.class_2806;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_2826;
/*     */ import net.minecraft.class_2919;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5321;
/*     */ import net.minecraft.class_5819;
/*     */ import net.minecraft.class_638;
/*     */ import net.minecraft.class_6880;
/*     */ import net.minecraft.class_7833;
/*     */ 
/*     */ public final class NetheriteFinder extends Module {
/*  38 */   private final NumberSetting alpha = new NumberSetting((CharSequence)EncryptedString.of("Alpha"), 1.0D, 255.0D, 125.0D, 1.0D);
/*  39 */   private final NumberSetting range = new NumberSetting((CharSequence)EncryptedString.of("Range"), 1.0D, 10.0D, 5.0D, 1.0D);
/*  40 */   private final StringSetting customSeed = new StringSetting((CharSequence)EncryptedString.of("Custom Seed"), "6608149111735331168");
/*  41 */   private final Map<Long, Map<Ore, Set<class_243>>> chunkOreData = new ConcurrentHashMap<>();
/*     */   private Map<class_5321<class_1959>, List<Ore>> biomeOreMap;
/*     */   
/*     */   public NetheriteFinder() {
/*  45 */     super((CharSequence)EncryptedString.of("Netherite Finder"), (CharSequence)EncryptedString.of("Finds netherites"), -1, Category.DONUT);
/*  46 */     addsettings(new Setting[] { (Setting)this.alpha, (Setting)this.range, (Setting)this.customSeed });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  51 */     super.onEnable();
/*  52 */     initializeOreLocations();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  57 */     super.onDisable();
/*  58 */     this.chunkOreData.clear();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onRender3D(Render3DEvent renderEvent) {
/*  63 */     if (this.mc.field_1724 != null && this.biomeOreMap != null) {
/*  64 */       class_4184 camera = this.mc.field_1773.method_19418();
/*  65 */       if (camera != null) {
/*  66 */         class_4587 matrixStack = renderEvent.matrixStack;
/*  67 */         renderEvent.matrixStack.method_22903();
/*  68 */         class_243 cameraPos = camera.method_19326();
/*  69 */         class_7833 xAxis = class_7833.field_40714;
/*  70 */         matrixStack.method_22907(xAxis.rotationDegrees(camera.method_19329()));
/*  71 */         class_7833 yAxis = class_7833.field_40716;
/*  72 */         matrixStack.method_22907(yAxis.rotationDegrees(camera.method_19330() + 180.0F));
/*  73 */         matrixStack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
/*     */       } 
/*     */       
/*  76 */       int playerChunkX = (this.mc.field_1724.method_31476()).field_9181;
/*  77 */       int playerChunkZ = (this.mc.field_1724.method_31476()).field_9180;
/*  78 */       int renderRange = this.range.getIntValue();
/*     */ 
/*     */       
/*  81 */       for (int x = playerChunkX - renderRange; x <= playerChunkX + renderRange; x++) {
/*  82 */         for (int z = playerChunkZ - renderRange; z <= playerChunkZ + renderRange; z++) {
/*  83 */           renderChunk(x, z, renderEvent);
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/*  88 */       renderEvent.matrixStack.method_22909();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void renderChunk(int chunkX, int chunkZ, Render3DEvent renderEvent) {
/*  93 */     long chunkKey = class_1923.method_8331(chunkX, chunkZ);
/*  94 */     Map<Ore, Set<class_243>> chunkData = this.chunkOreData.get(Long.valueOf(chunkKey));
/*  95 */     if (chunkData != null) {
/*  96 */       for (Map.Entry<Ore, Set<class_243>> entry : chunkData.entrySet()) {
/*  97 */         for (class_243 pos : entry.getValue()) {
/*  98 */           class_4587 matrixStack = renderEvent.matrixStack;
/*  99 */           float x = (float)pos.field_1352;
/* 100 */           float y = (float)pos.field_1351;
/* 101 */           float z = (float)pos.field_1350;
/* 102 */           RenderUtils.renderFilledBox(matrixStack, x, y, z, (float)(pos.field_1352 + 1.0D), (float)(pos.field_1351 + 1.0D), (float)(pos.field_1350 + 1.0D), 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 110 */               getAlphaColor(this.alpha.getIntValue()));
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void initializeOreLocations() {
/* 118 */     this.chunkOreData.clear();
/* 119 */     if (this.mc.field_1687 != null) {
/* 120 */       this.biomeOreMap = Ore.register();
/* 121 */       populateOreLocations();
/*     */     } 
/*     */   }
/*     */   
/*     */   private Color getAlphaColor(int alphaValue) {
/* 126 */     return new Color(191, 64, 191, alphaValue);
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onChunkDataReceived(ChunkDataEvent chunkEvent) {
/* 131 */     if (this.biomeOreMap == null && this.mc.field_1687 != null) {
/* 132 */       this.biomeOreMap = Ore.register();
/*     */     }
/*     */     
/* 135 */     class_638 world = this.mc.field_1687;
/* 136 */     processChunk((class_2791)world.method_8497(chunkEvent.packet.method_11523(), chunkEvent.packet.method_11524()));
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onBlockStateChange(SetBlockStateEvent blockEvent) {
/* 141 */     if (blockEvent.oldState.method_26204().equals(class_2246.field_10124)) {
/* 142 */       long chunkKey = class_1923.method_37232(blockEvent.pos);
/* 143 */       Map<Ore, Set<class_243>> chunkData = this.chunkOreData.get(Long.valueOf(chunkKey));
/* 144 */       if (chunkData != null) {
/* 145 */         class_243 blockPos = class_243.method_24954((class_2382)blockEvent.pos);
/* 146 */         for (Set<class_243> oreSet : chunkData.values()) {
/* 147 */           oreSet.remove(blockPos);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void populateOreLocations() {
/* 154 */     if (this.mc.field_1724 != null) {
/* 155 */       Iterator<class_2818> loadedChunks = BlockUtil.getLoadedChunks().iterator();
/*     */       
/* 157 */       while (loadedChunks.hasNext()) {
/* 158 */         processChunk((class_2791)loadedChunks.next());
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void processChunk(class_2791 chunk) {
/* 164 */     if (this.biomeOreMap != null) {
/* 165 */       class_1923 chunkPos = chunk.method_12004();
/* 166 */       long chunkKey = chunkPos.method_8324();
/* 167 */       class_638 world = this.mc.field_1687;
/* 168 */       if (!this.chunkOreData.containsKey(Long.valueOf(chunkKey)) && world != null) {
/* 169 */         long seedValue; HashSet<class_5321<class_1959>> biomesInChunk = new HashSet<>();
/* 170 */         class_1923.method_19280(chunkPos, 1).forEach(chunkPos2 -> {
/*     */               class_2791 neighborChunk = world.method_8402(chunkPos2.field_9181, chunkPos2.field_9180, class_2806.field_12794, false);
/*     */               
/*     */               if (neighborChunk != null) {
/*     */                 class_2826[] sections = neighborChunk.method_12006();
/*     */                 for (int sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
/*     */                   sections[sectionIndex].method_38294().method_39793(());
/*     */                 }
/*     */               } 
/*     */             });
/* 180 */         Set<Ore> oresInBiomes = (Set<Ore>)biomesInChunk.stream().flatMap(biome -> getOresForBiome(biome).stream()).collect(Collectors.toSet());
/* 181 */         int chunkStartX = chunkPos.field_9181 << 4;
/* 182 */         int chunkStartZ = chunkPos.field_9180 << 4;
/* 183 */         class_2919 random = new class_2919(class_2919.class_6675.field_35143.method_39006(0L));
/*     */         
/*     */         try {
/* 186 */           seedValue = Long.parseLong(this.customSeed.getValue());
/* 187 */         } catch (NumberFormatException e) {
/* 188 */           seedValue = 6608149111735331168L;
/*     */         } 
/* 190 */         long populationSeed = random.method_12661(seedValue, chunkStartX, chunkStartZ);
/* 191 */         HashMap<Ore, Set<class_243>> oreLocations = new HashMap<>();
/*     */         
/* 193 */         for (Ore ore : oresInBiomes) {
/* 194 */           HashSet<class_243> orePositions = new HashSet<>();
/* 195 */           random.method_12664(populationSeed, ore.featureIndex, ore.generationStep);
/* 196 */           int oreCount = ore.countProvider.method_35008((class_5819)random);
/*     */           
/* 198 */           for (int oreIndex = 0; oreIndex < oreCount; oreIndex++) {
/* 199 */             if (ore.rarityChance != 1.0F) {
/* 200 */               float rarityThreshold = 1.0F / ore.rarityChance;
/* 201 */               if (random.method_43057() >= rarityThreshold) {
/*     */                 continue;
/*     */               }
/*     */             } 
/*     */             
/* 206 */             int oreX = random.method_43048(16) + chunkStartX;
/* 207 */             int oreZ = random.method_43048(16) + chunkStartZ;
/* 208 */             int oreY = ore.heightProvider.method_35391((class_5819)random, ore.heightContext);
/* 209 */             class_2338 orePos = new class_2338(oreX, oreY, oreZ);
/* 210 */             if (getOresForBiome(chunk.method_16359(oreX, oreY, oreZ).method_40230().get()).contains(ore)) {
/* 211 */               if (ore.isScatteredOre) {
/* 212 */                 orePositions.addAll(generateOreLocations(world, random, orePos, ore.oreSize));
/*     */               } else {
/* 214 */                 orePositions.addAll(generateOreLocations(world, random, orePos, ore.oreSize, ore.discardOnAirChance));
/*     */               } 
/*     */             }
/*     */             continue;
/*     */           } 
/* 219 */           if (!orePositions.isEmpty()) {
/* 220 */             oreLocations.put(ore, orePositions);
/*     */           }
/*     */         } 
/*     */         
/* 224 */         this.chunkOreData.put(Long.valueOf(chunkKey), oreLocations);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private List<Ore> getOresForBiome(class_5321<class_1959> biome) {
/* 230 */     if (this.biomeOreMap == null) {
/* 231 */       this.biomeOreMap = Ore.register();
/*     */     }
/*     */     
/* 234 */     return this.biomeOreMap.containsKey(biome) ? this.biomeOreMap.get(biome) : this.biomeOreMap.values().stream().findAny().get();
/*     */   }
/*     */   
/*     */   private ArrayList<class_243> generateOreLocations(class_638 world, class_2919 random, class_2338 centerPos, int oreSize, float discardChance) {
/* 238 */     float angle = random.method_43057() * 3.1415927F;
/* 239 */     float radius = oreSize / 8.0F;
/* 240 */     int maxRadius = class_3532.method_15386((oreSize / 16.0F * 2.0F + 1.0F) / 2.0F);
/* 241 */     int centerX = centerPos.method_10263();
/* 242 */     int centerX2 = centerPos.method_10263();
/* 243 */     double sinAngle = Math.sin(angle);
/* 244 */     int centerZ = centerPos.method_10260();
/* 245 */     int centerZ2 = centerPos.method_10260();
/* 246 */     double cosAngle = Math.cos(angle);
/* 247 */     int centerY = centerPos.method_10264();
/* 248 */     int centerY2 = centerPos.method_10264();
/* 249 */     int minX = centerPos.method_10263() - class_3532.method_15386(radius) - maxRadius;
/* 250 */     int minY = centerPos.method_10264() - 2 - maxRadius;
/* 251 */     int minZ = centerPos.method_10260() - class_3532.method_15386(radius) - maxRadius;
/* 252 */     int range = 2 * (class_3532.method_15386(radius) + maxRadius);
/*     */     
/* 254 */     for (int x = minX; x <= minX + range; x++) {
/* 255 */       for (int z = minZ; z <= minZ + range; z++) {
/* 256 */         if (minY <= world.method_8624(class_2902.class_2903.field_13197, x, z)) {
/* 257 */           return generateOreLocations(world, random, oreSize, centerX + 
/*     */ 
/*     */ 
/*     */               
/* 261 */               Math.sin(angle) * radius, centerX2 - sinAngle * radius, centerZ + 
/*     */               
/* 263 */               Math.cos(angle) * radius, centerZ2 - cosAngle * radius, (centerY + random
/*     */               
/* 265 */               .method_43048(3) - 2), (centerY2 + random
/* 266 */               .method_43048(3) - 2), minX, minY, minZ, range, 2 * (2 + maxRadius), discardChance);
/*     */         }
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 278 */     return new ArrayList<>();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private ArrayList<class_243> generateOreLocations(class_638 world, class_2919 random, int oreSize, double startX, double endX, double startZ, double endZ, double startY, double endY, int minX, int minY, int minZ, int range, int heightRange, float discardChance) {
/* 298 */     BitSet occupiedPositions = new BitSet(range * heightRange * range);
/* 299 */     class_2338.class_2339 blockPos = new class_2338.class_2339();
/* 300 */     double[] orePoints = new double[oreSize * 4];
/* 301 */     ArrayList<class_243> oreLocations = new ArrayList<>();
/*     */     
/* 303 */     for (int j = 0; j < oreSize; j++) {
/* 304 */       float progress = j / oreSize;
/* 305 */       double x = class_3532.method_16436(progress, startX, endX);
/* 306 */       double y = class_3532.method_16436(progress, startY, endY);
/* 307 */       double z = class_3532.method_16436(progress, startZ, endZ);
/* 308 */       orePoints[j * 4] = x;
/* 309 */       orePoints[j * 4 + 1] = y;
/* 310 */       orePoints[j * 4 + 2] = z;
/* 311 */       orePoints[j * 4 + 3] = ((class_3532.method_15374(3.1415927F * progress) + 1.0F) * random.method_43058() * oreSize / 16.0D + 1.0D) / 2.0D;
/*     */     } 
/*     */     
/* 314 */     for (int i = 0; i < oreSize - 1; i++) {
/* 315 */       double radius1 = orePoints[i * 4 + 3];
/* 316 */       if (radius1 > 0.0D) {
/* 317 */         for (int k = i + 1; k < oreSize; k++) {
/* 318 */           double radius2 = orePoints[k * 4 + 3];
/* 319 */           if (radius2 > 0.0D) {
/* 320 */             double x1 = orePoints[i * 4];
/* 321 */             double x2 = orePoints[k * 4];
/* 322 */             double dx = x1 - x2;
/* 323 */             double y1 = orePoints[i * 4 + 1];
/* 324 */             double y2 = orePoints[k * 4 + 1];
/* 325 */             double dy = y1 - y2;
/* 326 */             double z1 = orePoints[i * 4 + 2];
/* 327 */             double z2 = orePoints[k * 4 + 2];
/* 328 */             double dz = z1 - z2;
/* 329 */             double r1 = orePoints[i * 4 + 3];
/* 330 */             double r2 = orePoints[k * 4 + 3];
/* 331 */             double dr = r1 - r2;
/* 332 */             if (dr * dr > dx * dx + dy * dy + dz * dz) {
/* 333 */               if (dr > 0.0D) {
/* 334 */                 orePoints[k * 4 + 3] = -1.0D;
/*     */               } else {
/* 336 */                 orePoints[i * 4 + 3] = -1.0D;
/*     */               } 
/*     */             }
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 344 */     for (int pointIndex = 0; pointIndex < oreSize; pointIndex++) {
/* 345 */       double radius = orePoints[pointIndex * 4 + 3];
/* 346 */       if (radius >= 0.0D) {
/* 347 */         double centerX = orePoints[pointIndex * 4];
/* 348 */         double centerY = orePoints[pointIndex * 4 + 1];
/* 349 */         double centerZ = orePoints[pointIndex * 4 + 2];
/* 350 */         int minBlockX = Math.max(class_3532.method_15357(centerX - radius), minX);
/* 351 */         int minBlockY = Math.max(class_3532.method_15357(centerY - radius), minY);
/* 352 */         int minBlockZ = Math.max(class_3532.method_15357(centerZ - radius), minZ);
/* 353 */         int maxBlockX = Math.max(class_3532.method_15357(centerX + radius), minBlockX);
/* 354 */         int maxBlockY = Math.max(class_3532.method_15357(centerY + radius), minBlockY);
/*     */         
/* 356 */         for (int maxBlockZ = Math.max(class_3532.method_15357(centerZ + radius), minBlockZ); minBlockX <= maxBlockX; minBlockX++) {
/* 357 */           double normalizedX = (minBlockX + 0.5D - centerX) / radius;
/* 358 */           if (normalizedX * normalizedX < 1.0D) {
/* 359 */             while (minBlockY <= maxBlockY) {
/* 360 */               double normalizedY = (minBlockY + 0.5D - centerY) / radius;
/* 361 */               if (normalizedX * normalizedX + normalizedY * normalizedY < 1.0D && minBlockZ <= maxBlockZ) {
/* 362 */                 double normalizedZ = (minBlockZ + 0.5D - centerZ) / radius;
/* 363 */                 if (normalizedX * normalizedX + normalizedY * normalizedY + normalizedZ * normalizedZ < 1.0D) {
/* 364 */                   int bitIndex = minBlockX - minX + (minBlockY - minY) * range + (minBlockZ - minZ) * range * heightRange;
/* 365 */                   if (!occupiedPositions.get(bitIndex)) {
/* 366 */                     occupiedPositions.set(bitIndex);
/* 367 */                     blockPos.method_10103(minBlockX, minBlockY, minBlockZ);
/* 368 */                     if (minBlockY >= -64 && minBlockY < 320 && world.method_8320((class_2338)blockPos).method_26225() && isValidOreLocation(world, (class_2338)blockPos, discardChance, random)) {
/* 369 */                       oreLocations.add(new class_243(minBlockX, minBlockY, minBlockZ));
/*     */                     }
/*     */                   } 
/*     */                 } 
/*     */                 
/* 374 */                 minBlockZ++;
/*     */               } 
/*     */               
/* 377 */               minBlockY++;
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 384 */     return oreLocations;
/*     */   }
/*     */   
/*     */   private boolean isValidOreLocation(class_638 world, class_2338 pos, float discardChance, class_2919 random) {
/* 388 */     if (discardChance != 0.0F && (discardChance == 1.0F || random.method_43057() < discardChance)) {
/* 389 */       class_2350[] directions = class_2350.values();
/*     */       
/* 391 */       for (class_2350 direction : directions) {
/* 392 */         if (!world.method_8320(pos.method_10081(direction.method_10163())).method_26225() && discardChance != 1.0F) {
/* 393 */           return false;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 398 */     return true;
/*     */   }
/*     */   
/*     */   private ArrayList<class_243> generateOreLocations(class_638 world, class_2919 random, class_2338 centerPos, int oreSize) {
/* 402 */     ArrayList<class_243> oreLocations = new ArrayList<>();
/* 403 */     int actualOreSize = random.method_43048(oreSize + 1);
/*     */     
/* 405 */     for (int oreIndex = 0; oreIndex < actualOreSize; oreIndex++) {
/* 406 */       int maxOffset = Math.min(oreIndex, 7);
/* 407 */       int offsetX = random(random, maxOffset) + centerPos.method_10263();
/* 408 */       int offsetY = random(random, maxOffset) + centerPos.method_10264();
/* 409 */       int offsetZ = random(random, maxOffset) + centerPos.method_10260();
/* 410 */       if (world.method_8320(new class_2338(offsetX, offsetY, offsetZ)).method_26225() && isValidOreLocation(world, new class_2338(offsetX, offsetY, offsetZ), 1.0F, random)) {
/* 411 */         oreLocations.add(new class_243(offsetX, offsetY, offsetZ));
/*     */       }
/*     */     } 
/*     */     
/* 415 */     return oreLocations;
/*     */   }
/*     */   
/*     */   private int random(class_2919 random, int maxOffset) {
/* 419 */     return Math.round((random.method_43057() - random.method_43057()) * maxOffset);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\donut\NetheriteFinder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */