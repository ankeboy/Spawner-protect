/*    */ package dev.FORE.module.modules.crystal;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.setting.BooleanSetting;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1713;
/*    */ import net.minecraft.class_1723;
/*    */ import net.minecraft.class_1735;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_437;
/*    */ import net.minecraft.class_490;
/*    */ 
/*    */ public final class HoverTotem extends Module {
/* 18 */   private final NumberSetting tickDelay = (new NumberSetting((CharSequence)EncryptedString.of("Tick Delay"), 0.0D, 20.0D, 0.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("Ticks to wait between operations"));
/* 19 */   private final BooleanSetting hotbarTotem = (new BooleanSetting((CharSequence)EncryptedString.of("Hotbar Totem"), true)).setDescription((CharSequence)EncryptedString.of("Also places a totem in your preferred hotbar slot"));
/* 20 */   private final NumberSetting hotbarSlot = (new NumberSetting((CharSequence)EncryptedString.of("Hotbar Slot"), 1.0D, 9.0D, 1.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("Your preferred hotbar slot for totem (1-9)"));
/* 21 */   private final BooleanSetting autoSwitchToTotem = (new BooleanSetting((CharSequence)EncryptedString.of("Auto Switch To Totem"), false)).setDescription((CharSequence)EncryptedString.of("Automatically switches to totem slot when inventory is opened"));
/*    */   private int remainingDelay;
/*    */   
/*    */   public HoverTotem() {
/* 25 */     super((CharSequence)EncryptedString.of("Hover Totem"), (CharSequence)EncryptedString.of("Equips a totem in offhand and optionally hotbar when hovering over one in inventory"), -1, Category.CRYSTAL);
/* 26 */     addsettings(new Setting[] { (Setting)this.tickDelay, (Setting)this.hotbarTotem, (Setting)this.hotbarSlot, (Setting)this.autoSwitchToTotem });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 31 */     resetDelay();
/* 32 */     super.onEnable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {
/* 37 */     if (this.mc.field_1724 == null) {
/*    */       return;
/*    */     }
/* 40 */     class_437 currentScreen = this.mc.field_1755;
/* 41 */     if (!(this.mc.field_1755 instanceof class_490)) {
/* 42 */       resetDelay();
/*    */       return;
/*    */     } 
/* 45 */     class_1735 focusedSlot = ((HandledScreenMixin)currentScreen).getFocusedSlot();
/* 46 */     if (focusedSlot == null || focusedSlot.method_34266() > 35) {
/*    */       return;
/*    */     }
/* 49 */     if (this.autoSwitchToTotem.getValue()) {
/* 50 */       (this.mc.field_1724.method_31548()).field_7545 = this.hotbarSlot.getIntValue() - 1;
/*    */     }
/* 52 */     if (focusedSlot.method_7677().method_7909() != class_1802.field_8288) {
/*    */       return;
/*    */     }
/* 55 */     if (this.remainingDelay > 0) {
/* 56 */       this.remainingDelay--;
/*    */       return;
/*    */     } 
/* 59 */     int index = focusedSlot.method_34266();
/* 60 */     int syncId = ((class_1723)((class_490)currentScreen).method_17577()).field_7763;
/* 61 */     if (!this.mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
/* 62 */       equipOffhandTotem(syncId, index);
/*    */       return;
/*    */     } 
/* 65 */     if (this.hotbarTotem.getValue()) {
/* 66 */       int n = this.hotbarSlot.getIntValue() - 1;
/* 67 */       if (!this.mc.field_1724.method_31548().method_5438(n).method_31574(class_1802.field_8288)) {
/* 68 */         equipHotbarTotem(syncId, index, n);
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private void equipOffhandTotem(int syncId, int slotIndex) {
/* 74 */     this.mc.field_1761.method_2906(syncId, slotIndex, 40, class_1713.field_7791, (class_1657)this.mc.field_1724);
/* 75 */     resetDelay();
/*    */   }
/*    */   
/*    */   private void equipHotbarTotem(int syncId, int slotIndex, int hotbarSlotIndex) {
/* 79 */     this.mc.field_1761.method_2906(syncId, slotIndex, hotbarSlotIndex, class_1713.field_7791, (class_1657)this.mc.field_1724);
/* 80 */     resetDelay();
/*    */   }
/*    */   
/*    */   private void resetDelay() {
/* 84 */     this.remainingDelay = this.tickDelay.getIntValue();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\crystal\HoverTotem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */