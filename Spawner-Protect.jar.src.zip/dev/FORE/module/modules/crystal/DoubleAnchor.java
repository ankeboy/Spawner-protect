/*     */ package dev.FORE.module.modules.crystal;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BindSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.BlockUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.InventoryUtil;
/*     */ import dev.FORE.utils.KeyUtils;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_3965;
/*     */ 
/*     */ public final class DoubleAnchor extends Module {
/*  20 */   private final BindSetting activateKey = (new BindSetting((CharSequence)EncryptedString.of("Activate Key"), 71, false)).setDescription((CharSequence)EncryptedString.of("Key that starts double anchoring"));
/*  21 */   private final NumberSetting switchDelay = new NumberSetting((CharSequence)EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  22 */   private final NumberSetting totemSlot = new NumberSetting((CharSequence)EncryptedString.of("Totem Slot"), 1.0D, 9.0D, 1.0D, 1.0D);
/*  23 */   private int delayCounter = 0;
/*  24 */   private int step = 0;
/*     */   private boolean isAnchoring = false;
/*     */   
/*     */   public DoubleAnchor() {
/*  28 */     super((CharSequence)EncryptedString.of("Double Anchor"), (CharSequence)EncryptedString.of("Automatically Places 2 anchors"), -1, Category.CRYSTAL);
/*  29 */     addsettings(new Setting[] { (Setting)this.switchDelay, (Setting)this.totemSlot, (Setting)this.activateKey });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  34 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  39 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  44 */     if (this.mc.field_1755 != null) {
/*     */       return;
/*     */     }
/*  47 */     if (this.mc.field_1724 == null) {
/*     */       return;
/*     */     }
/*  50 */     if (!hasRequiredItems()) {
/*     */       return;
/*     */     }
/*  53 */     if (!this.isAnchoring && !checkActivationKey()) {
/*     */       return;
/*     */     }
/*  56 */     class_239 crosshairTarget = this.mc.field_1765;
/*  57 */     if (!(this.mc.field_1765 instanceof class_3965) || BlockUtil.isBlockAtPosition(((class_3965)crosshairTarget).method_17777(), class_2246.field_10124)) {
/*  58 */       this.isAnchoring = false;
/*  59 */       resetState();
/*     */       return;
/*     */     } 
/*  62 */     if (this.delayCounter < this.switchDelay.getIntValue()) {
/*  63 */       this.delayCounter++;
/*     */       return;
/*     */     } 
/*  66 */     if (this.step == 0) {
/*  67 */       InventoryUtil.swap(class_1802.field_23141);
/*  68 */     } else if (this.step == 1) {
/*  69 */       BlockUtil.interactWithBlock((class_3965)crosshairTarget, true);
/*  70 */     } else if (this.step == 2) {
/*  71 */       InventoryUtil.swap(class_1802.field_8801);
/*  72 */     } else if (this.step == 3) {
/*  73 */       BlockUtil.interactWithBlock((class_3965)crosshairTarget, true);
/*  74 */     } else if (this.step == 4) {
/*  75 */       InventoryUtil.swap(class_1802.field_23141);
/*  76 */     } else if (this.step == 5) {
/*  77 */       BlockUtil.interactWithBlock((class_3965)crosshairTarget, true);
/*  78 */       BlockUtil.interactWithBlock((class_3965)crosshairTarget, true);
/*  79 */     } else if (this.step == 6) {
/*  80 */       InventoryUtil.swap(class_1802.field_8801);
/*  81 */     } else if (this.step == 7) {
/*  82 */       BlockUtil.interactWithBlock((class_3965)crosshairTarget, true);
/*  83 */     } else if (this.step == 8) {
/*  84 */       InventoryUtil.swap(this.totemSlot.getIntValue() - 1);
/*  85 */     } else if (this.step == 9) {
/*  86 */       BlockUtil.interactWithBlock((class_3965)crosshairTarget, true);
/*  87 */     } else if (this.step == 10) {
/*  88 */       this.isAnchoring = false;
/*  89 */       this.step = 0;
/*  90 */       resetState();
/*     */       return;
/*     */     } 
/*  93 */     this.step++;
/*     */   }
/*     */   
/*     */   private boolean hasRequiredItems() {
/*  97 */     boolean hasAnchor = false;
/*  98 */     boolean hasGlowstone = false;
/*  99 */     for (int slotIndex = 0; slotIndex < 9; slotIndex++) {
/* 100 */       class_1799 itemStack = this.mc.field_1724.method_31548().method_5438(slotIndex);
/* 101 */       if (itemStack.method_7909().equals(class_1802.field_23141)) {
/* 102 */         hasAnchor = true;
/*     */       }
/* 104 */       if (itemStack.method_7909().equals(class_1802.field_8801)) {
/* 105 */         hasGlowstone = true;
/*     */       }
/*     */     } 
/* 108 */     return (hasAnchor && hasGlowstone);
/*     */   }
/*     */   
/*     */   private boolean checkActivationKey() {
/* 112 */     int keyCode = this.activateKey.getValue();
/* 113 */     if (keyCode == -1 || !KeyUtils.isKeyPressed(keyCode)) {
/* 114 */       resetState();
/* 115 */       return false;
/*     */     } 
/* 117 */     return this.isAnchoring = true;
/*     */   }
/*     */   
/*     */   private void resetState() {
/* 121 */     this.delayCounter = 0;
/*     */   }
/*     */   
/*     */   public boolean isAnchoringActive() {
/* 125 */     return this.isAnchoring;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\crystal\DoubleAnchor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */