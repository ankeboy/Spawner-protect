/*     */ package dev.FORE.module.modules.crystal;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import java.util.function.Predicate;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1661;
/*     */ import net.minecraft.class_1713;
/*     */ import net.minecraft.class_1723;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_490;
/*     */ 
/*     */ public final class AutoInventoryTotem extends Module {
/*  21 */   private final NumberSetting delay = new NumberSetting((CharSequence)EncryptedString.of("Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  22 */   private final BooleanSetting hotbar = (new BooleanSetting((CharSequence)EncryptedString.of("Hotbar"), true)).setDescription((CharSequence)EncryptedString.of("Puts a totem in your hotbar as well, if enabled (Setting below will work if this is enabled)"));
/*  23 */   private final NumberSetting totemSlot = (new NumberSetting((CharSequence)EncryptedString.of("Totem Slot"), 1.0D, 9.0D, 1.0D, 1.0D)).getValue((CharSequence)EncryptedString.of("Your preferred totem slot"));
/*  24 */   private final BooleanSetting autoSwitch = (new BooleanSetting((CharSequence)EncryptedString.of("Auto Switch"), false)).setDescription((CharSequence)EncryptedString.of("Switches to totem slot when going inside the inventory"));
/*  25 */   private final BooleanSetting forceTotem = (new BooleanSetting((CharSequence)EncryptedString.of("Force Totem"), false)).setDescription((CharSequence)EncryptedString.of("Puts the totem in the slot, regardless if its space is taken up by something else"));
/*  26 */   private final BooleanSetting autoOpen = (new BooleanSetting((CharSequence)EncryptedString.of("Auto Open"), false)).setDescription((CharSequence)EncryptedString.of("Automatically opens and closes the inventory for you"));
/*  27 */   private final NumberSetting stayOpenDuration = new NumberSetting((CharSequence)EncryptedString.of("Stay Open For"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  28 */   int delayCounter = -1;
/*  29 */   int stayOpenCounter = -1;
/*     */   
/*     */   public AutoInventoryTotem() {
/*  32 */     super((CharSequence)EncryptedString.of("Auto Inv Totem"), (CharSequence)EncryptedString.of("Automatically equips a totem in your offhand and main hand if empty"), -1, Category.CRYSTAL);
/*  33 */     addsettings(new Setting[] { (Setting)this.delay, (Setting)this.hotbar, (Setting)this.totemSlot, (Setting)this.autoSwitch, (Setting)this.forceTotem, (Setting)this.autoOpen, (Setting)this.stayOpenDuration });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  38 */     this.delayCounter = -1;
/*  39 */     this.stayOpenCounter = -1;
/*  40 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  45 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent event) {
/*  50 */     if (shouldOpenInventory() && this.autoOpen.getValue()) {
/*  51 */       this.mc.method_1507((class_437)new FakeInvScreen((class_1657)this.mc.field_1724));
/*     */     }
/*  53 */     if (!(this.mc.field_1755 instanceof class_490) && !(this.mc.field_1755 instanceof FakeInvScreen)) {
/*  54 */       this.delayCounter = -1;
/*  55 */       this.stayOpenCounter = -1;
/*     */       return;
/*     */     } 
/*  58 */     if (this.delayCounter == -1) {
/*  59 */       this.delayCounter = this.delay.getIntValue();
/*     */     }
/*  61 */     if (this.stayOpenCounter == -1) {
/*  62 */       this.stayOpenCounter = this.stayOpenDuration.getIntValue();
/*     */     }
/*  64 */     if (this.delayCounter > 0) {
/*  65 */       this.delayCounter--;
/*     */     }
/*  67 */     class_1661 inventory = this.mc.field_1724.method_31548();
/*  68 */     if (this.autoSwitch.getValue()) {
/*  69 */       inventory.field_7545 = this.totemSlot.getIntValue() - 1;
/*     */     }
/*  71 */     if (this.delayCounter <= 0) {
/*  72 */       if (((class_1799)inventory.field_7544.get(0)).method_7909() != class_1802.field_8288) {
/*  73 */         int totemSlotIndex = findTotemSlot();
/*  74 */         if (totemSlotIndex != -1) {
/*  75 */           this.mc.field_1761.method_2906(((class_1723)((class_490)this.mc.field_1755).method_17577()).field_7763, totemSlotIndex, 40, class_1713.field_7791, (class_1657)this.mc.field_1724);
/*     */           return;
/*     */         } 
/*     */       } 
/*  79 */       if (this.hotbar.getValue()) {
/*  80 */         class_1799 mainHandStack = this.mc.field_1724.method_6047();
/*  81 */         if (mainHandStack.method_7960() || (this.forceTotem.getValue() && mainHandStack.method_7909() != class_1802.field_8288)) {
/*  82 */           int totemSlotIndex = findTotemSlot();
/*  83 */           if (totemSlotIndex != -1) {
/*  84 */             this.mc.field_1761.method_2906(((class_1723)((class_490)this.mc.field_1755).method_17577()).field_7763, totemSlotIndex, inventory.field_7545, class_1713.field_7791, (class_1657)this.mc.field_1724);
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       } 
/*  89 */       if (isTotemEquipped() && this.autoOpen.getValue()) {
/*  90 */         if (this.stayOpenCounter != 0) {
/*  91 */           this.stayOpenCounter--;
/*     */           return;
/*     */         } 
/*  94 */         this.mc.field_1755.method_25419();
/*  95 */         this.stayOpenCounter = this.stayOpenDuration.getIntValue();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean isTotemEquipped() {
/* 101 */     if (this.hotbar.getValue()) {
/* 102 */       return (this.mc.field_1724.method_31548().method_5438(this.totemSlot.getIntValue() - 1).method_7909() == class_1802.field_8288 && this.mc.field_1724.method_6079().method_7909() == class_1802.field_8288 && this.mc.field_1755 instanceof FakeInvScreen);
/*     */     }
/* 104 */     return (this.mc.field_1724.method_6079().method_7909() == class_1802.field_8288 && this.mc.field_1755 instanceof FakeInvScreen);
/*     */   }
/*     */   
/*     */   public boolean shouldOpenInventory() {
/* 108 */     if (this.hotbar.getValue()) {
/* 109 */       return ((this.mc.field_1724.method_6079().method_7909() != class_1802.field_8288 || this.mc.field_1724.method_31548().method_5438(this.totemSlot.getIntValue() - 1).method_7909() != class_1802.field_8288) && !(this.mc.field_1755 instanceof FakeInvScreen) && countTotems(item -> (item == class_1802.field_8288)) != 0);
/*     */     }
/* 111 */     return (this.mc.field_1724.method_6079().method_7909() != class_1802.field_8288 && !(this.mc.field_1755 instanceof FakeInvScreen) && countTotems(item2 -> (item2 == class_1802.field_8288)) != 0);
/*     */   }
/*     */   
/*     */   private int findTotemSlot() {
/* 115 */     class_1661 inventory = this.mc.field_1724.method_31548();
/* 116 */     for (int slotIndex = 0; slotIndex < inventory.field_7547.size(); slotIndex++) {
/* 117 */       if (((class_1799)inventory.field_7547.get(slotIndex)).method_7909() == class_1802.field_8288) {
/* 118 */         return slotIndex;
/*     */       }
/*     */     } 
/* 121 */     return -1;
/*     */   }
/*     */   
/*     */   private int countTotems(Predicate<class_1792> predicate) {
/* 125 */     int count = 0;
/* 126 */     class_1661 inventory = this.mc.field_1724.method_31548();
/* 127 */     for (int slotIndex = 0; slotIndex < inventory.field_7547.size(); slotIndex++) {
/* 128 */       class_1799 stack = (class_1799)inventory.field_7547.get(slotIndex);
/* 129 */       if (predicate.test(stack.method_7909())) {
/* 130 */         count += stack.method_7947();
/*     */       }
/*     */     } 
/* 133 */     return count;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\crystal\AutoInventoryTotem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */