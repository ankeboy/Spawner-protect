/*     */ package dev.FORE.module.modules.crystal;
/*     */ 
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.PreItemUseEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BindSetting;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.BlockUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.KeyUtils;
/*     */ import dev.FORE.utils.WorldUtils;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_3966;
/*     */ 
/*     */ public final class AutoCrystal extends Module {
/*  28 */   private final BindSetting activateKey = (new BindSetting((CharSequence)EncryptedString.of("Activate Key"), 1, false)).setDescription((CharSequence)EncryptedString.of("Key that does the crystalling"));
/*  29 */   private final NumberSetting placeDelay = new NumberSetting((CharSequence)EncryptedString.of("Place Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  30 */   private final NumberSetting breakDelay = new NumberSetting((CharSequence)EncryptedString.of("Break Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  31 */   private final BooleanSetting stopOnKill = (new BooleanSetting((CharSequence)EncryptedString.of("Stop on Kill"), false)).setDescription((CharSequence)EncryptedString.of("Stops crystalling when a player dies nearby"));
/*     */   private int placeDelayCounter;
/*     */   private int breakDelayCounter;
/*     */   public boolean isActive;
/*     */   
/*     */   public AutoCrystal() {
/*  37 */     super((CharSequence)EncryptedString.of("Auto Crystal"), (CharSequence)EncryptedString.of("Automatically crystals fast for you"), -1, Category.CRYSTAL);
/*  38 */     addsettings(new Setting[] { (Setting)this.activateKey, (Setting)this.placeDelay, (Setting)this.breakDelay, (Setting)this.stopOnKill });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  43 */     resetCounters();
/*  44 */     this.isActive = false;
/*  45 */     super.onEnable();
/*     */   }
/*     */   
/*     */   private void resetCounters() {
/*  49 */     this.placeDelayCounter = 0;
/*  50 */     this.breakDelayCounter = 0;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent tickEvent) {
/*  55 */     if (this.mc.field_1755 != null) {
/*     */       return;
/*     */     }
/*  58 */     updateCounters();
/*  59 */     if (this.mc.field_1724.method_6115()) {
/*     */       return;
/*     */     }
/*  62 */     if (!isKeyActive()) {
/*     */       return;
/*     */     }
/*  65 */     if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_8301) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  70 */     if (this.stopOnKill.getValue() && WorldUtils.isDeadBodyNearby()) {
/*     */       return;
/*     */     }
/*     */     
/*  74 */     handleInteraction();
/*     */   }
/*     */   
/*     */   private void updateCounters() {
/*  78 */     if (this.placeDelayCounter > 0) {
/*  79 */       this.placeDelayCounter--;
/*     */     }
/*  81 */     if (this.breakDelayCounter > 0) {
/*  82 */       this.breakDelayCounter--;
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isKeyActive() {
/*  87 */     int activateKeyCode = this.activateKey.getValue();
/*  88 */     if (activateKeyCode != -1 && !KeyUtils.isKeyPressed(activateKeyCode)) {
/*  89 */       resetCounters();
/*  90 */       return this.isActive = false;
/*     */     } 
/*  92 */     return this.isActive = true;
/*     */   }
/*     */   
/*     */   private void handleInteraction() {
/*  96 */     class_239 crosshairTarget = this.mc.field_1765;
/*  97 */     if (this.mc.field_1765 instanceof class_3965)
/*  98 */     { handleBlockInteraction((class_3965)crosshairTarget); }
/*  99 */     else { class_239 class_239 = this.mc.field_1765; if (class_239 instanceof class_3966) { class_3966 entityHitResult = (class_3966)class_239;
/* 100 */         handleEntityInteraction(entityHitResult); }
/*     */        }
/*     */   
/*     */   }
/*     */   private void handleBlockInteraction(class_3965 blockHitResult) {
/* 105 */     if (blockHitResult.method_17783() != class_239.class_240.field_1332) {
/*     */       return;
/*     */     }
/* 108 */     if (this.placeDelayCounter > 0) {
/*     */       return;
/*     */     }
/* 111 */     class_2338 blockPos = blockHitResult.method_17777();
/* 112 */     if ((BlockUtil.isBlockAtPosition(blockPos, class_2246.field_10540) || BlockUtil.isBlockAtPosition(blockPos, class_2246.field_9987)) && isValidCrystalPlacement(blockPos)) {
/* 113 */       BlockUtil.interactWithBlock(blockHitResult, true);
/* 114 */       this.placeDelayCounter = this.placeDelay.getIntValue();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void handleEntityInteraction(class_3966 entityHitResult) {
/* 119 */     if (this.breakDelayCounter > 0) {
/*     */       return;
/*     */     }
/* 122 */     class_1297 entity = entityHitResult.method_17782();
/* 123 */     if (!(entity instanceof net.minecraft.class_1511) && !(entity instanceof net.minecraft.class_1621)) {
/*     */       return;
/*     */     }
/* 126 */     this.mc.field_1761.method_2918((class_1657)this.mc.field_1724, entity);
/* 127 */     this.mc.field_1724.method_6104(class_1268.field_5808);
/* 128 */     this.breakDelayCounter = this.breakDelay.getIntValue();
/*     */   }
/*     */   @EventListener
/*     */   public void onPreItemUse(PreItemUseEvent preItemUseEvent) {
/*     */     class_3965 blockHitResult;
/* 133 */     if (this.mc.field_1724.method_6047().method_7909() != class_1802.field_8301) {
/*     */       return;
/*     */     }
/* 136 */     class_239 class_239 = this.mc.field_1765; if (class_239 instanceof class_3965) { blockHitResult = (class_3965)class_239; }
/*     */     else
/*     */     { return; }
/* 139 */      if (this.mc.field_1765.method_17783() != class_239.class_240.field_1332) {
/*     */       return;
/*     */     }
/* 142 */     class_2338 blockPos = blockHitResult.method_17777();
/* 143 */     if (BlockUtil.isBlockAtPosition(blockPos, class_2246.field_10540) || BlockUtil.isBlockAtPosition(blockPos, class_2246.field_9987)) {
/* 144 */       preItemUseEvent.cancel();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isValidCrystalPlacement(class_2338 blockPos) {
/* 149 */     class_2338 up = blockPos.method_10084();
/* 150 */     if (!this.mc.field_1687.method_22347(up)) {
/* 151 */       return false;
/*     */     }
/* 153 */     int crystalX = up.method_10263();
/* 154 */     int crystalY = up.method_10264();
/* 155 */     int crystalZ = up.method_10260();
/* 156 */     return this.mc.field_1687.method_8335(null, new class_238(crystalX, crystalY, crystalZ, crystalX + 1.0D, crystalY + 2.0D, crystalZ + 1.0D)).isEmpty();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\crystal\AutoCrystal.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */