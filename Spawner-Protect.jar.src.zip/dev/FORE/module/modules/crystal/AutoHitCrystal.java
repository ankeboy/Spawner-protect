/*     */ package dev.FORE.module.modules.crystal;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.AttackEvent;
/*     */ import dev.FORE.event.events.PreItemUseEvent;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BindSetting;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.BlockUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.InventoryUtil;
/*     */ import dev.FORE.utils.KeyUtils;
/*     */ import dev.FORE.utils.MathUtil;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_2248;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_3965;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ public final class AutoHitCrystal extends Module {
/*  25 */   private final BindSetting activateKey = (new BindSetting((CharSequence)EncryptedString.of("Activate Key"), 1, false))
/*  26 */     .setDescription((CharSequence)EncryptedString.of("Key that does hit crystalling"));
/*  27 */   private final BooleanSetting checkPlace = (new BooleanSetting((CharSequence)EncryptedString.of("Check Place"), false))
/*  28 */     .setDescription((CharSequence)EncryptedString.of("Checks if you can place the obsidian on that block"));
/*  29 */   private final NumberSetting switchDelay = new NumberSetting((CharSequence)EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  30 */   private final NumberSetting switchChance = new NumberSetting((CharSequence)EncryptedString.of("Switch Chance"), 0.0D, 100.0D, 100.0D, 1.0D);
/*  31 */   private final NumberSetting placeDelay = new NumberSetting((CharSequence)EncryptedString.of("Place Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  32 */   private final NumberSetting placeChance = new NumberSetting((CharSequence)EncryptedString.of("Place Chance"), 0.0D, 100.0D, 100.0D, 1.0D);
/*  33 */   private final BooleanSetting workWithTotem = new BooleanSetting((CharSequence)EncryptedString.of("Work With Totem"), false);
/*  34 */   private final BooleanSetting workWithCrystal = new BooleanSetting((CharSequence)EncryptedString.of("Work With Crystal"), false);
/*     */   
/*  36 */   private final BooleanSetting swordSwap = new BooleanSetting((CharSequence)EncryptedString.of("Sword Swap"), true);
/*     */   
/*  38 */   private int placeClock = 0;
/*  39 */   private int switchClock = 0;
/*     */   private boolean active;
/*     */   private boolean crystalling;
/*     */   private boolean crystalSelected;
/*     */   
/*     */   public AutoHitCrystal() {
/*  45 */     super((CharSequence)EncryptedString.of("Auto Hit Crystal"), 
/*  46 */         (CharSequence)EncryptedString.of("Automatically hit-crystals for you"), -1, Category.CRYSTAL);
/*     */ 
/*     */     
/*  49 */     addsettings(new Setting[] { (Setting)this.activateKey, (Setting)this.checkPlace, (Setting)this.switchDelay, (Setting)this.switchChance, (Setting)this.placeDelay, (Setting)this.placeChance, (Setting)this.workWithTotem, (Setting)this.workWithCrystal, (Setting)this.swordSwap });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  54 */     reset();
/*  55 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  60 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent tickEvent) {
/*  65 */     int randomChance = MathUtil.randomInt(1, 100);
/*     */     
/*  67 */     if (this.mc.field_1755 != null) {
/*     */       return;
/*     */     }
/*  70 */     if (KeyUtils.isKeyPressed(this.activateKey.getValue())) {
/*  71 */       class_239 class_2391 = this.mc.field_1765; if (class_2391 instanceof class_3965) { class_3965 hitResult = (class_3965)class_2391; if (this.mc.field_1765.method_17783() == class_239.class_240.field_1332 && 
/*  72 */           !this.active && !BlockUtil.canPlaceBlockClient(hitResult.method_17777()) && this.checkPlace.getValue())
/*     */           return;  }
/*     */       
/*  75 */       class_1799 mainHandStack = this.mc.field_1724.method_6047();
/*     */       
/*  77 */       if (!(mainHandStack.method_7909() instanceof net.minecraft.class_1829) && (!this.workWithTotem.getValue() || !mainHandStack.method_31574(class_1802.field_8288)) && (!this.workWithCrystal.getValue() || !mainHandStack.method_31574(class_1802.field_8301)) && !this.active)
/*     */         return; 
/*  79 */       class_239 class_2392 = this.mc.field_1765; if (class_2392 instanceof class_3965) { class_3965 hitResult = (class_3965)class_2392; if (!this.active && 
/*  80 */           this.swordSwap.getValue() && 
/*  81 */           this.mc.field_1765.method_17783() == class_239.class_240.field_1332) {
/*  82 */           class_2248 targetBlock = this.mc.field_1687.method_8320(hitResult.method_17777()).method_26204();
/*     */           
/*  84 */           this.crystalling = (targetBlock == class_2246.field_10540 || targetBlock == class_2246.field_9987);
/*     */         }  }
/*     */ 
/*     */ 
/*     */       
/*  89 */       this.active = true;
/*     */       
/*  91 */       if (!this.crystalling) {
/*  92 */         class_2392 = this.mc.field_1765; if (class_2392 instanceof class_3965) { class_3965 hitResult = (class_3965)class_2392;
/*  93 */           if (hitResult.method_17783() == class_239.class_240.field_1333) {
/*     */             return;
/*     */           }
/*  96 */           if (!BlockUtil.isBlock(hitResult.method_17777(), class_2246.field_10540)) {
/*  97 */             if (BlockUtil.isBlock(hitResult.method_17777(), class_2246.field_23152) && BlockUtil.isAnchorCharged(hitResult.method_17777())) {
/*     */               return;
/*     */             }
/* 100 */             this.mc.field_1690.field_1904.method_23481(false);
/*     */             
/* 102 */             if (!this.mc.field_1724.method_24518(class_1802.field_8281)) {
/* 103 */               if (this.switchClock > 0) {
/* 104 */                 this.switchClock--;
/*     */                 
/*     */                 return;
/*     */               } 
/* 108 */               if (randomChance <= this.switchChance.getIntValue()) {
/* 109 */                 this.switchClock = this.switchDelay.getIntValue();
/* 110 */                 InventoryUtil.selectItemFromHotbar(class_1802.field_8281);
/*     */               } 
/*     */             } 
/*     */             
/* 114 */             if (this.mc.field_1724.method_24518(class_1802.field_8281)) {
/* 115 */               if (this.placeClock > 0) {
/* 116 */                 this.placeClock--;
/*     */                 
/*     */                 return;
/*     */               } 
/* 120 */               randomChance = MathUtil.randomInt(1, 100);
/*     */               
/* 122 */               if (randomChance <= this.placeChance.getIntValue()) {
/* 123 */                 WorldUtils.placeBlock(hitResult, true);
/*     */                 
/* 125 */                 this.placeClock = this.placeDelay.getIntValue();
/* 126 */                 this.crystalling = true;
/*     */               } 
/*     */             } 
/*     */           }  }
/*     */       
/*     */       } 
/*     */       
/* 133 */       if (this.crystalling) {
/* 134 */         if (!this.mc.field_1724.method_24518(class_1802.field_8301) && !this.crystalSelected) {
/* 135 */           if (this.switchClock > 0) {
/* 136 */             this.switchClock--;
/*     */             
/*     */             return;
/*     */           } 
/* 140 */           randomChance = MathUtil.randomInt(1, 100);
/*     */           
/* 142 */           if (randomChance <= this.switchChance.getIntValue()) {
/* 143 */             this.crystalSelected = InventoryUtil.selectItemFromHotbar(class_1802.field_8301);
/* 144 */             this.switchClock = this.switchDelay.getIntValue();
/*     */           } 
/*     */         } 
/*     */         
/* 148 */         if (this.mc.field_1724.method_24518(class_1802.field_8301)) {
/* 149 */           Module autoCrystalModule = DonutBBC.INSTANCE.getModuleManager().getModuleByClass(AutoCrystal.class);
/*     */           
/* 151 */           if (autoCrystalModule != null && !autoCrystalModule.isEnabled())
/*     */           {
/* 153 */             autoCrystalModule.toggle(true); } 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 157 */       reset();
/*     */     } 
/*     */   }
/*     */   @EventListener
/*     */   public void onItemUse(PreItemUseEvent event) {
/* 162 */     class_1799 mainHandStack = this.mc.field_1724.method_6047();
/* 163 */     if ((mainHandStack.method_31574(class_1802.field_8301) || mainHandStack.method_31574(class_1802.field_8281)) && GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 1) != 1)
/* 164 */       event.cancel(); 
/*     */   }
/*     */   
/*     */   public void reset() {
/* 168 */     this.placeClock = this.placeDelay.getIntValue();
/* 169 */     this.switchClock = this.switchDelay.getIntValue();
/* 170 */     this.active = false;
/* 171 */     this.crystalling = false;
/* 172 */     this.crystalSelected = false;
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onAttack(AttackEvent event) {
/* 177 */     if (this.mc.field_1724.method_6047().method_31574(class_1802.field_8301) && GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 0) != 1)
/* 178 */       event.cancel(); 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\crystal\AutoHitCrystal.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */