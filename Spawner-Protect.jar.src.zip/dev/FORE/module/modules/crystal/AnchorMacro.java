/*     */ package dev.FORE.module.modules.crystal;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.TickEvent;
/*     */ import dev.FORE.module.Category;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.utils.BlockUtil;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import dev.FORE.utils.InventoryUtil;
/*     */ import dev.FORE.utils.KeyUtils;
/*     */ import net.minecraft.class_1802;
/*     */ import net.minecraft.class_2246;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_9334;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ public final class AnchorMacro extends Module {
/*  20 */   private final NumberSetting switchDelay = new NumberSetting((CharSequence)EncryptedString.of("Switch Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  21 */   private final NumberSetting glowstoneDelay = new NumberSetting((CharSequence)EncryptedString.of("Glowstone Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  22 */   private final NumberSetting explodeDelay = new NumberSetting((CharSequence)EncryptedString.of("Explode Delay"), 0.0D, 20.0D, 0.0D, 1.0D);
/*  23 */   private final NumberSetting totemSlot = new NumberSetting((CharSequence)EncryptedString.of("Totem Slot"), 1.0D, 9.0D, 1.0D, 1.0D);
/*     */   private int keybind;
/*     */   private int glowstoneDelayCounter;
/*     */   private int explodeDelayCounter;
/*     */   
/*     */   public AnchorMacro() {
/*  29 */     super((CharSequence)EncryptedString.of("Anchor Macro"), (CharSequence)EncryptedString.of("Automatically blows up respawn anchors for you"), -1, Category.CRYSTAL);
/*  30 */     this.keybind = 0;
/*  31 */     this.glowstoneDelayCounter = 0;
/*  32 */     this.explodeDelayCounter = 0;
/*  33 */     addsettings(new Setting[] { (Setting)this.switchDelay, (Setting)this.glowstoneDelay, (Setting)this.explodeDelay, (Setting)this.totemSlot });
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {
/*  38 */     resetCounters();
/*  39 */     super.onEnable();
/*     */   }
/*     */ 
/*     */   
/*     */   public void onDisable() {
/*  44 */     super.onDisable();
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void onTick(TickEvent tickEvent) {
/*  49 */     if (this.mc.field_1755 != null) {
/*     */       return;
/*     */     }
/*  52 */     if (isShieldOrFoodActive()) {
/*     */       return;
/*     */     }
/*  55 */     if (KeyUtils.isKeyPressed(1)) {
/*  56 */       handleAnchorInteraction();
/*     */     }
/*     */   }
/*     */   
/*     */   private boolean isShieldOrFoodActive() {
/*  61 */     boolean isFood = (this.mc.field_1724.method_6047().method_7909().method_57347().method_57832(class_9334.field_50075) || this.mc.field_1724.method_6079().method_7909().method_57347().method_57832(class_9334.field_50075));
/*  62 */     boolean isShield = (this.mc.field_1724.method_6047().method_7909() instanceof net.minecraft.class_1819 || this.mc.field_1724.method_6079().method_7909() instanceof net.minecraft.class_1819);
/*  63 */     boolean isRightClickPressed = (GLFW.glfwGetMouseButton(this.mc.method_22683().method_4490(), 1) == 1);
/*  64 */     return ((isFood || isShield) && isRightClickPressed);
/*     */   }
/*     */   private void handleAnchorInteraction() {
/*     */     class_3965 blockHitResult;
/*  68 */     class_239 class_239 = this.mc.field_1765; if (class_239 instanceof class_3965) { blockHitResult = (class_3965)class_239; }
/*     */     else
/*     */     { return; }
/*  71 */      if (!BlockUtil.isBlockAtPosition(blockHitResult.method_17777(), class_2246.field_23152)) {
/*     */       return;
/*     */     }
/*  74 */     this.mc.field_1690.field_1904.method_23481(false);
/*  75 */     if (BlockUtil.isRespawnAnchorUncharged(blockHitResult.method_17777())) {
/*  76 */       placeGlowstone(blockHitResult);
/*  77 */     } else if (BlockUtil.isRespawnAnchorCharged(blockHitResult.method_17777())) {
/*  78 */       explodeAnchor(blockHitResult);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void placeGlowstone(class_3965 blockHitResult) {
/*  83 */     if (!this.mc.field_1724.method_6047().method_31574(class_1802.field_8801)) {
/*  84 */       if (this.keybind < this.switchDelay.getIntValue()) {
/*  85 */         this.keybind++;
/*     */         return;
/*     */       } 
/*  88 */       this.keybind = 0;
/*  89 */       InventoryUtil.swap(class_1802.field_8801);
/*     */     } 
/*  91 */     if (this.mc.field_1724.method_6047().method_31574(class_1802.field_8801)) {
/*  92 */       if (this.glowstoneDelayCounter < this.glowstoneDelay.getIntValue()) {
/*  93 */         this.glowstoneDelayCounter++;
/*     */         return;
/*     */       } 
/*  96 */       this.glowstoneDelayCounter = 0;
/*  97 */       BlockUtil.interactWithBlock(blockHitResult, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void explodeAnchor(class_3965 blockHitResult) {
/* 102 */     int selectedSlot = this.totemSlot.getIntValue() - 1;
/* 103 */     if ((this.mc.field_1724.method_31548()).field_7545 != selectedSlot) {
/* 104 */       if (this.keybind < this.switchDelay.getIntValue()) {
/* 105 */         this.keybind++;
/*     */         return;
/*     */       } 
/* 108 */       this.keybind = 0;
/* 109 */       (this.mc.field_1724.method_31548()).field_7545 = selectedSlot;
/*     */     } 
/* 111 */     if ((this.mc.field_1724.method_31548()).field_7545 == selectedSlot) {
/* 112 */       if (this.explodeDelayCounter < this.explodeDelay.getIntValue()) {
/* 113 */         this.explodeDelayCounter++;
/*     */         return;
/*     */       } 
/* 116 */       this.explodeDelayCounter = 0;
/* 117 */       BlockUtil.interactWithBlock(blockHitResult, true);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void resetCounters() {
/* 122 */     this.keybind = 0;
/* 123 */     this.glowstoneDelayCounter = 0;
/* 124 */     this.explodeDelayCounter = 0;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\crystal\AnchorMacro.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */