/*    */ package dev.FORE.module.modules.crystal;
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.modules.donut.RtpBaseFinder;
/*    */ import dev.FORE.module.modules.donut.TunnelBaseFinder;
/*    */ import dev.FORE.module.setting.NumberSetting;
/*    */ import dev.FORE.module.setting.Setting;
/*    */ import dev.FORE.utils.EncryptedString;
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1713;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1802;
/*    */ 
/*    */ public final class AutoTotem extends Module {
/* 17 */   private final NumberSetting delay = new NumberSetting((CharSequence)EncryptedString.of("Delay"), 0.0D, 5.0D, 1.0D, 1.0D);
/*    */   private int delayCounter;
/*    */   
/*    */   public AutoTotem() {
/* 21 */     super((CharSequence)EncryptedString.of("Auto Totem"), (CharSequence)EncryptedString.of("Automatically holds totem in your off hand"), -1, Category.CRYSTAL);
/* 22 */     addsettings(new Setting[] { (Setting)this.delay });
/*    */   }
/*    */ 
/*    */   
/*    */   public void onEnable() {
/* 27 */     super.onEnable();
/*    */   }
/*    */ 
/*    */   
/*    */   public void onDisable() {
/* 32 */     super.onDisable();
/*    */   }
/*    */   
/*    */   @EventListener
/*    */   public void onTick(TickEvent event) {
/* 37 */     if (this.mc.field_1724 == null) {
/*    */       return;
/*    */     }
/* 40 */     Module rtpBaseFinder = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(RtpBaseFinder.class);
/* 41 */     if (rtpBaseFinder.isEnabled() && ((RtpBaseFinder)rtpBaseFinder).isRepairingActive()) {
/*    */       return;
/*    */     }
/* 44 */     Module tunnelBaseFinder = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(TunnelBaseFinder.class);
/* 45 */     if (tunnelBaseFinder.isEnabled() && ((TunnelBaseFinder)tunnelBaseFinder).isDigging()) {
/*    */       return;
/*    */     }
/* 48 */     if (this.mc.field_1724.method_31548().method_5438(40).method_7909() == class_1802.field_8288) {
/* 49 */       this.delayCounter = this.delay.getIntValue();
/*    */       return;
/*    */     } 
/* 52 */     if (this.delayCounter > 0) {
/* 53 */       this.delayCounter--;
/*    */       return;
/*    */     } 
/* 56 */     int slot = findItemSlot(class_1802.field_8288);
/* 57 */     if (slot == -1) {
/*    */       return;
/*    */     }
/* 60 */     this.mc.field_1761.method_2906(this.mc.field_1724.field_7512.field_7763, convertSlotIndex(slot), 40, class_1713.field_7791, (class_1657)this.mc.field_1724);
/* 61 */     this.delayCounter = this.delay.getIntValue();
/*    */   }
/*    */   
/*    */   public int findItemSlot(class_1792 item) {
/* 65 */     if (this.mc.field_1724 == null) {
/* 66 */       return -1;
/*    */     }
/* 68 */     for (int slotIndex = 0; slotIndex < 36; slotIndex++) {
/* 69 */       if (this.mc.field_1724.method_31548().method_5438(slotIndex).method_31574(item)) {
/* 70 */         return slotIndex;
/*    */       }
/*    */     } 
/* 73 */     return -1;
/*    */   }
/*    */   
/*    */   private static int convertSlotIndex(int slotIndex) {
/* 77 */     if (slotIndex < 9) {
/* 78 */       return 36 + slotIndex;
/*    */     }
/* 80 */     return slotIndex;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\modules\crystal\AutoTotem.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */