/*     */ package dev.FORE.module;
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.event.EventListener;
/*     */ import dev.FORE.event.events.KeyEvent;
/*     */ import dev.FORE.module.modules.client.Friends;
/*     */ import dev.FORE.module.modules.client.SelfDestruct;
/*     */ import dev.FORE.module.modules.combat.Hitbox;
/*     */ import dev.FORE.module.modules.combat.MaceSwap;
/*     */ import dev.FORE.module.modules.crystal.AutoCrystal;
/*     */ import dev.FORE.module.modules.crystal.HoverTotem;
/*     */ import dev.FORE.module.modules.donut.AutoSell;
/*     */ import dev.FORE.module.modules.donut.MediaSpoof;
/*     */ import dev.FORE.module.modules.donut.ShulkerDropper;
/*     */ import dev.FORE.module.modules.donut.SpawnerProtect;
/*     */ import dev.FORE.module.modules.misc.NameProtect;
/*     */ import dev.FORE.module.modules.misc.TridentBoost;
/*     */ import dev.FORE.module.modules.render.BlockEsp;
/*     */ import dev.FORE.module.modules.render.LightDebug;
/*     */ import dev.FORE.module.modules.render.PlayerESP;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Objects;
/*     */ 
/*     */ public final class ModuleManager {
/*     */   public ModuleManager() {
/*  27 */     this.modules = new ArrayList<>();
/*  28 */     a();
/*  29 */     d();
/*     */   }
/*     */   private final List<Module> modules;
/*     */   
/*     */   public void a() {
/*  34 */     add((Module)new ElytraSwap());
/*  35 */     add((Module)new Hitbox());
/*  36 */     add((Module)new MaceSwap());
/*  37 */     add((Module)new StaticHitboxes());
/*  38 */     add((Module)new AimAssist());
/*  39 */     add((Module)new AutoClicker());
/*  40 */     add((Module)new Criticals());
/*  41 */     add((Module)new Velocity());
/*  42 */     add((Module)new Killaura());
/*  43 */     add((Module)new TriggerBot());
/*     */     
/*  45 */     add((Module)new TapResetMacro());
/*     */ 
/*     */ 
/*     */     
/*  49 */     add((Module)new DonutBBC());
/*  50 */     add((Module)new SelfDestruct());
/*  51 */     add((Module)new Friends());
/*  52 */     add((Module)new ChunkChecker());
/*     */ 
/*     */ 
/*     */     
/*  56 */     add((Module)new Animations());
/*  57 */     add((Module)new ChunkFinder());
/*  58 */     add((Module)new FullBright());
/*  59 */     add((Module)new HUD());
/*  60 */     add((Module)new KelpESP());
/*  61 */     add((Module)new NoRender());
/*  62 */     add((Module)new PlayerESP());
/*  63 */     add((Module)new StorageESP());
/*  64 */     add((Module)new SwingSpeed());
/*  65 */     add((Module)new TargetHUD());
/*  66 */     add((Module)new TridentESP());
/*  67 */     add((Module)new ScoreboardModule());
/*  68 */     add((Module)new BlockEsp());
/*  69 */     add((Module)new LightDebug());
/*  70 */     add((Module)new SuspiciousEsp());
/*     */ 
/*     */     
/*  73 */     add((Module)new AutoEat());
/*  74 */     add((Module)new AutoFirework());
/*  75 */     add((Module)new AutoMine());
/*  76 */     add((Module)new AutoTPA());
/*  77 */     add((Module)new AutoTool());
/*  78 */     add((Module)new CordSnapper());
/*  79 */     add((Module)new ElytraGlide());
/*  80 */     add((Module)new FastPlace());
/*  81 */     add((Module)new Freecam());
/*  82 */     add((Module)new KeyPearl());
/*  83 */     add((Module)new NameProtect());
/*  84 */     add((Module)new WeatherNotifier());
/*  85 */     add((Module)new TridentBoost());
/*  86 */     add((Module)new PearlBoost());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  92 */     add((Module)new AnchorMacro());
/*  93 */     add((Module)new AutoCrystal());
/*  94 */     add((Module)new AutoHitCrystal());
/*  95 */     add((Module)new AutoInventoryTotem());
/*  96 */     add((Module)new AutoTotem());
/*  97 */     add((Module)new DoubleAnchor());
/*  98 */     add((Module)new HoverTotem());
/*     */ 
/*     */     
/* 101 */     add((Module)new AntiTrap());
/* 102 */     add((Module)new AuctionSniper());
/* 103 */     add((Module)new AutoSell());
/* 104 */     add((Module)new AutoSpawnerSell());
/* 105 */     add((Module)new BoneDropper());
/* 106 */     add((Module)new NetheriteFinder());
/* 107 */     add((Module)new RtpBaseFinder());
/* 108 */     add((Module)new RTPEndBaseFinder());
/* 109 */     add((Module)new ShulkerDropper());
/* 110 */     add((Module)new TunnelBaseFinder());
/* 111 */     add((Module)new TunnelBase());
/* 112 */     add((Module)new SpawnerProtect());
/* 113 */     add((Module)new ShearsToElytra());
/* 114 */     add((Module)new MediaSpoof());
/*     */ 
/*     */ 
/*     */     
/* 118 */     add((Module)new FakeLag());
/*     */     
/* 120 */     add((Module)new QuickMacro());
/*     */     
/* 122 */     Friends a = Friends.getInstance();
/* 123 */     a.setEnabled(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public List<Module> b() {
/* 128 */     return this.modules.stream().filter(Module::isEnabled).toList();
/*     */   }
/*     */   
/*     */   public List<Module> c() {
/* 132 */     return this.modules;
/*     */   }
/*     */   
/*     */   public void d() {
/* 136 */     DonutBBC.INSTANCE.getEventBus().register(this);
/* 137 */     for (Module next : this.modules) {
/* 138 */       next.addsetting((Setting)(new BindSetting((CharSequence)EncryptedString.of("Keybind"), next.getKeybind(), true)).setDescription((CharSequence)EncryptedString.of("Key to enabled the module")));
/*     */     }
/*     */   }
/*     */   
/*     */   public List<Module> a(Category category) {
/* 143 */     return this.modules.stream().filter(module -> (module.getCategory() == category)).toList();
/*     */   }
/*     */   
/*     */   public Module getModuleByClass(Class<? extends Module> obj) {
/* 147 */     Objects.requireNonNull(obj);
/* 148 */     Objects.requireNonNull(obj); return this.modules.stream().filter(obj::isInstance).findFirst().orElse(null);
/*     */   }
/*     */   
/*     */   public void add(Module module) {
/* 152 */     DonutBBC.INSTANCE.getEventBus().register(module);
/* 153 */     this.modules.add(module);
/*     */   }
/*     */   
/*     */   @EventListener
/*     */   public void a(KeyEvent keyEvent) {
/* 158 */     if (DonutBBC.mc.field_1755 instanceof net.minecraft.class_408) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/* 163 */     if (DonutBBC.mc.field_1755 instanceof dev.FORE.gui.ClickGUI) {
/*     */       return;
/*     */     }
/*     */     
/* 167 */     this.modules.forEach(module -> {
/*     */           if (module.getKeybind() == keyEvent.key && keyEvent.mode == 1) {
/*     */             boolean isGuiModule = module instanceof DonutBBC;
/*     */             if (!isGuiModule && DonutBBC.mc.field_1724 == null)
/*     */               return; 
/*     */             if (module instanceof SelfDestruct && SelfDestruct.isActive)
/*     */               return; 
/*     */             if (module instanceof DonutBBC && SelfDestruct.hasSelfDestructed)
/*     */               return; 
/*     */             module.toggle();
/*     */           } 
/*     */         });
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\ModuleManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */