/*     */ package dev.FORE.module;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.manager.EventManager;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import java.io.Serializable;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ public abstract class Module
/*     */   implements Serializable {
/*     */   private final List<Setting> settings;
/*     */   protected final EventManager EVENT_BUS;
/*     */   protected class_310 mc;
/*     */   private CharSequence name;
/*     */   private CharSequence description;
/*     */   private boolean enabled;
/*     */   private int keybind;
/*     */   private Category category;
/*     */   private final boolean i;
/*     */   
/*     */   public Module(CharSequence name, CharSequence description, int keybind, Category category) {
/*  25 */     this.settings = new ArrayList<>();
/*  26 */     this.EVENT_BUS = DonutBBC.INSTANCE.getEventBus();
/*  27 */     this.mc = class_310.method_1551();
/*  28 */     this.i = false;
/*  29 */     this.name = name;
/*  30 */     this.description = description;
/*  31 */     this.enabled = false;
/*  32 */     this.keybind = keybind;
/*  33 */     this.category = category;
/*     */   }
/*     */   
/*     */   public void toggle() {
/*  37 */     this.enabled = !this.enabled;
/*  38 */     if (this.enabled) {
/*  39 */       onEnable();
/*     */     } else {
/*  41 */       onDisable();
/*     */     } 
/*     */   }
/*     */   
/*     */   public CharSequence getName() {
/*  46 */     return this.name;
/*     */   }
/*     */   
/*     */   public boolean isEnabled() {
/*  50 */     return this.enabled;
/*     */   }
/*     */   
/*     */   public CharSequence getDescription() {
/*  54 */     return this.description;
/*     */   }
/*     */   
/*     */   public int getKeybind() {
/*  58 */     return this.keybind;
/*     */   }
/*     */   
/*     */   public Category getCategory() {
/*  62 */     return this.category;
/*     */   }
/*     */   
/*     */   public void setCategory(Category category) {
/*  66 */     this.category = category;
/*     */   }
/*     */   
/*     */   public void setName(CharSequence name) {
/*  70 */     this.name = name;
/*     */   }
/*     */   
/*     */   public void setDescription(CharSequence description) {
/*  74 */     this.description = description;
/*     */   }
/*     */   
/*     */   public void setKeybind(int keybind) {
/*  78 */     this.keybind = keybind;
/*     */   }
/*     */   
/*     */   public List<Setting> getSettings() {
/*  82 */     return this.settings;
/*     */   }
/*     */ 
/*     */   
/*     */   public void onEnable() {}
/*     */ 
/*     */   
/*     */   public void onDisable() {}
/*     */   
/*     */   public void addsetting(Setting setting) {
/*  92 */     this.settings.add(setting);
/*     */   }
/*     */   
/*     */   public void addsettings(Setting... a) {
/*  96 */     this.settings.addAll(Arrays.asList(a));
/*     */   }
/*     */   
/*     */   public void toggle(boolean enabled) {
/* 100 */     if (this.enabled != enabled) {
/* 101 */       this.enabled = enabled;
/* 102 */       if (enabled) {
/* 103 */         onEnable();
/*     */       } else {
/* 105 */         onDisable();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setEnabled(boolean enabled) {
/* 111 */     this.enabled = enabled;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\module\Module.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */