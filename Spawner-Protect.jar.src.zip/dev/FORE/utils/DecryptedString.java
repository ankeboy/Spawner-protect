/*     */ package dev.FORE.utils;
/*     */ 
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.Base64;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.spec.IvParameterSpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ public class DecryptedString
/*     */ {
/*     */   private static final String _0x4a2b = "U3VwZXJTZWNyZXQyMDI0S2V5IUAjJCVeJiooKV8r";
/*  13 */   private static byte[] _0x10a2b = Base64.getDecoder().decode("U3VwZXJTZWNyZXQyMDI0S2V5IUAjJCVeJiooKV8r");
/*  14 */   private static final String _0x9a2b = new String(_0x10a2b);
/*     */   private static final int _0x7f3c = 3;
/*     */   private static final String _0x9e1a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
/*     */   private static final String _0x2d8f = "ZYXWVUTSRQPONMLKJIHGFEDCBAzyxwvutsrqponmlkjihgfedcba9876543210=+/";
/*     */   
/*     */   public static String of(String _0x5c9d) {
/*     */     try {
/*  21 */       String _0x8b4e = new String(Base64.getDecoder().decode(_0x5c9d), StandardCharsets.UTF_8);
/*  22 */       String _0x3f7a = _0x6d2c(_0x8b4e, 3);
/*  23 */       String _0x1e9b = (new StringBuilder(_0x3f7a)).reverse().toString();
/*  24 */       String _0x4d8a = new String(Base64.getDecoder().decode(_0x1e9b), StandardCharsets.UTF_8);
/*  25 */       String _0x7c3e = _0x9a5f(_0x4d8a);
/*  26 */       String _0x2b6d = _0x8e4c(_0x7c3e);
/*  27 */       String _0x5f1a = _0x3c7b(_0x2b6d);
/*  28 */       return new String(Base64.getDecoder().decode(_0x5f1a), StandardCharsets.UTF_8);
/*  29 */     } catch (Exception _0x9d2e) {
/*  30 */       throw new RuntimeException("Decryption failed: " + _0x9d2e.getMessage(), _0x9d2e);
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String _0x3c7b(String _0x6e8a) {
/*  35 */     String _0x4f2d = new String(Base64.getDecoder().decode(_0x6e8a), StandardCharsets.UTF_8);
/*  36 */     StringBuilder _0x1a9c = new StringBuilder();
/*  37 */     String _0x7b3e = _0x9a2b;
/*  38 */     for (int _0x2d5f = 0; _0x2d5f < _0x4f2d.length(); _0x2d5f++) {
/*  39 */       int _0x8c4a = (_0x2d5f * 7 + 13) % _0x7b3e.length();
/*  40 */       _0x1a9c.append((char)(_0x4f2d.charAt(_0x2d5f) ^ _0x7b3e.charAt(_0x8c4a)));
/*     */     } 
/*  42 */     return _0x1a9c.toString();
/*     */   }
/*     */   
/*     */   private static String _0x8e4c(String _0x3b7d) throws Exception {
/*  46 */     byte[] _0x5e2a = _0x4d9f();
/*  47 */     byte[] _0x7c1b = new byte[16];
/*  48 */     System.arraycopy(_0x5e2a, 0, _0x7c1b, 0, 16);
/*  49 */     SecretKeySpec _0x9a3e = new SecretKeySpec(_0x5e2a, "AES");
/*  50 */     IvParameterSpec _0x2f8c = new IvParameterSpec(_0x7c1b);
/*  51 */     Cipher _0x6b4d = Cipher.getInstance("AES/CBC/PKCS5Padding");
/*  52 */     _0x6b4d.init(2, _0x9a3e, _0x2f8c);
/*  53 */     byte[] _0x1e7a = _0x6b4d.doFinal(Base64.getDecoder().decode(_0x3b7d));
/*  54 */     return new String(_0x1e7a, StandardCharsets.UTF_8);
/*     */   }
/*     */   
/*     */   private static byte[] _0x4d9f() throws Exception {
/*  58 */     MessageDigest _0x8c5b = MessageDigest.getInstance("SHA-256");
/*  59 */     byte[] _0x3a7e = _0x8c5b.digest(_0x9a2b.getBytes(StandardCharsets.UTF_8));
/*  60 */     return _0x3a7e;
/*     */   }
/*     */   
/*     */   private static String _0x9a5f(String _0x7e3b) {
/*  64 */     StringBuilder _0x2c8d = new StringBuilder();
/*  65 */     for (char _0x5a1f : _0x7e3b.toCharArray()) {
/*  66 */       int _0x9b4e = "ZYXWVUTSRQPONMLKJIHGFEDCBAzyxwvutsrqponmlkjihgfedcba9876543210=+/".indexOf(_0x5a1f);
/*  67 */       if (_0x9b4e != -1) {
/*  68 */         _0x2c8d.append("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(_0x9b4e));
/*     */       } else {
/*  70 */         _0x2c8d.append(_0x5a1f);
/*     */       } 
/*     */     } 
/*  73 */     return _0x2c8d.toString();
/*     */   }
/*     */   
/*     */   private static String _0x6d2c(String _0x4b8e, int _0x7a2f) {
/*  77 */     if (_0x7a2f <= 1) return _0x4b8e; 
/*  78 */     int _0x3e9c = _0x4b8e.length();
/*  79 */     int[] _0x5d1a = new int[_0x7a2f];
/*  80 */     int _0x8f4b = 0;
/*  81 */     int _0x2c7e = 1;
/*  82 */     for (int _0x9a3d = 0; _0x9a3d < _0x3e9c; _0x9a3d++) {
/*  83 */       _0x5d1a[_0x8f4b] = _0x5d1a[_0x8f4b] + 1;
/*  84 */       _0x8f4b += _0x2c7e;
/*  85 */       if (_0x8f4b == 0 || _0x8f4b == _0x7a2f - 1) {
/*  86 */         _0x2c7e = -_0x2c7e;
/*     */       }
/*     */     } 
/*  89 */     char[][] _0x6e5b = new char[_0x7a2f][];
/*  90 */     int _0x1f8c = 0;
/*  91 */     for (int _0x4d2a = 0; _0x4d2a < _0x7a2f; _0x4d2a++) {
/*  92 */       _0x6e5b[_0x4d2a] = new char[_0x5d1a[_0x4d2a]];
/*  93 */       for (int _0x7b9e = 0; _0x7b9e < _0x5d1a[_0x4d2a]; _0x7b9e++) {
/*  94 */         _0x6e5b[_0x4d2a][_0x7b9e] = _0x4b8e.charAt(_0x1f8c++);
/*     */       }
/*     */     } 
/*  97 */     StringBuilder _0x3c6d = new StringBuilder();
/*  98 */     _0x8f4b = 0;
/*  99 */     _0x2c7e = 1;
/* 100 */     int[] _0x9e1b = new int[_0x7a2f];
/* 101 */     for (int _0x5a7c = 0; _0x5a7c < _0x3e9c; _0x5a7c++) {
/* 102 */       _0x9e1b[_0x8f4b] = _0x9e1b[_0x8f4b] + 1; _0x3c6d.append(_0x6e5b[_0x8f4b][_0x9e1b[_0x8f4b]]);
/* 103 */       _0x8f4b += _0x2c7e;
/* 104 */       if (_0x8f4b == 0 || _0x8f4b == _0x7a2f - 1) {
/* 105 */         _0x2c7e = -_0x2c7e;
/*     */       }
/*     */     } 
/* 108 */     return _0x3c6d.toString();
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\DecryptedString.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */