/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import it.unimi.dsi.fastutil.objects.Object2IntArrayMap;
/*    */ import it.unimi.dsi.fastutil.objects.Object2IntMap;
/*    */ import it.unimi.dsi.fastutil.objects.ObjectIterator;
/*    */ import java.util.Set;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_5321;
/*    */ import net.minecraft.class_6880;
/*    */ import net.minecraft.class_9304;
/*    */ import net.minecraft.class_9334;
/*    */ 
/*    */ public class EnchantmentUtil
/*    */ {
/*    */   public static boolean hasEnchantment(class_1799 itemStack, class_5321<?> enchantmentKey) {
/* 17 */     if (itemStack.method_7960() || enchantmentKey == null) {
/* 18 */       return false;
/*    */     }
/*    */     try {
/* 21 */       Object2IntArrayMap<?> enchantmentMap = new Object2IntArrayMap();
/* 22 */       populateEnchantmentMap(itemStack, (Object2IntMap)enchantmentMap);
/* 23 */       return containsEnchantment((Object2IntMap<?>)enchantmentMap, enchantmentKey);
/* 24 */     } catch (Exception e) {
/* 25 */       return false;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   private static boolean containsEnchantment(Object2IntMap<?> enchantmentMap, class_5321<?> enchantmentKey) {
/* 31 */     if (enchantmentMap == null || enchantmentKey == null) {
/* 32 */       return false;
/*    */     }
/*    */     
/* 35 */     for (ObjectIterator objectIterator = enchantmentMap.keySet().iterator(); objectIterator.hasNext(); ) { Object enchantment = objectIterator.next();
/* 36 */       if (enchantment instanceof class_6880 && (
/* 37 */         (class_6880)enchantment).method_40225(enchantmentKey)) {
/* 38 */         return true;
/*    */       } }
/*    */ 
/*    */     
/* 42 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void populateEnchantmentMap(class_1799 itemStack, Object2IntMap enchantmentMap) {
/* 47 */     if (enchantmentMap == null || itemStack.method_7960()) {
/*    */       return;
/*    */     }
/*    */     
/* 51 */     enchantmentMap.clear();
/*    */     
/*    */     try {
/*    */       Set<?> enchantments;
/* 55 */       if (itemStack.method_7909() == class_1802.field_8598) {
/* 56 */         enchantments = ((class_9304)itemStack.method_57824(class_9334.field_49643)).method_57539();
/*    */       } else {
/* 58 */         enchantments = itemStack.method_58657().method_57539();
/*    */       } 
/*    */       
/* 61 */       if (enchantments != null) {
/* 62 */         for (Object enchantmentEntry : enchantments) {
/* 63 */           if (enchantmentEntry instanceof Object2IntMap.Entry) {
/* 64 */             enchantmentMap.put(((Object2IntMap.Entry)enchantmentEntry).getKey(), ((Object2IntMap.Entry)enchantmentEntry).getIntValue());
/*    */           }
/*    */         } 
/*    */       }
/* 68 */     } catch (Exception exception) {}
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\EnchantmentUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */