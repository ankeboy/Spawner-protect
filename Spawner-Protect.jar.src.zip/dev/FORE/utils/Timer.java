/*    */ package dev.FORE.utils;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class Timer
/*    */ {
/*    */   public static final String PART = "!@#$%^&*()*+";
/*  9 */   private long lastTime = System.currentTimeMillis();
/*    */ 
/*    */   
/*    */   public boolean passedMs(long ms) {
/* 13 */     return (System.currentTimeMillis() - this.lastTime >= ms);
/*    */   }
/*    */   
/*    */   public long getPassedTimeMs() {
/* 17 */     return System.currentTimeMillis() - this.lastTime;
/*    */   }
/*    */   
/*    */   public void reset() {
/* 21 */     this.lastTime = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public void setTime(long time) {
/* 25 */     this.lastTime = time;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\Timer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */