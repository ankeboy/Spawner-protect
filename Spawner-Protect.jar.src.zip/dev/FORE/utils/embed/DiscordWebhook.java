/*     */ package dev.FORE.utils.embed;
/*     */ import java.awt.Color;
/*     */ import java.io.OutputStream;
/*     */ import java.lang.reflect.Array;
/*     */ import java.net.URLConnection;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ import javax.net.ssl.HttpsURLConnection;
/*     */ 
/*     */ public class DiscordWebhook {
/*     */   private final String webhookUrl;
/*     */   private String content;
/*     */   private String username;
/*     */   private String avatarUrl;
/*     */   private boolean tts;
/*     */   private final List<EmbedObject> embeds;
/*     */   
/*     */   public DiscordWebhook(String webhookUrl) {
/*  23 */     this.embeds = new ArrayList<>();
/*  24 */     this.webhookUrl = webhookUrl;
/*     */   }
/*     */   
/*     */   public void setContent(String content) {
/*  28 */     this.content = content;
/*     */   }
/*     */   
/*     */   public void setUsername(String username) {
/*  32 */     this.username = username;
/*     */   }
/*     */   
/*     */   public void setAvatarUrl(String avatarUrl) {
/*  36 */     this.avatarUrl = avatarUrl;
/*     */   }
/*     */   
/*     */   public void setTts(boolean tts) {
/*  40 */     this.tts = tts;
/*     */   }
/*     */   
/*     */   public void addEmbed(EmbedObject embed) {
/*  44 */     this.embeds.add(embed);
/*     */   }
/*     */ 
/*     */   
/*     */   public void execute() throws Throwable {
/*  49 */     if (this.content == null && this.embeds.isEmpty()) {
/*  50 */       throw new IllegalArgumentException("Set content or add at least one EmbedObject");
/*     */     }
/*  52 */     JSONObject jsonSerializer = new JSONObject();
/*  53 */     jsonSerializer.put("content", this.content);
/*  54 */     jsonSerializer.put("username", this.username);
/*  55 */     jsonSerializer.put("avatar_url", this.avatarUrl);
/*  56 */     jsonSerializer.put("tts", Boolean.valueOf(this.tts));
/*  57 */     if (!this.embeds.isEmpty()) {
/*  58 */       ArrayList<JSONObject> embedList = new ArrayList<>();
/*  59 */       for (EmbedObject embed : this.embeds) {
/*  60 */         JSONObject jsonEmbed = new JSONObject();
/*  61 */         jsonEmbed.put("title", embed.title);
/*  62 */         jsonEmbed.put("description", embed.description);
/*  63 */         jsonEmbed.put("url", embed.url);
/*  64 */         if (embed.color != null) {
/*  65 */           Color color = embed.color;
/*  66 */           jsonEmbed.put("color", Integer.valueOf(((color.getRed() << 8) + color.getGreen() << 8) + color.getBlue()));
/*     */         } 
/*  68 */         Footer footer = embed.footer;
/*  69 */         Image image = embed.image;
/*  70 */         Thumbnail thumbnail = embed.thumbnail;
/*  71 */         Author author = embed.author;
/*  72 */         List<Field> fields = embed.fields;
/*  73 */         if (footer != null) {
/*  74 */           JSONObject jsonFooter = new JSONObject();
/*  75 */           jsonFooter.put("text", footer.text);
/*  76 */           jsonFooter.put("icon_url", footer.iconUrl);
/*  77 */           jsonEmbed.put("footer", jsonFooter);
/*     */         } 
/*  79 */         if (image != null) {
/*  80 */           JSONObject jsonImage = new JSONObject();
/*  81 */           jsonImage.put("url", image.url);
/*  82 */           jsonEmbed.put("image", jsonImage);
/*     */         } 
/*  84 */         if (thumbnail != null) {
/*  85 */           JSONObject jsonThumbnail = new JSONObject();
/*  86 */           jsonThumbnail.put("url", thumbnail.url);
/*  87 */           jsonEmbed.put("thumbnail", jsonThumbnail);
/*     */         } 
/*  89 */         if (author != null) {
/*  90 */           JSONObject jsonAuthor = new JSONObject();
/*  91 */           jsonAuthor.put("name", author.name);
/*  92 */           jsonAuthor.put("url", author.url);
/*  93 */           jsonAuthor.put("icon_url", author.iconUrl);
/*  94 */           jsonEmbed.put("author", jsonAuthor);
/*     */         } 
/*  96 */         ArrayList<JSONObject> jsonFields = new ArrayList<>();
/*  97 */         for (Field field : fields) {
/*  98 */           JSONObject jsonField = new JSONObject();
/*  99 */           jsonField.put("name", field.name());
/* 100 */           jsonField.put("value", field.value());
/* 101 */           jsonField.put("inline", Boolean.valueOf(field.inline()));
/* 102 */           jsonFields.add(jsonField);
/*     */         } 
/* 104 */         jsonEmbed.put("fields", jsonFields.toArray());
/* 105 */         embedList.add(jsonEmbed);
/*     */       } 
/*     */       
/* 108 */       jsonSerializer.put("embeds", embedList.toArray());
/*     */     } 
/* 110 */     URLConnection connection = (new URL(this.webhookUrl)).openConnection();
/* 111 */     connection.addRequestProperty("Content-Type", "application/json");
/* 112 */     connection.addRequestProperty("User-Agent", "YourLocalLinuxUser");
/* 113 */     connection.setDoOutput(true);
/* 114 */     ((HttpsURLConnection)connection).setRequestMethod("POST");
/* 115 */     OutputStream outputStream = connection.getOutputStream();
/* 116 */     outputStream.write(jsonSerializer.toString().getBytes(StandardCharsets.UTF_8));
/* 117 */     outputStream.flush();
/* 118 */     outputStream.close();
/* 119 */     connection.getInputStream().close();
/* 120 */     ((HttpsURLConnection)connection).disconnect();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static class JSONObject
/*     */   {
/* 128 */     private final HashMap<String, Object> data = new HashMap<>();
/*     */ 
/*     */     
/*     */     void put(String key, Object value) {
/* 132 */       if (value != null) {
/* 133 */         this.data.put(key, value);
/*     */       }
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 139 */       StringBuilder stringBuilder = new StringBuilder();
/* 140 */       Set<Map.Entry<String, Object>> entrySet = this.data.entrySet();
/* 141 */       stringBuilder.append("{");
/* 142 */       int count = 0;
/* 143 */       for (Map.Entry<String, Object> entry : entrySet) {
/* 144 */         Object value = entry.getValue();
/* 145 */         stringBuilder.append(escapeString(entry.getKey())).append(":");
/* 146 */         if (value instanceof String) {
/* 147 */           stringBuilder.append(escapeString(String.valueOf(value)));
/* 148 */         } else if (value instanceof Integer) {
/* 149 */           stringBuilder.append(Integer.valueOf(String.valueOf(value)));
/* 150 */         } else if (value instanceof Boolean) {
/* 151 */           stringBuilder.append(value);
/* 152 */         } else if (value instanceof JSONObject) {
/* 153 */           stringBuilder.append(value);
/* 154 */         } else if (value.getClass().isArray()) {
/* 155 */           stringBuilder.append("[");
/* 156 */           for (int length = Array.getLength(value), i = 0; i < length; i++) {
/* 157 */             String separator; StringBuilder append = stringBuilder.append(Array.get(value, i).toString());
/*     */             
/* 159 */             if (i != length - 1) {
/* 160 */               separator = ",";
/*     */             } else {
/* 162 */               separator = "";
/*     */             } 
/* 164 */             append.append(separator);
/*     */           } 
/* 166 */           stringBuilder.append("]");
/*     */         } 
/* 168 */         count++;
/* 169 */         stringBuilder.append((count == entrySet.size()) ? "}" : ",");
/*     */       } 
/* 171 */       return stringBuilder.toString();
/*     */     }
/*     */     
/*     */     private String escapeString(String str) {
/* 175 */       return "\"" + str;
/*     */     }
/*     */   }
/*     */   
/*     */   public static class EmbedObject {
/*     */     public String title;
/*     */     public String description;
/*     */     public String url;
/*     */     public Color color;
/*     */     public DiscordWebhook.Footer footer;
/*     */     public DiscordWebhook.Thumbnail thumbnail;
/*     */     public DiscordWebhook.Image image;
/*     */     public DiscordWebhook.Author author;
/*     */     public final List<DiscordWebhook.Field> fields;
/*     */     
/*     */     public EmbedObject() {
/* 191 */       this.fields = new ArrayList<>();
/*     */     }
/*     */     
/*     */     public EmbedObject setDescription(String description) {
/* 195 */       this.description = description;
/* 196 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setColor(Color color) {
/* 200 */       this.color = color;
/* 201 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setTitle(String title) {
/* 205 */       this.title = title;
/* 206 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setUrl(String url) {
/* 210 */       this.url = url;
/* 211 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setFooter(String text, String iconUrl) {
/* 215 */       this.footer = new DiscordWebhook.Footer(text, iconUrl);
/* 216 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setImage(DiscordWebhook.Image image) {
/* 220 */       this.image = image;
/* 221 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setThumbnail(String url) {
/* 225 */       this.thumbnail = new DiscordWebhook.Thumbnail(url);
/* 226 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject setAuthor(DiscordWebhook.Author author) {
/* 230 */       this.author = author;
/* 231 */       return this;
/*     */     }
/*     */     
/*     */     public EmbedObject addField(String name, String value, boolean inline) {
/* 235 */       this.fields.add(new DiscordWebhook.Field(name, value, inline));
/* 236 */       return this;
/*     */     } } static final class Image extends Record { private final String url; public final String toString() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ldev/FORE/utils/embed/DiscordWebhook$Image;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #241	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Image;
/*     */     } public final int hashCode() {
/*     */       // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ldev/FORE/utils/embed/DiscordWebhook$Image;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #241	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Image;
/* 241 */     } Image(String url) { this.url = url; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ldev/FORE/utils/embed/DiscordWebhook$Image;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #241	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Image;
/* 241 */       //   0	8	1	o	Ljava/lang/Object; } public String url() { return this.url; }
/*     */      }
/*     */   static final class Footer extends Record { private final String text; private final String iconUrl;
/* 244 */     Footer(String text, String iconUrl) { this.text = text; this.iconUrl = iconUrl; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ldev/FORE/utils/embed/DiscordWebhook$Footer;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #244	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Footer; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ldev/FORE/utils/embed/DiscordWebhook$Footer;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #244	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Footer; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ldev/FORE/utils/embed/DiscordWebhook$Footer;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #244	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Footer;
/* 244 */       //   0	8	1	o	Ljava/lang/Object; } public String text() { return this.text; } public String iconUrl() { return this.iconUrl; }
/*     */      }
/*     */   static final class Field extends Record { private final String name; private final String value; private final boolean inline;
/* 247 */     Field(String name, String value, boolean inline) { this.name = name; this.value = value; this.inline = inline; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ldev/FORE/utils/embed/DiscordWebhook$Field;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #247	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Field; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ldev/FORE/utils/embed/DiscordWebhook$Field;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #247	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Field; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ldev/FORE/utils/embed/DiscordWebhook$Field;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #247	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Field;
/* 247 */       //   0	8	1	o	Ljava/lang/Object; } public String name() { return this.name; } public String value() { return this.value; } public boolean inline() { return this.inline; }
/*     */      }
/*     */   static final class Author extends Record { private final String name; private final String url; private final String iconUrl;
/* 250 */     Author(String name, String url, String iconUrl) { this.name = name; this.url = url; this.iconUrl = iconUrl; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ldev/FORE/utils/embed/DiscordWebhook$Author;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #250	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Author; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ldev/FORE/utils/embed/DiscordWebhook$Author;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #250	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Author; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ldev/FORE/utils/embed/DiscordWebhook$Author;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #250	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Author;
/* 250 */       //   0	8	1	o	Ljava/lang/Object; } public String name() { return this.name; } public String url() { return this.url; } public String iconUrl() { return this.iconUrl; }
/*     */      }
/*     */   static final class Thumbnail extends Record { private final String url;
/* 253 */     Thumbnail(String url) { this.url = url; } public final String toString() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> toString : (Ldev/FORE/utils/embed/DiscordWebhook$Thumbnail;)Ljava/lang/String;
/*     */       //   6: areturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #253	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Thumbnail; } public final int hashCode() { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: <illegal opcode> hashCode : (Ldev/FORE/utils/embed/DiscordWebhook$Thumbnail;)I
/*     */       //   6: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #253	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	7	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Thumbnail; } public final boolean equals(Object o) { // Byte code:
/*     */       //   0: aload_0
/*     */       //   1: aload_1
/*     */       //   2: <illegal opcode> equals : (Ldev/FORE/utils/embed/DiscordWebhook$Thumbnail;Ljava/lang/Object;)Z
/*     */       //   7: ireturn
/*     */       // Line number table:
/*     */       //   Java source line number -> byte code offset
/*     */       //   #253	-> 0
/*     */       // Local variable table:
/*     */       //   start	length	slot	name	descriptor
/*     */       //   0	8	0	this	Ldev/FORE/utils/embed/DiscordWebhook$Thumbnail;
/* 253 */       //   0	8	1	o	Ljava/lang/Object; } public String url() { return this.url; }
/*     */      }
/*     */ 
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\embed\DiscordWebhook.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */