/*     */ package dev.FORE.utils.embed;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EmbedObject
/*     */ {
/*     */   public String title;
/*     */   public String description;
/*     */   public String url;
/*     */   public Color color;
/*     */   public DiscordWebhook.Footer footer;
/*     */   public DiscordWebhook.Thumbnail thumbnail;
/*     */   public DiscordWebhook.Image image;
/*     */   public DiscordWebhook.Author author;
/* 191 */   public final List<DiscordWebhook.Field> fields = new ArrayList<>();
/*     */ 
/*     */   
/*     */   public EmbedObject setDescription(String description) {
/* 195 */     this.description = description;
/* 196 */     return this;
/*     */   }
/*     */   
/*     */   public EmbedObject setColor(Color color) {
/* 200 */     this.color = color;
/* 201 */     return this;
/*     */   }
/*     */   
/*     */   public EmbedObject setTitle(String title) {
/* 205 */     this.title = title;
/* 206 */     return this;
/*     */   }
/*     */   
/*     */   public EmbedObject setUrl(String url) {
/* 210 */     this.url = url;
/* 211 */     return this;
/*     */   }
/*     */   
/*     */   public EmbedObject setFooter(String text, String iconUrl) {
/* 215 */     this.footer = new DiscordWebhook.Footer(text, iconUrl);
/* 216 */     return this;
/*     */   }
/*     */   
/*     */   public EmbedObject setImage(DiscordWebhook.Image image) {
/* 220 */     this.image = image;
/* 221 */     return this;
/*     */   }
/*     */   
/*     */   public EmbedObject setThumbnail(String url) {
/* 225 */     this.thumbnail = new DiscordWebhook.Thumbnail(url);
/* 226 */     return this;
/*     */   }
/*     */   
/*     */   public EmbedObject setAuthor(DiscordWebhook.Author author) {
/* 230 */     this.author = author;
/* 231 */     return this;
/*     */   }
/*     */   
/*     */   public EmbedObject addField(String name, String value, boolean inline) {
/* 235 */     this.fields.add(new DiscordWebhook.Field(name, value, inline));
/* 236 */     return this;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\embed\DiscordWebhook$EmbedObject.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */