/*     */ package dev.FORE.utils.embed;
/*     */ 
/*     */ import java.lang.reflect.Array;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class JSONObject
/*     */ {
/* 128 */   private final HashMap<String, Object> data = new HashMap<>();
/*     */ 
/*     */   
/*     */   void put(String key, Object value) {
/* 132 */     if (value != null) {
/* 133 */       this.data.put(key, value);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/* 139 */     StringBuilder stringBuilder = new StringBuilder();
/* 140 */     Set<Map.Entry<String, Object>> entrySet = this.data.entrySet();
/* 141 */     stringBuilder.append("{");
/* 142 */     int count = 0;
/* 143 */     for (Map.Entry<String, Object> entry : entrySet) {
/* 144 */       Object value = entry.getValue();
/* 145 */       stringBuilder.append(escapeString(entry.getKey())).append(":");
/* 146 */       if (value instanceof String) {
/* 147 */         stringBuilder.append(escapeString(String.valueOf(value)));
/* 148 */       } else if (value instanceof Integer) {
/* 149 */         stringBuilder.append(Integer.valueOf(String.valueOf(value)));
/* 150 */       } else if (value instanceof Boolean) {
/* 151 */         stringBuilder.append(value);
/* 152 */       } else if (value instanceof JSONObject) {
/* 153 */         stringBuilder.append(value);
/* 154 */       } else if (value.getClass().isArray()) {
/* 155 */         stringBuilder.append("[");
/* 156 */         for (int length = Array.getLength(value), i = 0; i < length; i++) {
/* 157 */           String separator; StringBuilder append = stringBuilder.append(Array.get(value, i).toString());
/*     */           
/* 159 */           if (i != length - 1) {
/* 160 */             separator = ",";
/*     */           } else {
/* 162 */             separator = "";
/*     */           } 
/* 164 */           append.append(separator);
/*     */         } 
/* 166 */         stringBuilder.append("]");
/*     */       } 
/* 168 */       count++;
/* 169 */       stringBuilder.append((count == entrySet.size()) ? "}" : ",");
/*     */     } 
/* 171 */     return stringBuilder.toString();
/*     */   }
/*     */   
/*     */   private String escapeString(String str) {
/* 175 */     return "\"" + str;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\embed\DiscordWebhook$JSONObject.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */