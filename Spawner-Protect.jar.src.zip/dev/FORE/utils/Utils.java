/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.modules.client.DonutBBC;
/*    */ import dev.FORE.module.modules.client.SelfDestruct;
/*    */ import java.awt.Color;
/*    */ import java.io.File;
/*    */ import java.io.FileOutputStream;
/*    */ import java.io.InputStream;
/*    */ import java.net.HttpURLConnection;
/*    */ import java.net.URISyntaxException;
/*    */ import java.net.URL;
/*    */ import net.minecraft.class_243;
/*    */ import org.joml.Vector3d;
/*    */ 
/*    */ 
/*    */ public final class Utils
/*    */ {
/*    */   public static Color getMainColor(int alpha, int offset) {
/* 20 */     int red = DonutBBC.redColor.getIntValue();
/* 21 */     int green = DonutBBC.greenColor.getIntValue();
/* 22 */     int blue = DonutBBC.blueColor.getIntValue();
/*    */     
/* 24 */     if (DonutBBC.enableRainbowEffect.getValue()) {
/* 25 */       return ColorUtil.getRainbowColor(offset, alpha);
/*    */     }
/*    */     
/* 28 */     if (DonutBBC.enableBreathingEffect.getValue()) {
/* 29 */       return ColorUtil.getBreathingColor(new Color(red, green, blue, alpha), offset, 20);
/*    */     }
/*    */     
/* 32 */     return new Color(red, green, blue, alpha);
/*    */   }
/*    */ 
/*    */   
/*    */   public static File getCurrentJarPath() throws URISyntaxException {
/* 37 */     return new File(SelfDestruct.class.getProtectionDomain().getCodeSource().getLocation().toURI().getPath());
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static void downloadAndOverwriteFile(String url, File targetFile) {
/*    */     try {
/* 44 */       HttpURLConnection connection = (HttpURLConnection)(new URL(url)).openConnection();
/* 45 */       connection.setRequestMethod("GET");
/*    */       
/* 47 */       InputStream inputStream = connection.getInputStream();
/* 48 */       FileOutputStream fileOutputStream = new FileOutputStream(targetFile);
/* 49 */       byte[] buffer = new byte[1024];
/*    */       
/*    */       while (true) {
/* 52 */         int bytesRead = inputStream.read(buffer);
/* 53 */         if (bytesRead == -1) {
/*    */           break;
/*    */         }
/* 56 */         fileOutputStream.write(buffer, 0, bytesRead);
/*    */       } 
/*    */       
/* 59 */       fileOutputStream.close();
/* 60 */       inputStream.close();
/* 61 */       connection.disconnect();
/* 62 */     } catch (Throwable exception) {
/* 63 */       exception.printStackTrace(System.err);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void copyVector(Vector3d destination, class_243 source) {
/* 69 */     destination.x = source.field_1352;
/* 70 */     destination.y = source.field_1351;
/* 71 */     destination.z = source.field_1350;
/*    */   }
/*    */   public static float getTick() {
/* 74 */     return DonutBBC.mc.method_60646().method_60637(false);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\Utils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */