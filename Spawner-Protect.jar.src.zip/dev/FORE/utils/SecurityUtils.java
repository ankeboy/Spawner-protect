/*     */ package dev.FORE.utils;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.net.NetworkInterface;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.KeyFactory;
/*     */ import java.security.KeyPairGenerator;
/*     */ import java.security.MessageDigest;
/*     */ import java.security.PrivateKey;
/*     */ import java.security.PublicKey;
/*     */ import java.security.Signature;
/*     */ import java.util.Arrays;
/*     */ import java.util.Base64;
/*     */ import javax.crypto.Cipher;
/*     */ import javax.crypto.KeyGenerator;
/*     */ import javax.crypto.SecretKey;
/*     */ import javax.crypto.spec.GCMParameterSpec;
/*     */ import javax.crypto.spec.SecretKeySpec;
/*     */ 
/*     */ public class SecurityUtils {
/*     */   private static final String AES_ALGORITHM = "AES/GCM/NoPadding";
/*     */   private static final String RSA_ALGORITHM = "RSA/ECB/PKCS1Padding";
/*  23 */   private static final SecureRandom secureRandom = new SecureRandom(); private static final int AES_KEY_SIZE = 256; private static final int GCM_IV_LENGTH = 12;
/*     */   private static final int GCM_TAG_LENGTH = 16;
/*     */   
/*     */   public static SecretKey generateAESKey() throws Exception {
/*  27 */     KeyGenerator keyGen = KeyGenerator.getInstance("AES");
/*  28 */     keyGen.init(256, secureRandom);
/*  29 */     return keyGen.generateKey();
/*     */   }
/*     */ 
/*     */   
/*     */   public static KeyPair generateRSAKeyPair() throws Exception {
/*  34 */     KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
/*  35 */     keyGen.initialize(2048, secureRandom);
/*  36 */     return keyGen.generateKeyPair();
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] encryptAES(byte[] data, SecretKey key) throws Exception {
/*  41 */     Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
/*  42 */     byte[] iv = new byte[12];
/*  43 */     secureRandom.nextBytes(iv);
/*     */     
/*  45 */     GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
/*  46 */     cipher.init(1, key, gcmSpec);
/*     */     
/*  48 */     byte[] encrypted = cipher.doFinal(data);
/*  49 */     byte[] result = new byte[iv.length + encrypted.length];
/*  50 */     System.arraycopy(iv, 0, result, 0, iv.length);
/*  51 */     System.arraycopy(encrypted, 0, result, iv.length, encrypted.length);
/*     */     
/*  53 */     return result;
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] decryptAES(byte[] encryptedData, SecretKey key) throws Exception {
/*  58 */     if (encryptedData.length < 12) {
/*  59 */       throw new IllegalArgumentException("Encrypted data too short");
/*     */     }
/*     */     
/*  62 */     byte[] iv = Arrays.copyOfRange(encryptedData, 0, 12);
/*  63 */     byte[] encrypted = Arrays.copyOfRange(encryptedData, 12, encryptedData.length);
/*     */     
/*  65 */     Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
/*  66 */     GCMParameterSpec gcmSpec = new GCMParameterSpec(128, iv);
/*  67 */     cipher.init(2, key, gcmSpec);
/*     */     
/*  69 */     return cipher.doFinal(encrypted);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String encryptString(String data, SecretKey key) throws Exception {
/*  74 */     byte[] encrypted = encryptAES(data.getBytes(StandardCharsets.UTF_8), key);
/*  75 */     return Base64.getEncoder().encodeToString(encrypted);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String decryptString(String encryptedData, SecretKey key) throws Exception {
/*  80 */     byte[] encrypted = Base64.getDecoder().decode(encryptedData);
/*  81 */     byte[] decrypted = decryptAES(encrypted, key);
/*  82 */     return new String(decrypted, StandardCharsets.UTF_8);
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] encryptRSA(byte[] data, PublicKey publicKey) throws Exception {
/*  87 */     Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
/*  88 */     cipher.init(1, publicKey);
/*  89 */     return cipher.doFinal(data);
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] decryptRSA(byte[] encryptedData, PrivateKey privateKey) throws Exception {
/*  94 */     Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
/*  95 */     cipher.init(2, privateKey);
/*  96 */     return cipher.doFinal(encryptedData);
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] sign(byte[] data, PrivateKey privateKey) throws Exception {
/* 101 */     Signature signature = Signature.getInstance("SHA256withRSA");
/* 102 */     signature.initSign(privateKey);
/* 103 */     signature.update(data);
/* 104 */     return signature.sign();
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean verify(byte[] data, byte[] signature, PublicKey publicKey) throws Exception {
/* 109 */     Signature sig = Signature.getInstance("SHA256withRSA");
/* 110 */     sig.initVerify(publicKey);
/* 111 */     sig.update(data);
/* 112 */     return sig.verify(signature);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String generateRandomString(int length) {
/* 117 */     String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
/* 118 */     StringBuilder sb = new StringBuilder(length);
/* 119 */     for (int i = 0; i < length; i++) {
/* 120 */       sb.append(chars.charAt(secureRandom.nextInt(chars.length())));
/*     */     }
/* 122 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String generateRandomHex(int length) {
/* 127 */     StringBuilder sb = new StringBuilder(length);
/* 128 */     for (int i = 0; i < length; i++) {
/* 129 */       sb.append(String.format("%02x", new Object[] { Integer.valueOf(secureRandom.nextInt(256)) }));
/*     */     } 
/* 131 */     return sb.toString().toUpperCase();
/*     */   }
/*     */ 
/*     */   
/*     */   public static String hashSHA256(String data) throws Exception {
/* 136 */     MessageDigest digest = MessageDigest.getInstance("SHA-256");
/* 137 */     byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
/* 138 */     return bytesToHex(hash);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String hashSHA512(String data) throws Exception {
/* 143 */     MessageDigest digest = MessageDigest.getInstance("SHA-512");
/* 144 */     byte[] hash = digest.digest(data.getBytes(StandardCharsets.UTF_8));
/* 145 */     return bytesToHex(hash);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String bytesToHex(byte[] bytes) {
/* 150 */     StringBuilder sb = new StringBuilder();
/* 151 */     for (byte b : bytes) {
/* 152 */       sb.append(String.format("%02x", new Object[] { Byte.valueOf(b) }));
/*     */     } 
/* 154 */     return sb.toString();
/*     */   }
/*     */ 
/*     */   
/*     */   public static byte[] hexToBytes(String hex) {
/* 159 */     int len = hex.length();
/* 160 */     byte[] data = new byte[len / 2];
/* 161 */     for (int i = 0; i < len; i += 2) {
/* 162 */       data[i / 2] = 
/* 163 */         (byte)((Character.digit(hex.charAt(i), 16) << 4) + Character.digit(hex.charAt(i + 1), 16));
/*     */     }
/* 165 */     return data;
/*     */   }
/*     */   
/*     */   public static void saveKey(Key key, String filename) throws Exception
/*     */   {
/* 170 */     FileOutputStream fos = new FileOutputStream(filename); 
/* 171 */     try { fos.write(key.getEncoded());
/* 172 */       fos.close(); }
/*     */     catch (Throwable throwable) { try { fos.close(); }
/*     */       catch (Throwable throwable1)
/*     */       { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 177 */      } public static SecretKey loadAESKey(String filename) throws Exception { FileInputStream fis = new FileInputStream(filename); 
/* 178 */     try { byte[] keyBytes = fis.readAllBytes();
/* 179 */       SecretKeySpec secretKeySpec = new SecretKeySpec(keyBytes, "AES");
/* 180 */       fis.close(); return secretKeySpec; }
/*     */     catch (Throwable throwable) { try { fis.close(); }
/*     */       catch (Throwable throwable1)
/*     */       { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 185 */      } public static PrivateKey loadRSAPrivateKey(String filename) throws Exception { FileInputStream fis = new FileInputStream(filename); 
/* 186 */     try { byte[] keyBytes = fis.readAllBytes();
/* 187 */       PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(keyBytes);
/* 188 */       KeyFactory factory = KeyFactory.getInstance("RSA");
/* 189 */       PrivateKey privateKey = factory.generatePrivate(spec);
/* 190 */       fis.close(); return privateKey; }
/*     */     catch (Throwable throwable) { try { fis.close(); }
/*     */       catch (Throwable throwable1)
/*     */       { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 195 */      } public static PublicKey loadRSAPublicKey(String filename) throws Exception { FileInputStream fis = new FileInputStream(filename); 
/* 196 */     try { byte[] keyBytes = fis.readAllBytes();
/* 197 */       X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
/* 198 */       KeyFactory factory = KeyFactory.getInstance("RSA");
/* 199 */       PublicKey publicKey = factory.generatePublic(spec);
/* 200 */       fis.close(); return publicKey; }
/*     */     catch (Throwable throwable) { try { fis.close(); }
/*     */       catch (Throwable throwable1)
/*     */       { throwable.addSuppressed(throwable1); }
/*     */        throw throwable; }
/* 205 */      } public static String obfuscateString(String input) { if (input == null || input.isEmpty()) {
/* 206 */       return input;
/*     */     }
/*     */     
/* 209 */     byte[] key = new byte[16];
/* 210 */     secureRandom.nextBytes(key);
/*     */     
/* 212 */     byte[] inputBytes = input.getBytes(StandardCharsets.UTF_8);
/* 213 */     byte[] output = new byte[inputBytes.length + 16];
/*     */ 
/*     */     
/* 216 */     System.arraycopy(key, 0, output, 0, 16);
/*     */ 
/*     */     
/* 219 */     for (int i = 0; i < inputBytes.length; i++) {
/* 220 */       output[i + 16] = (byte)(inputBytes[i] ^ key[i % key.length]);
/*     */     }
/*     */     
/* 223 */     return Base64.getEncoder().encodeToString(output); }
/*     */ 
/*     */ 
/*     */   
/*     */   public static String deobfuscateString(String obfuscated) {
/* 228 */     if (obfuscated == null || obfuscated.isEmpty()) {
/* 229 */       return obfuscated;
/*     */     }
/*     */     
/*     */     try {
/* 233 */       byte[] data = Base64.getDecoder().decode(obfuscated);
/* 234 */       if (data.length < 16) {
/* 235 */         return obfuscated;
/*     */       }
/*     */       
/* 238 */       byte[] key = Arrays.copyOfRange(data, 0, 16);
/* 239 */       byte[] encrypted = Arrays.copyOfRange(data, 16, data.length);
/* 240 */       byte[] decrypted = new byte[encrypted.length];
/*     */ 
/*     */       
/* 243 */       for (int i = 0; i < encrypted.length; i++) {
/* 244 */         decrypted[i] = (byte)(encrypted[i] ^ key[i % key.length]);
/*     */       }
/*     */       
/* 247 */       return new String(decrypted, StandardCharsets.UTF_8);
/* 248 */     } catch (Exception e) {
/* 249 */       return obfuscated;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static String generateHardwareFingerprint() {
/*     */     try {
/* 256 */       StringBuilder fingerprint = new StringBuilder();
/*     */ 
/*     */       
/* 259 */       fingerprint.append(System.getProperty("os.name"));
/* 260 */       fingerprint.append(System.getProperty("os.version"));
/* 261 */       fingerprint.append(System.getProperty("os.arch"));
/* 262 */       fingerprint.append(System.getProperty("user.name"));
/* 263 */       fingerprint.append(System.getProperty("user.home"));
/*     */ 
/*     */       
/* 266 */       fingerprint.append(Runtime.getRuntime().availableProcessors());
/*     */ 
/*     */       
/* 269 */       fingerprint.append(Runtime.getRuntime().maxMemory());
/*     */ 
/*     */       
/* 272 */       NetworkInterface.getNetworkInterfaces().asIterator().forEachRemaining(networkInterface -> {
/*     */             try {
/*     */               if (networkInterface.isUp() && !networkInterface.isLoopback()) {
/*     */                 byte[] mac = networkInterface.getHardwareAddress();
/*     */                 if (mac != null) {
/*     */                   for (byte b : mac) {
/*     */                     fingerprint.append(String.format("%02X", new Object[] { Byte.valueOf(b) }));
/*     */                   } 
/*     */                 }
/*     */               } 
/* 282 */             } catch (Exception exception) {}
/*     */           });
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 288 */       MessageDigest digest = MessageDigest.getInstance("SHA-256");
/* 289 */       byte[] hash = digest.digest(fingerprint.toString().getBytes(StandardCharsets.UTF_8));
/*     */       
/* 291 */       return bytesToHex(hash).substring(0, 32).toUpperCase();
/*     */     }
/* 293 */     catch (Exception e) {
/*     */       
/* 295 */       return "HWID_" + System.getProperty("user.name") + "_" + 
/* 296 */         System.getProperty("os.name").replaceAll("\\s+", "") + "_" + 
/* 297 */         System.currentTimeMillis();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isValidLicenseFormat(String license) {
/* 303 */     if (license == null || license.length() != 32) {
/* 304 */       return false;
/*     */     }
/* 306 */     return license.matches("^[A-F0-9]{32}$");
/*     */   }
/*     */ 
/*     */   
/*     */   public static String generateLicenseKey() {
/* 311 */     return generateRandomHex(32);
/*     */   }
/*     */ 
/*     */   
/*     */   public static String createChecksum(byte[] data) throws Exception {
/* 316 */     MessageDigest digest = MessageDigest.getInstance("SHA-256");
/* 317 */     byte[] hash = digest.digest(data);
/* 318 */     return Base64.getEncoder().encodeToString(hash);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean verifyChecksum(byte[] data, String expectedChecksum) throws Exception {
/* 323 */     String actualChecksum = createChecksum(data);
/* 324 */     return actualChecksum.equals(expectedChecksum);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean secureStringEquals(String a, String b) {
/* 329 */     if (a == null || b == null) {
/* 330 */       return (a == b);
/*     */     }
/*     */     
/* 333 */     if (a.length() != b.length()) {
/* 334 */       return false;
/*     */     }
/*     */     
/* 337 */     int result = 0;
/* 338 */     for (int i = 0; i < a.length(); i++) {
/* 339 */       result |= a.charAt(i) ^ b.charAt(i);
/*     */     }
/*     */     
/* 342 */     return (result == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clearSensitiveData(byte[] data) {
/* 347 */     if (data != null) {
/* 348 */       Arrays.fill(data, (byte)0);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static void clearSensitiveData(String data) {
/* 354 */     if (data != null)
/*     */     {
/*     */       
/* 357 */       data = null;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\SecurityUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */