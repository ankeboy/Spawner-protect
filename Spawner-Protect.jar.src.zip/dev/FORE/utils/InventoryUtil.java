/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.mixin.ClientPlayerInteractionManagerAccessor;
/*    */ import java.util.function.Predicate;
/*    */ import net.minecraft.class_1661;
/*    */ import net.minecraft.class_1703;
/*    */ import net.minecraft.class_1707;
/*    */ import net.minecraft.class_1792;
/*    */ import net.minecraft.class_1799;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class InventoryUtil
/*    */ {
/*    */   public static void swap(int selectedSlot) {
/* 17 */     if (selectedSlot < 0 || selectedSlot > 8) {
/*    */       return;
/*    */     }
/* 20 */     (DonutBBC.mc.field_1724.method_31548()).field_7545 = selectedSlot;
/* 21 */     ((ClientPlayerInteractionManagerAccessor)DonutBBC.mc.field_1761).syncSlot();
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean swapStack(Predicate<class_1799> predicate) {
/* 26 */     class_1661 playerInventory = DonutBBC.mc.field_1724.method_31548();
/* 27 */     for (int slotIndex = 0; slotIndex < 9; slotIndex++) {
/* 28 */       if (predicate.test(playerInventory.method_5438(slotIndex))) {
/* 29 */         playerInventory.field_7545 = slotIndex;
/* 30 */         ((ClientPlayerInteractionManagerAccessor)DonutBBC.mc.field_1761).syncSlot();
/* 31 */         return true;
/*    */       } 
/*    */     } 
/* 34 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean swapItem(Predicate<class_1792> predicate) {
/* 39 */     class_1661 playerInventory = DonutBBC.mc.field_1724.method_31548();
/* 40 */     for (int slotIndex = 0; slotIndex < 9; slotIndex++) {
/* 41 */       if (predicate.test(playerInventory.method_5438(slotIndex).method_7909())) {
/* 42 */         playerInventory.field_7545 = slotIndex;
/* 43 */         ((ClientPlayerInteractionManagerAccessor)DonutBBC.mc.field_1761).syncSlot();
/* 44 */         return true;
/*    */       } 
/*    */     } 
/* 47 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean swap(class_1792 targetItem) {
/* 52 */     return swapItem(item -> (item == targetItem));
/*    */   }
/*    */ 
/*    */   
/*    */   public static int getSlot(class_1792 targetItem) {
/* 57 */     class_1703 currentScreenHandler = DonutBBC.mc.field_1724.field_7512;
/* 58 */     if (DonutBBC.mc.field_1724.field_7512 instanceof class_1707) {
/* 59 */       int itemCount = 0;
/* 60 */       for (int slotIndex = 0; slotIndex < ((class_1707)DonutBBC.mc.field_1724.field_7512).method_17388() * 9; slotIndex++) {
/* 61 */         if (currentScreenHandler.method_7611(slotIndex).method_7677().method_7909().equals(targetItem)) {
/* 62 */           itemCount++;
/*    */         }
/*    */       } 
/* 65 */       return itemCount;
/*    */     } 
/* 67 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public static boolean selectItemFromHotbar(class_1792 targetItem) {
/* 72 */     class_1661 playerInventory = DonutBBC.mc.field_1724.method_31548();
/* 73 */     for (int slotIndex = 0; slotIndex < 9; slotIndex++) {
/* 74 */       if (playerInventory.method_5438(slotIndex).method_7909() == targetItem) {
/* 75 */         playerInventory.field_7545 = slotIndex;
/* 76 */         ((ClientPlayerInteractionManagerAccessor)DonutBBC.mc.field_1761).syncSlot();
/* 77 */         return true;
/*    */       } 
/*    */     } 
/* 80 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\InventoryUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */