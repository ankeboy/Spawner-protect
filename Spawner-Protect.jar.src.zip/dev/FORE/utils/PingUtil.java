/*    */ package dev.FORE.utils;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_640;
/*    */ 
/*    */ public class PingUtil {
/*    */   public static Integer getPingString() {
/*  7 */     class_310 mc = class_310.method_1551();
/*    */     
/*  9 */     if (mc.field_1724 == null || mc.method_1562() == null) {
/* 10 */       return Integer.valueOf(0);
/*    */     }
/*    */     
/* 13 */     class_640 entry = mc.method_1562().method_2871(mc.field_1724.method_5667());
/* 14 */     if (entry == null) {
/* 15 */       return Integer.valueOf(0);
/*    */     }
/*    */     
/* 18 */     int ping = entry.method_2959();
/* 19 */     return Integer.valueOf(ping);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\PingUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */