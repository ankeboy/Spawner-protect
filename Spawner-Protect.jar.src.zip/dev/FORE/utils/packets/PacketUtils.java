/*    */ package dev.FORE.utils.packets;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.mixin.IClientWorldMixin;
/*    */ import java.util.Objects;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2596;
/*    */ import net.minecraft.class_2828;
/*    */ import net.minecraft.class_634;
/*    */ import net.minecraft.class_7202;
/*    */ import net.minecraft.class_7204;
/*    */ import net.minecraft.class_7648;
/*    */ 
/*    */ public class PacketUtils
/*    */ {
/*    */   public static void sendPacket(class_2596 packet) {
/* 17 */     if (DonutBBC.mc.field_1724 != null) {
/* 18 */       DonutBBC.mc.method_1562().method_52787(packet);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static void sendPosition(class_243 pos) {
/* 24 */     if (DonutBBC.mc.field_1724 != null) {
/* 25 */       DonutBBC.mc.field_1724.field_3944.method_52787((class_2596)new class_2828.class_2829(pos.method_10216(), pos.method_10214(), pos.method_10215(), DonutBBC.mc.field_1724.method_24828()));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public static void sendSequencedPacket(class_7204 packetCreator) {
/* 31 */     if (DonutBBC.mc.method_1562() != null && DonutBBC.mc.field_1687 != null) {
/* 32 */       class_7202 pendingUpdateManager = ((IClientWorldMixin)DonutBBC.mc.field_1687).getPendingUpdateManager().method_41937();
/*    */       
/*    */       try {
/* 35 */         int i = pendingUpdateManager.method_41942();
/* 36 */         DonutBBC.mc.method_1562().method_52787(packetCreator.predict(i));
/* 37 */       } catch (Throwable var5) {
/* 38 */         if (pendingUpdateManager != null) {
/*    */           try {
/* 40 */             pendingUpdateManager.close();
/* 41 */           } catch (Throwable var4) {
/* 42 */             var5.addSuppressed(var4);
/*    */           } 
/*    */         }
/*    */         
/* 46 */         throw var5;
/*    */       } 
/*    */       
/* 49 */       if (pendingUpdateManager != null) {
/* 50 */         pendingUpdateManager.close();
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void sendPacketSilently(class_2596 packet) {
/* 57 */     DonutBBC.mc.method_1562().method_48296().method_10752(packet, (class_7648)null);
/*    */   }
/*    */   
/*    */   public void sendPacket2(class_2596<?> packetIn) {
/* 61 */     if (packetIn != null)
/* 62 */       ((class_634)Objects.<class_634>requireNonNull(DonutBBC.mc.method_1562())).method_48296().method_10743(packetIn); 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\packets\PacketUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */