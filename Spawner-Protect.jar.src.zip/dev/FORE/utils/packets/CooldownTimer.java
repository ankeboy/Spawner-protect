/*    */ package dev.FORE.utils.packets;
/*    */ 
/*    */ public class CooldownTimer {
/*    */   private long cooldownDuration;
/*    */   private long lastStartTime;
/*    */   private boolean hasCompleted;
/*    */   
/*    */   public CooldownTimer(long cooldownDuration) {
/*  9 */     this.cooldownDuration = cooldownDuration;
/*    */   }
/*    */   
/*    */   public CooldownTimer() {
/* 13 */     this.cooldownDuration = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public void startCooldown() {
/* 17 */     resetTimer();
/* 18 */     this.hasCompleted = false;
/*    */   }
/*    */   
/*    */   public void resetTimer() {
/* 22 */     this.lastStartTime = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public long getElapsedTime() {
/* 26 */     return Math.max(0L, System.currentTimeMillis() - this.lastStartTime);
/*    */   }
/*    */   
/*    */   public boolean hasCooldownElapsed(long delay) {
/* 30 */     return (getElapsedTime() >= delay);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\packets\CooldownTimer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */