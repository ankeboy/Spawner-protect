/*    */ package dev.FORE.utils.packets;
/*    */ 
/*    */ public final class TimerUtils {
/*    */   private long lastMS;
/*    */   
/*    */   public TimerUtils() {
/*  7 */     reset();
/*    */   }
/*    */   
/*    */   public long getCurrentMS() {
/* 11 */     return System.nanoTime() / 1000000L;
/*    */   }
/*    */   
/*    */   public boolean hasTimeElapsed(long milliseconds) {
/* 15 */     return (getCurrentMS() - this.lastMS >= milliseconds);
/*    */   }
/*    */   
/*    */   public boolean hasReached(double milliseconds) {
/* 19 */     return ((getCurrentMS() - this.lastMS) >= milliseconds);
/*    */   }
/*    */   
/*    */   public void reset() {
/* 23 */     this.lastMS = getCurrentMS();
/*    */   }
/*    */   
/*    */   public boolean delay(float milliSec) {
/* 27 */     return ((float)(getTime() - this.lastMS) >= milliSec);
/*    */   }
/*    */   
/*    */   public long getTime() {
/* 31 */     return System.nanoTime() / 1000000L;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\packets\TimerUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */