/*    */ package dev.FORE.utils.packets;
/*    */ 
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ public class TimedPacket {
/*    */   private final class_2596<?> packet;
/*    */   private final CooldownTimer time;
/*    */   private final long millis;
/*    */   
/*    */   public TimedPacket(class_2596<?> packet) {
/* 11 */     this.packet = packet;
/* 12 */     this.time = new CooldownTimer();
/* 13 */     this.millis = System.currentTimeMillis();
/*    */   }
/*    */   
/*    */   public TimedPacket(class_2596<?> packet, long millis) {
/* 17 */     this.packet = packet;
/* 18 */     this.millis = millis;
/* 19 */     this.time = new CooldownTimer();
/*    */   }
/*    */   
/*    */   public class_2596 getPacket() {
/* 23 */     return this.packet;
/*    */   }
/*    */   
/*    */   public CooldownTimer getTimer() {
/* 27 */     return getTime();
/*    */   }
/*    */   
/*    */   public CooldownTimer getTime() {
/* 31 */     return this.time;
/*    */   }
/*    */   
/*    */   public long getMillis() {
/* 35 */     return this.millis;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\packets\TimedPacket.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */