/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import java.util.Optional;
/*    */ import java.util.concurrent.atomic.AtomicReference;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class RamAuthUtil
/*    */ {
/* 15 */   private static final AtomicReference<String> REGISTRY_A = new AtomicReference<>();
/* 16 */   private static final AtomicReference<String> REGISTRY_B = new AtomicReference<>();
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean setIfAbsentA(String value) {
/* 23 */     return REGISTRY_A.compareAndSet(null, value);
/*    */   }
/*    */   
/*    */   public static void forceSetA(String value) {
/* 27 */     REGISTRY_A.set(value);
/*    */   }
/*    */   
/*    */   public static Optional<String> getA() {
/* 31 */     return Optional.ofNullable(REGISTRY_A.get());
/*    */   }
/*    */   
/*    */   public static Optional<String> getAndClearA() {
/* 35 */     return Optional.ofNullable(REGISTRY_A.getAndSet(null));
/*    */   }
/*    */   
/*    */   public static boolean replaceIfMatchesA(String expected, String newValue) {
/* 39 */     return REGISTRY_A.compareAndSet(expected, newValue);
/*    */   }
/*    */   
/*    */   public static Optional<String> getAndOverwriteA(String newValue) {
/* 43 */     return Optional.ofNullable(REGISTRY_A.getAndSet(newValue));
/*    */   }
/*    */   
/*    */   public static void clearA() {
/* 47 */     REGISTRY_A.set(null);
/*    */   }
/*    */   
/*    */   public static boolean existsA() {
/* 51 */     return (REGISTRY_A.get() != null);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static boolean setIfAbsentB(String value) {
/* 57 */     return REGISTRY_B.compareAndSet(null, value);
/*    */   }
/*    */   
/*    */   public static void forceSetB(String value) {
/* 61 */     REGISTRY_B.set(value);
/*    */   }
/*    */   
/*    */   public static Optional<String> getB() {
/* 65 */     return Optional.ofNullable(REGISTRY_B.get());
/*    */   }
/*    */   
/*    */   public static Optional<String> getAndClearB() {
/* 69 */     return Optional.ofNullable(REGISTRY_B.getAndSet(null));
/*    */   }
/*    */   
/*    */   public static boolean replaceIfMatchesB(String expected, String newValue) {
/* 73 */     return REGISTRY_B.compareAndSet(expected, newValue);
/*    */   }
/*    */   
/*    */   public static Optional<String> getAndOverwriteB(String newValue) {
/* 77 */     return Optional.ofNullable(REGISTRY_B.getAndSet(newValue));
/*    */   }
/*    */   
/*    */   public static void clearB() {
/* 81 */     REGISTRY_B.set(null);
/*    */   }
/*    */   
/*    */   public static boolean existsB() {
/* 85 */     return (REGISTRY_B.get() != null);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\RamAuthUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */