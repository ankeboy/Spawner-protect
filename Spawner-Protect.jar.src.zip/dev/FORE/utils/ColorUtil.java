/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import java.awt.Color;
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class ColorUtil
/*    */ {
/*    */   public static Color getRainbowColor(int offset, int alpha) {
/* 10 */     Color hsbColor = Color.getHSBColor((float)((System.currentTimeMillis() * 3L + (offset * 175)) % 7200L) / 7200.0F, 0.6F, 1.0F);
/* 11 */     return new Color(hsbColor.getRed(), hsbColor.getGreen(), hsbColor.getBlue(), alpha);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Color getBreathingColor(Color baseColor, int offset, int speed) {
/* 16 */     float[] hsbValues = new float[3];
/* 17 */     Color.RGBtoHSB(baseColor.getRed(), baseColor.getGreen(), baseColor.getBlue(), hsbValues);
/*    */ 
/*    */     
/* 20 */     hsbValues[2] = 0.25F + 0.75F * Math.abs(((float)(System.currentTimeMillis() % 2000L) / 1000.0F + offset / speed * 2.0F) % 2.0F - 1.0F) % 2.0F;
/*    */     
/* 22 */     int rgbValue = Color.HSBtoRGB(hsbValues[0], hsbValues[1], hsbValues[2]);
/* 23 */     return new Color(rgbValue >> 16 & 0xFF, rgbValue >> 8 & 0xFF, rgbValue & 0xFF, baseColor.getAlpha());
/*    */   }
/*    */ 
/*    */   
/*    */   public static Color interpolateColors(float interpolation, Color color1, Color color2) {
/* 28 */     return new Color(
/* 29 */         (int)MathUtil.approachValue(interpolation, color2.getRed(), color1.getRed()), 
/* 30 */         (int)MathUtil.approachValue(interpolation, color2.getGreen(), color1.getGreen()), 
/* 31 */         (int)MathUtil.approachValue(interpolation, color2.getBlue(), color1.getBlue()));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static Color interpolateAlpha(float interpolation, int targetAlpha, Color color) {
/* 37 */     return new Color(color
/* 38 */         .getRed(), color
/* 39 */         .getGreen(), color
/* 40 */         .getBlue(), 
/* 41 */         (int)MathUtil.approachValue(interpolation, color.getAlpha(), targetAlpha));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public static Color smoothInterpolate(Color color1, Color color2, float interpolation) {
/* 47 */     return new Color(
/* 48 */         clampValue(Math.round(color1.getRed() + interpolation * (color2.getRed() - color1.getRed())), 0, 255), 
/* 49 */         clampValue(Math.round(color1.getGreen() + interpolation * (color2.getGreen() - color1.getGreen())), 0, 255), 
/* 50 */         clampValue(Math.round(color1.getBlue() + interpolation * (color2.getBlue() - color1.getBlue())), 0, 255), 
/* 51 */         clampValue(Math.round(color1.getAlpha() + interpolation * (color2.getAlpha() - color1.getAlpha())), 0, 255));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   private static int clampValue(int value, int min, int max) {
/* 57 */     return Math.max(min, Math.min(max, value));
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static Color a(int offset, int alpha) {
/* 64 */     return getRainbowColor(offset, alpha);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Color a(float interpolation, Color color1, Color color2) {
/* 69 */     return interpolateColors(interpolation, color1, color2);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Color a(float interpolation, int targetAlpha, Color color) {
/* 74 */     return interpolateAlpha(interpolation, targetAlpha, color);
/*    */   }
/*    */ 
/*    */   
/*    */   public static Color a(Color color1, Color color2, float interpolation) {
/* 79 */     return smoothInterpolate(color1, color2, interpolation);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\ColorUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */