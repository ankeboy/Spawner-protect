/*     */ package dev.FORE.utils;
/*     */ 
/*     */ import dev.FORE.DonutBBC;
/*     */ import org.apache.commons.lang3.StringUtils;
/*     */ import org.lwjgl.glfw.GLFW;
/*     */ 
/*     */ public final class KeyUtils
/*     */ {
/*     */   public static CharSequence getKey(int key) {
/*  10 */     switch (key) {
/*     */       case 2:
/*  12 */         return EncryptedString.of("MMB");
/*     */       
/*     */       case -1:
/*  15 */         return EncryptedString.of("N/A");
/*     */       
/*     */       case 256:
/*  18 */         return EncryptedString.of("Esc");
/*     */       
/*     */       case 96:
/*  21 */         return EncryptedString.of("Grave Accent");
/*     */       
/*     */       case 161:
/*  24 */         return EncryptedString.of("World 1");
/*     */       
/*     */       case 162:
/*  27 */         return EncryptedString.of("World 2");
/*     */       
/*     */       case 283:
/*  30 */         return EncryptedString.of("Print Screen");
/*     */       
/*     */       case 284:
/*  33 */         return EncryptedString.of("Pause");
/*     */       
/*     */       case 260:
/*  36 */         return EncryptedString.of("Insert");
/*     */       
/*     */       case 261:
/*  39 */         return EncryptedString.of("Delete");
/*     */       
/*     */       case 268:
/*  42 */         return EncryptedString.of("Home");
/*     */       
/*     */       case 266:
/*  45 */         return EncryptedString.of("Page Up");
/*     */       
/*     */       case 267:
/*  48 */         return EncryptedString.of("Page Down");
/*     */       
/*     */       case 269:
/*  51 */         return EncryptedString.of("End");
/*     */       
/*     */       case 258:
/*  54 */         return EncryptedString.of("Tab");
/*     */       
/*     */       case 341:
/*  57 */         return EncryptedString.of("Left Control");
/*     */       
/*     */       case 345:
/*  60 */         return EncryptedString.of("Right Control");
/*     */       
/*     */       case 342:
/*  63 */         return EncryptedString.of("Left Alt");
/*     */       
/*     */       case 346:
/*  66 */         return EncryptedString.of("Right Alt");
/*     */       
/*     */       case 340:
/*  69 */         return EncryptedString.of("Left Shift");
/*     */       
/*     */       case 344:
/*  72 */         return EncryptedString.of("Right Shift");
/*     */       
/*     */       case 265:
/*  75 */         return EncryptedString.of("Arrow Up");
/*     */       
/*     */       case 264:
/*  78 */         return EncryptedString.of("Arrow Down");
/*     */       
/*     */       case 263:
/*  81 */         return EncryptedString.of("Arrow Left");
/*     */       
/*     */       case 262:
/*  84 */         return EncryptedString.of("Arrow Right");
/*     */       
/*     */       case 39:
/*  87 */         return EncryptedString.of("Apostrophe");
/*     */       
/*     */       case 259:
/*  90 */         return EncryptedString.of("Backspace");
/*     */       
/*     */       case 280:
/*  93 */         return EncryptedString.of("Caps Lock");
/*     */       
/*     */       case 348:
/*  96 */         return EncryptedString.of("Menu");
/*     */       
/*     */       case 343:
/*  99 */         return EncryptedString.of("Left Super");
/*     */       
/*     */       case 347:
/* 102 */         return EncryptedString.of("Right Super");
/*     */       
/*     */       case 257:
/* 105 */         return EncryptedString.of("Enter");
/*     */       
/*     */       case 335:
/* 108 */         return EncryptedString.of("Numpad Enter");
/*     */       
/*     */       case 282:
/* 111 */         return EncryptedString.of("Num Lock");
/*     */       
/*     */       case 32:
/* 114 */         return EncryptedString.of("Space");
/*     */       
/*     */       case 290:
/* 117 */         return EncryptedString.of("F1");
/*     */       
/*     */       case 291:
/* 120 */         return EncryptedString.of("F2");
/*     */       
/*     */       case 292:
/* 123 */         return EncryptedString.of("F3");
/*     */       
/*     */       case 293:
/* 126 */         return EncryptedString.of("F4");
/*     */       
/*     */       case 294:
/* 129 */         return EncryptedString.of("F5");
/*     */       
/*     */       case 295:
/* 132 */         return EncryptedString.of("F6");
/*     */       
/*     */       case 296:
/* 135 */         return EncryptedString.of("F7");
/*     */       
/*     */       case 297:
/* 138 */         return EncryptedString.of("F8");
/*     */       
/*     */       case 298:
/* 141 */         return EncryptedString.of("F9");
/*     */       
/*     */       case 299:
/* 144 */         return EncryptedString.of("F10");
/*     */       
/*     */       case 300:
/* 147 */         return EncryptedString.of("F11");
/*     */       
/*     */       case 301:
/* 150 */         return EncryptedString.of("F12");
/*     */       
/*     */       case 302:
/* 153 */         return EncryptedString.of("F13");
/*     */       
/*     */       case 303:
/* 156 */         return EncryptedString.of("F14");
/*     */       
/*     */       case 304:
/* 159 */         return EncryptedString.of("F15");
/*     */       
/*     */       case 305:
/* 162 */         return EncryptedString.of("F16");
/*     */       
/*     */       case 306:
/* 165 */         return EncryptedString.of("F17");
/*     */       
/*     */       case 307:
/* 168 */         return EncryptedString.of("F18");
/*     */       
/*     */       case 308:
/* 171 */         return EncryptedString.of("F19");
/*     */       
/*     */       case 309:
/* 174 */         return EncryptedString.of("F20");
/*     */       
/*     */       case 310:
/* 177 */         return EncryptedString.of("F21");
/*     */       
/*     */       case 311:
/* 180 */         return EncryptedString.of("F22");
/*     */       
/*     */       case 312:
/* 183 */         return EncryptedString.of("F23");
/*     */       
/*     */       case 313:
/* 186 */         return EncryptedString.of("F24");
/*     */       
/*     */       case 314:
/* 189 */         return EncryptedString.of("F25");
/*     */       
/*     */       case 281:
/* 192 */         return EncryptedString.of("Scroll Lock");
/*     */       
/*     */       case 91:
/* 195 */         return EncryptedString.of("Left Bracket");
/*     */       
/*     */       case 93:
/* 198 */         return EncryptedString.of("Right Bracket");
/*     */       
/*     */       case 59:
/* 201 */         return EncryptedString.of("Semicolon");
/*     */       
/*     */       case 61:
/* 204 */         return EncryptedString.of("Equals");
/*     */       
/*     */       case 92:
/* 207 */         return EncryptedString.of("Backslash");
/*     */       
/*     */       case 44:
/* 210 */         return EncryptedString.of("Comma");
/*     */       
/*     */       case 0:
/* 213 */         return EncryptedString.of("LMB");
/*     */       
/*     */       case 1:
/* 216 */         return EncryptedString.of("RMB");
/*     */     } 
/*     */     
/* 219 */     String keyName = GLFW.glfwGetKeyName(key, 0);
/* 220 */     if (keyName == null) {
/* 221 */       return EncryptedString.of("None");
/*     */     }
/* 223 */     return StringUtils.capitalize(keyName);
/*     */   }
/*     */   
/*     */   public static boolean isKeyPressed(int n) {
/* 227 */     if (n <= 8) {
/* 228 */       return (GLFW.glfwGetMouseButton(DonutBBC.mc.method_22683().method_4490(), n) == 1);
/*     */     }
/* 230 */     return (GLFW.glfwGetKey(DonutBBC.mc.method_22683().method_4490(), n) == 1);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\KeyUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */