/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import dev.FORE.module.modules.client.DonutBBC;
/*    */ 
/*    */ public final class Animation {
/*    */   private double currentValue;
/*    */   private final double targetValue;
/*    */   
/*    */   public Animation(double targetValue) {
/* 10 */     this.currentValue = targetValue;
/* 11 */     this.targetValue = targetValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void animate(double speed, double target) {
/* 16 */     if (DonutBBC.animationMode.isMode((Enum)DonutBBC.AnimationMode.NORMAL)) {
/* 17 */       this.currentValue = MathUtil.approachValue((float)speed, this.currentValue, target);
/* 18 */     } else if (DonutBBC.animationMode.isMode((Enum)DonutBBC.AnimationMode.POSITIVE)) {
/* 19 */       this.currentValue = MathUtil.smoothStep(speed, this.currentValue, target);
/* 20 */     } else if (DonutBBC.animationMode.isMode((Enum)DonutBBC.AnimationMode.OFF)) {
/* 21 */       this.currentValue = target;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public double getAnimation() {
/* 27 */     return this.currentValue;
/*    */   }
/*    */ 
/*    */   
/*    */   public void setAnimation(double factor) {
/* 32 */     this.currentValue = MathUtil.smoothStep(factor, this.currentValue, this.targetValue);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\Animation.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */