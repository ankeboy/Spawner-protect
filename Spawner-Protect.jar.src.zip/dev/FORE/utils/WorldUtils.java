/*     */ package dev.FORE.utils;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_1268;
/*     */ import net.minecraft.class_1269;
/*     */ import net.minecraft.class_1294;
/*     */ import net.minecraft.class_1297;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_1831;
/*     */ import net.minecraft.class_1832;
/*     */ import net.minecraft.class_1834;
/*     */ import net.minecraft.class_1923;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_2374;
/*     */ import net.minecraft.class_238;
/*     */ import net.minecraft.class_239;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2818;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_3959;
/*     */ import net.minecraft.class_3965;
/*     */ import net.minecraft.class_3966;
/*     */ import net.minecraft.class_742;
/*     */ import net.minecraft.class_9779;
/*     */ 
/*     */ public final class WorldUtils {
/*  28 */   private static final class_310 mc = DonutBBC.mc;
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isDeadBodyNearby() {
/*  33 */     return mc.field_1687.method_18456().parallelStream()
/*  34 */       .filter(player -> (player != mc.field_1724))
/*  35 */       .filter(player -> (player.method_5858((class_1297)mc.field_1724) <= 36.0D))
/*  36 */       .anyMatch(class_1309::method_29504);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_1297 findNearestEntity(class_1657 targetPlayer, float radius, boolean seeOnly) {
/*  41 */     float minDistance = Float.MAX_VALUE;
/*  42 */     class_1297 nearestEntity = null;
/*     */     
/*  44 */     assert mc.field_1687 != null;
/*  45 */     for (class_1297 entity : mc.field_1687.method_18112()) {
/*  46 */       float distance = entity.method_5739((class_1297)targetPlayer);
/*     */       
/*  48 */       if (entity != targetPlayer && distance <= radius && mc.field_1724.method_6057(entity) == seeOnly && 
/*  49 */         distance < minDistance) {
/*  50 */         minDistance = distance;
/*  51 */         nearestEntity = entity;
/*     */       } 
/*     */     } 
/*     */     
/*  55 */     return nearestEntity;
/*     */   }
/*     */ 
/*     */   
/*     */   public static double distance(class_243 fromVec, class_243 toVec) {
/*  60 */     return Math.sqrt(Math.pow(toVec.field_1352 - fromVec.field_1352, 2.0D) + Math.pow(toVec.field_1351 - fromVec.field_1351, 2.0D) + Math.pow(toVec.field_1350 - fromVec.field_1350, 2.0D));
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_1657 findNearestPlayer(class_1657 targetPlayer, float range, boolean seeOnly, boolean excludeFriends) {
/*  65 */     float minDistance = Float.MAX_VALUE;
/*  66 */     class_1657 nearestPlayer = null;
/*     */     
/*  68 */     for (class_1657 player : mc.field_1687.method_18456()) {
/*  69 */       float distance = (float)distance(targetPlayer.method_19538(), player.method_19538());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  75 */       if (player != targetPlayer && distance <= range && player.method_6057((class_1297)targetPlayer) == seeOnly && 
/*  76 */         distance < minDistance) {
/*  77 */         minDistance = distance;
/*  78 */         nearestPlayer = player;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  83 */     return nearestPlayer;
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_243 getPlayerLookVec(float yaw, float pitch) {
/*  88 */     float pitchRadians = pitch * 0.017453292F;
/*  89 */     float yawRadians = -yaw * 0.017453292F;
/*     */     
/*  91 */     float cosYaw = class_3532.method_15362(yawRadians);
/*  92 */     float sinYaw = class_3532.method_15374(yawRadians);
/*  93 */     float cosPitch = class_3532.method_15362(pitchRadians);
/*  94 */     float sinPitch = class_3532.method_15374(pitchRadians);
/*     */     
/*  96 */     return new class_243((sinYaw * cosPitch), -sinPitch, (cosYaw * cosPitch));
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_243 getPlayerLookVec(class_1657 player) {
/* 101 */     return getPlayerLookVec(player.method_36454(), player.method_36455());
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_239 getHitResult(double radius) {
/* 106 */     return getHitResult((class_1657)mc.field_1724, false, mc.field_1724.method_36454(), mc.field_1724.method_36455(), radius);
/*     */   }
/*     */ 
/*     */   
/*     */   public static class_239 getHitResult(class_1657 entity, boolean ignoreInvisibles, float yaw, float pitch, double distance) {
/* 111 */     if (entity == null || mc.field_1687 == null) return null;
/*     */     
/* 113 */     double currentDistance = distance;
/* 114 */     class_243 cameraPosVec = entity.method_5836(class_9779.field_51956.method_60637(true));
/* 115 */     class_243 rotationVec = getPlayerLookVec(yaw, pitch);
/* 116 */     class_243 range = cameraPosVec.method_1031(rotationVec.field_1352 * currentDistance, rotationVec.field_1351 * currentDistance, rotationVec.field_1350 * currentDistance);
/*     */     
/* 118 */     class_3965 class_3965 = mc.field_1687.method_17742(new class_3959(cameraPosVec, range, class_3959.class_3960.field_17559, class_3959.class_242.field_1348, (class_1297)entity));
/*     */     
/* 120 */     double squaredDistance = currentDistance * currentDistance;
/* 121 */     currentDistance = distance;
/*     */     
/* 123 */     if (class_3965 != null) {
/* 124 */       squaredDistance = class_3965.method_17784().method_1025(cameraPosVec);
/*     */     }
/*     */     
/* 127 */     class_243 vec3d3 = cameraPosVec.method_1031(rotationVec.field_1352 * currentDistance, rotationVec.field_1351 * currentDistance, rotationVec.field_1350 * currentDistance);
/* 128 */     class_238 box = entity.method_5829().method_18804(rotationVec.method_1021(currentDistance)).method_1009(1.0D, 1.0D, 1.0D);
/*     */     
/* 130 */     class_3966 entityHitResult = class_1675.method_18075((class_1297)entity, cameraPosVec, vec3d3, box, entityx -> 
/* 131 */         (!entityx.method_7325() && entityx.method_5863() && (!entityx.method_5767() || !ignoreInvisibles)), squaredDistance);
/*     */     
/* 133 */     if (entityHitResult != null) {
/* 134 */       class_243 vec3d4 = entityHitResult.method_17784();
/* 135 */       double entitySquaredDistance = cameraPosVec.method_1025(vec3d4);
/*     */       
/* 137 */       if ((distance > distance && entitySquaredDistance > Math.pow(distance, 2.0D)) || entitySquaredDistance < squaredDistance || class_3965 == null)
/*     */       {
/*     */         
/* 140 */         class_3965 = (entitySquaredDistance > Math.pow(distance, 2.0D)) ? class_3965.method_17778(vec3d4, class_2350.method_10142(rotationVec.field_1352, rotationVec.field_1351, rotationVec.field_1350), class_2338.method_49638((class_2374)vec3d4)) : (class_3965)entityHitResult;
/*     */       }
/*     */     } 
/*     */     
/* 144 */     return (class_239)class_3965;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void placeBlock(class_3965 blockHit, boolean swingHand) {
/* 149 */     class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, blockHit);
/* 150 */     if (result.method_23665() && result.method_23666() && swingHand) mc.field_1724.method_6104(class_1268.field_5808);
/*     */   
/*     */   }
/*     */   
/*     */   public static Stream<class_2818> getLoadedChunks() {
/* 155 */     int viewRadius = Math.max(2, mc.field_1690.method_38521()) + 3;
/* 156 */     int diameter = viewRadius * 2 + 1;
/*     */     
/* 158 */     class_1923 centerChunk = mc.field_1724.method_31476();
/* 159 */     class_1923 minChunk = new class_1923(centerChunk.field_9181 - viewRadius, centerChunk.field_9180 - viewRadius);
/* 160 */     class_1923 maxChunk = new class_1923(centerChunk.field_9181 + viewRadius, centerChunk.field_9180 + viewRadius);
/*     */     
/* 162 */     return Stream.<class_1923>iterate(minChunk, currentPos -> {
/*     */           int nextX = currentPos.field_9181;
/*     */           
/*     */           int nextZ = currentPos.field_9180;
/*     */           
/*     */           if (++nextX > maxChunk.field_9181) {
/*     */             nextX = minChunk.field_9181;
/*     */             nextZ++;
/*     */           } 
/*     */           if (nextZ > maxChunk.field_9180) {
/*     */             throw new IllegalStateException("Stream limit didn't work.");
/*     */           }
/*     */           return new class_1923(nextX, nextZ);
/* 175 */         }).limit(diameter * diameter)
/* 176 */       .filter(chunkPos -> mc.field_1687.method_8393(chunkPos.field_9181, chunkPos.field_9180))
/* 177 */       .map(chunkPos -> mc.field_1687.method_8497(chunkPos.field_9181, chunkPos.field_9180))
/* 178 */       .filter(Objects::nonNull);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean isShieldFacingAway(class_1657 player) {
/* 185 */     if (mc.field_1724 != null && player != null) {
/* 186 */       class_243 playerPos = mc.field_1724.method_19538();
/* 187 */       class_243 targetPos = player.method_19538();
/*     */       
/* 189 */       class_243 directionToPlayer = playerPos.method_1020(targetPos).method_1029();
/*     */       
/* 191 */       float yaw = player.method_36454();
/* 192 */       float pitch = player.method_36455();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 197 */       class_243 facingDirection = (new class_243(-Math.sin(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch)), -Math.sin(Math.toRadians(pitch)), Math.cos(Math.toRadians(yaw)) * Math.cos(Math.toRadians(pitch)))).method_1029();
/*     */       
/* 199 */       double dotProduct = facingDirection.method_1026(directionToPlayer);
/*     */       
/* 201 */       return (dotProduct < 0.0D);
/*     */     } 
/* 203 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isTool(class_1799 itemStack) {
/* 208 */     if (!(itemStack.method_7909() instanceof class_1831)) {
/* 209 */       return false;
/*     */     }
/* 211 */     class_1832 material = ((class_1831)itemStack.method_7909()).method_8022();
/* 212 */     return (material == class_1834.field_8930 || material == class_1834.field_22033);
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isCrit(class_1657 player, class_1297 target) {
/* 217 */     return (player.method_7261(0.5F) > 0.9F && player.field_6017 > 0.0F && !player.method_24828() && !player.method_6101() && !player.method_5869() && !player.method_6059(class_1294.field_5919) && target instanceof class_1309);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void hitEntity(class_1297 entity, boolean swingHand) {
/* 222 */     mc.field_1761.method_2918((class_1657)mc.field_1724, entity);
/*     */     
/* 224 */     if (swingHand)
/* 225 */       mc.field_1724.method_6104(class_1268.field_5808); 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\WorldUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */