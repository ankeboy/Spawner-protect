/*    */ package dev.FORE.utils;
/*    */ 
/*    */ 
/*    */ public final class MathUtil
/*    */ {
/*    */   public static double roundToNearest(double value, double step) {
/*  7 */     return step * Math.round(value / step);
/*    */   }
/*    */ 
/*    */   
/*    */   public static double smoothStep(double factor, double start, double end) {
/* 12 */     double clampedFactor = Math.max(0.0D, Math.min(1.0D, factor));
/* 13 */     return start + (end - start) * clampedFactor * clampedFactor * (3.0D - 2.0D * clampedFactor);
/*    */   }
/*    */ 
/*    */   
/*    */   public static double approachValue(float speed, double current, double target) {
/* 18 */     double stepSize = Math.ceil(Math.abs(target - current) * speed);
/* 19 */     if (current < target) {
/* 20 */       return Math.min(current + (int)stepSize, target);
/*    */     }
/* 22 */     return Math.max(current - (int)stepSize, target);
/*    */   }
/*    */ 
/*    */   
/*    */   public static double linearInterpolate(double factor, double start, double end) {
/* 27 */     return start + (end - start) * factor;
/*    */   }
/*    */ 
/*    */   
/*    */   public static double exponentialInterpolate(double start, double end, double base, double exponent) {
/* 32 */     return linearInterpolate((1.0F - (float)Math.pow(base, exponent)), start, end);
/*    */   }
/*    */ 
/*    */   
/*    */   public static double clampValue(double value, double min, double max) {
/* 37 */     return Math.max(min, Math.min(value, max));
/*    */   }
/*    */ 
/*    */   
/*    */   public static int clampInt(int value, int min, int max) {
/* 42 */     return Math.max(min, Math.min(value, max));
/*    */   }
/*    */ 
/*    */   
/*    */   public static int randomInt(int min, int max) {
/* 47 */     return (int)(Math.random() * (max - min + 1)) + min;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\MathUtil.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */