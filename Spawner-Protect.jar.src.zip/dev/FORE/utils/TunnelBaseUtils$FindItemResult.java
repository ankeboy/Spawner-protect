/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class FindItemResult
/*    */ {
/*    */   private final int slot;
/*    */   private final boolean found;
/*    */   
/*    */   public FindItemResult(int slot, boolean found) {
/* 21 */     this.slot = slot;
/* 22 */     this.found = found;
/*    */   }
/*    */   
/*    */   public boolean found() {
/* 26 */     return this.found;
/*    */   }
/*    */   
/*    */   public int slot() {
/* 30 */     return this.slot;
/*    */   }
/*    */   
/*    */   public boolean isMainHand() {
/* 34 */     return (this.slot == (DonutBBC.mc.field_1724.method_31548()).field_7545);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\TunnelBaseUtils$FindItemResult.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */