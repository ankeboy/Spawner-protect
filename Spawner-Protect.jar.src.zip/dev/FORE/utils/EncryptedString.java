/*     */ package dev.FORE.utils;
/*     */ 
/*     */ import java.nio.CharBuffer;
/*     */ import java.security.SecureRandom;
/*     */ import java.util.Arrays;
/*     */ import net.minecraft.class_2561;
/*     */ import org.jetbrains.annotations.NotNull;
/*     */ 
/*     */ public class EncryptedString
/*     */   implements AutoCloseable, CharSequence
/*     */ {
/*     */   public static final String PART = "Key";
/*     */   private final char[] key;
/*     */   private final char[] value;
/*     */   private final int length;
/*     */   
/*     */   public EncryptedString(String string) {
/*  18 */     this.closed = false;
/*  19 */     if (string == null) {
/*  20 */       throw new IllegalArgumentException("Input string cannot be null");
/*     */     }
/*  22 */     this.length = string.length();
/*  23 */     this.key = generateRandomKey(Math.min(this.length, 128));
/*  24 */     this.value = new char[this.length];
/*  25 */     string.getChars(0, this.length, this.value, 0);
/*  26 */     applyXorEncryption(this.value, this.key, 0, this.length);
/*     */   }
/*     */   
/*     */   public EncryptedString(char[] original, char[] original2) {
/*  30 */     this.closed = false;
/*  31 */     if (original == null || original2 == null) {
/*  32 */       throw new IllegalArgumentException("Neither encrypted value nor key can be null");
/*     */     }
/*  34 */     if (original2.length == 0) {
/*  35 */       throw new IllegalArgumentException("Encryption key cannot be empty");
/*     */     }
/*  37 */     this.length = original.length;
/*  38 */     this.value = Arrays.copyOf(original, original.length);
/*  39 */     this.key = Arrays.copyOf(original2, original2.length);
/*     */   }
/*     */   
/*     */   public static EncryptedString of(String s) {
/*  43 */     return new EncryptedString(s);
/*     */   }
/*     */   
/*     */   public static EncryptedString of(String s, String s2) {
/*  47 */     if (s == null || s2 == null) {
/*  48 */       throw new IllegalArgumentException("Neither encrypted data nor key can be null");
/*     */     }
/*  50 */     return new EncryptedString(s.toCharArray(), s2.toCharArray());
/*     */   }
/*     */   
/*     */   private static char[] generateRandomKey(int n) {
/*  54 */     char[] array = new char[n];
/*  55 */     for (int i = 0; i < n; i++) {
/*  56 */       array[i] = (char)random.nextInt(65536);
/*     */     }
/*  58 */     return array;
/*     */   }
/*     */   
/*     */   private static void applyXorEncryption(char[] array, char[] array2, int n, int n2) {
/*  62 */     for (int i = 0; i < n2; i++) {
/*  63 */       int n3 = n + i;
/*  64 */       array[n3] = (char)(array[n3] ^ array2[i % array2.length]);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int length() {
/*  70 */     setClosed();
/*  71 */     return this.length;
/*     */   }
/*     */ 
/*     */   
/*     */   public char charAt(int n) {
/*  76 */     setClosed();
/*  77 */     if (n < 0 || n >= this.length) {
/*  78 */       throw new IndexOutOfBoundsException("Index: " + n + ", Length: " + this.length);
/*     */     }
/*  80 */     return (char)(this.value[n] ^ this.key[n % this.key.length]);
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public CharSequence subSequence(int n, int n2) {
/*  86 */     setClosed();
/*  87 */     if (n < 0 || n2 > this.length || n > n2) {
/*  88 */       throw new IndexOutOfBoundsException("Invalid subsequence range: " + n + " to " + n2 + " (length: " + this.length);
/*     */     }
/*  90 */     int n3 = n2 - n;
/*  91 */     char[] array = new char[n3];
/*  92 */     System.arraycopy(this.value, n, array, 0, n3);
/*  93 */     char[] array2 = new char[n3];
/*  94 */     for (int i = 0; i < n3; i++) {
/*  95 */       array2[i] = this.key[(n + i) % this.key.length];
/*     */     }
/*  97 */     applyXorEncryption(array, this.key, 0, n3);
/*  98 */     applyXorEncryption(array, array2, 0, n3);
/*  99 */     return new EncryptedString(array, array2);
/*     */   }
/*     */ 
/*     */   
/*     */   @NotNull
/*     */   public String toString() {
/* 105 */     setClosed();
/* 106 */     char[] array = new char[this.length];
/* 107 */     for (int i = 0; i < this.length; i++) {
/* 108 */       array[i] = charAt(i);
/*     */     }
/* 110 */     String s = new String(array);
/* 111 */     Arrays.fill(array, false);
/* 112 */     return s;
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public String a() {
/* 117 */     setClosed();
/* 118 */     return toString();
/*     */   }
/*     */   
/*     */   @NotNull
/*     */   public class_2561 toText() {
/* 123 */     setClosed();
/* 124 */     return (class_2561)class_2561.method_43470(toString());
/*     */   }
/*     */   
/*     */   public CharBuffer b() {
/* 128 */     setClosed();
/* 129 */     CharBuffer allocate = CharBuffer.allocate(this.length);
/* 130 */     for (int i = 0; i < this.length; i++) {
/* 131 */       allocate.put(i, charAt(i));
/*     */     }
/* 133 */     allocate.flip();
/* 134 */     return allocate.asReadOnlyBuffer();
/*     */   }
/*     */ 
/*     */   
/*     */   public void close() {
/* 139 */     if (!this.closed) {
/* 140 */       Arrays.fill(this.value, false);
/* 141 */       Arrays.fill(this.key, false);
/* 142 */       this.closed = true;
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setClosed() {
/* 147 */     if (this.closed) {
/* 148 */       throw new IllegalStateException("This EncryptedString has been closed and cannot be used");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean equals(Object o) {
/* 154 */     setClosed();
/* 155 */     if (this == o) {
/* 156 */       return true;
/*     */     }
/* 158 */     if (!(o instanceof CharSequence)) {
/* 159 */       return false;
/*     */     }
/* 161 */     if (this.length != ((CharSequence)o).length()) {
/* 162 */       return false;
/*     */     }
/* 164 */     for (int i = 0; i < this.length; i++) {
/* 165 */       if (charAt(i) != ((CharSequence)o).charAt(i)) {
/* 166 */         return false;
/*     */       }
/*     */     } 
/* 169 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int hashCode() {
/* 174 */     setClosed();
/* 175 */     int n = 0;
/* 176 */     for (int i = 0; i < this.length; i++) {
/* 177 */       n = 31 * n + charAt(i);
/*     */     }
/* 179 */     return n;
/*     */   }
/*     */ 
/*     */   
/* 183 */   private static final SecureRandom random = new SecureRandom();
/*     */   private boolean closed;
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\EncryptedString.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */