/*     */ package dev.FORE.utils;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import dev.FORE.DonutBBC;
/*     */ import dev.FORE.manager.ShaderManager;
/*     */ import java.awt.Color;
/*     */ import java.util.function.Consumer;
/*     */ import java.util.function.Supplier;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1799;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_286;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_332;
/*     */ import net.minecraft.class_3532;
/*     */ import net.minecraft.class_4184;
/*     */ import net.minecraft.class_437;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_5944;
/*     */ import net.minecraft.class_757;
/*     */ import net.minecraft.class_8251;
/*     */ import org.joml.Matrix4f;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ 
/*     */ public final class RenderUtils {
/*     */   public static class_243 getCameraPos() {
/*  30 */     return getCamera().method_19326();
/*     */   }
/*     */   public static class_8251 vertexSorter;
/*     */   public static class_4184 getCamera() {
/*  34 */     return (DonutBBC.mc.method_31975()).field_4344;
/*     */   }
/*     */   
/*     */   public static double deltaTime() {
/*     */     double n;
/*  39 */     if (DonutBBC.mc.method_47599() > 0) {
/*  40 */       n = 1.0D / DonutBBC.mc.method_47599();
/*     */     } else {
/*  42 */       n = 1.0D;
/*     */     } 
/*  44 */     return n;
/*     */   }
/*     */   
/*     */   public static float fast(float currentValue, float targetValue, float speed) {
/*  48 */     return (1.0F - class_3532.method_15363((float)(deltaTime() * speed), 0.0F, 1.0F)) * currentValue + class_3532.method_15363((float)(deltaTime() * speed), 0.0F, 1.0F) * targetValue;
/*     */   }
/*     */   
/*     */   public static class_243 getPlayerLookVec(class_1657 playerEntity) {
/*  52 */     float cosYaw = class_3532.method_15362(playerEntity.method_36454() * 0.017453292F - 3.1415927F);
/*  53 */     float sinYaw = class_3532.method_15374(playerEntity.method_36454() * 0.017453292F - 3.1415927F);
/*  54 */     float cosPitch = class_3532.method_15362(playerEntity.method_36455() * 0.017453292F);
/*  55 */     return (new class_243((sinYaw * cosPitch), class_3532.method_15374(playerEntity.method_36455() * 0.017453292F), (cosYaw * cosPitch))).method_1029();
/*     */   }
/*     */   
/*     */   public static void unscaledProjection() {
/*  59 */     vertexSorter = RenderSystem.getVertexSorting();
/*  60 */     RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, DonutBBC.mc.method_22683().method_4489(), DonutBBC.mc.method_22683().method_4506(), 0.0F, 1000.0F, 21000.0F), class_8251.field_43361);
/*  61 */     rendering3D = false;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void drawBox(class_243 pos, Color color, class_4587 stack) {
/*  66 */     class_310 mc = class_310.method_1551();
/*  67 */     class_4184 camera = mc.field_1773.method_19418();
/*  68 */     class_243 camPos = camera.method_19326();
/*     */     
/*  70 */     float red = color.getRed() / 255.0F;
/*  71 */     float green = color.getGreen() / 255.0F;
/*  72 */     float blue = color.getBlue() / 255.0F;
/*  73 */     float alpha = color.getAlpha() / 255.0F;
/*     */     
/*  75 */     float boxWidth = 0.3F;
/*  76 */     float boxHeight = 1.8F;
/*     */     
/*  78 */     class_243 start = pos.method_1020(camPos);
/*  79 */     float x = (float)start.field_1352;
/*  80 */     float y = (float)start.field_1351;
/*  81 */     float z = (float)start.field_1350;
/*     */     
/*  83 */     stack.method_22903();
/*  84 */     Matrix4f matrix = stack.method_23760().method_23761();
/*     */ 
/*     */     
/*  87 */     RenderSystem.enableBlend();
/*  88 */     RenderSystem.disableDepthTest();
/*  89 */     RenderSystem.disableCull();
/*  90 */     RenderSystem.blendFuncSeparate(770, 771, 1, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  97 */     class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1576);
/*     */ 
/*     */ 
/*     */     
/* 101 */     RenderSystem.setShader(class_757::method_34540);
/*     */ 
/*     */     
/* 104 */     buffer.method_22918(matrix, x - boxWidth, y, z - boxWidth).method_22915(red, green, blue, alpha);
/* 105 */     buffer.method_22918(matrix, x + boxWidth, y, z - boxWidth).method_22915(red, green, blue, alpha);
/* 106 */     buffer.method_22918(matrix, x + boxWidth, y, z + boxWidth).method_22915(red, green, blue, alpha);
/* 107 */     buffer.method_22918(matrix, x - boxWidth, y, z + boxWidth).method_22915(red, green, blue, alpha);
/*     */ 
/*     */     
/* 110 */     buffer.method_22918(matrix, x - boxWidth, y + boxHeight, z - boxWidth).method_22915(red, green, blue, alpha);
/* 111 */     buffer.method_22918(matrix, x + boxWidth, y + boxHeight, z - boxWidth).method_22915(red, green, blue, alpha);
/* 112 */     buffer.method_22918(matrix, x + boxWidth, y + boxHeight, z + boxWidth).method_22915(red, green, blue, alpha);
/* 113 */     buffer.method_22918(matrix, x - boxWidth, y + boxHeight, z + boxWidth).method_22915(red, green, blue, alpha);
/*     */ 
/*     */     
/* 116 */     buffer.method_22918(matrix, x - boxWidth, y, z - boxWidth).method_22915(red, green, blue, alpha);
/* 117 */     buffer.method_22918(matrix, x + boxWidth, y, z - boxWidth).method_22915(red, green, blue, alpha);
/* 118 */     buffer.method_22918(matrix, x + boxWidth, y + boxHeight, z - boxWidth).method_22915(red, green, blue, alpha);
/* 119 */     buffer.method_22918(matrix, x - boxWidth, y + boxHeight, z - boxWidth).method_22915(red, green, blue, alpha);
/*     */ 
/*     */     
/* 122 */     buffer.method_22918(matrix, x - boxWidth, y, z + boxWidth).method_22915(red, green, blue, alpha);
/* 123 */     buffer.method_22918(matrix, x + boxWidth, y, z + boxWidth).method_22915(red, green, blue, alpha);
/* 124 */     buffer.method_22918(matrix, x + boxWidth, y + boxHeight, z + boxWidth).method_22915(red, green, blue, alpha);
/* 125 */     buffer.method_22918(matrix, x - boxWidth, y + boxHeight, z + boxWidth).method_22915(red, green, blue, alpha);
/*     */ 
/*     */     
/* 128 */     buffer.method_22918(matrix, x + boxWidth, y, z - boxWidth).method_22915(red, green, blue, alpha);
/* 129 */     buffer.method_22918(matrix, x + boxWidth, y, z + boxWidth).method_22915(red, green, blue, alpha);
/* 130 */     buffer.method_22918(matrix, x + boxWidth, y + boxHeight, z + boxWidth).method_22915(red, green, blue, alpha);
/* 131 */     buffer.method_22918(matrix, x + boxWidth, y + boxHeight, z - boxWidth).method_22915(red, green, blue, alpha);
/*     */ 
/*     */     
/* 134 */     buffer.method_22918(matrix, x - boxWidth, y, z - boxWidth).method_22915(red, green, blue, alpha);
/* 135 */     buffer.method_22918(matrix, x - boxWidth, y, z + boxWidth).method_22915(red, green, blue, alpha);
/* 136 */     buffer.method_22918(matrix, x - boxWidth, y + boxHeight, z + boxWidth).method_22915(red, green, blue, alpha);
/* 137 */     buffer.method_22918(matrix, x - boxWidth, y + boxHeight, z - boxWidth).method_22915(red, green, blue, alpha);
/*     */     
/* 139 */     class_286.method_43433(buffer.method_60800());
/*     */ 
/*     */     
/* 142 */     RenderSystem.enableDepthTest();
/* 143 */     RenderSystem.disableBlend();
/* 144 */     RenderSystem.enableCull();
/* 145 */     RenderSystem.defaultBlendFunc();
/*     */     
/* 147 */     stack.method_22909();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void drawLine(class_243 lastPos, class_243 pos, Color color, class_4587 stack) {
/* 152 */     class_310 mc = class_310.method_1551();
/* 153 */     class_4184 camera = mc.field_1773.method_19418();
/* 154 */     class_243 camPos = camera.method_19326();
/*     */     
/* 156 */     float red = color.getRed() / 255.0F;
/* 157 */     float green = color.getGreen() / 255.0F;
/* 158 */     float blue = color.getBlue() / 255.0F;
/* 159 */     float alpha = color.getAlpha() / 255.0F;
/*     */     
/* 161 */     stack.method_22903();
/* 162 */     Matrix4f matrix = stack.method_23760().method_23761();
/*     */ 
/*     */     
/* 165 */     RenderSystem.enableBlend();
/* 166 */     RenderSystem.disableDepthTest();
/* 167 */     RenderSystem.disableCull();
/* 168 */     RenderSystem.blendFuncSeparate(770, 771, 1, 0);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 176 */     GL11.glLineWidth(2.0F);
/*     */     
/* 178 */     class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_29344, class_290.field_1576);
/*     */ 
/*     */ 
/*     */     
/* 182 */     RenderSystem.setShader(class_757::method_34540);
/*     */     
/* 184 */     class_243 start = lastPos.method_1020(camPos);
/* 185 */     float startX = (float)start.field_1352;
/* 186 */     float startY = (float)start.field_1351;
/* 187 */     float startZ = (float)start.field_1350;
/*     */     
/* 189 */     class_243 end = pos.method_1020(camPos);
/* 190 */     float endX = (float)end.field_1352;
/* 191 */     float endY = (float)end.field_1351;
/* 192 */     float endZ = (float)end.field_1350;
/*     */     
/* 194 */     buffer.method_22918(matrix, startX, startY, startZ).method_22915(red, green, blue, alpha);
/* 195 */     buffer.method_22918(matrix, endX, endY, endZ).method_22915(red, green, blue, alpha);
/*     */     
/* 197 */     class_286.method_43433(buffer.method_60800());
/*     */ 
/*     */     
/* 200 */     GL11.glLineWidth(1.0F);
/* 201 */     RenderSystem.enableDepthTest();
/* 202 */     RenderSystem.disableBlend();
/* 203 */     RenderSystem.enableCull();
/* 204 */     RenderSystem.defaultBlendFunc();
/*     */     
/* 206 */     stack.method_22909();
/*     */   }
/*     */   
/*     */   public static void scaledProjection() {
/* 210 */     RenderSystem.setProjectionMatrix((new Matrix4f()).setOrtho(0.0F, (float)(DonutBBC.mc.method_22683().method_4489() / DonutBBC.mc.method_22683().method_4495()), (float)(DonutBBC.mc.method_22683().method_4506() / DonutBBC.mc.method_22683().method_4495()), 0.0F, 1000.0F, 21000.0F), vertexSorter);
/* 211 */     rendering3D = true;
/*     */   }
/*     */   
/*     */   public static void renderRoundedQuad(class_4587 matrixStack, Color color, double n, double n2, double n3, double n4, double n5, double n6, double n7, double n8, double n9) {
/* 215 */     int rgb = color.getRGB();
/* 216 */     Matrix4f positionMatrix = matrixStack.method_23760().method_23761();
/* 217 */     RenderSystem.enableBlend();
/* 218 */     RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 219 */     RenderSystem.setShader(class_757::method_34540);
/* 220 */     renderRoundedQuadInternal(positionMatrix, (rgb >> 16 & 0xFF) / 255.0F, (rgb >> 8 & 0xFF) / 255.0F, (rgb & 0xFF) / 255.0F, (rgb >> 24 & 0xFF) / 255.0F, n, n2, n3, n4, n5, n6, n7, n8, n9);
/* 221 */     RenderSystem.enableCull();
/* 222 */     RenderSystem.disableBlend();
/*     */   }
/*     */   
/*     */   private static void setup() {
/* 226 */     RenderSystem.enableBlend();
/* 227 */     RenderSystem.defaultBlendFunc();
/*     */   }
/*     */   
/*     */   private static void cleanup() {
/* 231 */     RenderSystem.enableCull();
/* 232 */     RenderSystem.disableBlend();
/*     */   }
/*     */   
/*     */   public static void renderRoundedQuad(class_4587 matrixStack, Color color, double n, double n2, double n3, double n4, double n5, double n6) {
/* 236 */     renderRoundedQuad(matrixStack, color, n, n2, n3, n4, n5, n5, n5, n5, n6);
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderRoundedQuadShader(class_4587 matrixStack, Color color, double x, double y, double width, double height, double topLeft, double topRight, double bottomRight, double bottomLeft, double smoothness) {
/* 241 */     if (ShaderManager.isInitialized()) {
/* 242 */       ShaderManager.renderRoundedQuad((float)x, (float)y, (float)width, (float)height, color
/* 243 */           .getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F, (float)topLeft, (float)topRight, (float)bottomRight, (float)bottomLeft);
/*     */     } else {
/*     */       
/* 246 */       renderRoundedQuad(matrixStack, color, x, y, x + width, y + height, topLeft, topRight, bottomRight, bottomLeft, smoothness);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderRoundedQuadShader(class_4587 matrixStack, Color color, double x, double y, double width, double height, double radius, double smoothness) {
/* 252 */     renderRoundedQuadShader(matrixStack, color, x, y, width, height, radius, radius, radius, radius, smoothness);
/*     */   }
/*     */   
/*     */   public static void renderRoundedOutlineInternal(Matrix4f matrix4f, float n, float n2, float n3, float n4, double n5, double n6, double n7, double n8, double n9, double n10, double n11, double n12, double n13, double n14) {
/* 256 */     class_287 begin = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1576);
/* 257 */     double[][] array = new double[4][];
/* 258 */     (new double[3])[0] = n7 - n12; (new double[3])[1] = n8 - n12; (new double[3])[2] = n12; array[0] = new double[3];
/* 259 */     (new double[3])[0] = n7 - n10; (new double[3])[1] = n6 + n10; (new double[3])[2] = n10; array[1] = new double[3];
/* 260 */     (new double[3])[0] = n5 + n9; (new double[3])[1] = n6 + n9; (new double[3])[2] = n9; array[2] = new double[3];
/* 261 */     (new double[3])[0] = n5 + n11; (new double[3])[1] = n8 - n11; (new double[3])[2] = n11; array[3] = new double[3];
/* 262 */     for (int i = 0; i < 4; i++) {
/* 263 */       double[] array2 = array[i];
/* 264 */       double n15 = array2[2]; double angdeg;
/* 265 */       for (angdeg = i * 90.0D; angdeg < 90.0D + i * 90.0D; angdeg += 90.0D / n14) {
/* 266 */         double radians = Math.toRadians(angdeg);
/* 267 */         double sin = Math.sin((float)radians);
/* 268 */         double n16 = sin * n15;
/* 269 */         double cos = Math.cos((float)radians);
/* 270 */         double n17 = cos * n15;
/* 271 */         begin.method_22918(matrix4f, (float)array2[0] + (float)n16, (float)array2[1] + (float)n17, 0.0F).method_22915(n, n2, n3, n4);
/* 272 */         begin.method_22918(matrix4f, (float)(array2[0] + (float)n16 + sin * n13), (float)(array2[1] + (float)n17 + cos * n13), 0.0F).method_22915(n, n2, n3, n4);
/*     */       } 
/* 274 */       double radians2 = Math.toRadians(90.0D + i * 90.0D);
/* 275 */       double sin2 = Math.sin((float)radians2);
/* 276 */       double n18 = sin2 * n15;
/* 277 */       double cos2 = Math.cos((float)radians2);
/* 278 */       double n19 = cos2 * n15;
/* 279 */       begin.method_22918(matrix4f, (float)array2[0] + (float)n18, (float)array2[1] + (float)n19, 0.0F).method_22915(n, n2, n3, n4);
/* 280 */       begin.method_22918(matrix4f, (float)(array2[0] + (float)n18 + sin2 * n13), (float)(array2[1] + (float)n19 + cos2 * n13), 0.0F).method_22915(n, n2, n3, n4);
/*     */     } 
/* 282 */     double[] array3 = array[0];
/* 283 */     double n20 = array3[2];
/* 284 */     begin.method_22918(matrix4f, (float)array3[0], (float)array3[1] + (float)n20, 0.0F).method_22915(n, n2, n3, n4);
/* 285 */     begin.method_22918(matrix4f, (float)array3[0], (float)(array3[1] + (float)n20 + n13), 0.0F).method_22915(n, n2, n3, n4);
/* 286 */     class_286.method_43433(begin.method_60800());
/*     */   }
/*     */   public static void setScissorRegion(int x, int y, int width, int height) {
/*     */     int adjustedY;
/* 290 */     class_310 instance = class_310.method_1551();
/* 291 */     class_437 currentScreen = instance.field_1755;
/*     */     
/* 293 */     if (instance.field_1755 == null) {
/* 294 */       adjustedY = 0;
/*     */     } else {
/* 296 */       adjustedY = currentScreen.field_22790 - height;
/*     */     } 
/* 298 */     double scaleFactor = class_310.method_1551().method_22683().method_4495();
/* 299 */     GL11.glScissor((int)(x * scaleFactor), (int)(adjustedY * scaleFactor), (int)((width - x) * scaleFactor), (int)((height - y) * scaleFactor));
/* 300 */     GL11.glEnable(3089);
/*     */   }
/*     */   
/*     */   public static void renderCircle(class_4587 matrixStack, Color color, double centerX, double centerY, double radius, int segments) {
/* 304 */     int clampedSegments = class_3532.method_15340(segments, 4, 360);
/* 305 */     int rgb = color.getRGB();
/* 306 */     Matrix4f positionMatrix = matrixStack.method_23760().method_23761();
/* 307 */     setup();
/* 308 */     RenderSystem.setShader(class_757::method_34540);
/* 309 */     class_287 begin = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1576); int i;
/* 310 */     for (i = 0; i < 360; i += Math.min(360 / clampedSegments, 360 - i)) {
/* 311 */       double radians = Math.toRadians(i);
/* 312 */       begin.method_22918(positionMatrix, (float)(centerX + Math.sin(radians) * radius), (float)(centerY + Math.cos(radians) * radius), 0.0F).method_22915((rgb >> 16 & 0xFF) / 255.0F, (rgb >> 8 & 0xFF) / 255.0F, (rgb & 0xFF) / 255.0F, (rgb >> 24 & 0xFF) / 255.0F);
/*     */     } 
/* 314 */     class_286.method_43433(begin.method_60800());
/* 315 */     cleanup();
/*     */   }
/*     */   
/*     */   public static void renderShaderRect(class_4587 matrixStack, Color color, Color color2, Color color3, Color color4, float n, float n2, float n3, float n4, float n5, float n6) {
/* 319 */     RenderSystem.enableBlend();
/* 320 */     RenderSystem.defaultBlendFunc();
/* 321 */     class_287 begin = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 322 */     begin.method_22918(matrixStack.method_23760().method_23761(), n - 10.0F, n2 - 10.0F, 0.0F);
/* 323 */     begin.method_22918(matrixStack.method_23760().method_23761(), n - 10.0F, n2 + n4 + 20.0F, 0.0F);
/* 324 */     begin.method_22918(matrixStack.method_23760().method_23761(), n + n3 + 20.0F, n2 + n4 + 20.0F, 0.0F);
/* 325 */     begin.method_22918(matrixStack.method_23760().method_23761(), n + n3 + 20.0F, n2 - 10.0F, 0.0F);
/* 326 */     class_286.method_43433(begin.method_60800());
/* 327 */     RenderSystem.disableBlend();
/*     */   }
/*     */   
/*     */   public static void renderRoundedOutline(class_332 drawContext, Color color, double n, double n2, double n3, double n4, double n5, double n6, double n7, double n8, double n9, double n10) {
/* 331 */     int rgb = color.getRGB();
/* 332 */     Matrix4f positionMatrix = drawContext.method_51448().method_23760().method_23761();
/* 333 */     setup();
/* 334 */     RenderSystem.setShader(class_757::method_34540);
/* 335 */     renderRoundedOutlineInternal(positionMatrix, (rgb >> 16 & 0xFF) / 255.0F, (rgb >> 8 & 0xFF) / 255.0F, (rgb & 0xFF) / 255.0F, (rgb >> 24 & 0xFF) / 255.0F, n, n2, n3, n4, n5, n6, n7, n8, n9, n10);
/* 336 */     cleanup();
/*     */   }
/*     */   
/*     */   public static class_4587 matrixFrom(double n, double n2, double n3) {
/* 340 */     class_4587 matrixStack = new class_4587();
/* 341 */     class_4184 camera = (class_310.method_1551()).field_1773.method_19418();
/* 342 */     matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
/* 343 */     matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
/* 344 */     matrixStack.method_22904(n - (camera.method_19326()).field_1352, n2 - (camera.method_19326()).field_1351, n3 - (camera.method_19326()).field_1350);
/* 345 */     return matrixStack;
/*     */   }
/*     */   
/*     */   public static void renderQuad(class_4587 matrixStack, float n, float n2, float n3, float n4, int n5) {
/* 349 */     float n6 = (n5 >> 24 & 0xFF) / 255.0F;
/* 350 */     float n7 = (n5 >> 16 & 0xFF) / 255.0F;
/* 351 */     float n8 = (n5 >> 8 & 0xFF) / 255.0F;
/* 352 */     float n9 = (n5 & 0xFF) / 255.0F;
/* 353 */     matrixStack.method_22903();
/* 354 */     matrixStack.method_22905(0.5F, 0.5F, 0.5F);
/* 355 */     matrixStack.method_22904(n, n2, 0.0D);
/* 356 */     class_289 instance = class_289.method_1348();
/* 357 */     RenderSystem.enableBlend();
/* 358 */     RenderSystem.defaultBlendFunc();
/* 359 */     class_287 begin = instance.method_60827(class_293.class_5596.field_27382, class_290.field_1576);
/* 360 */     begin.method_22912(0.0F, 0.0F, 0.0F).method_22915(n7, n8, n9, n6);
/* 361 */     begin.method_22912(0.0F, n4, 0.0F).method_22915(n7, n8, n9, n6);
/* 362 */     begin.method_22912(n3, n4, 0.0F).method_22915(n7, n8, n9, n6);
/* 363 */     begin.method_22912(n3, 0.0F, 0.0F).method_22915(n7, n8, n9, n6);
/* 364 */     class_286.method_43433(begin.method_60800());
/* 365 */     RenderSystem.disableBlend();
/* 366 */     matrixStack.method_22909();
/*     */   }
/*     */   
/*     */   public static void renderRoundedQuadInternal(Matrix4f matrix4f, float n, float n2, float n3, float n4, double n5, double n6, double n7, double n8, double n9, double n10, double n11, double n12, double n13) {
/* 370 */     class_287 begin = class_289.method_1348().method_60827(class_293.class_5596.field_27381, class_290.field_1576);
/* 371 */     double[][] array = new double[4][];
/* 372 */     (new double[3])[0] = n7 - n12; (new double[3])[1] = n8 - n12; (new double[3])[2] = n12; array[0] = new double[3];
/* 373 */     (new double[3])[0] = n7 - n10; (new double[3])[1] = n6 + n10; (new double[3])[2] = n10; array[1] = new double[3];
/* 374 */     (new double[3])[0] = n5 + n9; (new double[3])[1] = n6 + n9; (new double[3])[2] = n9; array[2] = new double[3];
/* 375 */     (new double[3])[0] = n5 + n11; (new double[3])[1] = n8 - n11; (new double[3])[2] = n11; array[3] = new double[3];
/* 376 */     for (int i = 0; i < 4; i++) {
/* 377 */       double[] array2 = array[i];
/* 378 */       double n14 = array2[2]; double angdeg;
/* 379 */       for (angdeg = i * 90.0D; angdeg < 90.0D + i * 90.0D; angdeg += 90.0D / n13) {
/* 380 */         double radians = Math.toRadians(angdeg);
/* 381 */         begin.method_22918(matrix4f, (float)array2[0] + (float)(Math.sin((float)radians) * n14), (float)array2[1] + (float)(Math.cos((float)radians) * n14), 0.0F).method_22915(n, n2, n3, n4);
/*     */       } 
/* 383 */       double radians2 = Math.toRadians(90.0D + i * 90.0D);
/* 384 */       begin.method_22918(matrix4f, (float)array2[0] + (float)(Math.sin((float)radians2) * n14), (float)array2[1] + (float)(Math.cos((float)radians2) * n14), 0.0F).method_22915(n, n2, n3, n4);
/*     */     } 
/* 386 */     class_286.method_43433(begin.method_60800());
/*     */   }
/*     */   
/*     */   public static void renderFilledBox(class_4587 matrixStack, float n, float n2, float n3, float n4, float n5, float n6, Color color) {
/* 390 */     RenderSystem.enableBlend();
/* 391 */     RenderSystem.disableDepthTest();
/* 392 */     RenderSystem.setShaderColor(color.getRed() / 255.0F, color.getGreen() / 255.0F, color.getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 393 */     RenderSystem.setShader(class_757::method_34539);
/* 394 */     class_287 begin = class_289.method_1348().method_60827(class_293.class_5596.field_27380, class_290.field_1592);
/* 395 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n2, n3);
/* 396 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n2, n3);
/* 397 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n2, n3);
/* 398 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n2, n6);
/* 399 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n5, n3);
/* 400 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n5, n6);
/* 401 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n5, n6);
/* 402 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n2, n6);
/* 403 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n5, n6);
/* 404 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n2, n6);
/* 405 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n2, n6);
/* 406 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n2, n3);
/* 407 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n5, n6);
/* 408 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n5, n3);
/* 409 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n5, n3);
/* 410 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n2, n3);
/* 411 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n5, n3);
/* 412 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n2, n3);
/* 413 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n2, n3);
/* 414 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n2, n3);
/* 415 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n2, n6);
/* 416 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n2, n6);
/* 417 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n2, n6);
/* 418 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n5, n3);
/* 419 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n5, n3);
/* 420 */     begin.method_22918(matrixStack.method_23760().method_23761(), n, n5, n6);
/* 421 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n5, n3);
/* 422 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n5, n6);
/* 423 */     begin.method_22918(matrixStack.method_23760().method_23761(), n4, n5, n6);
/* 424 */     class_286.method_43433(begin.method_60800());
/* 425 */     RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 426 */     RenderSystem.enableDepthTest();
/* 427 */     RenderSystem.disableBlend();
/*     */   }
/*     */ 
/*     */   
/*     */   public static void renderLine(class_4587 matrixStack, Color color, class_243 vec3d, class_243 vec3d2) {
/* 432 */     matrixStack.method_22903();
/* 433 */     Matrix4f positionMatrix = matrixStack.method_23760().method_23761();
/*     */ 
/*     */     
/* 436 */     if (DonutBBC.enableMSAA.getValue()) {
/* 437 */       GL11.glEnable(32925);
/* 438 */       GL11.glEnable(2848);
/* 439 */       GL11.glHint(3154, 4354);
/*     */     } 
/*     */ 
/*     */     
/* 443 */     RenderSystem.disableDepthTest();
/* 444 */     RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
/* 445 */     RenderSystem.defaultBlendFunc();
/* 446 */     RenderSystem.enableBlend();
/*     */     
/* 448 */     genericAABBRender(class_293.class_5596.field_29344, class_290.field_1576, class_757::method_34540, positionMatrix, vec3d, vec3d2.method_1020(vec3d), color, (bufferBuilder, n, n3, n5, n7, n9, n11, n13, n15, n17, n19, matrix4f) -> {
/*     */           bufferBuilder.method_22918(matrix4f, n, n3, n5).method_22915(n13, n15, n17, n19);
/*     */           
/*     */           bufferBuilder.method_22918(matrix4f, n7, n9, n11).method_22915(n13, n15, n17, n19);
/*     */         });
/*     */     
/* 454 */     RenderSystem.enableDepthTest();
/* 455 */     RenderSystem.disableBlend();
/*     */     
/* 457 */     if (DonutBBC.enableMSAA.getValue()) {
/* 458 */       GL11.glDisable(2848);
/* 459 */       GL11.glDisable(32925);
/*     */     } 
/* 461 */     matrixStack.method_22909();
/*     */   }
/*     */   
/*     */   public static void drawItem(class_332 drawContext, class_1799 itemStack, int n, int n2, float n3, int n4) {
/* 465 */     if (itemStack.method_7960()) {
/*     */       return;
/*     */     }
/* 468 */     float n5 = n3 / 16.0F;
/* 469 */     class_4587 matrices = drawContext.method_51448();
/* 470 */     matrices.method_22903();
/* 471 */     matrices.method_46416(n, n2, n4);
/* 472 */     matrices.method_22905(n5, n5, 1.0F);
/* 473 */     drawContext.method_51427(itemStack, 0, 0);
/* 474 */     matrices.method_22909();
/*     */   }
/*     */   
/*     */   private static void genericAABBRender(class_293.class_5596 mode, class_293 format, Supplier<class_5944> shader, Matrix4f stack, class_243 start, class_243 dimensions, Color color, RenderAction action) {
/* 478 */     float red = color.getRed() / 255.0F;
/* 479 */     float green = color.getGreen() / 255.0F;
/* 480 */     float blue = color.getBlue() / 255.0F;
/* 481 */     float alpha = color.getAlpha() / 255.0F;
/* 482 */     class_243 end = start.method_1019(dimensions);
/* 483 */     float x1 = (float)start.field_1352;
/* 484 */     float y1 = (float)start.field_1351;
/* 485 */     float z1 = (float)start.field_1350;
/* 486 */     float x2 = (float)end.field_1352;
/* 487 */     float y2 = (float)end.field_1351;
/* 488 */     float z2 = (float)end.field_1350;
/* 489 */     useBuffer(mode, format, shader, bufferBuilder -> action.run(bufferBuilder, x1, y1, z1, x2, y2, z2, red, green, blue, alpha, stack));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void useBuffer(class_293.class_5596 vertexFormat$DrawMode, class_293 vertexFormat, Supplier<class_5944> shader, Consumer<class_287> consumer) {
/* 497 */     class_287 begin = class_289.method_1348().method_60827(vertexFormat$DrawMode, vertexFormat);
/* 498 */     consumer.accept(begin);
/* 499 */     setup();
/* 500 */     RenderSystem.setShader(shader);
/* 501 */     class_286.method_43433(begin.method_60800());
/* 502 */     cleanup();
/*     */   }
/*     */   
/*     */   public static int getRainbowColor(int offset, float alpha) {
/* 506 */     float hue = (float)((System.currentTimeMillis() + offset) % 3000L) / 3000.0F;
/* 507 */     return Color.HSBtoRGB(hue, 1.0F, 1.0F) | (int)(alpha * 255.0F) << 24;
/*     */   }
/*     */   
/*     */   public static boolean rendering3D = true;
/*     */   
/*     */   static interface RenderAction {
/*     */     void run(class_287 param1class_287, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, float param1Float8, float param1Float9, float param1Float10, Matrix4f param1Matrix4f);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\RenderUtils.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */