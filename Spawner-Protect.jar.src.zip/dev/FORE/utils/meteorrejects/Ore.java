/*     */ package dev.FORE.utils.meteorrejects;
/*     */ 
/*     */ import dev.FORE.mixin.CountPlacementModifierAccessor;
/*     */ import dev.FORE.mixin.HeightRangePlacementModifierAccessor;
/*     */ import dev.FORE.mixin.RarityFilterPlacementModifierAccessor;
/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Objects;
/*     */ import java.util.stream.Stream;
/*     */ import net.minecraft.class_1959;
/*     */ import net.minecraft.class_2975;
/*     */ import net.minecraft.class_3037;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3124;
/*     */ import net.minecraft.class_5317;
/*     */ import net.minecraft.class_5321;
/*     */ import net.minecraft.class_5363;
/*     */ import net.minecraft.class_5539;
/*     */ import net.minecraft.class_5868;
/*     */ import net.minecraft.class_6016;
/*     */ import net.minecraft.class_6017;
/*     */ import net.minecraft.class_6122;
/*     */ import net.minecraft.class_6796;
/*     */ import net.minecraft.class_6816;
/*     */ import net.minecraft.class_6880;
/*     */ import net.minecraft.class_6885;
/*     */ import net.minecraft.class_7145;
/*     */ import net.minecraft.class_7225;
/*     */ import net.minecraft.class_7510;
/*     */ import net.minecraft.class_7887;
/*     */ import net.minecraft.class_7924;
/*     */ 
/*     */ public class Ore
/*     */ {
/*     */   public int generationStep;
/*     */   public int featureIndex;
/*     */   public class_6017 countProvider;
/*     */   public class_6122 heightProvider;
/*     */   public class_5868 heightContext;
/*     */   
/*     */   public static Map<class_5321<class_1959>, List<Ore>> register() {
/*  45 */     class_7225.class_7874 wrapperLookup = class_7887.method_46817();
/*  46 */     class_7225.class_7226<class_6796> placedFeatureRegistry = wrapperLookup.method_46762(class_7924.field_41245);
/*  47 */     List<class_6880<class_1959>> netherBiomes = ((class_5363)((class_7145)wrapperLookup.method_46762(class_7924.field_41250).method_46747(class_5317.field_25050).comp_349()).method_45546().comp_1014().get(class_5363.field_25413)).comp_1013().method_12098().method_28443().stream().toList();
/*  48 */     List<class_7510.class_6827> indexedFeatures = class_7510.method_44210(netherBiomes, registryEntry -> ((class_1959)registryEntry.comp_349()).method_30970().method_30983(), true);
/*  49 */     Map<class_6796, Ore> ores = new HashMap<>();
/*  50 */     class_5321<class_6796> smallDebrisRegistry = class_6816.field_36048;
/*  51 */     register(ores, indexedFeatures, placedFeatureRegistry, smallDebrisRegistry, 7, new Color(209, 27, 245));
/*  52 */     class_5321<class_6796> largeDebrisRegistry = class_6816.field_36047;
/*  53 */     register(ores, indexedFeatures, placedFeatureRegistry, largeDebrisRegistry, 7, new Color(209, 27, 245));
/*  54 */     Map<class_5321<class_1959>, List<Ore>> biomeOreMap = new HashMap<>();
/*  55 */     netherBiomes.forEach(registryEntry -> {
/*     */           biomeOreMap.put(registryEntry.method_40230().get(), new ArrayList()); Stream<class_6796> stream = ((class_1959)registryEntry.comp_349()).method_30970().method_30983().stream().flatMap(class_6885::method_40239).map(class_6880::comp_349);
/*     */           Objects.requireNonNull(ores);
/*     */           Objects.requireNonNull(ores);
/*     */           stream.filter(ores::containsKey).forEach(());
/*     */         });
/*  61 */     return biomeOreMap;
/*     */   }
/*     */ 
/*     */   
/*     */   public float rarityChance;
/*     */   public float discardOnAirChance;
/*     */   public int oreSize;
/*     */   public Color oreColor;
/*     */   public boolean isScatteredOre;
/*     */   
/*     */   private static void register(Map<class_6796, Ore> oreMap, List<class_7510.class_6827> indexedFeatures, class_7225.class_7226<class_6796> oreRegistry, class_5321<class_6796> oreKey, int generationStep, Color oreColor) {
/*  72 */     class_6796 orePlacement = (class_6796)oreRegistry.method_46747(oreKey).comp_349();
/*     */     
/*  74 */     int featureIndex = ((class_7510.class_6827)indexedFeatures.get(generationStep)).comp_304().applyAsInt(orePlacement);
/*     */     
/*  76 */     Ore ore = new Ore(orePlacement, generationStep, featureIndex, oreColor);
/*     */     
/*  78 */     oreMap.put(orePlacement, ore);
/*     */   }
/*     */   
/*     */   private Ore(class_6796 placedFeature, int generationStep, int featureIndex, Color oreColor) {
/*  82 */     this.countProvider = (class_6017)class_6016.method_34998(1);
/*  83 */     this.rarityChance = 1.0F;
/*  84 */     this.generationStep = generationStep;
/*  85 */     this.featureIndex = featureIndex;
/*  86 */     this.oreColor = oreColor;
/*  87 */     this.heightContext = new class_5868(null, class_5539.method_39034((class_310.method_1551()).field_1687.method_31607(), (class_310.method_1551()).field_1687.method_8597().comp_653()));
/*  88 */     for (Object placementModifier : placedFeature.comp_335()) {
/*  89 */       if (placementModifier instanceof net.minecraft.class_6793) {
/*  90 */         this.countProvider = ((CountPlacementModifierAccessor)placementModifier).getCount(); continue;
/*  91 */       }  if (placementModifier instanceof net.minecraft.class_6795) {
/*  92 */         this.heightProvider = ((HeightRangePlacementModifierAccessor)placementModifier).getHeight(); continue;
/*     */       } 
/*  94 */       if (!(placementModifier instanceof net.minecraft.class_6799)) {
/*     */         continue;
/*     */       }
/*  97 */       this.rarityChance = ((RarityFilterPlacementModifierAccessor)placementModifier).getChance();
/*     */     } 
/*     */     
/* 100 */     class_3037 featureConfig = ((class_2975)placedFeature.comp_334().comp_349()).comp_333();
/* 101 */     if (featureConfig instanceof class_3124) {
/* 102 */       this.discardOnAirChance = ((class_3124)featureConfig).field_29064;
/* 103 */       this.oreSize = ((class_3124)featureConfig).field_13723;
/* 104 */       if (((class_2975)placedFeature.comp_334().comp_349()).comp_332() instanceof net.minecraft.class_5875) {
/* 105 */         this.isScatteredOre = true;
/*     */       }
/*     */       return;
/*     */     } 
/* 109 */     throw new IllegalStateException("config for " + String.valueOf(placedFeature) + "is not OreFeatureConfig.class");
/*     */   }
/*     */   
/*     */   private static String getAncientDebrisDetectionKey() {
/* 113 */     return "ANCIENT_DEBRIS_DETECTION_KEY";
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\meteorrejects\Ore.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */