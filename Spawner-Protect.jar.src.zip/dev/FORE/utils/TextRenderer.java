/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.font.Fonts;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ public final class TextRenderer
/*    */ {
/*    */   public static void drawString(CharSequence text, class_332 drawContext, int x, int y, int color) {
/* 11 */     if (text == null || text.length() == 0) {
/*    */       return;
/*    */     }
/*    */     
/* 15 */     if (shouldUseCustomFont()) {
/* 16 */       Fonts.FONT.drawString(drawContext.method_51448(), text, x, y, color);
/*    */     } else {
/* 18 */       drawLargeString(text, drawContext, x, y, color);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static int getWidth(CharSequence text) {
/* 24 */     if (text == null || text.length() == 0) {
/* 25 */       return 0;
/*    */     }
/*    */     
/* 28 */     if (shouldUseCustomFont()) {
/* 29 */       return Fonts.FONT.getStringWidth(text);
/*    */     }
/* 31 */     return DonutBBC.mc.field_1772.method_1727(text.toString()) * 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public static void drawCenteredString(CharSequence text, class_332 drawContext, int x, int y, int color) {
/* 36 */     if (text == null || text.length() == 0) {
/*    */       return;
/*    */     }
/*    */     
/* 40 */     if (shouldUseCustomFont()) {
/* 41 */       Fonts.FONT.drawString(drawContext.method_51448(), text, (x - Fonts.FONT.getStringWidth(text) / 2), y, color);
/*    */     } else {
/* 43 */       drawCenteredMinecraftText(text, drawContext, x, y, color);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public static void drawLargeString(CharSequence text, class_332 drawContext, int x, int y, int color) {
/* 49 */     if (text == null || text.length() == 0) {
/*    */       return;
/*    */     }
/*    */     
/* 53 */     class_4587 matrices = drawContext.method_51448();
/* 54 */     matrices.method_22903();
/* 55 */     matrices.method_22905(2.0F, 2.0F, 2.0F);
/* 56 */     drawContext.method_51433(DonutBBC.mc.field_1772, text.toString(), x / 2, y / 2, color, false);
/* 57 */     matrices.method_22909();
/*    */   }
/*    */ 
/*    */   
/*    */   public static void drawCenteredMinecraftText(CharSequence text, class_332 drawContext, int x, int y, int color) {
/* 62 */     if (text == null || text.length() == 0) {
/*    */       return;
/*    */     }
/*    */     
/* 66 */     class_4587 matrices = drawContext.method_51448();
/* 67 */     String textStr = text.toString();
/* 68 */     matrices.method_22903();
/* 69 */     matrices.method_22905(2.0F, 2.0F, 2.0F);
/* 70 */     drawContext.method_51433(DonutBBC.mc.field_1772, textStr, x / 2 - DonutBBC.mc.field_1772.method_1727(textStr) / 2, y / 2, color, false);
/* 71 */     matrices.method_22909();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static boolean shouldUseCustomFont() {
/*    */     try {
/* 80 */       return false;
/* 81 */     } catch (Exception e) {
/* 82 */       return false;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\TextRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */