package dev.FORE.utils;

import net.minecraft.class_287;
import org.joml.Matrix4f;

interface RenderAction {
  void run(class_287 paramclass_287, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10, Matrix4f paramMatrix4f);
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\RenderUtils$RenderAction.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */