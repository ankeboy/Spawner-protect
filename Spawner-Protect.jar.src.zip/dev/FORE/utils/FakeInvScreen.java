/*    */ package dev.FORE.utils;
/*    */ 
/*    */ import net.minecraft.class_1657;
/*    */ import net.minecraft.class_1713;
/*    */ import net.minecraft.class_1735;
/*    */ import net.minecraft.class_490;
/*    */ 
/*    */ 
/*    */ public class FakeInvScreen
/*    */   extends class_490
/*    */ {
/*    */   public FakeInvScreen(class_1657 playerEntity) {
/* 13 */     super(playerEntity);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void method_2383(class_1735 slot, int slotId, int button, class_1713 actionType) {}
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean method_25402(double mouseX, double mouseY, int button) {
/* 23 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\FakeInvScreen.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */