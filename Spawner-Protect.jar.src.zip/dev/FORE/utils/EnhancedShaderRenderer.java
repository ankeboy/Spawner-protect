/*     */ package dev.FORE.utils;
/*     */ 
/*     */ import java.awt.Color;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_4587;
/*     */ import org.lwjgl.opengl.GL11;
/*     */ import org.lwjgl.opengl.GL15;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ import org.lwjgl.opengl.GL30;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class EnhancedShaderRenderer
/*     */ {
/*     */   private static int shaderProgram;
/*     */   private static int VAO;
/*     */   private static int VBO;
/*     */   private static boolean initialized = false;
/*     */   private static int u_resolution;
/*     */   
/*     */   public static void init() {
/*  24 */     if (initialized)
/*     */       return; 
/*  26 */     String vertexShaderSource = "#version 330 core\nlayout (location = 0) in vec2 aPos;\nout vec2 fragCoord;\nuniform vec2 u_resolution;\nvoid main() {\n    fragCoord = (aPos + 1.0) * 0.5 * u_resolution;\n    gl_Position = vec4(aPos, 0.0, 1.0);\n}";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  36 */     String fragmentShaderSource = "#version 330 core\nuniform vec2 u_resolution;\nuniform vec2 u_position;\nuniform vec2 u_size;\nuniform vec4 u_color;\nuniform vec4 u_cornerRadii;\nuniform float u_borderWidth;\nuniform vec4 u_borderColor;\nin vec2 fragCoord;\nout vec4 fragColor;\n\nfloat roundedBoxSDF(vec2 centerPos, vec2 size, vec4 radius) {\n    radius.xy = (centerPos.x > 0.0) ? radius.xy : radius.zw;\n    radius.x = (centerPos.y > 0.0) ? radius.x : radius.y;\n    vec2 q = abs(centerPos) - size + radius.x;\n    return min(max(q.x, q.y), 0.0) + length(max(q, 0.0)) - radius.x;\n}\n\nvoid main() {\n    vec2 halfSize = u_size * 0.5;\n    vec2 centerPos = fragCoord - u_position - halfSize;\n    float distance = roundedBoxSDF(centerPos, halfSize, u_cornerRadii);\n    float alpha = 1.0 - smoothstep(-1.0, 1.0, distance);\n    \n    if (u_borderWidth > 0.0) {\n        float borderDistance = abs(distance) - u_borderWidth * 0.5;\n        float borderAlpha = 1.0 - smoothstep(-1.0, 1.0, borderDistance);\n        vec4 finalColor = mix(u_color, u_borderColor, step(0.0, distance - u_borderWidth * 0.5));\n        fragColor = vec4(finalColor.rgb, finalColor.a * alpha * borderAlpha);\n    } else {\n        fragColor = vec4(u_color.rgb, u_color.a * alpha);\n    }\n}";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/*  72 */       shaderProgram = createShaderProgram(vertexShaderSource, fragmentShaderSource);
/*     */ 
/*     */       
/*  75 */       u_resolution = GL20.glGetUniformLocation(shaderProgram, "u_resolution");
/*  76 */       u_position = GL20.glGetUniformLocation(shaderProgram, "u_position");
/*  77 */       u_size = GL20.glGetUniformLocation(shaderProgram, "u_size");
/*  78 */       u_color = GL20.glGetUniformLocation(shaderProgram, "u_color");
/*  79 */       u_cornerRadii = GL20.glGetUniformLocation(shaderProgram, "u_cornerRadii");
/*  80 */       u_borderWidth = GL20.glGetUniformLocation(shaderProgram, "u_borderWidth");
/*  81 */       u_borderColor = GL20.glGetUniformLocation(shaderProgram, "u_borderColor");
/*     */       
/*  83 */       setupQuad();
/*  84 */       initialized = true;
/*  85 */     } catch (Exception e) {
/*  86 */       System.err.println("Failed to initialize EnhancedShaderRenderer: " + e.getMessage());
/*  87 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   private static int u_position; private static int u_size; private static int u_color; private static int u_cornerRadii; private static int u_borderWidth; private static int u_borderColor;
/*     */   private static void setupQuad() {
/*  92 */     float[] vertices = { -1.0F, -1.0F, 1.0F, -1.0F, 1.0F, 1.0F, -1.0F, -1.0F, 1.0F, 1.0F, -1.0F, 1.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 101 */     VAO = GL30.glGenVertexArrays();
/* 102 */     VBO = GL15.glGenBuffers();
/*     */     
/* 104 */     GL30.glBindVertexArray(VAO);
/* 105 */     GL15.glBindBuffer(34962, VBO);
/* 106 */     GL15.glBufferData(34962, vertices, 35044);
/*     */     
/* 108 */     GL20.glVertexAttribPointer(0, 2, 5126, false, 8, 0L);
/* 109 */     GL20.glEnableVertexAttribArray(0);
/*     */     
/* 111 */     GL15.glBindBuffer(34962, 0);
/* 112 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderRoundedRect(class_4587 matrices, Color color, float x, float y, float width, float height, float radius) {
/* 118 */     renderRoundedRect(matrices, color, x, y, width, height, radius, radius, radius, radius, 0.0F, null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderRoundedRect(class_4587 matrices, Color color, float x, float y, float width, float height, float topLeft, float topRight, float bottomLeft, float bottomRight, float borderWidth, Color borderColor) {
/* 127 */     if (!initialized) {
/* 128 */       init();
/*     */     }
/*     */     
/* 131 */     if (shaderProgram == 0) {
/*     */       return;
/*     */     }
/*     */     try {
/* 135 */       GL11.glEnable(3042);
/* 136 */       GL11.glBlendFunc(770, 771);
/*     */       
/* 138 */       GL20.glUseProgram(shaderProgram);
/*     */ 
/*     */       
/* 141 */       float screenWidth = class_310.method_1551().method_22683().method_4489();
/* 142 */       float screenHeight = class_310.method_1551().method_22683().method_4506();
/*     */ 
/*     */       
/* 145 */       GL20.glUniform2f(u_resolution, screenWidth, screenHeight);
/* 146 */       GL20.glUniform2f(u_position, x, screenHeight - y - height);
/* 147 */       GL20.glUniform2f(u_size, width, height);
/* 148 */       GL20.glUniform4f(u_color, color.getRed() / 255.0F, color.getGreen() / 255.0F, color
/* 149 */           .getBlue() / 255.0F, color.getAlpha() / 255.0F);
/* 150 */       GL20.glUniform4f(u_cornerRadii, topLeft, topRight, bottomLeft, bottomRight);
/*     */       
/* 152 */       if (borderWidth > 0.0F && borderColor != null) {
/* 153 */         GL20.glUniform1f(u_borderWidth, borderWidth);
/* 154 */         GL20.glUniform4f(u_borderColor, borderColor.getRed() / 255.0F, borderColor
/* 155 */             .getGreen() / 255.0F, borderColor.getBlue() / 255.0F, borderColor
/* 156 */             .getAlpha() / 255.0F);
/*     */       } else {
/* 158 */         GL20.glUniform1f(u_borderWidth, 0.0F);
/* 159 */         GL20.glUniform4f(u_borderColor, 0.0F, 0.0F, 0.0F, 0.0F);
/*     */       } 
/*     */ 
/*     */       
/* 163 */       GL11.glScissor((int)x, (int)(screenHeight - y - height), (int)width, (int)height);
/* 164 */       GL11.glEnable(3089);
/*     */ 
/*     */       
/* 167 */       GL30.glBindVertexArray(VAO);
/* 168 */       GL11.glDrawArrays(4, 0, 6);
/* 169 */       GL30.glBindVertexArray(0);
/*     */       
/* 171 */       GL11.glDisable(3089);
/* 172 */       GL20.glUseProgram(0);
/* 173 */       GL11.glDisable(3042);
/* 174 */     } catch (Exception e) {
/* 175 */       System.err.println("Error rendering rounded rect: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static int createShaderProgram(String vertexSource, String fragmentSource) {
/* 180 */     int vertexShader = compileShader(35633, vertexSource);
/* 181 */     int fragmentShader = compileShader(35632, fragmentSource);
/*     */     
/* 183 */     int program = GL20.glCreateProgram();
/* 184 */     GL20.glAttachShader(program, vertexShader);
/* 185 */     GL20.glAttachShader(program, fragmentShader);
/* 186 */     GL20.glLinkProgram(program);
/*     */     
/* 188 */     if (GL20.glGetProgrami(program, 35714) == 0) {
/* 189 */       throw new RuntimeException("Failed to link shader program: " + 
/* 190 */           GL20.glGetProgramInfoLog(program));
/*     */     }
/*     */     
/* 193 */     GL20.glDeleteShader(vertexShader);
/* 194 */     GL20.glDeleteShader(fragmentShader);
/*     */     
/* 196 */     return program;
/*     */   }
/*     */   
/*     */   private static int compileShader(int type, String source) {
/* 200 */     int shader = GL20.glCreateShader(type);
/* 201 */     GL20.glShaderSource(shader, source);
/* 202 */     GL20.glCompileShader(shader);
/*     */     
/* 204 */     if (GL20.glGetShaderi(shader, 35713) == 0) {
/* 205 */       throw new RuntimeException("Failed to compile shader: " + 
/* 206 */           GL20.glGetShaderInfoLog(shader));
/*     */     }
/*     */     
/* 209 */     return shader;
/*     */   }
/*     */   
/*     */   public static void cleanup() {
/* 213 */     if (initialized) {
/* 214 */       GL20.glDeleteProgram(shaderProgram);
/* 215 */       GL30.glDeleteVertexArrays(VAO);
/* 216 */       GL15.glDeleteBuffers(VBO);
/* 217 */       initialized = false;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FOR\\utils\EnhancedShaderRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */