/*   */ package dev.FORE;
/*   */ 
/*   */ import net.fabricmc.api.ModInitializer;
/*   */ 
/*   */ public final class Main
/*   */   implements ModInitializer {
/*   */   public void onInitialize() {
/* 8 */     new DonutBBC();
/*   */   }
/*   */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\Main.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */