/*    */ package dev.FORE.mixin;
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.events.AttackEvent;
/*    */ import dev.FORE.event.events.BlockBreakingEvent;
/*    */ import dev.FORE.event.events.PostItemUseEvent;
/*    */ import dev.FORE.event.events.PreItemUseEvent;
/*    */ import dev.FORE.event.events.ResolutionChangedEvent;
/*    */ import dev.FORE.event.events.SetScreenEvent;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.manager.EventManager;
/*    */ import net.minecraft.class_1041;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_437;
/*    */ import net.minecraft.class_638;
/*    */ import org.jetbrains.annotations.Nullable;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({class_310.class})
/*    */ public class MinecraftClientMixin {
/*    */   @Shadow
/*    */   @Nullable
/*    */   public class_638 field_1687;
/*    */   
/*    */   @Inject(method = {"tick"}, at = {@At("HEAD")})
/*    */   private void onTick(CallbackInfo ci) {
/* 33 */     if (this.field_1687 != null)
/* 34 */       EventManager.b((Event)new TickEvent()); 
/*    */   } @Shadow
/*    */   @Final
/*    */   private class_1041 field_1704; @Shadow
/*    */   private int field_1752; @Inject(method = {"onResolutionChanged"}, at = {@At("HEAD")})
/*    */   private void onResolutionChanged(CallbackInfo ci) {
/* 40 */     EventManager.b((Event)new ResolutionChangedEvent(this.field_1704));
/*    */   }
/*    */   
/*    */   @Inject(method = {"doItemUse"}, at = {@At("RETURN")}, cancellable = true)
/*    */   private void onItemUseReturn(CallbackInfo ci) {
/* 45 */     PostItemUseEvent event = new PostItemUseEvent(this.field_1752);
/* 46 */     EventManager.b((Event)event);
/* 47 */     if (event.isCancelled()) ci.cancel(); 
/* 48 */     this.field_1752 = event.cooldown;
/*    */   }
/*    */   
/*    */   @Inject(method = {"doItemUse"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onItemUseHead(CallbackInfo ci) {
/* 53 */     PreItemUseEvent event = new PreItemUseEvent(this.field_1752);
/* 54 */     EventManager.b((Event)event);
/* 55 */     if (event.isCancelled()) ci.cancel(); 
/* 56 */     this.field_1752 = event.cooldown;
/*    */   }
/*    */   
/*    */   @Inject(method = {"doAttack"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onAttack(CallbackInfoReturnable<Boolean> cir) {
/* 61 */     AttackEvent event = new AttackEvent();
/* 62 */     EventManager.b((Event)event);
/* 63 */     if (event.isCancelled()) cir.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"handleBlockBreaking"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onBlockBreaking(boolean breaking, CallbackInfo ci) {
/* 68 */     BlockBreakingEvent event = new BlockBreakingEvent();
/* 69 */     EventManager.b((Event)event);
/* 70 */     if (event.isCancelled()) ci.cancel(); 
/*    */   }
/*    */   
/*    */   @Inject(method = {"setScreen"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onSetScreen(class_437 screen, CallbackInfo ci) {
/* 75 */     SetScreenEvent event = new SetScreenEvent(screen);
/* 76 */     EventManager.b((Event)event);
/* 77 */     if (event.isCancelled()) ci.cancel();
/*    */ 
/*    */     
/* 80 */     if (DonutBBC.INSTANCE == null || DonutBBC.INSTANCE.isAuthenticated || screen != null);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"stop"}, at = {@At("HEAD")})
/*    */   private void onClose(CallbackInfo callbackInfo) {
/* 88 */     DonutBBC.INSTANCE.getConfigManager().shutdown();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\MinecraftClientMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */