/*    */ package dev.FORE.mixin;
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.modules.donut.ShearsToElytra;
/*    */ import dev.FORE.module.modules.misc.AutoFirework;
/*    */ import java.lang.reflect.Field;
/*    */ import java.lang.reflect.Method;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_2561;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({class_1799.class})
/*    */ public class ItemStackMixin {
/*    */   @Inject(method = {"decrement"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onDecrement(int amount, CallbackInfo ci) {
/* 21 */     if (DonutBBC.INSTANCE != null && DonutBBC.INSTANCE.MODULE_MANAGER != null) {
/*    */ 
/*    */       
/* 24 */       Module autoFirework = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(AutoFirework.class);
/*    */ 
/*    */       
/* 27 */       if (autoFirework != null && autoFirework.isEnabled()) {
/* 28 */         class_1799 stack = (class_1799)this;
/* 29 */         if (stack.method_31574(class_1802.field_8639)) {
/*    */           
/*    */           try {
/* 32 */             Field antiConsumeField = autoFirework.getClass().getDeclaredField("antiConsume");
/* 33 */             antiConsumeField.setAccessible(true);
/* 34 */             Object antiConsumeSetting = antiConsumeField.get(autoFirework);
/* 35 */             Method getValueMethod = antiConsumeSetting.getClass().getMethod("getValue", new Class[0]);
/* 36 */             boolean antiConsumeEnabled = ((Boolean)getValueMethod.invoke(antiConsumeSetting, new Object[0])).booleanValue();
/*    */             
/* 38 */             if (antiConsumeEnabled)
/*    */             {
/* 40 */               ci.cancel();
/*    */             }
/* 42 */           } catch (Exception exception) {}
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"getName"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onGetName(CallbackInfoReturnable<class_2561> cir) {
/* 52 */     class_1799 stack = (class_1799)this;
/* 53 */     ShearsToElytra module = ShearsToElytra.getInstance();
/*    */     
/* 55 */     if (module != null && module.shouldChangeName() && module.shouldChangeItem(stack.method_7909()))
/* 56 */       cir.setReturnValue(class_2561.method_43471("item.minecraft.elytra")); 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\ItemStackMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */