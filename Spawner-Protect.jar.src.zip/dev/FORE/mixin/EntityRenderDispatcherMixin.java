/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.Module;
/*    */ import dev.FORE.module.modules.combat.Hitbox;
/*    */ import net.minecraft.class_238;
/*    */ import net.minecraft.class_898;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyVariable;
/*    */ 
/*    */ @Mixin({class_898.class})
/*    */ public class EntityRenderDispatcherMixin {
/*    */   @ModifyVariable(method = {"renderHitbox"}, ordinal = 0, at = @At(value = "STORE", ordinal = 0))
/*    */   private static class_238 onRenderHitboxEditBox(class_238 box) {
/* 16 */     Module hitboxes = DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(Hitbox.class);
/* 17 */     return hitboxes.isEnabled() ? box.method_1014(((Hitbox)hitboxes).getHitboxExpansion()) : box;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\EntityRenderDispatcherMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */