/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import com.mojang.authlib.GameProfile;
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.events.SendMovementPacketsEvent;
/*    */ import dev.FORE.event.events.TickEvent;
/*    */ import dev.FORE.manager.EventManager;
/*    */ import net.minecraft.class_310;
/*    */ import net.minecraft.class_638;
/*    */ import net.minecraft.class_742;
/*    */ import net.minecraft.class_746;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ 
/*    */ @Mixin({class_746.class})
/*    */ public class ClientPlayerEntityMixin
/*    */   extends class_742
/*    */ {
/*    */   public ClientPlayerEntityMixin(class_638 world, GameProfile profile) {
/* 25 */     super(world, profile);
/*    */   } @Shadow
/*    */   @Final
/*    */   protected class_310 field_3937; @Inject(method = {"sendMovementPackets"}, at = {@At("HEAD")})
/*    */   private void onSendMovementPackets(CallbackInfo ci) {
/* 30 */     EventManager.b((Event)new SendMovementPacketsEvent());
/*    */   }
/*    */   
/*    */   @Inject(method = {"tick"}, at = {@At("HEAD")})
/*    */   private void onPlayerTick(CallbackInfo ci) {
/* 35 */     EventManager.b((Event)new TickEvent());
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\ClientPlayerEntityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */