/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.imixin.IEntityVelocityUpdateS2CPacket;
/*    */ import net.minecraft.class_243;
/*    */ import net.minecraft.class_2743;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ 
/*    */ @Mixin({class_2743.class})
/*    */ public abstract class EntityVelocityUpdateS2CPacketMixin
/*    */   implements IEntityVelocityUpdateS2CPacket
/*    */ {
/*    */   @Shadow
/*    */   private int field_12563;
/*    */   @Shadow
/*    */   private int field_12562;
/*    */   @Shadow
/*    */   private int field_12561;
/*    */   
/*    */   public class_243 getVelocity() {
/* 22 */     return new class_243(this.field_12563 / 8000.0D, this.field_12562 / 8000.0D, this.field_12561 / 8000.0D);
/*    */   }
/*    */ 
/*    */   
/*    */   public void setVelocity(class_243 velocity) {
/* 27 */     this.field_12563 = (int)(velocity.field_1352 * 8000.0D);
/* 28 */     this.field_12562 = (int)(velocity.field_1351 * 8000.0D);
/* 29 */     this.field_12561 = (int)(velocity.field_1350 * 8000.0D);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\EntityVelocityUpdateS2CPacketMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */