/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import net.minecraft.class_442;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArg;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_442.class})
/*    */ public class MainMenuMixin
/*    */ {
/*    */   @ModifyArg(method = {"render"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/DrawContext;drawTextWithShadow(Lnet/minecraft/client/font/TextRenderer;Ljava/lang/String;III)I", ordinal = 0), index = 1)
/*    */   private String modifyVersionText(String original) {
/* 21 */     return "§c4E 1.0";
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\MainMenuMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */