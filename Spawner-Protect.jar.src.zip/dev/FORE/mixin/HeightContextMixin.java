/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import net.minecraft.class_2794;
/*    */ import net.minecraft.class_5868;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Redirect;
/*    */ 
/*    */ @Mixin({class_5868.class})
/*    */ public abstract class HeightContextMixin {
/*    */   @Redirect(method = {"<init>"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/gen/chunk/ChunkGenerator;getMinimumY()I"))
/*    */   private int onMinY(class_2794 cg) {
/* 13 */     return (cg == null) ? -9999999 : cg.method_33730();
/*    */   }
/*    */   
/*    */   @Redirect(method = {"<init>"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/world/gen/chunk/ChunkGenerator;getWorldHeight()I"))
/*    */   private int onHeight(class_2794 cg) {
/* 18 */     return (cg == null) ? 100000000 : cg.method_12104();
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\HeightContextMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */