/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.events.MouseButtonEvent;
/*    */ import dev.FORE.event.events.MouseScrolledEvent;
/*    */ import dev.FORE.manager.EventManager;
/*    */ import net.minecraft.class_312;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({class_312.class})
/*    */ public abstract class MouseMixin {
/*    */   @Inject(method = {"onMouseButton"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
/* 17 */     if (button == -1)
/* 18 */       return;  MouseButtonEvent event = new MouseButtonEvent(button, window, action);
/* 19 */     EventManager.b((Event)event);
/* 20 */     if (event.isCancelled()) ci.cancel();
/*    */   
/*    */   }
/*    */   
/*    */   @Inject(method = {"onMouseScroll"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onMouseScroll(long window, double horizontal, double vertical, CallbackInfo ci) {
/* 26 */     MouseScrolledEvent event = new MouseScrolledEvent(vertical);
/* 27 */     EventManager.b((Event)event);
/* 28 */     if (event.isCancelled()) ci.cancel(); 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\MouseMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */