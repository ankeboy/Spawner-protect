package dev.FORE.mixin;

import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_310.class})
public interface MinecraftClientAccessor {
  @Invoker
  void invokeDoItemUse();
  
  @Invoker
  boolean invokeDoAttack();
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\MinecraftClientAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */