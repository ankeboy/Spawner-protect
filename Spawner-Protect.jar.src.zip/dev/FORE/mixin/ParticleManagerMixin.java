/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.modules.render.NoRender;
/*    */ import net.minecraft.class_2394;
/*    */ import net.minecraft.class_702;
/*    */ import net.minecraft.class_703;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_702.class})
/*    */ public class ParticleManagerMixin
/*    */ {
/*    */   @Inject(method = {"addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onAddParticle(class_2394 parameters, double x, double y, double z, double velocityX, double velocityY, double velocityZ, CallbackInfoReturnable<class_703> cir) {
/* 20 */     if (DonutBBC.INSTANCE != null) {
/* 21 */       NoRender noRender = (NoRender)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(NoRender.class);
/* 22 */       if (noRender != null && noRender.isEnabled()) {
/*    */         
/* 24 */         if (!noRender.shouldRenderParticles()) {
/* 25 */           cir.setReturnValue(null);
/*    */           
/*    */           return;
/*    */         } 
/*    */         
/* 30 */         if (!noRender.shouldRenderExplosions() && isExplosionParticle(parameters)) {
/* 31 */           cir.setReturnValue(null);
/*    */           
/*    */           return;
/*    */         } 
/*    */         
/* 36 */         if (!noRender.shouldRenderSmoke() && isSmokeParticle(parameters)) {
/* 37 */           cir.setReturnValue(null);
/*    */           return;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private boolean isExplosionParticle(class_2394 effect) {
/* 45 */     String particleType = effect.method_10295().toString().toLowerCase();
/* 46 */     return (particleType.contains("explosion") || particleType
/* 47 */       .contains("explode") || particleType
/* 48 */       .contains("blast") || particleType
/* 49 */       .contains("boom"));
/*    */   }
/*    */   
/*    */   private boolean isSmokeParticle(class_2394 effect) {
/* 53 */     String particleType = effect.method_10295().toString().toLowerCase();
/* 54 */     return (particleType.contains("smoke") || particleType
/* 55 */       .contains("cloud") || particleType
/* 56 */       .contains("fume"));
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\ParticleManagerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */