package dev.FORE.mixin;

import net.minecraft.class_4604;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_4604.class})
public interface FrustumAccessor {
  @Accessor("x")
  double getX();
  
  @Accessor("x")
  void setX(double paramDouble);
  
  @Accessor("y")
  double getY();
  
  @Accessor("y")
  void setY(double paramDouble);
  
  @Accessor("z")
  double getZ();
  
  @Accessor("z")
  void setZ(double paramDouble);
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\FrustumAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */