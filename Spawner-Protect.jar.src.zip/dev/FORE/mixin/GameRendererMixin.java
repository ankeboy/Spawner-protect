/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.events.Render3DEvent;
/*    */ import dev.FORE.manager.EventManager;
/*    */ import dev.FORE.module.modules.misc.Freecam;
/*    */ import net.minecraft.class_4184;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_757;
/*    */ import net.minecraft.class_9779;
/*    */ import org.joml.Matrix4f;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({class_757.class})
/*    */ public abstract class GameRendererMixin
/*    */ {
/*    */   @Shadow
/*    */   @Final
/*    */   private class_4184 field_18765;
/*    */   
/*    */   @Inject(method = {"renderWorld"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/util/profiler/Profiler;swap(Ljava/lang/String;)V", ordinal = 1)})
/*    */   private void onWorldRender(class_9779 rtc, CallbackInfo ci) {
/* 30 */     EventManager.b((Event)new Render3DEvent(new class_4587(), method_22973(method_3196(this.field_18765, rtc.method_60637(true), true)), rtc.method_60637(true)));
/*    */   } @Shadow
/*    */   protected abstract double method_3196(class_4184 paramclass_4184, float paramFloat, boolean paramBoolean); @Shadow
/*    */   public abstract Matrix4f method_22973(double paramDouble); @Inject(method = {"shouldRenderBlockOutline"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onShouldRenderBlockOutline(CallbackInfoReturnable<Boolean> cir) {
/* 35 */     if (DonutBBC.INSTANCE.getModuleManager().getModuleByClass(Freecam.class).isEnabled())
/* 36 */       cir.setReturnValue(Boolean.valueOf(false)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\GameRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */