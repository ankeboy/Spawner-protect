/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
/*    */ import dev.FORE.module.modules.misc.TridentBoost;
/*    */ import net.minecraft.class_1309;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1835;
/*    */ import net.minecraft.class_1937;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArgs;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1835.class})
/*    */ public abstract class TridentItemMixin
/*    */ {
/*    */   @Inject(method = {"onStoppedUsing"}, at = {@At("HEAD")})
/*    */   private void onStoppedUsingHead(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks, CallbackInfo ci) {}
/*    */   
/*    */   @Inject(method = {"onStoppedUsing"}, at = {@At("TAIL")})
/*    */   private void onStoppedUsingTail(class_1799 stack, class_1937 world, class_1309 user, int remainingUseTicks, CallbackInfo ci) {}
/*    */   
/*    */   @ModifyArgs(method = {"onStoppedUsing"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;addVelocity(DDD)V"))
/*    */   private void modifyVelocity(Args args) {
/* 31 */     TridentBoost module = TridentBoost.getInstance();
/*    */ 
/*    */     
/* 34 */     args.set(0, Double.valueOf(((Double)args.get(0)).doubleValue() * module.getMultiplier()));
/* 35 */     args.set(1, Double.valueOf(((Double)args.get(1)).doubleValue() * module.getMultiplier()));
/* 36 */     args.set(2, Double.valueOf(((Double)args.get(2)).doubleValue() * module.getMultiplier()));
/*    */   }
/*    */   
/*    */   @ModifyExpressionValue(method = {"use"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;isTouchingWaterOrRain()Z")})
/*    */   private boolean isInWaterUse(boolean original) {
/* 41 */     TridentBoost module = TridentBoost.getInstance();
/*    */     
/* 43 */     return (module.allowOutOfWater() || original);
/*    */   }
/*    */   
/*    */   @ModifyExpressionValue(method = {"onStoppedUsing"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/entity/player/PlayerEntity;isTouchingWaterOrRain()Z")})
/*    */   private boolean isInWaterPostUse(boolean original) {
/* 48 */     TridentBoost module = TridentBoost.getInstance();
/*    */     
/* 50 */     return (module.allowOutOfWater() || original);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\TridentItemMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */