/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.modules.misc.Freecam;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_1922;
/*    */ import net.minecraft.class_4184;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArgs;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
/*    */ 
/*    */ @Mixin({class_4184.class})
/*    */ public class CameraMixin {
/*    */   @Unique
/*    */   private float tickDelta;
/*    */   
/*    */   @Inject(method = {"update"}, at = {@At("HEAD")})
/*    */   private void onUpdateHead(class_1922 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
/* 24 */     this.tickDelta = tickDelta;
/*    */   }
/*    */   
/*    */   @ModifyArgs(method = {"update"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V"))
/*    */   private void update(Args args) {
/* 29 */     Freecam freecam = (Freecam)DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(Freecam.class);
/* 30 */     if (freecam.isEnabled()) {
/* 31 */       args.set(0, Double.valueOf(freecam.getInterpolatedX(this.tickDelta)));
/* 32 */       args.set(1, Double.valueOf(freecam.getInterpolatedY(this.tickDelta)));
/* 33 */       args.set(2, Double.valueOf(freecam.getInterpolatedZ(this.tickDelta)));
/*    */     } 
/*    */   }
/*    */   
/*    */   @ModifyArgs(method = {"update"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"))
/*    */   private void onUpdateSetRotationArgs(Args args) {
/* 39 */     Freecam freecam = (Freecam)DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(Freecam.class);
/* 40 */     if (freecam.isEnabled()) {
/* 41 */       args.set(0, Float.valueOf((float)freecam.getInterpolatedYaw(this.tickDelta)));
/* 42 */       args.set(1, Float.valueOf((float)freecam.getInterpolatedPitch(this.tickDelta)));
/*    */     } 
/*    */   }
/*    */   @Inject(method = {"isThirdPerson"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onIsThirdPerson(CallbackInfoReturnable<Boolean> cir) {
/* 47 */     Freecam freecam = Freecam.getInstance();
/* 48 */     if (freecam != null && freecam.isEnabled())
/* 49 */       cir.setReturnValue(Boolean.valueOf(true)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\CameraMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */