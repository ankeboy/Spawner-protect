/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.modules.misc.NameProtect;
/*    */ import net.minecraft.class_5223;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArg;
/*    */ 
/*    */ @Mixin({class_5223.class})
/*    */ public class TextVisitFactoryMixin {
/*    */   @ModifyArg(at = @At(value = "INVOKE", target = "Lnet/minecraft/text/TextVisitFactory;visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z", ordinal = 0), method = {"visitFormatted(Ljava/lang/String;ILnet/minecraft/text/Style;Lnet/minecraft/text/CharacterVisitor;)Z"}, index = 0)
/*    */   private static String adjustText(String s) {
/* 14 */     NameProtect nameprotect = (NameProtect)DonutBBC.INSTANCE.MODULE_MANAGER.getModuleByClass(NameProtect.class);
/* 15 */     return (nameprotect.isEnabled() && s.contains(DonutBBC.mc.method_1548().method_1676())) ? s.replace(DonutBBC.mc.method_1548().method_1676(), nameprotect.getFakeName()) : s;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\TextVisitFactoryMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */