package dev.FORE.mixin;

import net.minecraft.class_6799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_6799.class})
public interface RarityFilterPlacementModifierAccessor {
  @Accessor
  int getChance();
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\RarityFilterPlacementModifierAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */