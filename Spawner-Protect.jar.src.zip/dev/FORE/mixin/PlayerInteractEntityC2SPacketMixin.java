/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.imixin.IPlayerInteractEntityC2SPacket;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_2824;
/*    */ import net.minecraft.class_310;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ 
/*    */ @Mixin({class_2824.class})
/*    */ public abstract class PlayerInteractEntityC2SPacketMixin
/*    */   implements IPlayerInteractEntityC2SPacket {
/*    */   @Shadow
/*    */   private int field_12870;
/*    */   
/*    */   public class_1297 getEntity() {
/* 17 */     if ((class_310.method_1551()).field_1687 != null) {
/* 18 */       return (class_310.method_1551()).field_1687.method_8469(this.field_12870);
/*    */     }
/* 20 */     return null;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\PlayerInteractEntityC2SPacketMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */