/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.events.SetBlockStateEvent;
/*    */ import dev.FORE.manager.EventManager;
/*    */ import net.minecraft.class_1937;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ import net.minecraft.class_2818;
/*    */ import org.spongepowered.asm.mixin.Final;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_2818.class})
/*    */ public class WorldChunkMixin
/*    */ {
/*    */   @Inject(method = {"setBlockState"}, at = {@At("TAIL")})
/*    */   private void onSetBlockState(class_2338 pos, class_2680 state, boolean moved, CallbackInfoReturnable<class_2680> cir) {
/* 24 */     if (this.field_12858.field_9236)
/* 25 */       EventManager.b((Event)new SetBlockStateEvent(pos, (class_2680)cir.getReturnValue(), state)); 
/*    */   }
/*    */   
/*    */   @Shadow
/*    */   @Final
/*    */   class_1937 field_12858;
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\WorldChunkMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */