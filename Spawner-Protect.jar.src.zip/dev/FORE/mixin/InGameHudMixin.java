/*    */ package dev.FORE.mixin;
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.events.Render2DEvent;
/*    */ import dev.FORE.manager.EventManager;
/*    */ import net.minecraft.class_329;
/*    */ import net.minecraft.class_332;
/*    */ import net.minecraft.class_9779;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({class_329.class})
/*    */ public class InGameHudMixin {
/*    */   @Inject(method = {"render"}, at = {@At("HEAD")})
/*    */   private void onRenderHud(class_332 ctx, class_9779 rtc, CallbackInfo ci) {
/* 17 */     EventManager.b((Event)new Render2DEvent(ctx, rtc.method_60637(true)));
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\InGameHudMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */