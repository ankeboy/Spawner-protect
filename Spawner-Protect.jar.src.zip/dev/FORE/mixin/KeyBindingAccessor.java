package dev.FORE.mixin;

import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_304.class})
public interface KeyBindingAccessor {
  @Accessor("boundKey")
  class_3675.class_306 getBoundKey();
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\KeyBindingAccessor.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */