/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.modules.render.NoRender;
/*    */ import net.minecraft.class_1541;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({class_1541.class})
/*    */ public class ExplosionMixin
/*    */ {
/*    */   @Inject(method = {"tick"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void onTick(CallbackInfo ci) {
/* 16 */     if (DonutBBC.INSTANCE != null) {
/* 17 */       NoRender noRender = (NoRender)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(NoRender.class);
/* 18 */       if (noRender != null && noRender.isEnabled() && !noRender.shouldRenderExplosions()) {
/*    */         
/* 20 */         class_1541 tnt = (class_1541)this;
/* 21 */         tnt.method_31472();
/* 22 */         ci.cancel();
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\ExplosionMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */