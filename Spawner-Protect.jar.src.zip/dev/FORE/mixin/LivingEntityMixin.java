/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.module.modules.render.SwingSpeed;
/*    */ import net.minecraft.class_1309;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_1309.class})
/*    */ public class LivingEntityMixin
/*    */ {
/*    */   @Inject(method = {"getHandSwingDuration"}, at = {@At("HEAD")}, cancellable = true)
/*    */   public void getHandSwingDurationInject(CallbackInfoReturnable<Integer> cir) {
/* 18 */     if (DonutBBC.INSTANCE != null && DonutBBC.mc != null) {
/* 19 */       SwingSpeed swingSpeedModule = (SwingSpeed)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(SwingSpeed.class);
/* 20 */       if (swingSpeedModule != null && swingSpeedModule.isEnabled())
/* 21 */         cir.setReturnValue(Integer.valueOf(swingSpeedModule.getSwingSpeed().getIntValue())); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\LivingEntityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */