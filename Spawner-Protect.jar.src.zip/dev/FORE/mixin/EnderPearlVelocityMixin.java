/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.module.modules.misc.PearlBoost;
/*    */ import net.minecraft.class_1684;
/*    */ import net.minecraft.class_243;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ 
/*    */ @Mixin({class_1684.class})
/*    */ public class EnderPearlVelocityMixin
/*    */ {
/*    */   @Inject(method = {"tick"}, at = {@At("HEAD")})
/*    */   private void boostVelocityOnFirstTick(CallbackInfo ci) {
/* 16 */     class_1684 pearl = (class_1684)this;
/*    */ 
/*    */     
/* 19 */     if (pearl.field_6012 <= 1) {
/* 20 */       System.out.println("BOOSTING PEARL!");
/*    */       
/* 22 */       PearlBoost module = PearlBoost.getInstance();
/* 23 */       System.out.println("Module enabled: " + module.isEnabled());
/*    */       
/* 25 */       double multiplier = module.getMultiplier();
/* 26 */       System.out.println("Multiplier: " + multiplier);
/*    */       
/* 28 */       class_243 oldVelocity = pearl.method_18798();
/* 29 */       System.out.println("Old velocity: " + String.valueOf(oldVelocity));
/*    */       
/* 31 */       pearl.method_18799(oldVelocity.method_1021(multiplier));
/*    */       
/* 33 */       class_243 newVelocity = pearl.method_18798();
/* 34 */       System.out.println("New velocity: " + String.valueOf(newVelocity));
/* 35 */       System.out.println("---");
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\EnderPearlVelocityMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */