/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.events.HeldItemRendererEvent;
/*    */ import dev.FORE.module.modules.render.Animations;
/*    */ import dev.FORE.module.modules.render.NoRender;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_4587;
/*    */ import net.minecraft.class_4597;
/*    */ import net.minecraft.class_742;
/*    */ import net.minecraft.class_759;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.ModifyArgs;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
/*    */ import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
/*    */ 
/*    */ 
/*    */ 
/*    */ @Mixin({class_759.class})
/*    */ public abstract class HeldItemRendererMixin
/*    */ {
/*    */   @Inject(method = {"renderFirstPersonItem"}, at = {@At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderItem(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/item/ItemStack;Lnet/minecraft/client/render/model/json/ModelTransformationMode;ZLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V")})
/*    */   private void onRenderItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
/* 28 */     if (DonutBBC.mc.field_1724 == null || DonutBBC.mc.field_1687 == null)
/* 29 */       return;  HeldItemRendererEvent event = new HeldItemRendererEvent(hand, item, equipProgress, matrices);
/* 30 */     DonutBBC.INSTANCE.getEventBus().a((Event)event);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   @Inject(method = {"renderFirstPersonItem"}, at = {@At("HEAD")})
/*    */   private void onRenderItemHook(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
/* 37 */     Animations animationsModule = (Animations)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(Animations.class);
/* 38 */     if (animationsModule != null && animationsModule.isEnabled() && animationsModule.shouldAnimate() && !item.method_7960() && !(item.method_7909() instanceof net.minecraft.class_1806)) {
/* 39 */       animationsModule.applyTransformations(matrices, swingProgress);
/*    */     }
/*    */   }
/*    */   
/*    */   @Inject(method = {"renderFirstPersonItem"}, at = {@At("RETURN")})
/*    */   private void onRenderItemPost(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo ci) {
/* 45 */     Animations animationsModule = (Animations)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(Animations.class);
/* 46 */     if (animationsModule != null && animationsModule.isEnabled() && animationsModule.shouldAnimate() && !item.method_7960() && !(item.method_7909() instanceof net.minecraft.class_1806)) {
/* 47 */       matrices.method_22909();
/*    */     }
/*    */   }
/*    */   
/*    */   @ModifyArgs(method = {"renderItem(FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider$Immediate;Lnet/minecraft/client/network/ClientPlayerEntity;I)V"}, at = @At(value = "INVOKE", target = "Lnet/minecraft/client/render/item/HeldItemRenderer;renderFirstPersonItem(Lnet/minecraft/client/network/AbstractClientPlayerEntity;FFLnet/minecraft/util/Hand;FLnet/minecraft/item/ItemStack;FLnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"))
/*    */   private void renderItem(Args args) {
/* 53 */     NoRender noRenderModule = (NoRender)DonutBBC.INSTANCE.getModuleManager().getModuleByClass(NoRender.class);
/* 54 */     if (noRenderModule != null && noRenderModule.isEnabled() && !noRenderModule.shouldRenderSwing())
/* 55 */       args.set(6, Float.valueOf(0.0F)); 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\HeldItemRendererMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */