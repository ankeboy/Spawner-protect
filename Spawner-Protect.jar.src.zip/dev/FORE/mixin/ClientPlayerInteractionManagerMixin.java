/*    */ package dev.FORE.mixin;
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.events.AttackBlockEvent;
/*    */ import dev.FORE.manager.EventManager;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ import net.minecraft.class_636;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({class_636.class})
/*    */ public class ClientPlayerInteractionManagerMixin {
/*    */   @Inject(method = {"attackBlock"}, at = {@At("HEAD")})
/*    */   private void onAttackBlock(class_2338 pos, class_2350 dir, CallbackInfoReturnable<Boolean> cir) {
/* 17 */     EventManager.b((Event)new AttackBlockEvent(pos, dir));
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\ClientPlayerInteractionManagerMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */