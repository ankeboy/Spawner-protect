/*    */ package dev.FORE.mixin;
/*    */ 
/*    */ import dev.FORE.module.modules.donut.ShearsToElytra;
/*    */ import net.minecraft.class_1087;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_1802;
/*    */ import net.minecraft.class_1935;
/*    */ import net.minecraft.class_763;
/*    */ import org.spongepowered.asm.mixin.Mixin;
/*    */ import org.spongepowered.asm.mixin.Shadow;
/*    */ import org.spongepowered.asm.mixin.Unique;
/*    */ import org.spongepowered.asm.mixin.injection.At;
/*    */ import org.spongepowered.asm.mixin.injection.Inject;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ @Mixin({class_763.class})
/*    */ public abstract class ItemModelsMixin
/*    */ {
/*    */   @Unique
/*    */   private boolean isGettingElytraModel = false;
/*    */   
/*    */   @Shadow
/*    */   public abstract class_1087 method_3308(class_1799 paramclass_1799);
/*    */   
/*    */   @Inject(method = {"getModel(Lnet/minecraft/item/ItemStack;)Lnet/minecraft/client/render/model/BakedModel;"}, at = {@At("HEAD")}, cancellable = true)
/*    */   private void onGetModel(class_1799 stack, CallbackInfoReturnable<class_1087> cir) {
/* 27 */     if (this.isGettingElytraModel) {
/*    */       return;
/*    */     }
/*    */     
/* 31 */     ShearsToElytra module = ShearsToElytra.getInstance();
/*    */     
/* 33 */     if (module != null && module.shouldChangeTexture() && module.shouldChangeItem(stack.method_7909())) {
/* 34 */       this.isGettingElytraModel = true;
/*    */       try {
/* 36 */         class_1799 elytraStack = new class_1799((class_1935)class_1802.field_8833);
/* 37 */         class_1087 elytraModel = method_3308(elytraStack);
/* 38 */         cir.setReturnValue(elytraModel);
/*    */       } finally {
/* 40 */         this.isGettingElytraModel = false;
/*    */       } 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\mixin\ItemModelsMixin.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */