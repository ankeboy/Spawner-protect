/*     */ package dev.FORE;
/*     */ import com.google.gson.JsonObject;
/*     */ import com.google.gson.JsonParser;
/*     */ import com.jagrosh.discordipc.IPCClient;
/*     */ import com.jagrosh.discordipc.IPCListener;
/*     */ import com.jagrosh.discordipc.entities.RichPresence;
/*     */ import com.jagrosh.discordipc.exceptions.NoDiscordClientException;
/*     */ import dev.FORE.gui.ClickGUI;
/*     */ import dev.FORE.manager.ConfigManager;
/*     */ import dev.FORE.manager.EventManager;
/*     */ import dev.FORE.manager.LicenseManager;
/*     */ import dev.FORE.module.ModuleManager;
/*     */ import java.io.BufferedReader;
/*     */ import java.io.File;
/*     */ import java.io.InputStream;
/*     */ import java.io.InputStreamReader;
/*     */ import java.io.OutputStream;
/*     */ import java.net.HttpURLConnection;
/*     */ import java.net.URL;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.nio.file.Files;
/*     */ import java.nio.file.Paths;
/*     */ import java.security.MessageDigest;
/*     */ import java.time.OffsetDateTime;
/*     */ import java.util.Timer;
/*     */ import java.util.TimerTask;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ public final class DonutBBC {
/*     */   public ConfigManager configManager;
/*     */   public ModuleManager MODULE_MANAGER;
/*     */   public EventManager EVENT_BUS;
/*     */   public LicenseManager licenseManager;
/*     */   public static class_310 mc;
/*     */   public String version;
/*     */   public static DonutBBC INSTANCE;
/*     */   public boolean shouldPreventClose;
/*     */   public boolean isAuthenticated;
/*     */   public ClickGUI GUI;
/*     */   public class_437 screen;
/*     */   public long modified;
/*     */   public File jar;
/*     */   private static final String AUTH_URL = "http://151.145.40.147:2997/validate";
/*  44 */   private static String username = "Unknown";
/*     */   
/*     */   private static boolean shouldoverride = false;
/*     */   
/*     */   private static Timer heartbeatTimer;
/*     */   
/*     */   private static final int XOR_KEY = 66;
/*     */   private static final String LICENSE_FILE_PATH = "/dev/FORE/auth/license.txt";
/*     */   private static final String INVALID_LICENSE = "INVALID";
/*     */   private static final String DELIMITER = " ";
/*     */   private static final String EXPECTED_CLASS_NAME = "dev.FORE.DonutBBC";
/*  55 */   private static String cachedLicense = null;
/*     */   
/*     */   private static final long DISCORD_APP_ID = 1434966252668977172L;
/*     */   
/*     */   private IPCClient client;
/*     */   
/*     */   private OffsetDateTime startTimestamp;
/*     */ 
/*     */   
/*     */   static {
/*     */     try {
/*  66 */       if (!verifyIntegrity()) {
/*  67 */         System.err.println("[DonutBBC] Integrity check failed");
/*  68 */         System.exit(-1);
/*     */       } 
/*     */ 
/*     */       
/*  72 */       detectEnvironment();
/*     */     }
/*  74 */     catch (Exception e) {
/*  75 */       System.err.println("[DonutBBC] Integrity check exception: " + e.getMessage());
/*  76 */       System.exit(-1);
/*     */     } 
/*     */   }
/*     */   
/*     */   public DonutBBC() {
/*     */     try {
/*  82 */       INSTANCE = this;
/*  83 */       this.version = " b1.0";
/*  84 */       this.screen = null;
/*  85 */       this.shouldPreventClose = false;
/*  86 */       this.isAuthenticated = false;
/*     */ 
/*     */       
/*  89 */       mc = class_310.method_1551();
/*     */ 
/*     */       
/*  92 */       this.jar = new File(DonutBBC.class.getProtectionDomain().getCodeSource().getLocation().toURI());
/*  93 */       this.modified = this.jar.lastModified();
/*     */ 
/*     */       
/*  96 */       if (!hasLicense()) {
/*  97 */         System.err.println("[DonutBBC] No valid license found");
/*  98 */         this.EVENT_BUS = new EventManager();
/*  99 */         this.MODULE_MANAGER = new ModuleManager();
/* 100 */         this.GUI = new ClickGUI();
/* 101 */         this.configManager = new ConfigManager();
/* 102 */         this.configManager.loadProfile();
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */ 
/*     */       
/* 109 */       this.isAuthenticated = authenticate();
/* 110 */       if (!this.isAuthenticated) {
/* 111 */         System.err.println("[DonutBBC] Authentication failed");
/* 112 */         this.EVENT_BUS = new EventManager();
/* 113 */         this.MODULE_MANAGER = new ModuleManager();
/* 114 */         this.GUI = new ClickGUI();
/* 115 */         this.configManager = new ConfigManager();
/* 116 */         this.configManager.loadProfile();
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/* 121 */       System.out.println("[DonutBBC] Authenticated as: " + getUsername());
/*     */ 
/*     */       
/* 124 */       this.EVENT_BUS = new EventManager();
/* 125 */       this.MODULE_MANAGER = new ModuleManager();
/* 126 */       this.GUI = new ClickGUI();
/* 127 */       this.configManager = new ConfigManager();
/* 128 */       this.configManager.loadProfile();
/*     */ 
/*     */       
/* 131 */       initializeDiscordRPC();
/*     */ 
/*     */       
/* 134 */       Runtime.getRuntime().addShutdownHook(new Thread(() -> {
/*     */               shutdown();
/*     */               
/*     */               shutdownDiscordRPC();
/*     */             }));
/* 139 */     } catch (Throwable t) {
/* 140 */       t.printStackTrace(System.err);
/* 141 */       System.exit(-1);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void detectEnvironment() {
/* 149 */     System.out.println("[DonutBBC] ========== Environment Detection ==========");
/*     */     
/* 151 */     int suspiciousFlags = 0;
/* 152 */     StringBuilder detectionLog = new StringBuilder();
/*     */ 
/*     */     
/* 155 */     suspiciousFlags += checkVMIndicators(detectionLog);
/*     */ 
/*     */     
/* 158 */     suspiciousFlags += checkSandboxIndicators(detectionLog);
/*     */ 
/*     */     
/* 161 */     suspiciousFlags += checkSystemProperties(detectionLog);
/*     */ 
/*     */     
/* 164 */     suspiciousFlags += checkHardwareCharacteristics(detectionLog);
/*     */ 
/*     */     
/* 167 */     suspiciousFlags += checkDebuggerPresence(detectionLog);
/*     */ 
/*     */     
/* 170 */     System.out.println(detectionLog.toString());
/*     */ 
/*     */     
/* 173 */     if (suspiciousFlags != 0 && 
/* 174 */       suspiciousFlags > 2)
/*     */     {
/* 176 */       CrashClient();
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 181 */     System.out.println("[DonutBBC] ===============================================");
/*     */   }
/*     */   
/*     */   private static int checkVMIndicators(StringBuilder log) {
/* 185 */     int flags = 0;
/*     */ 
/*     */     
/* 188 */     String[] vmProps = { "java.vendor", "java.vm.name", "java.vm.vendor" };
/*     */ 
/*     */ 
/*     */     
/* 192 */     for (String prop : vmProps) {
/* 193 */       String value = System.getProperty(prop, "").toLowerCase();
/* 194 */       if (value.contains("vmware") || value.contains("virtualbox") || value
/* 195 */         .contains("qemu") || value.contains("kvm") || value
/* 196 */         .contains("xen") || value.contains("hyper-v")) {
/* 197 */         flags++;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 202 */     String osName = System.getProperty("os.name", "").toLowerCase();
/* 203 */     if (osName.contains("linux")) {
/*     */       
/*     */       try {
/* 206 */         if (Files.exists(Paths.get("/sys/class/dmi/id/product_name", new String[0]), new java.nio.file.LinkOption[0])) {
/* 207 */           String productName = (new String(Files.readAllBytes(Paths.get("/sys/class/dmi/id/product_name", new String[0])))).toLowerCase();
/* 208 */           if (productName.contains("vmware") || productName.contains("virtualbox") || productName
/* 209 */             .contains("qemu") || productName.contains("kvm")) {
/* 210 */             flags++;
/*     */           }
/*     */         } 
/* 213 */       } catch (Exception exception) {}
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     try {
/* 220 */       Process p = Runtime.getRuntime().exec(osName.contains("windows") ? "getmac" : "ifconfig");
/* 221 */       BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()));
/*     */       String line;
/* 223 */       while ((line = reader.readLine()) != null) {
/* 224 */         String lowerLine = line.toLowerCase();
/* 225 */         if (lowerLine.contains("00:05:69") || lowerLine
/* 226 */           .contains("00:0c:29") || lowerLine
/* 227 */           .contains("00:1c:14") || lowerLine
/* 228 */           .contains("00:50:56") || lowerLine
/* 229 */           .contains("08:00:27")) {
/* 230 */           flags++;
/*     */           break;
/*     */         } 
/*     */       } 
/* 234 */       reader.close();
/* 235 */     } catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */     
/* 239 */     if (flags == 0);
/*     */ 
/*     */     
/* 242 */     return flags;
/*     */   }
/*     */   
/*     */   private static int checkSandboxIndicators(StringBuilder log) {
/* 246 */     int flags = 0;
/*     */ 
/*     */ 
/*     */     
/* 250 */     if (System.getProperty("os.name", "").toLowerCase().contains("windows")) {
/* 251 */       String[] sandboxFiles = { "C:\\analysis\\", "C:\\sandbox\\", "C:\\sample\\", "C:\\cwsandbox\\", "C:\\insidetm\\" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 259 */       for (String path : sandboxFiles) {
/* 260 */         if ((new File(path)).exists())
/*     */         {
/* 262 */           flags++;
/*     */         }
/*     */       } 
/*     */ 
/*     */       
/* 267 */       if ((new File("C:\\cuckoo")).exists() || (new File("C:\\agent\\agent.py")).exists()) {
/* 268 */         flags++;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 273 */     int processors = Runtime.getRuntime().availableProcessors();
/* 274 */     if (processors < 2) {
/* 275 */       flags++;
/*     */     }
/*     */ 
/*     */     
/* 279 */     long totalMemory = Runtime.getRuntime().maxMemory() / 1048576L;
/* 280 */     if (totalMemory < 2048L) {
/* 281 */       flags++;
/*     */     }
/*     */     
/* 284 */     if (flags == 0);
/*     */ 
/*     */     
/* 287 */     return flags;
/*     */   }
/*     */   
/*     */   private static int checkSystemProperties(StringBuilder log) {
/* 291 */     int flags = 0;
/*     */ 
/*     */     
/* 294 */     String userHome = System.getProperty("user.home", "").toLowerCase();
/* 295 */     if (userHome.contains("sandbox") || userHome.contains("sample") || userHome.contains("virus")) {
/* 296 */       flags++;
/*     */     }
/*     */ 
/*     */     
/* 300 */     String tmpDir = System.getProperty("java.io.tmpdir", "").toLowerCase();
/* 301 */     if (tmpDir.contains("sandbox") || tmpDir.contains("sample")) {
/* 302 */       flags++;
/*     */     }
/*     */     
/* 305 */     if (flags == 0);
/*     */ 
/*     */     
/* 308 */     return flags;
/*     */   }
/*     */   
/*     */   private static int checkHardwareCharacteristics(StringBuilder log) {
/* 312 */     int flags = 0;
/*     */ 
/*     */     
/* 315 */     int cpus = Runtime.getRuntime().availableProcessors();
/* 316 */     long totalMem = Runtime.getRuntime().maxMemory() / 1048576L;
/*     */ 
/*     */ 
/*     */     
/* 320 */     long uptimeMs = System.currentTimeMillis();
/* 321 */     long uptimeMins = uptimeMs / 60000L;
/*     */     
/* 323 */     if (uptimeMins < 10L) {
/* 324 */       flags++;
/*     */     }
/*     */     
/* 327 */     return flags;
/*     */   }
/*     */   
/*     */   private static int checkDebuggerPresence(StringBuilder log) {
/* 331 */     int flags = 0;
/*     */ 
/*     */ 
/*     */     
/* 335 */     boolean isDebug = ManagementFactory.getRuntimeMXBean().getInputArguments().toString().contains("-agentlib:jdwp");
/*     */     
/* 337 */     if (isDebug) {
/* 338 */       CrashClient();
/* 339 */       flags++;
/*     */     } 
/*     */ 
/*     */     
/* 343 */     if (System.getProperty("java.compiler") != null) {
/* 344 */       flags++;
/*     */     }
/*     */     
/* 347 */     if (flags == 0);
/*     */ 
/*     */     
/* 350 */     return flags;
/*     */   }
/*     */ 
/*     */   
/*     */   public static boolean isInWorld() {
/* 355 */     return (mc != null && mc.field_1724 != null && mc.field_1687 != null);
/*     */   }
/*     */   
/*     */   public static class_746 getPlayerSafe() {
/* 359 */     return isInWorld() ? mc.field_1724 : null;
/*     */   }
/*     */   
/*     */   public static class_638 getWorldSafe() {
/* 363 */     return isInWorld() ? mc.field_1687 : null;
/*     */   }
/*     */ 
/*     */   
/*     */   public ConfigManager getConfigManager() {
/* 368 */     return this.configManager;
/*     */   }
/*     */   
/*     */   public ModuleManager getModuleManager() {
/* 372 */     return this.MODULE_MANAGER;
/*     */   }
/*     */   
/*     */   public EventManager getEventBus() {
/* 376 */     return this.EVENT_BUS;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public LicenseManager getLicenseManager() {
/* 382 */     return this.licenseManager;
/*     */   }
/*     */   
/*     */   public boolean isAuthenticated() {
/* 386 */     return this.isAuthenticated;
/*     */   }
/*     */   
/*     */   public void resetModifiedDate() {
/* 390 */     this.jar.setLastModified(this.modified);
/*     */   }
/*     */ 
/*     */   
/*     */   public void showAuthenticationScreen() {
/* 395 */     if (mc != null);
/*     */   }
/*     */ 
/*     */   
/*     */   private void onAuthenticationSuccess() {
/* 400 */     this.isAuthenticated = true;
/* 401 */     System.out.println("[DonutBBC] Authentication successful - Client loaded");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean authenticate() {
/*     */     try {
/* 408 */       String licenseKey = getLicense();
/* 409 */       if (licenseKey.equals("INVALID")) {
/* 410 */         System.err.println("[DonutBBC] Invalid license key");
/* 411 */         return false;
/*     */       } 
/*     */       
/* 414 */       String hwid = getHWID();
/* 415 */       username = System.getProperty("user.name");
/*     */       
/* 417 */       JsonObject payload = new JsonObject();
/* 418 */       payload.addProperty("license_key", licenseKey);
/* 419 */       payload.addProperty("hwid", hwid);
/* 420 */       payload.addProperty("username", username);
/* 421 */       payload.addProperty("mode", "login");
/*     */       
/* 423 */       String response = sendRequest(payload);
/* 424 */       if (response == null) {
/* 425 */         System.err.println("[DonutBBC] Failed to get authentication response");
/* 426 */         return false;
/*     */       } 
/*     */       
/* 429 */       JsonObject json = JsonParser.parseString(response).getAsJsonObject();
/* 430 */       shouldoverride = json.get("valid").getAsBoolean();
/*     */       
/* 432 */       if (shouldoverride) {
/* 433 */         System.out.println("[DonutBBC] Authentication successful, starting heartbeat");
/* 434 */         startHeartbeat(licenseKey, hwid);
/*     */       } else {
/* 436 */         System.err.println("[DonutBBC] Authentication response invalid");
/*     */       } 
/*     */       
/* 439 */       return shouldoverride;
/*     */     }
/* 441 */     catch (Exception e) {
/* 442 */       System.err.println("[DonutBBC] Authentication exception: " + e.getMessage());
/* 443 */       e.printStackTrace();
/* 444 */       return false;
/*     */     } 
/*     */   }
/*     */   
/*     */   private static void startHeartbeat(final String licenseKey, final String hwid) {
/* 449 */     heartbeatTimer = new Timer(true);
/* 450 */     heartbeatTimer.scheduleAtFixedRate(new TimerTask()
/*     */         {
/*     */           public void run() {
/*     */             try {
/* 454 */               JsonObject payload = new JsonObject();
/* 455 */               payload.addProperty("license_key", licenseKey);
/* 456 */               payload.addProperty("hwid", hwid);
/* 457 */               payload.addProperty("username", DonutBBC.username);
/* 458 */               payload.addProperty("mode", "heartbeat");
/*     */               
/* 460 */               String response = DonutBBC.sendRequest(payload);
/* 461 */               if (response == null) {
/* 462 */                 System.err.println("[DonutBBC] Heartbeat failed - no response");
/* 463 */                 DonutBBC.shouldoverride = false;
/* 464 */                 System.exit(-1);
/*     */                 
/*     */                 return;
/*     */               } 
/* 468 */               JsonObject json = JsonParser.parseString(response).getAsJsonObject();
/* 469 */               if (!json.get("valid").getAsBoolean()) {
/* 470 */                 System.err.println("[DonutBBC] Heartbeat failed - invalid session");
/* 471 */                 DonutBBC.shouldoverride = false;
/* 472 */                 System.exit(-1);
/*     */               } 
/* 474 */             } catch (Exception e) {
/* 475 */               System.err.println("[DonutBBC] Heartbeat exception: " + e.getMessage());
/* 476 */               DonutBBC.shouldoverride = false;
/* 477 */               System.exit(-1);
/*     */             } 
/*     */           }
/*     */         }30000L, 30000L);
/*     */   }
/*     */   
/*     */   private static String sendRequest(JsonObject payload) {
/* 484 */     HttpURLConnection conn = null;
/*     */     try {
/* 486 */       URL url = new URL("http://151.145.40.147:2997/validate");
/* 487 */       conn = (HttpURLConnection)url.openConnection();
/* 488 */       conn.setRequestMethod("POST");
/* 489 */       conn.setRequestProperty("Content-Type", "application/json");
/* 490 */       conn.setDoOutput(true);
/* 491 */       conn.setConnectTimeout(5000);
/* 492 */       conn.setReadTimeout(5000);
/*     */       
/* 494 */       OutputStream os = conn.getOutputStream(); 
/* 495 */       try { byte[] input = payload.toString().getBytes(StandardCharsets.UTF_8);
/* 496 */         os.write(input, 0, input.length);
/* 497 */         if (os != null) os.close();  } catch (Throwable throwable) { if (os != null)
/*     */           try { os.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }   throw throwable; }
/* 499 */        int responseCode = conn.getResponseCode();
/* 500 */       if (responseCode != 200) {
/* 501 */         System.err.println("[DonutBBC] HTTP response code: " + responseCode);
/* 502 */         return null;
/*     */       } 
/*     */       
/* 505 */       StringBuilder response = new StringBuilder();
/*     */       
/* 507 */       BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8)); 
/*     */       try { String line;
/* 509 */         while ((line = br.readLine()) != null) {
/* 510 */           response.append(line.trim());
/*     */         }
/* 512 */         br.close(); } catch (Throwable throwable) { try { br.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/* 514 */        return response.toString();
/*     */     }
/* 516 */     catch (Exception e) {
/* 517 */       System.err.println("[DonutBBC] Request exception: " + e.getMessage());
/* 518 */       e.printStackTrace();
/* 519 */       return null;
/*     */     } finally {
/* 521 */       if (conn != null) {
/* 522 */         conn.disconnect();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private static String getHWID() {
/*     */     try {
/* 529 */       String os = System.getProperty("os.name");
/* 530 */       String arch = System.getProperty("os.arch");
/* 531 */       String version = System.getProperty("os.version");
/* 532 */       String user = System.getProperty("user.name");
/*     */       
/* 534 */       String rawHWID = os + os + arch + version;
/*     */       
/* 536 */       MessageDigest digest = MessageDigest.getInstance("SHA-256");
/* 537 */       byte[] hash = digest.digest(rawHWID.getBytes(StandardCharsets.UTF_8));
/*     */       
/* 539 */       StringBuilder hexString = new StringBuilder();
/* 540 */       for (byte b : hash) {
/* 541 */         String hex = Integer.toHexString(0xFF & b);
/* 542 */         if (hex.length() == 1) hexString.append('0'); 
/* 543 */         hexString.append(hex);
/*     */       } 
/*     */       
/* 546 */       return hexString.toString();
/*     */     }
/* 548 */     catch (Exception e) {
/* 549 */       System.err.println("[DonutBBC] HWID generation failed: " + e.getMessage());
/* 550 */       e.printStackTrace();
/* 551 */       return "UNKNOWN";
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void shutdown() {
/* 556 */     if (heartbeatTimer != null) {
/* 557 */       heartbeatTimer.cancel();
/* 558 */       heartbeatTimer = null;
/*     */     } 
/* 560 */     System.out.println("[DonutBBC] Shutdown complete");
/*     */   }
/*     */   
/*     */   public static boolean isshouldoverride() {
/* 564 */     return shouldoverride;
/*     */   }
/*     */   
/*     */   public static String getUsername() {
/* 568 */     return username;
/*     */   }
/*     */   
/*     */   public static String getLicense() {
/* 572 */     if (cachedLicense != null) {
/* 573 */       return cachedLicense;
/*     */     }
/*     */     
/* 576 */     InputStream inputStream = null;
/* 577 */     BufferedReader reader = null;
/*     */     try {
/* 579 */       inputStream = DonutBBC.class.getResourceAsStream("/dev/FORE/auth/license.txt");
/* 580 */       if (inputStream == null) {
/* 581 */         System.err.println("[DonutBBC] License file not found at: /dev/FORE/auth/license.txt");
/* 582 */         cachedLicense = "INVALID";
/* 583 */         return cachedLicense;
/*     */       } 
/*     */       
/* 586 */       reader = new BufferedReader(new InputStreamReader(inputStream));
/* 587 */       String encodedBytes = reader.readLine();
/*     */       
/* 589 */       if (encodedBytes == null || encodedBytes.isEmpty()) {
/* 590 */         System.err.println("[DonutBBC] License file is empty");
/* 591 */         cachedLicense = "INVALID";
/* 592 */         return cachedLicense;
/*     */       } 
/*     */       
/* 595 */       String[] parts = encodedBytes.split(" ");
/* 596 */       StringBuilder result = new StringBuilder();
/* 597 */       for (String part : parts) {
/* 598 */         int byteValue = Integer.parseInt(part.trim());
/* 599 */         result.append((char)(byteValue ^ 0x42));
/*     */       } 
/*     */       
/* 602 */       cachedLicense = result.toString();
/* 603 */       System.out.println("[DonutBBC] License loaded successfully");
/* 604 */       return cachedLicense;
/*     */     }
/* 606 */     catch (Exception e) {
/* 607 */       System.err.println("[DonutBBC] Failed to read license: " + e.getMessage());
/* 608 */       e.printStackTrace();
/* 609 */       cachedLicense = "INVALID";
/* 610 */       return cachedLicense;
/*     */     } finally {
/*     */       try {
/* 613 */         if (reader != null) reader.close(); 
/* 614 */         if (inputStream != null) inputStream.close(); 
/* 615 */       } catch (IOException iOException) {}
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean hasLicense() {
/* 622 */     String license = getLicense();
/*     */ 
/*     */     
/* 625 */     boolean valid = (license != null && !license.equals("INVALID") && license.length() == 16);
/*     */     
/* 627 */     if (!valid) {
/* 628 */       System.err.println("[DonutBBC] License validation failed. Length: " + 
/* 629 */           String.valueOf((license != null) ? Integer.valueOf(license.length()) : "null"));
/*     */     }
/*     */     
/* 632 */     return valid;
/*     */   }
/*     */   
/*     */   private static boolean verifyIntegrity() {
/*     */     try {
/* 637 */       String className = DonutBBC.class.getName();
/* 638 */       return className.equals("dev.FORE.DonutBBC");
/* 639 */     } catch (Exception e) {
/* 640 */       return false;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void initializeDiscordRPC() {
/* 651 */     (new Thread(() -> {
/*     */           try {
/*     */             System.out.println("[Discord RPC] Creating IPC client with ID: 1434966252668977172");
/*     */             this.client = new IPCClient(1434966252668977172L);
/*     */             this.startTimestamp = OffsetDateTime.now();
/*     */             System.out.println("[Discord RPC] Setting up listener...");
/*     */             this.client.setListener(new IPCListener()
/*     */                 {
/*     */                   public void onReady(IPCClient client) {
/* 660 */                     System.out.println("[Discord RPC] Connected successfully");
/*     */                     try {
/* 662 */                       DonutBBC.this.updateDiscordPresence("In Menu");
/* 663 */                     } catch (Exception e) {
/* 664 */                       System.err.println("[Discord RPC] Failed to set initial presence: " + e.getMessage());
/*     */                     } 
/*     */                   }
/*     */                   
/*     */                   public void onClose(IPCClient client, String message) {
/* 669 */                     System.out.println("[Discord RPC] Connection closed: " + message);
/*     */                   }
/*     */                 },  );
/*     */             
/*     */             System.out.println("[Discord RPC] Attempting to connect...");
/*     */             this.client.connect(new com.jagrosh.discordipc.entities.DiscordBuild[0]);
/*     */             System.out.println("[Discord RPC] Connected successfully!");
/* 676 */           } catch (NoDiscordClientException e) {
/*     */             System.err.println("[Discord RPC] Discord not running - Rich Presence disabled");
/*     */             this.client = null;
/* 679 */           } catch (Exception e) {
/*     */             System.err.println("[Discord RPC] Failed to initialize (this is non-fatal)");
/*     */             System.err.println("[Discord RPC] Error: " + e.getClass().getName() + ": " + e.getMessage());
/*     */             this.client = null;
/*     */           } 
/* 684 */         }"Discord-RPC-Init")).start();
/*     */   }
/*     */   
/*     */   public void updateDiscordPresence(String details) {
/* 688 */     if (this.client == null)
/*     */       return; 
/*     */     try {
/* 691 */       RichPresence.Builder builder = new RichPresence.Builder();
/* 692 */       builder.setDetails(details)
/* 693 */         .setStartTimestamp(this.startTimestamp)
/* 694 */         .setLargeImage("donut_logo", "DonutBBC" + this.version)
/* 695 */         .setSmallImage("minecraft", "Minecraft");
/*     */       
/* 697 */       this.client.sendRichPresence(builder.build());
/* 698 */     } catch (Exception e) {
/* 699 */       System.err.println("[Discord RPC] Failed to update presence: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public void updatePresenceFromGameState() {
/* 704 */     if (!this.isAuthenticated) {
/* 705 */       updateDiscordPresence("Authenticating...");
/*     */       
/*     */       return;
/*     */     } 
/* 709 */     if (isInWorld()) {
/* 710 */       if (mc.method_1542()) {
/* 711 */         updateDiscordPresence("Playing Singleplayer");
/* 712 */       } else if (mc.method_1558() != null) {
/* 713 */         String serverIP = (mc.method_1558()).field_3761;
/* 714 */         updateDiscordPresence("Playing on " + serverIP);
/*     */       } else {
/* 716 */         updateDiscordPresence("Playing Multiplayer");
/*     */       } 
/*     */     } else {
/* 719 */       updateDiscordPresence("In Menu");
/*     */     } 
/*     */   }
/*     */   
/*     */   public void shutdownDiscordRPC() {
/*     */     try {
/* 725 */       if (this.client != null) {
/* 726 */         this.client.close();
/* 727 */         this.client = null;
/*     */       } 
/* 729 */       System.out.println("[Discord RPC] Shutdown successfully");
/* 730 */     } catch (Exception e) {
/* 731 */       System.err.println("[Discord RPC] Error during shutdown: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static void CrashClient() {
/* 736 */     class_310 kla = null;
/* 737 */     String bla = String.valueOf(kla.method_47599());
/* 738 */     System.out.println(bla);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\DonutBBC.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */