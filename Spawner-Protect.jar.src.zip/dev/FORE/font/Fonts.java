/*   */ package dev.FORE.font;
/*   */ 
/*   */ public final class Fonts {
/* 4 */   public static GlyphPageFontRenderer FONT = GlyphPageFontRenderer.init("/font.ttf", 35, false, false, false);
/*   */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\font\Fonts.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */