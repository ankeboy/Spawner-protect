/*     */ package dev.FORE.font;
/*     */ import com.mojang.blaze3d.systems.RenderSystem;
/*     */ import java.awt.Color;
/*     */ import java.awt.Font;
/*     */ import java.awt.FontMetrics;
/*     */ import java.awt.Graphics2D;
/*     */ import java.awt.RenderingHints;
/*     */ import java.awt.font.FontRenderContext;
/*     */ import java.awt.geom.Rectangle2D;
/*     */ import java.awt.image.BufferedImage;
/*     */ import java.io.ByteArrayOutputStream;
/*     */ import java.nio.ByteBuffer;
/*     */ import java.util.HashMap;
/*     */ import javax.imageio.ImageIO;
/*     */ import net.minecraft.class_1011;
/*     */ import net.minecraft.class_1043;
/*     */ import net.minecraft.class_1044;
/*     */ import net.minecraft.class_286;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_4587;
/*     */ import net.minecraft.class_757;
/*     */ import org.lwjgl.BufferUtils;
/*     */ 
/*     */ public final class GlyphPage {
/*     */   private int imageSize;
/*     */   private int maxHeight;
/*     */   private final Font font;
/*     */   private final boolean antiAlias;
/*     */   
/*     */   public GlyphPage(Font font, boolean antiAlias, boolean fractionalMetrics) {
/*  33 */     this.maxHeight = -1;
/*  34 */     this.glyphs = new HashMap<>();
/*  35 */     this.font = font;
/*  36 */     this.antiAlias = antiAlias;
/*  37 */     this.fractionalMetrics = fractionalMetrics;
/*     */   }
/*     */   private final boolean fractionalMetrics; private final HashMap<Character, Glyph> glyphs; private BufferedImage img; private class_1044 texture;
/*     */   public void generate(char[] chars) {
/*  41 */     double width = -1.0D;
/*  42 */     double height = -1.0D;
/*     */     
/*  44 */     FontRenderContext frc = new FontRenderContext(new AffineTransform(), this.antiAlias, this.fractionalMetrics);
/*     */     
/*  46 */     for (char item : chars) {
/*  47 */       Rectangle2D bounds = this.font.getStringBounds(Character.toString(item), frc);
/*  48 */       if (width < bounds.getWidth()) width = bounds.getWidth(); 
/*  49 */       if (height < bounds.getHeight()) height = bounds.getHeight();
/*     */     
/*     */     } 
/*  52 */     double maxWidth = width + 2.0D;
/*  53 */     double maxHeight = height + 2.0D;
/*  54 */     this.imageSize = (int)Math.ceil(Math.max(Math.ceil(Math.sqrt(maxWidth * maxWidth * chars.length) / maxWidth), Math.ceil(Math.sqrt(maxHeight * maxHeight * chars.length) / maxHeight)) * Math.max(maxWidth, maxHeight)) + 1;
/*  55 */     this.img = new BufferedImage(this.imageSize, this.imageSize, 2);
/*  56 */     Graphics2D graphics = this.img.createGraphics();
/*  57 */     graphics.setFont(this.font);
/*  58 */     graphics.setColor(new Color(255, 255, 255, 0));
/*  59 */     graphics.fillRect(0, 0, this.imageSize, this.imageSize);
/*  60 */     graphics.setColor(Color.white);
/*  61 */     graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS, this.fractionalMetrics ? RenderingHints.VALUE_FRACTIONALMETRICS_ON : RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
/*  62 */     graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, this.antiAlias ? RenderingHints.VALUE_ANTIALIAS_ON : RenderingHints.VALUE_ANTIALIAS_OFF);
/*  63 */     graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, this.antiAlias ? RenderingHints.VALUE_TEXT_ANTIALIAS_ON : RenderingHints.VALUE_TEXT_ANTIALIAS_OFF);
/*     */     
/*  65 */     FontMetrics metrics = graphics.getFontMetrics();
/*     */     
/*  67 */     int currentHeight = 0;
/*  68 */     int posX = 0;
/*  69 */     int posY = 1;
/*     */     
/*  71 */     for (char c : chars) {
/*  72 */       Glyph glyph = new Glyph();
/*  73 */       Rectangle2D bounds = metrics.getStringBounds(Character.toString(c), graphics);
/*     */       
/*  75 */       glyph.width = (bounds.getBounds()).width + 8;
/*  76 */       glyph.height = (bounds.getBounds()).height;
/*     */       
/*  78 */       if (posX + glyph.width >= this.imageSize) {
/*  79 */         posX = 0;
/*  80 */         posY += currentHeight;
/*  81 */         currentHeight = 0;
/*     */       } 
/*     */       
/*  84 */       glyph.x = posX;
/*  85 */       glyph.y = posY;
/*     */       
/*  87 */       if (glyph.height > this.maxHeight) this.maxHeight = glyph.height; 
/*  88 */       if (glyph.height > currentHeight) currentHeight = glyph.height;
/*     */       
/*  90 */       graphics.drawString(Character.toString(c), posX + 2, posY + metrics.getAscent());
/*  91 */       posX += glyph.width;
/*  92 */       this.glyphs.put(Character.valueOf(c), glyph);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void setup() {
/*     */     try {
/*  98 */       ByteArrayOutputStream output = new ByteArrayOutputStream();
/*  99 */       ImageIO.write(this.img, "png", output);
/* 100 */       byte[] byteArray = output.toByteArray();
/* 101 */       ByteBuffer data = BufferUtils.createByteBuffer(byteArray.length).put(byteArray);
/* 102 */       data.flip();
/* 103 */       this.texture = (class_1044)new class_1043(class_1011.method_4324(data));
/* 104 */     } catch (Throwable _t) {
/* 105 */       _t.printStackTrace(System.err);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void bind() {
/* 110 */     if (this.texture != null) {
/* 111 */       RenderSystem.setShaderTexture(0, this.texture.method_4624());
/*     */     }
/*     */   }
/*     */   
/*     */   public void unbind() {
/* 116 */     RenderSystem.setShaderTexture(0, 0);
/*     */   }
/*     */   
/*     */   public float drawChar(class_4587 stack, char ch, float x, float y, float r, float b, float g, float alpha) {
/* 120 */     Glyph glyph = this.glyphs.get(Character.valueOf(ch));
/* 121 */     if (glyph == null) return 0.0F;
/*     */     
/* 123 */     if (this.texture == null) return 0.0F;
/*     */     
/* 125 */     float pageX = glyph.x / this.imageSize;
/* 126 */     float pageY = glyph.y / this.imageSize;
/*     */     
/* 128 */     float pageWidth = glyph.width / this.imageSize;
/* 129 */     float pageHeight = glyph.height / this.imageSize;
/*     */     
/* 131 */     float width = glyph.width;
/* 132 */     float height = glyph.height;
/*     */     
/* 134 */     RenderSystem.setShader(class_757::method_34543);
/*     */     
/* 136 */     bind();
/*     */     
/* 138 */     class_287 builder = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1575);
/*     */     
/* 140 */     builder.method_22918(stack.method_23760().method_23761(), x, y + height, 0.0F).method_22915(r, g, b, alpha).method_22913(pageX, pageY + pageHeight);
/* 141 */     builder.method_22918(stack.method_23760().method_23761(), x + width, y + height, 0.0F).method_22915(r, g, b, alpha).method_22913(pageX + pageWidth, pageY + pageHeight);
/* 142 */     builder.method_22918(stack.method_23760().method_23761(), x + width, y, 0.0F).method_22915(r, g, b, alpha).method_22913(pageX + pageWidth, pageY);
/* 143 */     builder.method_22918(stack.method_23760().method_23761(), x, y, 0.0F).method_22915(r, g, b, alpha).method_22913(pageX, pageY);
/*     */     
/* 145 */     class_286.method_43433(builder.method_60800());
/*     */     
/* 147 */     unbind();
/*     */     
/* 149 */     return width - 8.0F;
/*     */   }
/*     */   
/*     */   public float getWidth(char c) {
/* 153 */     Glyph glyph = this.glyphs.get(Character.valueOf(c));
/* 154 */     return (glyph != null) ? glyph.width : 0.0F;
/*     */   }
/*     */   
/*     */   public boolean isAntiAlias() {
/* 158 */     return this.antiAlias;
/*     */   }
/*     */   
/*     */   public boolean isFractionalMetrics() {
/* 162 */     return this.fractionalMetrics;
/*     */   }
/*     */   
/*     */   public int getMaxHeight() {
/* 166 */     return this.maxHeight;
/*     */   }
/*     */   
/*     */   public static final class Glyph {
/*     */     private int x;
/*     */     private int y;
/*     */     private int width;
/*     */     private int height;
/*     */     
/*     */     Glyph(int x, int y, int width, int height) {
/* 176 */       this.x = x;
/* 177 */       this.y = y;
/* 178 */       this.width = width;
/* 179 */       this.height = height;
/*     */     }
/*     */     
/*     */     Glyph() {}
/*     */     
/*     */     public int getX() {
/* 185 */       return this.x;
/*     */     }
/*     */     
/*     */     public int getY() {
/* 189 */       return this.y;
/*     */     }
/*     */     
/*     */     public int getWidth() {
/* 193 */       return this.width;
/*     */     }
/*     */     
/*     */     public int getHeight() {
/* 197 */       return this.height;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\font\GlyphPage.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */