/*     */ package dev.FORE.font;
/*     */ 
/*     */ import com.mojang.blaze3d.platform.GlStateManager;
/*     */ import dev.FORE.utils.EncryptedString;
/*     */ import java.awt.Font;
/*     */ import java.io.InputStream;
/*     */ import java.util.Objects;
/*     */ import java.util.Random;
/*     */ import net.minecraft.class_286;
/*     */ import net.minecraft.class_287;
/*     */ import net.minecraft.class_289;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_293;
/*     */ import net.minecraft.class_4587;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class GlyphPageFontRenderer
/*     */ {
/*     */   public Random random;
/*     */   private float posX;
/*     */   private float posY;
/*     */   private final int[] colorCode;
/*     */   private boolean isBold;
/*     */   private boolean isItalic;
/*     */   
/*     */   public GlyphPageFontRenderer(GlyphPage regular, GlyphPage bold, GlyphPage italic, GlyphPage boldItalic) {
/*  29 */     this.random = new Random();
/*  30 */     this.colorCode = new int[32];
/*  31 */     this.regular = regular;
/*  32 */     this.bold = bold;
/*  33 */     this.italic = italic;
/*  34 */     this.boldItalic = boldItalic;
/*     */     
/*  36 */     for (int n = 0; n < 32; n++) {
/*  37 */       int j = (n >> 3 & 0x1) * 85;
/*  38 */       int k = (n >> 2 & 0x1) * 170 + j;
/*  39 */       int l = (n >> 1 & 0x1) * 170 + j;
/*  40 */       int m = (n & 0x1) * 170 + j;
/*     */       
/*  42 */       if (n == 6) k += 85;
/*     */       
/*  44 */       if (n >= 16) {
/*  45 */         k /= 4;
/*  46 */         l /= 4;
/*  47 */         m /= 4;
/*     */       } 
/*     */       
/*  50 */       this.colorCode[n] = (k & 0xFF) << 16 | (l & 0xFF) << 8 | m & 0xFF;
/*     */     } 
/*     */   }
/*     */   private boolean isUnderline; private boolean isStrikethrough; private final GlyphPage regular; private final GlyphPage bold; private final GlyphPage italic; private final GlyphPage boldItalic;
/*     */   public static GlyphPageFontRenderer a(CharSequence font, int size, boolean bold, boolean italic, boolean boldItalic) {
/*  55 */     char[] chars = new char[256];
/*  56 */     for (int i = 0; i < 256; ) { chars[i] = (char)i; i++; }
/*  57 */      GlyphPage regularPage = new GlyphPage(new Font(font.toString(), 0, size), true, true);
/*  58 */     regularPage.generate(chars);
/*  59 */     regularPage.setup();
/*     */     
/*  61 */     GlyphPage boldPage = regularPage;
/*  62 */     GlyphPage italicPage = regularPage;
/*  63 */     GlyphPage boldItalicPage = regularPage;
/*     */     
/*  65 */     if (bold) {
/*  66 */       boldPage = new GlyphPage(new Font(font.toString(), 1, size), true, true);
/*  67 */       boldPage.generate(chars);
/*  68 */       boldPage.setup();
/*     */     } 
/*     */     
/*  71 */     if (italic) {
/*  72 */       italicPage = new GlyphPage(new Font(font.toString(), 2, size), true, true);
/*  73 */       italicPage.generate(chars);
/*  74 */       italicPage.setup();
/*     */     } 
/*     */     
/*  77 */     if (boldItalic) {
/*  78 */       boldItalicPage = new GlyphPage(new Font(font.toString(), 3, size), true, true);
/*  79 */       boldItalicPage.generate(chars);
/*  80 */       boldItalicPage.setup();
/*     */     } 
/*     */     
/*  83 */     return new GlyphPageFontRenderer(regularPage, boldPage, italicPage, boldItalicPage);
/*     */   }
/*     */   
/*     */   public static GlyphPageFontRenderer init(CharSequence id, int size, boolean bold, boolean italic, boolean boldItalic) {
/*     */     try {
/*  88 */       char[] chars = new char[256];
/*  89 */       for (int i = 0; i < chars.length; ) { chars[i] = (char)i; i++; }
/*     */       
/*  91 */       Font font = Font.createFont(0, Objects.<InputStream>requireNonNull(GlyphPageFontRenderer.class.getResourceAsStream(id.toString()))).deriveFont(0, size);
/*     */       
/*  93 */       GlyphPage regularPage = new GlyphPage(font, true, true);
/*  94 */       regularPage.generate(chars);
/*  95 */       regularPage.setup();
/*     */       
/*  97 */       GlyphPage boldPage = regularPage;
/*  98 */       GlyphPage italicPage = regularPage;
/*  99 */       GlyphPage boldItalicPage = regularPage;
/*     */       
/* 101 */       if (bold) {
/* 102 */         boldPage = new GlyphPage(Font.createFont(0, Objects.<InputStream>requireNonNull(GlyphPageFontRenderer.class.getResourceAsStream(id.toString()))).deriveFont(1, size), true, true);
/* 103 */         boldPage.generate(chars);
/* 104 */         boldPage.setup();
/*     */       } 
/*     */       
/* 107 */       if (italic) {
/* 108 */         italicPage = new GlyphPage(Font.createFont(0, Objects.<InputStream>requireNonNull(GlyphPageFontRenderer.class.getResourceAsStream(id.toString()))).deriveFont(2, size), true, true);
/* 109 */         italicPage.generate(chars);
/* 110 */         italicPage.setup();
/*     */       } 
/*     */       
/* 113 */       if (boldItalic) {
/* 114 */         boldItalicPage = new GlyphPage(Font.createFont(0, Objects.<InputStream>requireNonNull(GlyphPageFontRenderer.class.getResourceAsStream(id.toString()))).deriveFont(3, size), true, true);
/* 115 */         boldItalicPage.generate(chars);
/* 116 */         boldItalicPage.setup();
/*     */       } 
/*     */       
/* 119 */       return new GlyphPageFontRenderer(regularPage, boldPage, italicPage, boldItalicPage);
/* 120 */     } catch (Throwable _t) {
/* 121 */       _t.printStackTrace(System.err);
/* 122 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public int drawStringWithShadow(class_4587 matrices, CharSequence text, float x, float y, int color) {
/* 127 */     return drawString(matrices, text, x, y, color, true);
/*     */   }
/*     */   
/*     */   public int drawStringWithShadow(class_4587 matrices, CharSequence text, double x, double y, int color) {
/* 131 */     return drawString(matrices, text, (float)x, (float)y, color, true);
/*     */   }
/*     */   
/*     */   public int drawString(class_4587 matrices, CharSequence text, float x, float y, int color) {
/* 135 */     return drawString(matrices, text, x, y, color, false);
/*     */   }
/*     */   
/*     */   public int drawString(class_4587 matrices, CharSequence text, double x, double y, int color) {
/* 139 */     return drawString(matrices, text, (float)x, (float)y, color, false);
/*     */   }
/*     */   
/*     */   public int drawCenteredString(class_4587 matrices, CharSequence text, double x, double y, float scale, int color) {
/* 143 */     return drawString(matrices, text, (float)x - (getStringWidth(text) / 2), (float)y, scale, color, false);
/*     */   }
/*     */   
/*     */   public int drawCenteredString(class_4587 matrices, CharSequence text, double x, double y, int color) {
/* 147 */     return drawString(matrices, text, (float)x - (getStringWidth(text) / 2), (float)y, color, false);
/*     */   }
/*     */   
/*     */   public int drawCenteredStringWithShadow(class_4587 matrices, CharSequence text, double x, double y, int color) {
/* 151 */     return drawString(matrices, text, (float)x - (getStringWidth(text) / 2), (float)y, color, true);
/*     */   }
/*     */   
/*     */   public int drawString(class_4587 matrices, CharSequence text, float x, float y, float scale, int color, boolean shadow) {
/* 155 */     resetStyles();
/* 156 */     return shadow ? Math.max(renderString(matrices, text, x + 1.0F, y + 1.0F, scale, color, true), renderString(matrices, text, x, y, scale, color, false)) : renderString(matrices, text, x, y, scale, color, false);
/*     */   }
/*     */   
/*     */   public int drawString(class_4587 matrices, CharSequence text, float x, float y, int color, boolean shadow) {
/* 160 */     resetStyles();
/* 161 */     return shadow ? Math.max(renderString(matrices, text, x + 1.0F, y + 1.0F, color, true), renderString(matrices, text, x, y, color, false)) : renderString(matrices, text, x, y, color, false);
/*     */   }
/*     */   
/*     */   private int renderString(class_4587 matrices, CharSequence text, float x, float y, int color, boolean shadow) {
/* 165 */     if (text == null) return 0; 
/* 166 */     if ((color & 0xFC000000) == 0) color |= 0xFF000000; 
/* 167 */     if (shadow) color = (color & 0xFCFCFC) >> 2 | color & 0xFF000000; 
/* 168 */     this.posX = x * 2.0F;
/* 169 */     this.posY = y * 2.0F;
/* 170 */     a(matrices, text, shadow, color);
/* 171 */     return (int)(this.posX / 4.0F);
/*     */   }
/*     */   
/*     */   private int renderString(class_4587 matrices, CharSequence text, float x, float y, float scale, int color, boolean shadow) {
/* 175 */     if (text == null) return 0; 
/* 176 */     if ((color & 0xFC000000) == 0) color |= 0xFF000000; 
/* 177 */     if (shadow) color = (color & 0xFCFCFC) >> 2 | color & 0xFF000000; 
/* 178 */     this.posX = x * 2.0F;
/* 179 */     this.posY = y * 2.0F;
/* 180 */     renderStringAtPos(matrices, text, scale, shadow, color);
/* 181 */     return (int)(this.posX / 4.0F);
/*     */   }
/*     */   
/*     */   private void a(class_4587 matrices, CharSequence text, boolean shadow, int color) {
/* 185 */     GlyphPage page = getPage();
/*     */     
/* 187 */     float red = (color >> 16 & 0xFF) / 255.0F;
/* 188 */     float green = (color >> 8 & 0xFF) / 255.0F;
/* 189 */     float blue = (color & 0xFF) / 255.0F;
/*     */     
/* 191 */     matrices.method_22903();
/* 192 */     matrices.method_22905(0.5F, 0.5F, 0.5F);
/*     */     
/* 194 */     GlStateManager._enableBlend();
/* 195 */     GlStateManager._blendFunc(770, 771);
/*     */     
/* 197 */     page.bind();
/*     */     
/* 199 */     GlStateManager._texParameter(3553, 10240, 9729);
/*     */     
/* 201 */     for (int i = 0; i < text.length(); i++) {
/* 202 */       char ch = text.charAt(i);
/*     */       
/* 204 */       if (ch == '�' && i + 1 < text.length()) {
/* 205 */         int index = "0123456789abcdefklmnor".indexOf(Character.toLowerCase(text.charAt(i + 1)));
/*     */         
/* 207 */         if (index < 16) {
/* 208 */           this.isBold = false;
/* 209 */           this.isStrikethrough = false;
/* 210 */           this.isUnderline = false;
/* 211 */           this.isItalic = false;
/* 212 */           if (index < 0) index = 15; 
/* 213 */           if (shadow) index += 16; 
/* 214 */           int colorCode = this.colorCode[index];
/* 215 */           red = (colorCode >> 16 & 0xFF) / 255.0F;
/* 216 */           green = (colorCode >> 8 & 0xFF) / 255.0F;
/* 217 */           blue = (colorCode & 0xFF) / 255.0F;
/* 218 */         } else if (index != 16) {
/* 219 */           if (index == 17) { this.isBold = true; }
/* 220 */           else if (index == 18) { this.isStrikethrough = true; }
/* 221 */           else if (index == 19) { this.isUnderline = true; }
/* 222 */           else if (index == 20) { this.isItalic = true; }
/*     */           else
/* 224 */           { this.isBold = false;
/* 225 */             this.isStrikethrough = false;
/* 226 */             this.isUnderline = false;
/* 227 */             this.isItalic = false; }
/*     */         
/*     */         } 
/*     */         
/* 231 */         i++;
/*     */       } else {
/* 233 */         page = getPage();
/* 234 */         page.bind();
/* 235 */         doDraw(page.drawChar(matrices, ch, this.posX, this.posY, red, blue, green, (color >> 24 & 0xFF) / 255.0F), page);
/*     */       } 
/*     */     } 
/*     */     
/* 239 */     page.unbind();
/* 240 */     matrices.method_22909();
/*     */   }
/*     */   
/*     */   private void renderStringAtPos(class_4587 matrices, CharSequence text, float scale, boolean shadow, int color) {
/* 244 */     GlyphPage page = getPage();
/*     */     
/* 246 */     float red = (color >> 16 & 0xFF) / 255.0F;
/* 247 */     float green = (color >> 8 & 0xFF) / 255.0F;
/* 248 */     float blue = (color & 0xFF) / 255.0F;
/*     */     
/* 250 */     matrices.method_22903();
/* 251 */     matrices.method_22905(scale, scale, scale);
/*     */     
/* 253 */     GlStateManager._enableBlend();
/* 254 */     GlStateManager._blendFunc(770, 771);
/*     */     
/* 256 */     page.bind();
/*     */     
/* 258 */     GlStateManager._texParameter(3553, 10240, 9729);
/*     */     
/* 260 */     for (int i = 0; i < text.length(); i++) {
/* 261 */       char ch = text.charAt(i);
/*     */       
/* 263 */       if (ch == '�' && i + 1 < text.length()) {
/* 264 */         int index = "0123456789abcdefklmnor".indexOf(Character.toLowerCase(text.charAt(i + 1)));
/*     */         
/* 266 */         if (index < 16) {
/* 267 */           this.isBold = false;
/* 268 */           this.isStrikethrough = false;
/* 269 */           this.isUnderline = false;
/* 270 */           this.isItalic = false;
/* 271 */           if (index < 0) index = 15; 
/* 272 */           if (shadow) index += 16; 
/* 273 */           int colorCode = this.colorCode[index];
/* 274 */           red = (colorCode >> 16 & 0xFF) / 255.0F;
/* 275 */           green = (colorCode >> 8 & 0xFF) / 255.0F;
/* 276 */           blue = (colorCode & 0xFF) / 255.0F;
/* 277 */         } else if (index != 16) {
/* 278 */           if (index == 17) { this.isBold = true; }
/* 279 */           else if (index == 18) { this.isStrikethrough = true; }
/* 280 */           else if (index == 19) { this.isUnderline = true; }
/* 281 */           else if (index == 20) { this.isItalic = true; }
/*     */           else
/* 283 */           { this.isBold = false;
/* 284 */             this.isStrikethrough = false;
/* 285 */             this.isUnderline = false;
/* 286 */             this.isItalic = false; }
/*     */         
/*     */         } 
/*     */         
/* 290 */         i++;
/*     */       } else {
/* 292 */         page = getPage();
/* 293 */         page.bind();
/* 294 */         doDraw(page.drawChar(matrices, ch, this.posX, this.posY, red, blue, green, (color >> 24 & 0xFF) / 255.0F), page);
/*     */       } 
/*     */     } 
/* 297 */     page.unbind();
/* 298 */     matrices.method_22909();
/*     */   }
/*     */   
/*     */   private void doDraw(float f, GlyphPage page) {
/* 302 */     if (this.isStrikethrough) {
/* 303 */       class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/*     */       
/* 305 */       buffer.method_22912(this.posX, this.posY + (page.getMaxHeight() / 2), 0.0F);
/* 306 */       buffer.method_22912(this.posX + f, this.posY + (page.getMaxHeight() / 2), 0.0F);
/* 307 */       buffer.method_22912(this.posX + f, this.posY + (page.getMaxHeight() / 2) - 1.0F, 0.0F);
/* 308 */       buffer.method_22912(this.posX, this.posY + (page.getMaxHeight() / 2) - 1.0F, 0.0F);
/*     */       
/* 310 */       class_286.method_43433(buffer.method_60800());
/*     */     } 
/*     */     
/* 313 */     if (this.isUnderline) {
/* 314 */       class_287 buffer = class_289.method_1348().method_60827(class_293.class_5596.field_27382, class_290.field_1592);
/* 315 */       int l = this.isUnderline ? -1 : 0;
/*     */       
/* 317 */       buffer.method_22912(this.posX + l, this.posY + page.getMaxHeight(), 0.0F);
/* 318 */       buffer.method_22912(this.posX + f, this.posY + page.getMaxHeight(), 0.0F);
/* 319 */       buffer.method_22912(this.posX + f, this.posY + page.getMaxHeight() - 1.0F, 0.0F);
/* 320 */       buffer.method_22912(this.posX + l, this.posY + page.getMaxHeight() - 1.0F, 0.0F);
/*     */       
/* 322 */       class_286.method_43433(buffer.method_60800());
/*     */     } 
/*     */     
/* 325 */     this.posX += f;
/*     */   }
/*     */   
/*     */   private GlyphPage getPage() {
/* 329 */     if (this.isBold && this.isItalic) return this.boldItalic; 
/* 330 */     if (this.isBold) return this.bold; 
/* 331 */     if (this.isItalic) return this.italic; 
/* 332 */     return this.regular;
/*     */   }
/*     */   
/*     */   private void resetStyles() {
/* 336 */     this.isBold = false;
/* 337 */     this.isItalic = false;
/* 338 */     this.isUnderline = false;
/* 339 */     this.isStrikethrough = false;
/*     */   }
/*     */   
/*     */   public int getHeight() {
/* 343 */     return this.regular.getMaxHeight() / 2;
/*     */   }
/*     */   
/*     */   public int getStringWidth(CharSequence text) {
/* 347 */     if (text == null) return 0;
/*     */     
/* 349 */     int width = 0;
/* 350 */     boolean on = false;
/*     */     
/* 352 */     for (int i = 0; i < text.length(); i++) {
/* 353 */       char ch = text.charAt(i);
/*     */       
/* 355 */       if (ch == '�') { on = true; }
/* 356 */       else if (on && ch >= '0' && ch <= 'r')
/* 357 */       { int index = "0123456789abcdefklmnor".indexOf(ch);
/* 358 */         if (index < 16)
/* 359 */         { this.isBold = false;
/* 360 */           this.isItalic = false; }
/* 361 */         else if (index == 17) { this.isBold = true; }
/* 362 */         else if (index == 20) { this.isItalic = true; }
/* 363 */         else if (index == 21)
/* 364 */         { this.isBold = false;
/* 365 */           this.isItalic = false; }
/*     */ 
/*     */         
/* 368 */         i++;
/* 369 */         on = false; }
/*     */       else
/* 371 */       { if (on) i--; 
/* 372 */         width += (int)(getPage().getWidth(text.charAt(i)) - 8.0F); }
/*     */     
/*     */     } 
/*     */     
/* 376 */     return width / 2;
/*     */   }
/*     */   
/*     */   public CharSequence trimStringToWidth(CharSequence text, int width) {
/* 380 */     return trimStringToWidth(text, width, false);
/*     */   }
/*     */   
/*     */   public CharSequence trimStringToWidth(CharSequence text, int maxWidth, boolean reverse) {
/* 384 */     StringBuilder sb = new StringBuilder();
/* 385 */     boolean on = false;
/* 386 */     int j = reverse ? (text.length() - 1) : 0;
/* 387 */     int k = reverse ? -1 : 1;
/* 388 */     int width = 0;
/*     */     
/* 390 */     while (j >= 0 && j < text.length() && j < maxWidth) {
/* 391 */       char ch = text.charAt(j);
/* 392 */       if (ch == '�') { on = true; }
/* 393 */       else if (on && ch >= '0' && ch <= 'r')
/* 394 */       { int index = "0123456789abcdefklmnor".indexOf(ch);
/* 395 */         if (index < 16)
/* 396 */         { this.isBold = false;
/* 397 */           this.isItalic = false; }
/* 398 */         else if (index == 17) { this.isBold = true; }
/* 399 */         else if (index == 20) { this.isItalic = true; }
/* 400 */         else if (index == 21)
/* 401 */         { this.isBold = false;
/* 402 */           this.isItalic = false; }
/*     */         
/* 404 */         j++;
/* 405 */         on = false; }
/*     */       else
/* 407 */       { if (on) j--; 
/* 408 */         ch = text.charAt(j);
/* 409 */         width += (int)((getPage().getWidth(ch) - 8.0F) / 2.0F); }
/*     */ 
/*     */       
/* 412 */       if (width > maxWidth)
/*     */         break; 
/* 414 */       if (reverse) { sb.insert(0, ch); }
/* 415 */       else { sb.append(ch); }
/*     */       
/* 417 */       j += k;
/*     */     } 
/*     */     
/* 420 */     return (CharSequence)EncryptedString.of(sb.toString());
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\font\GlyphPageFontRenderer.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */