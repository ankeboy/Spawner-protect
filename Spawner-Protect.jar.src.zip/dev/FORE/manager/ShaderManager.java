/*     */ package dev.FORE.manager;
/*     */ 
/*     */ import java.io.IOException;
/*     */ import java.nio.FloatBuffer;
/*     */ import net.minecraft.class_290;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3300;
/*     */ import net.minecraft.class_5912;
/*     */ import net.minecraft.class_5944;
/*     */ import org.lwjgl.opengl.GL20;
/*     */ import org.lwjgl.opengl.GL30;
/*     */ import org.lwjgl.system.MemoryUtil;
/*     */ 
/*     */ public class ShaderManager {
/*     */   private static class_5944 roundedQuadShader;
/*     */   private static int vao;
/*     */   private static int vbo;
/*     */   private static boolean initialized = false;
/*     */   
/*     */   public static void init(class_3300 resourceManager) {
/*  21 */     if (initialized) {
/*     */       return;
/*     */     }
/*     */     try {
/*  25 */       roundedQuadShader = new class_5944((class_5912)resourceManager, "krypton:rounded_quad", class_290.field_1585);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  30 */       vao = GL30.glGenVertexArrays();
/*  31 */       vbo = GL20.glGenBuffers();
/*     */       
/*  33 */       setupVertexData();
/*  34 */       initialized = true;
/*  35 */     } catch (IOException e) {
/*  36 */       System.err.println("Failed to initialize shaders: " + e.getMessage());
/*  37 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private static void setupVertexData() {
/*  43 */     float[] vertices = { 0.0F, 1.0F, 0.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 1.0F, 0.0F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     GL30.glBindVertexArray(vao);
/*  52 */     GL20.glBindBuffer(34962, vbo);
/*     */     
/*  54 */     FloatBuffer buffer = MemoryUtil.memAllocFloat(vertices.length);
/*  55 */     buffer.put(vertices).flip();
/*  56 */     GL20.glBufferData(34962, buffer, 35044);
/*  57 */     MemoryUtil.memFree(buffer);
/*     */ 
/*     */     
/*  60 */     GL20.glVertexAttribPointer(0, 2, 5126, false, 16, 0L);
/*  61 */     GL20.glEnableVertexAttribArray(0);
/*     */ 
/*     */     
/*  64 */     GL20.glVertexAttribPointer(1, 2, 5126, false, 16, 8L);
/*  65 */     GL20.glEnableVertexAttribArray(1);
/*     */     
/*  67 */     GL30.glBindVertexArray(0);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static void renderRoundedQuad(float x, float y, float width, float height, float r, float g, float b, float a, float topLeft, float topRight, float bottomRight, float bottomLeft) {
/*  73 */     if (!initialized || roundedQuadShader == null) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*     */     try {
/*  79 */       roundedQuadShader.method_34586();
/*     */ 
/*     */       
/*  82 */       int programId = GL20.glGetInteger(35725);
/*     */ 
/*     */       
/*  85 */       int colorLocation = GL20.glGetUniformLocation(programId, "color");
/*  86 */       int sizeLocation = GL20.glGetUniformLocation(programId, "size");
/*  87 */       int radiusLocation = GL20.glGetUniformLocation(programId, "radius");
/*  88 */       int smoothnessLocation = GL20.glGetUniformLocation(programId, "smoothness");
/*     */       
/*  90 */       if (colorLocation != -1) GL20.glUniform4f(colorLocation, r, g, b, a); 
/*  91 */       if (sizeLocation != -1) GL20.glUniform2f(sizeLocation, width, height); 
/*  92 */       if (radiusLocation != -1) GL20.glUniform4f(radiusLocation, topLeft, topRight, bottomRight, bottomLeft); 
/*  93 */       if (smoothnessLocation != -1) GL20.glUniform1f(smoothnessLocation, 1.0F);
/*     */ 
/*     */       
/*  96 */       int projectionLocation = GL20.glGetUniformLocation(programId, "projection");
/*  97 */       int modelLocation = GL20.glGetUniformLocation(programId, "model");
/*     */ 
/*     */       
/* 100 */       class_310 client = class_310.method_1551();
/* 101 */       if (client != null && client.method_22683() != null) {
/* 102 */         float[] projection = createOrthographicMatrix(0.0F, client.method_22683().method_4486(), 0.0F, client
/* 103 */             .method_22683().method_4502(), -1.0F, 1.0F);
/* 104 */         if (projectionLocation != -1) GL20.glUniformMatrix4fv(projectionLocation, false, projection);
/*     */       
/*     */       } 
/*     */       
/* 108 */       float[] model = createModelMatrix(x, y, width, height);
/* 109 */       if (modelLocation != -1) GL20.glUniformMatrix4fv(modelLocation, false, model);
/*     */ 
/*     */       
/* 112 */       GL30.glBindVertexArray(vao);
/* 113 */       GL20.glDrawArrays(6, 0, 4);
/* 114 */       GL30.glBindVertexArray(0);
/*     */       
/* 116 */       roundedQuadShader.method_34585();
/* 117 */     } catch (Exception e) {
/* 118 */       System.err.println("Error rendering rounded quad with shader: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   private static float[] createOrthographicMatrix(float left, float right, float bottom, float top, float near, float far) {
/* 123 */     return new float[] { 2.0F / (right - left), 0.0F, 0.0F, 0.0F, 0.0F, 2.0F / (top - bottom), 0.0F, 0.0F, 0.0F, 0.0F, -2.0F / (far - near), 0.0F, -(right + left) / (right - left), -(top + bottom) / (top - bottom), -(far + near) / (far - near), 1.0F };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static float[] createModelMatrix(float x, float y, float width, float height) {
/* 132 */     return new float[] { width, 0.0F, 0.0F, 0.0F, 0.0F, height, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F, 0.0F, x, y, 0.0F, 1.0F };
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void cleanup() {
/* 141 */     if (vao != 0) {
/* 142 */       GL30.glDeleteVertexArrays(vao);
/* 143 */       vao = 0;
/*     */     } 
/* 145 */     if (vbo != 0) {
/* 146 */       GL20.glDeleteBuffers(vbo);
/* 147 */       vbo = 0;
/*     */     } 
/* 149 */     initialized = false;
/*     */   }
/*     */   
/*     */   public static boolean isInitialized() {
/* 153 */     return initialized;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\manager\ShaderManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */