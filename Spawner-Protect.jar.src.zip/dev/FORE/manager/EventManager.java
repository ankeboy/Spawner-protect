/*    */ package dev.FORE.manager;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.event.Event;
/*    */ import dev.FORE.event.EventListener;
/*    */ import dev.FORE.event.Listener;
/*    */ import dev.FORE.module.Module;
/*    */ import java.lang.reflect.Method;
/*    */ import java.util.Comparator;
/*    */ import java.util.HashMap;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.concurrent.CopyOnWriteArrayList;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public final class EventManager
/*    */ {
/* 21 */   private final Map<Class<?>, List<Listener>> EVENTS = new HashMap<>();
/*    */ 
/*    */   
/*    */   public void register(Object o) {
/* 25 */     Method[] declaredMethods = o.getClass().getDeclaredMethods();
/* 26 */     for (Method method : declaredMethods) {
/* 27 */       if (method.isAnnotationPresent((Class)EventListener.class) && method.getParameterCount() == 1 && Event.class.isAssignableFrom(method.getParameterTypes()[0])) {
/* 28 */         addListener(o, method, method.<EventListener>getAnnotation(EventListener.class));
/*    */       }
/*    */     } 
/*    */   }
/*    */   
/*    */   private void addListener(Object o, Method method, EventListener eventListener) {
/* 34 */     Class<?> key = method.getParameterTypes()[0];
/* 35 */     method.setAccessible(true);
/* 36 */     ((List<Listener>)this.EVENTS.computeIfAbsent(key, p0 -> new CopyOnWriteArrayList())).add(new Listener(o, method, eventListener.priority()));
/* 37 */     ((List)this.EVENTS.get(key)).sort(Comparator.comparingInt(listener -> listener.getPriority().getValue()));
/*    */   }
/*    */   
/*    */   public void unregister(Object object) {
/* 41 */     for (List<Listener> listeners : this.EVENTS.values()) {
/* 42 */       listeners.removeIf(listener -> (listener.getInstance() == object));
/*    */     }
/*    */   }
/*    */   
/*    */   public void clear() {
/* 47 */     this.EVENTS.clear();
/*    */   }
/*    */   
/*    */   public void a(Event event) {
/* 51 */     List<Listener> listeners = this.EVENTS.get(event.getClass());
/* 52 */     if (listeners == null)
/*    */       return; 
/* 54 */     for (Listener listener : listeners) {
/*    */       try {
/* 56 */         Object holder = listener.getInstance();
/*    */         
/* 58 */         if (holder instanceof Module && !((Module)holder).isEnabled()) {
/*    */           continue;
/*    */         }
/*    */         
/* 62 */         if (!event.isCancelled() || event instanceof dev.FORE.event.CancellableEvent) {
/* 63 */           listener.invoke(event);
/*    */         }
/* 65 */       } catch (Throwable _t) {
/* 66 */         System.err.println("Error dispatching event " + event.getClass().getSimpleName() + " to " + ((listener.getInstance() != null) ? listener.getInstance().getClass().getSimpleName() : "unknown"));
/* 67 */         _t.printStackTrace(System.err);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public static void b(Event event) {
/* 73 */     if (DonutBBC.INSTANCE == null || DonutBBC.INSTANCE.getEventBus() == null)
/* 74 */       return;  DonutBBC.INSTANCE.getEventBus().a(event);
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\manager\EventManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */