/*     */ package dev.FORE.manager;
/*     */ import dev.FORE.utils.SecurityUtils;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.ObjectInputStream;
/*     */ import java.io.ObjectOutputStream;
/*     */ import java.nio.charset.StandardCharsets;
/*     */ import java.security.MessageDigest;
/*     */ import java.util.HashMap;
/*     */ import java.util.Map;
/*     */ import java.util.Properties;
/*     */ import java.util.concurrent.CompletableFuture;
/*     */ 
/*     */ public class LicenseManager {
/*     */   private static final String LICENSE_CACHE_FILE = "krispy.license.cache";
/*     */   private static final String LICENSE_CONFIG_FILE = "krispy.license.config";
/*     */   private static final long CACHE_DURATION = 86400000L;
/*     */   private static final String OFFLINE_SIGNATURE = "OFFLINE_MODE_ENABLED";
/*     */   private final Properties config;
/*     */   private final Map<String, LicenseInfo> licenseCache;
/*     */   private String currentLicense;
/*     */   private boolean offlineMode;
/*     */   
/*     */   public LicenseManager() {
/*  26 */     this.config = new Properties();
/*  27 */     this.licenseCache = new HashMap<>();
/*  28 */     this.currentLicense = "";
/*  29 */     this.offlineMode = false;
/*  30 */     loadConfig();
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<Boolean> initialize() {
/*  35 */     return CompletableFuture.supplyAsync(() -> {
/*     */           try {
/*     */             loadLicenseCache();
/*     */             return Boolean.valueOf(true);
/*  39 */           } catch (Exception e) {
/*     */             System.err.println("[LicenseManager] Initialization failed: " + e.getMessage());
/*     */             return Boolean.valueOf(false);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public CompletableFuture<LicenseValidationResult> validateLicense(String licenseKey) {
/*  48 */     return CompletableFuture.supplyAsync(() -> {
/*     */           try {
/*     */             if (this.licenseCache.containsKey(licenseKey)) {
/*     */               LicenseInfo cached = this.licenseCache.get(licenseKey);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               if (System.currentTimeMillis() < cached.getExpiryTime()) {
/*     */                 this.currentLicense = licenseKey;
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/*     */                 return new LicenseValidationResult(true, "License valid (cached)", cached);
/*     */               } 
/*     */ 
/*     */ 
/*     */ 
/*     */               
/*     */               this.licenseCache.remove(licenseKey);
/*     */             } 
/*     */ 
/*     */ 
/*     */ 
/*     */             
/*     */             return !SecurityUtils.isValidLicenseFormat(licenseKey) ? new LicenseValidationResult(false, "Invalid license format", null) : (isOfflineLicense(licenseKey) ? validateOfflineLicense(licenseKey) : simulateOnlineValidation(licenseKey));
/*  76 */           } catch (Exception e) {
/*     */             System.err.println("[LicenseManager] License validation failed: " + e.getMessage());
/*     */             return new LicenseValidationResult(false, "Validation error: " + e.getMessage(), null);
/*     */           } 
/*     */         });
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOfflineLicense(String licenseKey) {
/*  85 */     return (licenseKey.startsWith("OFFLINE_") || licenseKey.equals("OFFLINE_MODE_ENABLED"));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private LicenseValidationResult validateOfflineLicense(String licenseKey) {
/*     */     try {
/*  92 */       String hwid = SecurityUtils.generateHardwareFingerprint();
/*  93 */       String expectedLicense = generateOfflineLicense(hwid);
/*     */       
/*  95 */       if (licenseKey.equals(expectedLicense) || licenseKey.equals("OFFLINE_MODE_ENABLED")) {
/*  96 */         LicenseInfo licenseInfo = new LicenseInfo();
/*  97 */         licenseInfo.setLicenseKey(licenseKey);
/*  98 */         licenseInfo.setUsername("Offline User");
/*  99 */         licenseInfo.setPlan("Offline");
/* 100 */         licenseInfo.setExpiryTime(System.currentTimeMillis() + -1702967296L);
/* 101 */         licenseInfo.setHardwareId(hwid);
/* 102 */         licenseInfo.setOffline(true);
/*     */ 
/*     */         
/* 105 */         this.licenseCache.put(licenseKey, licenseInfo);
/* 106 */         this.currentLicense = licenseKey;
/* 107 */         this.offlineMode = true;
/*     */         
/* 109 */         saveLicenseCache();
/*     */         
/* 111 */         return new LicenseValidationResult(true, "Offline license valid", licenseInfo);
/*     */       } 
/* 113 */       return new LicenseValidationResult(false, "Invalid offline license", null);
/*     */     
/*     */     }
/* 116 */     catch (Exception e) {
/* 117 */       return new LicenseValidationResult(false, "Offline validation failed: " + e.getMessage(), null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String generateOfflineLicense() {
/*     */     try {
/* 124 */       String hwid = SecurityUtils.generateHardwareFingerprint();
/* 125 */       return generateOfflineLicense(hwid);
/* 126 */     } catch (Exception e) {
/* 127 */       return "OFFLINE_ERROR";
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private String generateOfflineLicense(String hwid) throws Exception {
/* 133 */     String base = "OFFLINE_" + hwid + "_" + System.getProperty("user.name");
/* 134 */     MessageDigest digest = MessageDigest.getInstance("SHA-256");
/* 135 */     byte[] hash = digest.digest(base.getBytes(StandardCharsets.UTF_8));
/*     */     
/* 137 */     StringBuilder license = new StringBuilder();
/* 138 */     for (int i = 0; i < 16; i++) {
/* 139 */       license.append(String.format("%02X", new Object[] { Byte.valueOf(hash[i]) }));
/*     */     } 
/*     */     
/* 142 */     return license.toString();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private LicenseValidationResult simulateOnlineValidation(String licenseKey) {
/*     */     try {
/* 152 */       if (SecurityUtils.isValidLicenseFormat(licenseKey)) {
/* 153 */         LicenseInfo licenseInfo = new LicenseInfo();
/* 154 */         licenseInfo.setLicenseKey(licenseKey);
/* 155 */         licenseInfo.setUsername("Demo User");
/* 156 */         licenseInfo.setPlan("Premium");
/* 157 */         licenseInfo.setExpiryTime(System.currentTimeMillis() + 1471228928L);
/* 158 */         licenseInfo.setHardwareId(SecurityUtils.generateHardwareFingerprint());
/* 159 */         licenseInfo.setOffline(false);
/*     */ 
/*     */         
/* 162 */         this.licenseCache.put(licenseKey, licenseInfo);
/* 163 */         this.currentLicense = licenseKey;
/*     */         
/* 165 */         saveLicenseCache();
/*     */         
/* 167 */         return new LicenseValidationResult(true, "License validated successfully", licenseInfo);
/*     */       } 
/* 169 */       return new LicenseValidationResult(false, "Invalid license format", null);
/*     */     
/*     */     }
/* 172 */     catch (Exception e) {
/* 173 */       return new LicenseValidationResult(false, "Online validation failed: " + e.getMessage(), null);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLicenseValid() {
/* 179 */     if (this.currentLicense.isEmpty()) {
/* 180 */       return false;
/*     */     }
/*     */     
/* 183 */     LicenseInfo info = this.licenseCache.get(this.currentLicense);
/* 184 */     if (info == null) {
/* 185 */       return false;
/*     */     }
/*     */     
/* 188 */     return (System.currentTimeMillis() < info.getExpiryTime());
/*     */   }
/*     */ 
/*     */   
/*     */   public LicenseInfo getCurrentLicenseInfo() {
/* 193 */     if (this.currentLicense.isEmpty()) {
/* 194 */       return null;
/*     */     }
/*     */     
/* 197 */     return this.licenseCache.get(this.currentLicense);
/*     */   }
/*     */ 
/*     */   
/*     */   public long getLicenseExpiryTime() {
/* 202 */     LicenseInfo info = getCurrentLicenseInfo();
/* 203 */     return (info != null) ? info.getExpiryTime() : 0L;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isLicenseExpired() {
/* 208 */     return (System.currentTimeMillis() > getLicenseExpiryTime());
/*     */   }
/*     */ 
/*     */   
/*     */   public int getDaysUntilExpiry() {
/* 213 */     long expiryTime = getLicenseExpiryTime();
/* 214 */     if (expiryTime == 0L) {
/* 215 */       return -1;
/*     */     }
/*     */     
/* 218 */     long days = (expiryTime - System.currentTimeMillis()) / 86400000L;
/* 219 */     return Math.max(0, (int)days);
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearLicense() {
/* 224 */     this.currentLicense = "";
/* 225 */     this.offlineMode = false;
/* 226 */     saveConfig();
/*     */   }
/*     */ 
/*     */   
/*     */   public void enableOfflineMode() {
/* 231 */     this.offlineMode = true;
/* 232 */     this.currentLicense = "OFFLINE_MODE_ENABLED";
/* 233 */     saveConfig();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean isOfflineMode() {
/* 238 */     return this.offlineMode;
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadConfig() {
/*     */     try {
/* 244 */       File configFile = new File("krispy.license.config");
/* 245 */       if (configFile.exists()) {
/* 246 */         FileInputStream fis = new FileInputStream(configFile); 
/* 247 */         try { this.config.load(fis);
/* 248 */           fis.close(); } catch (Throwable throwable) { try { fis.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */            throw throwable; }
/* 250 */          this.currentLicense = this.config.getProperty("currentLicense", "");
/* 251 */         this.offlineMode = Boolean.parseBoolean(this.config.getProperty("offlineMode", "false"));
/*     */       } 
/* 253 */     } catch (Exception e) {
/* 254 */       System.err.println("[LicenseManager] Failed to load config: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void saveConfig() {
/*     */     try {
/* 261 */       this.config.setProperty("currentLicense", this.currentLicense);
/* 262 */       this.config.setProperty("offlineMode", String.valueOf(this.offlineMode));
/*     */       
/* 264 */       FileOutputStream fos = new FileOutputStream("krispy.license.config"); 
/* 265 */       try { this.config.store(fos, "Krypton License Configuration");
/* 266 */         fos.close(); } catch (Throwable throwable) { try { fos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 267 */     } catch (Exception e) {
/* 268 */       System.err.println("[LicenseManager] Failed to save config: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void loadLicenseCache() {
/*     */     try {
/* 275 */       File cacheFile = new File("krispy.license.cache");
/* 276 */       if (cacheFile.exists()) {
/* 277 */         ObjectInputStream ois = new ObjectInputStream(new FileInputStream(cacheFile));
/*     */         
/* 279 */         try { Map<String, LicenseInfo> cached = (Map<String, LicenseInfo>)ois.readObject();
/*     */ 
/*     */           
/* 282 */           long currentTime = System.currentTimeMillis();
/* 283 */           for (Map.Entry<String, LicenseInfo> entry : cached.entrySet()) {
/* 284 */             if (((LicenseInfo)entry.getValue()).getExpiryTime() > currentTime) {
/* 285 */               this.licenseCache.put(entry.getKey(), entry.getValue());
/*     */             }
/*     */           } 
/* 288 */           ois.close(); } catch (Throwable throwable) { try { ois.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/*     */       } 
/* 290 */     } catch (Exception e) {
/* 291 */       System.err.println("[LicenseManager] Failed to load license cache: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void saveLicenseCache() {
/*     */     try {
/* 298 */       ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("krispy.license.cache")); 
/* 299 */       try { oos.writeObject(this.licenseCache);
/* 300 */         oos.close(); } catch (Throwable throwable) { try { oos.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; } 
/* 301 */     } catch (Exception e) {
/* 302 */       System.err.println("[LicenseManager] Failed to save license cache: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void clearLicenseCache() {
/* 308 */     this.licenseCache.clear();
/*     */     try {
/* 310 */       File cacheFile = new File("krispy.license.cache");
/* 311 */       if (cacheFile.exists()) {
/* 312 */         cacheFile.delete();
/*     */       }
/* 314 */     } catch (Exception e) {
/* 315 */       System.err.println("[LicenseManager] Failed to clear license cache: " + e.getMessage());
/*     */     } 
/*     */   }
/*     */   
/*     */   public static class LicenseValidationResult
/*     */   {
/*     */     private final boolean valid;
/*     */     private final String message;
/*     */     private final LicenseManager.LicenseInfo licenseInfo;
/*     */     
/*     */     public LicenseValidationResult(boolean valid, String message, LicenseManager.LicenseInfo licenseInfo) {
/* 326 */       this.valid = valid;
/* 327 */       this.message = message;
/* 328 */       this.licenseInfo = licenseInfo;
/*     */     }
/*     */     
/*     */     public boolean isValid() {
/* 332 */       return this.valid;
/*     */     }
/*     */     
/*     */     public String getMessage() {
/* 336 */       return this.message;
/*     */     }
/*     */     
/*     */     public LicenseManager.LicenseInfo getLicenseInfo() {
/* 340 */       return this.licenseInfo;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public static class LicenseInfo
/*     */     implements Serializable
/*     */   {
/*     */     private static final long serialVersionUID = 1L;
/*     */     
/*     */     private String licenseKey;
/*     */     
/*     */     private String username;
/*     */     
/*     */     private String plan;
/*     */     private long expiryTime;
/*     */     private String hardwareId;
/*     */     private boolean offline;
/*     */     
/*     */     public String getLicenseKey() {
/* 360 */       return this.licenseKey;
/*     */     }
/*     */     
/*     */     public void setLicenseKey(String licenseKey) {
/* 364 */       this.licenseKey = licenseKey;
/*     */     }
/*     */     
/*     */     public String getUsername() {
/* 368 */       return this.username;
/*     */     }
/*     */     
/*     */     public void setUsername(String username) {
/* 372 */       this.username = username;
/*     */     }
/*     */     
/*     */     public String getPlan() {
/* 376 */       return this.plan;
/*     */     }
/*     */     
/*     */     public void setPlan(String plan) {
/* 380 */       this.plan = plan;
/*     */     }
/*     */     
/*     */     public long getExpiryTime() {
/* 384 */       return this.expiryTime;
/*     */     }
/*     */     
/*     */     public void setExpiryTime(long expiryTime) {
/* 388 */       this.expiryTime = expiryTime;
/*     */     }
/*     */     
/*     */     public String getHardwareId() {
/* 392 */       return this.hardwareId;
/*     */     }
/*     */     
/*     */     public void setHardwareId(String hardwareId) {
/* 396 */       this.hardwareId = hardwareId;
/*     */     }
/*     */     
/*     */     public boolean isOffline() {
/* 400 */       return this.offline;
/*     */     }
/*     */     
/*     */     public void setOffline(boolean offline) {
/* 404 */       this.offline = offline;
/*     */     }
/*     */ 
/*     */     
/*     */     public String toString() {
/* 409 */       return "LicenseInfo{licenseKey='" + this.licenseKey + "', username='" + this.username + "', plan='" + this.plan + "', expiryTime=" + this.expiryTime + ", hardwareId='" + this.hardwareId + "', offline=" + this.offline + "}";
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\manager\LicenseManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */