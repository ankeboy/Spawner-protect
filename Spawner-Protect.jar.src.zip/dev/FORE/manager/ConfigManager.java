/*     */ package dev.FORE.manager;
/*     */ import com.google.gson.JsonArray;
/*     */ import com.google.gson.JsonElement;
/*     */ import com.google.gson.JsonObject;
/*     */ import dev.FORE.module.Module;
/*     */ import dev.FORE.module.setting.BindSetting;
/*     */ import dev.FORE.module.setting.BooleanSetting;
/*     */ import dev.FORE.module.setting.ItemSetting;
/*     */ import dev.FORE.module.setting.ItemsSetting;
/*     */ import dev.FORE.module.setting.MacroSetting;
/*     */ import dev.FORE.module.setting.MinMaxSetting;
/*     */ import dev.FORE.module.setting.ModeSetting;
/*     */ import dev.FORE.module.setting.NumberSetting;
/*     */ import dev.FORE.module.setting.Setting;
/*     */ import dev.FORE.module.setting.StringSetting;
/*     */ import java.io.File;
/*     */ import java.io.FileReader;
/*     */ import java.io.FileWriter;
/*     */ import java.io.IOException;
/*     */ import java.util.Set;
/*     */ import net.minecraft.class_1792;
/*     */ import net.minecraft.class_2960;
/*     */ import net.minecraft.class_7923;
/*     */ 
/*     */ public final class ConfigManager {
/*     */   private JsonObject jsonObject;
/*     */   private final File configFile;
/*     */   private final Gson gson;
/*     */   
/*     */   public ConfigManager() {
/*  31 */     String userHome = System.getProperty("user.home");
/*  32 */     String configDir = userHome + userHome + ".minecraft" + File.separator + "config";
/*  33 */     File configFolder = new File(configDir);
/*  34 */     if (!configFolder.exists()) {
/*  35 */       configFolder.mkdirs();
/*     */     }
/*     */     
/*  38 */     this.configFile = new File(configFolder, "krypton_config.json");
/*  39 */     this.gson = (new GsonBuilder()).setPrettyPrinting().create();
/*  40 */     this.jsonObject = new JsonObject();
/*     */ 
/*     */     
/*  43 */     loadConfigFromFile();
/*     */   }
/*     */   
/*     */   private void loadConfigFromFile() {
/*     */     try {
/*  48 */       if (this.configFile.exists())
/*  49 */       { FileReader reader = new FileReader(this.configFile); 
/*  50 */         try { this.jsonObject = (JsonObject)this.gson.fromJson(reader, JsonObject.class);
/*  51 */           if (this.jsonObject == null) {
/*  52 */             this.jsonObject = new JsonObject();
/*     */           }
/*     */           
/*  55 */           reader.close(); } catch (Throwable throwable) { try { reader.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }  throw throwable; }
/*     */          }
/*  57 */       else { this.jsonObject = new JsonObject(); }
/*     */     
/*  59 */     } catch (Exception e) {
/*  60 */       System.err.println("[ConfigManager] Error loading config file: " + e.getMessage());
/*  61 */       e.printStackTrace();
/*  62 */       this.jsonObject = new JsonObject();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void loadProfile() {
/*     */     try {
/*  68 */       if (this.jsonObject == null) {
/*  69 */         this.jsonObject = new JsonObject();
/*     */         
/*     */         return;
/*     */       } 
/*     */       
/*  74 */       int modulesLoaded = 0;
/*     */       
/*  76 */       for (Module next : DonutBBC.INSTANCE.getModuleManager().c()) {
/*     */         try {
/*  78 */           String moduleName = getModuleName(next);
/*  79 */           JsonElement value = this.jsonObject.get(moduleName);
/*  80 */           if (value == null || 
/*  81 */             !value.isJsonObject()) {
/*     */             continue;
/*     */           }
/*  84 */           JsonObject asJsonObject = value.getAsJsonObject();
/*  85 */           JsonElement value2 = asJsonObject.get("enabled");
/*  86 */           if (value2 != null && value2.isJsonPrimitive() && value2.getAsBoolean()) {
/*  87 */             next.toggle(true);
/*     */           }
/*  89 */           for (Object next2 : next.getSettings()) {
/*     */             try {
/*  91 */               String settingName = getSettingName((Setting)next2);
/*  92 */               JsonElement value3 = asJsonObject.get(settingName);
/*  93 */               if (value3 == null) {
/*     */                 continue;
/*     */               }
/*  96 */               setValueFromJson((Setting)next2, value3, next);
/*  97 */             } catch (Exception e) {
/*  98 */               System.err.println("[ConfigManager] Error loading setting for module " + moduleName + ": " + e.getMessage());
/*     */             } 
/*     */           } 
/* 101 */           modulesLoaded++;
/*     */         }
/* 103 */         catch (Exception e) {
/* 104 */           System.err.println("[ConfigManager] Error loading module: " + e.getMessage());
/*     */         }
/*     */       
/*     */       }
/*     */     
/* 109 */     } catch (Exception ex) {
/* 110 */       System.err.println("[ConfigManager] Error loading profile: " + ex.getMessage());
/* 111 */       ex.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getModuleName(Module module) {
/*     */     try {
/* 117 */       CharSequence name = module.getName();
/* 118 */       if (name instanceof EncryptedString) {
/* 119 */         return ((EncryptedString)name).toString();
/*     */       }
/* 121 */       return name.toString();
/*     */     }
/* 123 */     catch (Exception e) {
/*     */       
/* 125 */       return "Module_" + module.hashCode();
/*     */     } 
/*     */   }
/*     */   
/*     */   private String getSettingName(Setting setting) {
/*     */     try {
/* 131 */       CharSequence name = setting.getName();
/* 132 */       if (name instanceof EncryptedString) {
/* 133 */         return ((EncryptedString)name).toString();
/*     */       }
/* 135 */       return name.toString();
/*     */     }
/* 137 */     catch (Exception e) {
/*     */       
/* 139 */       return "Setting_" + setting.hashCode();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void setValueFromJson(Setting setting, JsonElement jsonElement, Module module) {
/*     */     try {
/* 145 */       if (setting instanceof BooleanSetting) { BooleanSetting booleanSetting = (BooleanSetting)setting;
/* 146 */         if (jsonElement.isJsonPrimitive()) {
/* 147 */           booleanSetting.setValue(jsonElement.getAsBoolean());
/*     */         } }
/* 149 */       else if (setting instanceof ModeSetting) { ModeSetting enumSetting = (ModeSetting)setting;
/* 150 */         if (jsonElement.isJsonPrimitive()) {
/* 151 */           int asInt = jsonElement.getAsInt();
/* 152 */           if (asInt != -1) {
/* 153 */             enumSetting.setModeIndex(asInt);
/*     */           } else {
/* 155 */             enumSetting.setModeIndex(enumSetting.getOriginalValue());
/*     */           } 
/*     */         }  }
/* 158 */       else if (setting instanceof NumberSetting) { NumberSetting numberSetting = (NumberSetting)setting;
/* 159 */         if (jsonElement.isJsonPrimitive()) {
/* 160 */           numberSetting.getValue(jsonElement.getAsDouble());
/*     */         } }
/* 162 */       else if (setting instanceof BindSetting) { BindSetting bindSetting = (BindSetting)setting;
/* 163 */         if (jsonElement.isJsonPrimitive()) {
/* 164 */           int asInt2 = jsonElement.getAsInt();
/* 165 */           bindSetting.setValue(asInt2);
/* 166 */           if (bindSetting.isModuleKey()) {
/* 167 */             module.setKeybind(asInt2);
/*     */           }
/*     */         }  }
/* 170 */       else if (setting instanceof StringSetting) { StringSetting stringSetting = (StringSetting)setting;
/* 171 */         if (jsonElement.isJsonPrimitive()) {
/* 172 */           stringSetting.setValue(jsonElement.getAsString());
/*     */         } }
/* 174 */       else if (setting instanceof MinMaxSetting) { MinMaxSetting minMaxSetting = (MinMaxSetting)setting;
/* 175 */         if (jsonElement.isJsonObject()) {
/* 176 */           JsonObject asJsonObject = jsonElement.getAsJsonObject();
/* 177 */           if (asJsonObject.has("min") && asJsonObject.has("max")) {
/* 178 */             double asDouble = asJsonObject.get("min").getAsDouble();
/* 179 */             double asDouble2 = asJsonObject.get("max").getAsDouble();
/* 180 */             minMaxSetting.setCurrentMin(asDouble);
/* 181 */             minMaxSetting.setCurrentMax(asDouble2);
/*     */           } 
/*     */         }  }
/* 184 */       else if (setting instanceof ItemSetting && jsonElement.isJsonPrimitive())
/* 185 */       { ((ItemSetting)setting).setItem((class_1792)class_7923.field_41178.method_10223(class_2960.method_60654(jsonElement.getAsString()))); }
/* 186 */       else if (setting instanceof ItemsSetting && jsonElement.isJsonArray())
/* 187 */       { ItemsSetting itemsSetting = (ItemsSetting)setting;
/* 188 */         Set<class_1792> items = new HashSet<>();
/* 189 */         for (JsonElement element : jsonElement.getAsJsonArray()) {
/* 190 */           if (element.isJsonPrimitive()) {
/*     */             try {
/* 192 */               class_2960 id = class_2960.method_60654(element.getAsString());
/* 193 */               class_1792 item = (class_1792)class_7923.field_41178.method_10223(id);
/* 194 */               if (item != null) {
/* 195 */                 items.add(item);
/*     */               }
/* 197 */             } catch (Exception exception) {}
/*     */           }
/*     */         } 
/*     */         
/* 201 */         itemsSetting.setItems(items); }
/* 202 */       else if (setting instanceof MacroSetting && jsonElement.isJsonArray())
/* 203 */       { MacroSetting macroSetting = (MacroSetting)setting;
/* 204 */         macroSetting.clearCommands();
/* 205 */         for (JsonElement element : jsonElement.getAsJsonArray()) {
/* 206 */           if (element.isJsonPrimitive()) {
/* 207 */             macroSetting.addCommand(element.getAsString());
/*     */           }
/*     */         }  }
/*     */     
/* 211 */     } catch (Exception ex) {
/* 212 */       System.err.println("[ConfigManager] Error setting value from JSON: " + ex.getMessage());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void saveConfigToFile() {
/*     */     try {
/* 219 */       File parentDir = this.configFile.getParentFile();
/* 220 */       if (parentDir != null && !parentDir.exists()) {
/* 221 */         parentDir.mkdirs();
/*     */       }
/*     */       
/* 224 */       FileWriter writer = new FileWriter(this.configFile); 
/* 225 */       try { this.gson.toJson((JsonElement)this.jsonObject, writer);
/* 226 */         writer.close(); } catch (Throwable throwable) { try { writer.close(); } catch (Throwable throwable1) { throwable.addSuppressed(throwable1); }
/*     */          throw throwable; }
/*     */     
/* 229 */     } catch (IOException e) {
/* 230 */       System.err.println("[ConfigManager] Error saving config file: " + e.getMessage());
/* 231 */       e.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void saveConfig() {
/* 236 */     shutdown();
/*     */   }
/*     */   
/*     */   public void manualSave() {
/* 240 */     shutdown();
/*     */   }
/*     */   
/*     */   public void reloadConfig() {
/* 244 */     loadConfigFromFile();
/* 245 */     loadProfile();
/*     */   }
/*     */   
/*     */   public File getConfigFile() {
/* 249 */     return this.configFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public void shutdown() {
/*     */     try {
/* 255 */       this.jsonObject = new JsonObject();
/* 256 */       int modulesSaved = 0;
/*     */       
/* 258 */       for (Module module : DonutBBC.INSTANCE.getModuleManager().c()) {
/*     */         try {
/* 260 */           String moduleName = getModuleName(module);
/* 261 */           JsonObject jsonObject = new JsonObject();
/* 262 */           jsonObject.addProperty("enabled", Boolean.valueOf(module.isEnabled()));
/*     */           
/* 264 */           for (Setting setting : module.getSettings()) {
/*     */             try {
/* 266 */               save(setting, jsonObject, module);
/* 267 */             } catch (Exception e) {
/* 268 */               System.err.println("[ConfigManager] Error saving setting for module " + moduleName + ": " + e.getMessage());
/*     */             } 
/*     */           } 
/*     */           
/* 272 */           this.jsonObject.add(moduleName, (JsonElement)jsonObject);
/* 273 */           modulesSaved++;
/* 274 */         } catch (Exception e) {
/* 275 */           System.err.println("[ConfigManager] Error saving module: " + e.getMessage());
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 280 */       saveConfigToFile();
/* 281 */     } catch (Exception _t) {
/* 282 */       System.err.println("[ConfigManager] Error during shutdown: " + _t.getMessage());
/* 283 */       _t.printStackTrace(System.err);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void save(Setting setting, JsonObject jsonObject, Module module) {
/*     */     try {
/* 289 */       String settingName = getSettingName(setting);
/*     */       
/* 291 */       if (setting instanceof BooleanSetting) { BooleanSetting booleanSetting = (BooleanSetting)setting;
/* 292 */         jsonObject.addProperty(settingName, Boolean.valueOf(booleanSetting.getValue())); }
/* 293 */       else if (setting instanceof ModeSetting) { ModeSetting<?> enumSetting = (ModeSetting)setting;
/* 294 */         jsonObject.addProperty(settingName, Integer.valueOf(enumSetting.getModeIndex())); }
/* 295 */       else if (setting instanceof NumberSetting) { NumberSetting numberSetting = (NumberSetting)setting;
/* 296 */         jsonObject.addProperty(settingName, Double.valueOf(numberSetting.getValue())); }
/* 297 */       else if (setting instanceof BindSetting) { BindSetting bindSetting = (BindSetting)setting;
/* 298 */         jsonObject.addProperty(settingName, Integer.valueOf(bindSetting.getValue())); }
/* 299 */       else if (setting instanceof StringSetting) { StringSetting stringSetting = (StringSetting)setting;
/* 300 */         jsonObject.addProperty(settingName, stringSetting.getValue()); }
/* 301 */       else if (setting instanceof MinMaxSetting)
/* 302 */       { JsonObject jsonObject2 = new JsonObject();
/* 303 */         jsonObject2.addProperty("min", Double.valueOf(((MinMaxSetting)setting).getCurrentMin()));
/* 304 */         jsonObject2.addProperty("max", Double.valueOf(((MinMaxSetting)setting).getCurrentMax()));
/* 305 */         jsonObject.add(settingName, (JsonElement)jsonObject2); }
/* 306 */       else if (setting instanceof ItemSetting) { ItemSetting itemSetting = (ItemSetting)setting;
/* 307 */         jsonObject.addProperty(settingName, class_7923.field_41178.method_10221(itemSetting.getItem()).toString()); }
/* 308 */       else if (setting instanceof ItemsSetting) { ItemsSetting itemsSetting = (ItemsSetting)setting;
/* 309 */         JsonArray itemsArray = new JsonArray();
/* 310 */         for (class_1792 item : itemsSetting.getItems()) {
/* 311 */           class_2960 id = class_7923.field_41178.method_10221(item);
/* 312 */           if (id != null) {
/* 313 */             itemsArray.add(id.toString());
/*     */           }
/*     */         } 
/* 316 */         jsonObject.add(settingName, (JsonElement)itemsArray); }
/* 317 */       else if (setting instanceof MacroSetting) { MacroSetting macroSetting = (MacroSetting)setting;
/* 318 */         JsonArray commandsArray = new JsonArray();
/* 319 */         for (String command : macroSetting.getCommands()) {
/* 320 */           commandsArray.add(command);
/*     */         }
/* 322 */         jsonObject.add(settingName, (JsonElement)commandsArray); }
/*     */     
/* 324 */     } catch (Exception ex) {
/* 325 */       String settingName = "Unknown";
/*     */       try {
/* 327 */         settingName = getSettingName(setting);
/* 328 */       } catch (Exception e) {
/* 329 */         settingName = "Setting_" + setting.hashCode();
/*     */       } 
/* 331 */       System.err.println("[ConfigManager] Error saving setting " + settingName + ": " + ex.getMessage());
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\manager\ConfigManager.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */