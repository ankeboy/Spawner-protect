/*     */ package dev.FORE.AI;
/*     */ 
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_304;
/*     */ import net.minecraft.class_310;
/*     */ 
/*     */ public class SimpleSneakCentering {
/*   8 */   private final class_310 mc = class_310.method_1551();
/*     */   
/*     */   private static final double TOLERANCE = 0.15D;
/*     */   
/*     */   private boolean active = false;
/*  13 */   private class_2338 targetBlock = null;
/*     */   
/*     */   private double targetX;
/*     */   
/*     */   private double targetZ;
/*  18 */   private int tickCount = 0;
/*  19 */   private double lastDistanceToTarget = 0.0D;
/*     */   
/*     */   public boolean startCentering() {
/*  22 */     if (this.mc.field_1724 == null) return false;
/*     */ 
/*     */     
/*  25 */     this.targetBlock = this.mc.field_1724.method_24515();
/*     */ 
/*     */     
/*  28 */     this.targetX = this.targetBlock.method_10263() + 0.5D;
/*  29 */     this.targetZ = this.targetBlock.method_10260() + 0.5D;
/*     */ 
/*     */     
/*  32 */     double offsetX = Math.abs(this.mc.field_1724.method_23317() - this.targetX);
/*  33 */     double offsetZ = Math.abs(this.mc.field_1724.method_23321() - this.targetZ);
/*     */     
/*  35 */     System.out.println("=== CENTERING START ===");
/*  36 */     System.out.println("Player pos: " + this.mc.field_1724.method_23317() + ", " + this.mc.field_1724.method_23321());
/*  37 */     System.out.println("Target block: " + String.valueOf(this.targetBlock));
/*  38 */     System.out.println("Target center: " + this.targetX + ", " + this.targetZ);
/*  39 */     System.out.println("Initial offset: X=" + offsetX + ", Z=" + offsetZ);
/*     */     
/*  41 */     if (offsetX <= 0.15D && offsetZ <= 0.15D) {
/*  42 */       System.out.println("Already centered!");
/*  43 */       return false;
/*     */     } 
/*     */     
/*  46 */     this.active = true;
/*  47 */     this.tickCount = 0;
/*  48 */     this.lastDistanceToTarget = Math.sqrt(offsetX * offsetX + offsetZ * offsetZ);
/*  49 */     return true;
/*     */   }
/*     */   
/*     */   public boolean tick() {
/*  53 */     if (!this.active || this.mc.field_1724 == null) return false;
/*     */     
/*  55 */     this.tickCount++;
/*     */ 
/*     */     
/*  58 */     double worldOffsetX = this.mc.field_1724.method_23317() - this.targetX;
/*  59 */     double worldOffsetZ = this.mc.field_1724.method_23321() - this.targetZ;
/*     */ 
/*     */     
/*  62 */     double currentDistance = Math.sqrt(worldOffsetX * worldOffsetX + worldOffsetZ * worldOffsetZ);
/*     */     
/*  64 */     System.out.println("\n--- Tick " + this.tickCount + " ---");
/*  65 */     System.out.println("Player pos: " + this.mc.field_1724.method_23317() + ", " + this.mc.field_1724.method_23321());
/*  66 */     System.out.println("World offset: X=" + worldOffsetX + ", Z=" + worldOffsetZ);
/*  67 */     System.out.println("Distance to target: " + currentDistance + " (was " + this.lastDistanceToTarget + ")");
/*     */ 
/*     */     
/*  70 */     if (currentDistance > this.lastDistanceToTarget + 0.01D) {
/*  71 */       System.out.println("WARNING: Moving AWAY from target!");
/*     */     }
/*  73 */     this.lastDistanceToTarget = currentDistance;
/*     */ 
/*     */     
/*  76 */     if (Math.abs(worldOffsetX) <= 0.15D && Math.abs(worldOffsetZ) <= 0.15D) {
/*  77 */       System.out.println("CENTERED! Stopping.");
/*  78 */       stopCentering();
/*  79 */       return false;
/*     */     } 
/*     */ 
/*     */     
/*  83 */     releaseAllKeys();
/*     */ 
/*     */     
/*  86 */     setPressed(this.mc.field_1690.field_1832, true);
/*     */ 
/*     */     
/*  89 */     float yaw = this.mc.field_1724.method_36454();
/*  90 */     double yawRad = Math.toRadians(yaw);
/*     */     
/*  92 */     System.out.println("Player yaw: " + yaw + "° (" + getCardinalDirection(yaw) + ")");
/*     */ 
/*     */     
/*  95 */     double moveX = -worldOffsetX;
/*  96 */     double moveZ = -worldOffsetZ;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 103 */     double relativeForward = moveX * -Math.sin(yawRad) + moveZ * Math.cos(yawRad);
/* 104 */     double relativeStrafe = moveX * -Math.cos(yawRad) + moveZ * -Math.sin(yawRad);
/*     */     
/* 106 */     System.out.println("Relative movement needed: Forward=" + relativeForward + ", Strafe=" + relativeStrafe);
/*     */ 
/*     */     
/* 109 */     StringBuilder keysPressed = new StringBuilder("Keys pressed: ");
/*     */ 
/*     */     
/* 112 */     if (Math.abs(relativeForward) > 0.075D) {
/* 113 */       if (relativeForward > 0.0D) {
/* 114 */         setPressed(this.mc.field_1690.field_1894, true);
/* 115 */         keysPressed.append("FORWARD ");
/*     */       } else {
/* 117 */         setPressed(this.mc.field_1690.field_1881, true);
/* 118 */         keysPressed.append("BACK ");
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 123 */     if (Math.abs(relativeStrafe) > 0.075D) {
/* 124 */       if (relativeStrafe > 0.0D) {
/* 125 */         setPressed(this.mc.field_1690.field_1849, true);
/* 126 */         keysPressed.append("RIGHT ");
/*     */       } else {
/* 128 */         setPressed(this.mc.field_1690.field_1913, true);
/* 129 */         keysPressed.append("LEFT ");
/*     */       } 
/*     */     }
/*     */     
/* 133 */     keysPressed.append("SNEAK");
/* 134 */     System.out.println(keysPressed.toString());
/*     */ 
/*     */     
/* 137 */     if (this.tickCount > 100) {
/* 138 */       System.out.println("ERROR: Centering timed out after 100 ticks!");
/* 139 */       stopCentering();
/* 140 */       return false;
/*     */     } 
/*     */     
/* 143 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private String getCardinalDirection(float yaw) {
/* 148 */     float normalizedYaw = (yaw % 360.0F + 360.0F) % 360.0F;
/*     */     
/* 150 */     if (normalizedYaw >= 315.0F || normalizedYaw < 45.0F) return "SOUTH"; 
/* 151 */     if (normalizedYaw >= 45.0F && normalizedYaw < 135.0F) return "WEST"; 
/* 152 */     if (normalizedYaw >= 135.0F && normalizedYaw < 225.0F) return "NORTH"; 
/* 153 */     return "EAST";
/*     */   }
/*     */   
/*     */   public void stopCentering() {
/* 157 */     System.out.println("=== CENTERING STOPPED ===\n");
/* 158 */     this.active = false;
/* 159 */     this.targetBlock = null;
/* 160 */     releaseAllKeys();
/* 161 */     this.tickCount = 0;
/*     */   }
/*     */   
/*     */   private void releaseAllKeys() {
/* 165 */     setPressed(this.mc.field_1690.field_1894, false);
/* 166 */     setPressed(this.mc.field_1690.field_1881, false);
/* 167 */     setPressed(this.mc.field_1690.field_1913, false);
/* 168 */     setPressed(this.mc.field_1690.field_1849, false);
/* 169 */     setPressed(this.mc.field_1690.field_1832, false);
/*     */   }
/*     */   
/*     */   private void setPressed(class_304 key, boolean pressed) {
/* 173 */     key.method_23481(pressed);
/*     */   }
/*     */   
/*     */   public boolean isCentering() {
/* 177 */     return this.active;
/*     */   }
/*     */   
/*     */   public boolean isDone() {
/* 181 */     if (!this.active || this.mc.field_1724 == null) return true;
/*     */     
/* 183 */     double offsetX = Math.abs(this.mc.field_1724.method_23317() - this.targetX);
/* 184 */     double offsetZ = Math.abs(this.mc.field_1724.method_23321() - this.targetZ);
/*     */     
/* 186 */     return (offsetX <= 0.15D && offsetZ <= 0.15D);
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\AI\SimpleSneakCentering.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */