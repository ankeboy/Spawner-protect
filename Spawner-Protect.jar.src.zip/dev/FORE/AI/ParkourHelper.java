/*     */ package dev.FORE.AI;
/*     */ import net.minecraft.class_1657;
/*     */ import net.minecraft.class_1922;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ import net.minecraft.class_243;
/*     */ import net.minecraft.class_2680;
/*     */ import net.minecraft.class_638;
/*     */ import net.minecraft.class_746;
/*     */ 
/*     */ public class ParkourHelper {
/*  12 */   private final class_310 mc = class_310.method_1551();
/*     */   
/*     */   private boolean isJumping = false;
/*     */   
/*  16 */   private int jumpCooldown = 0;
/*  17 */   private class_2338 jumpTarget = null;
/*  18 */   private class_243 jumpStartPos = null;
/*     */   
/*     */   private static final int JUMP_COOLDOWN_TICKS = 10;
/*     */   private static final double JUMP_DISTANCE_THRESHOLD = 1.5D;
/*     */   
/*     */   public static class JumpCheck
/*     */   {
/*     */     public final boolean canJump;
/*     */     public final boolean shouldJump;
/*     */     public final class_2338 targetPos;
/*     */     public final String reason;
/*     */     
/*     */     public JumpCheck(boolean canJump, boolean shouldJump, class_2338 targetPos, String reason) {
/*  31 */       this.canJump = canJump;
/*  32 */       this.shouldJump = shouldJump;
/*  33 */       this.targetPos = targetPos;
/*  34 */       this.reason = reason;
/*     */     }
/*     */   }
/*     */   
/*     */   public JumpCheck checkJumpOpportunity(class_1657 player, class_2350 movingDirection) {
/*  39 */     if (this.jumpCooldown > 0 || !player.method_24828() || this.isJumping) {
/*  40 */       return new JumpCheck(false, false, null, "On cooldown or already jumping");
/*     */     }
/*     */     
/*  43 */     class_638 class_638 = this.mc.field_1687;
/*  44 */     class_2338 playerPos = player.method_24515();
/*     */ 
/*     */     
/*  47 */     class_2338 frontPos = playerPos.method_10093(movingDirection);
/*  48 */     class_2338 frontGround = frontPos.method_10074();
/*  49 */     class_2680 frontState = class_638.method_8320(frontPos);
/*  50 */     class_2680 frontGroundState = class_638.method_8320(frontGround);
/*     */ 
/*     */     
/*  53 */     if (frontState.method_26215() && !frontGroundState.method_26215() && frontGroundState.method_26212((class_1922)class_638, frontGround)) {
/*     */       
/*  55 */       class_2338 twoDown = frontGround.method_10074();
/*  56 */       if (class_638.method_8320(twoDown).method_26215()) {
/*  57 */         return new JumpCheck(true, false, null, "Safe 1-block drop - just walk");
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*  62 */     if (frontState.method_26215() || !frontState.method_26212((class_1922)class_638, frontPos)) {
/*  63 */       return new JumpCheck(true, false, null, "No obstacle");
/*     */     }
/*     */ 
/*     */     
/*  67 */     class_2338 aboveFront = frontPos.method_10084();
/*  68 */     class_2680 aboveFrontState = class_638.method_8320(aboveFront);
/*     */ 
/*     */     
/*  71 */     class_2338 twoAboveFront = frontPos.method_10086(2);
/*  72 */     class_2680 twoAboveFrontState = class_638.method_8320(twoAboveFront);
/*     */ 
/*     */     
/*  75 */     if (!aboveFrontState.method_26215() || !twoAboveFrontState.method_26215()) {
/*  76 */       return new JumpCheck(false, false, null, "No clearance above obstacle");
/*     */     }
/*     */ 
/*     */     
/*  80 */     class_2338 landingPos = frontPos.method_10093(movingDirection);
/*  81 */     class_2680 landingState = class_638.method_8320(landingPos);
/*  82 */     class_2338 landingGround = landingPos.method_10074();
/*  83 */     class_2680 landingGroundState = class_638.method_8320(landingGround);
/*     */ 
/*     */ 
/*     */     
/*  87 */     boolean safeLanding = (landingState.method_26215() && class_638.method_8320(landingPos.method_10084()).method_26215());
/*     */ 
/*     */     
/*  90 */     boolean hasLandingGround = landingGroundState.method_26212((class_1922)class_638, landingGround);
/*  91 */     if (!hasLandingGround) {
/*     */       
/*  93 */       class_2338 landingTwoDown = landingGround.method_10074();
/*  94 */       hasLandingGround = class_638.method_8320(landingTwoDown).method_26212((class_1922)class_638, landingTwoDown);
/*     */     } 
/*     */     
/*  97 */     if (safeLanding && hasLandingGround) {
/*  98 */       return new JumpCheck(true, true, landingPos, "Safe jump available (may include drop)");
/*     */     }
/*     */ 
/*     */     
/* 102 */     if (aboveFrontState.method_26215() && class_638.method_8320(aboveFront.method_10084()).method_26215()) {
/* 103 */       return new JumpCheck(true, true, aboveFront, "Jump onto block");
/*     */     }
/*     */     
/* 106 */     return new JumpCheck(false, false, null, "No safe landing");
/*     */   }
/*     */   
/*     */   public boolean startJump(class_2338 target) {
/* 110 */     if (this.isJumping || this.jumpCooldown > 0) {
/* 111 */       return false;
/*     */     }
/*     */     
/* 114 */     class_746 class_746 = this.mc.field_1724;
/* 115 */     if (class_746 == null || !class_746.method_24828()) {
/* 116 */       return false;
/*     */     }
/*     */     
/* 119 */     this.jumpTarget = target;
/* 120 */     this.jumpStartPos = class_746.method_19538();
/* 121 */     this.isJumping = true;
/*     */ 
/*     */     
/* 124 */     class_746.method_6043();
/*     */     
/* 126 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void update() {
/* 131 */     if (this.jumpCooldown > 0) {
/* 132 */       this.jumpCooldown--;
/*     */     }
/*     */ 
/*     */     
/* 136 */     if (this.isJumping && this.mc.field_1724 != null) {
/* 137 */       class_243 currentPos = this.mc.field_1724.method_19538();
/*     */ 
/*     */       
/* 140 */       if (this.mc.field_1724.method_24828() && currentPos.method_1022(this.jumpStartPos) > 0.5D) {
/*     */         
/* 142 */         completeJump();
/* 143 */       } else if (currentPos.method_1022(this.jumpStartPos) > 1.5D) {
/*     */         
/* 145 */         completeJump();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void completeJump() {
/* 151 */     this.isJumping = false;
/* 152 */     this.jumpCooldown = 10;
/* 153 */     this.jumpTarget = null;
/* 154 */     this.jumpStartPos = null;
/*     */   }
/*     */   
/*     */   public boolean isJumping() {
/* 158 */     return this.isJumping;
/*     */   }
/*     */   
/*     */   public void reset() {
/* 162 */     this.isJumping = false;
/* 163 */     this.jumpCooldown = 0;
/* 164 */     this.jumpTarget = null;
/* 165 */     this.jumpStartPos = null;
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\AI\ParkourHelper.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */