/*    */ package dev.FORE.AI;
/*    */ 
/*    */ import java.util.LinkedList;
/*    */ import java.util.Queue;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class PathPlan
/*    */ {
/*    */   public final boolean needsDetour;
/*    */   public final Queue<class_2338> waypoints;
/*    */   public final String reason;
/*    */   public final class_2350 newPrimaryDirection;
/*    */   
/*    */   public PathPlan(boolean needsDetour, Queue<class_2338> waypoints, String reason) {
/* 73 */     this.needsDetour = needsDetour;
/* 74 */     this.waypoints = waypoints;
/* 75 */     this.reason = reason;
/* 76 */     this.newPrimaryDirection = null;
/*    */   }
/*    */   
/*    */   public PathPlan(class_2350 newDirection, String reason) {
/* 80 */     this.needsDetour = false;
/* 81 */     this.waypoints = new LinkedList<>();
/* 82 */     this.reason = reason;
/* 83 */     this.newPrimaryDirection = newDirection;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\AI\DirectionalPathfinder$PathPlan.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */