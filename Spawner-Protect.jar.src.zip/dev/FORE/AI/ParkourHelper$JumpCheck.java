/*    */ package dev.FORE.AI;
/*    */ 
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class JumpCheck
/*    */ {
/*    */   public final boolean canJump;
/*    */   public final boolean shouldJump;
/*    */   public final class_2338 targetPos;
/*    */   public final String reason;
/*    */   
/*    */   public JumpCheck(boolean canJump, boolean shouldJump, class_2338 targetPos, String reason) {
/* 31 */     this.canJump = canJump;
/* 32 */     this.shouldJump = shouldJump;
/* 33 */     this.targetPos = targetPos;
/* 34 */     this.reason = reason;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\AI\ParkourHelper$JumpCheck.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */