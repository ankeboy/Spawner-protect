/*    */ package dev.FORE.AI;
/*    */ 
/*    */ import java.util.HashSet;
/*    */ import java.util.Set;
/*    */ import net.minecraft.class_2338;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ScanResult
/*    */ {
/*    */   private final boolean safe;
/*    */   private final PathScanner.HazardType hazardType;
/*    */   private final int hazardDistance;
/*    */   private final Set<class_2338> hazardPositions;
/*    */   
/*    */   public ScanResult(boolean safe, PathScanner.HazardType hazardType, int hazardDistance) {
/* 47 */     this(safe, hazardType, hazardDistance, new HashSet<>());
/*    */   }
/*    */   
/*    */   public ScanResult(boolean safe, PathScanner.HazardType hazardType, int hazardDistance, Set<class_2338> hazardPositions) {
/* 51 */     this.safe = safe;
/* 52 */     this.hazardType = hazardType;
/* 53 */     this.hazardDistance = hazardDistance;
/* 54 */     this.hazardPositions = hazardPositions;
/*    */   }
/*    */   
/* 57 */   public boolean isSafe() { return this.safe; }
/* 58 */   public PathScanner.HazardType getHazardType() { return this.hazardType; }
/* 59 */   public int getHazardDistance() { return this.hazardDistance; } public Set<class_2338> getHazardPositions() {
/* 60 */     return this.hazardPositions;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\AI\PathScanner$ScanResult.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */