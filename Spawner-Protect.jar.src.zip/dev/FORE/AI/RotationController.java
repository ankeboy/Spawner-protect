/*     */ package dev.FORE.AI;
/*     */ 
/*     */ import java.util.Random;
/*     */ import net.minecraft.class_310;
/*     */ import net.minecraft.class_3532;
/*     */ 
/*     */ public class RotationController {
/*   8 */   private final class_310 mc = class_310.method_1551();
/*   9 */   private final Random random = new Random();
/*     */   
/*     */   private float currentYaw;
/*     */   
/*     */   private float targetYaw;
/*     */   
/*     */   private float currentPitch;
/*     */   private float targetPitch;
/*     */   private float currentRotationSpeed;
/*     */   private float currentPitchSpeed;
/*     */   private boolean isRotating = false;
/*     */   private Runnable callback;
/*     */   private boolean smoothRotation = true;
/*  22 */   private double baseSpeed = 4.5D;
/*  23 */   private double acceleration = 0.8D;
/*     */   private boolean humanLike = true;
/*  25 */   private double overshootChance = 0.3D;
/*     */   private boolean preciseLanding = true;
/*  27 */   private double randomVariation = 0.0D;
/*     */   
/*     */   private double effectiveSpeed;
/*     */   
/*     */   private double effectiveAcceleration;
/*     */   
/*     */   public void updateSettings(boolean smooth, double speed, double accel, boolean human, double overshoot) {
/*  34 */     this.smoothRotation = smooth;
/*  35 */     this.baseSpeed = speed;
/*  36 */     this.acceleration = accel;
/*  37 */     this.humanLike = human;
/*  38 */     this.overshootChance = overshoot;
/*     */   }
/*     */ 
/*     */   
/*     */   public void updateRandomVariation(double variation) {
/*  43 */     this.randomVariation = variation;
/*     */   }
/*     */ 
/*     */   
/*     */   public void setPreciseLanding(boolean precise) {
/*  48 */     this.preciseLanding = precise;
/*     */   }
/*     */   
/*     */   public void startRotation(float targetYaw, Runnable onComplete) {
/*  52 */     startRotation(targetYaw, 0.0F, onComplete);
/*     */   }
/*     */   
/*     */   public void startRotation(float targetYaw, float targetPitch, Runnable onComplete) {
/*  56 */     this.targetYaw = targetYaw;
/*  57 */     this.targetPitch = targetPitch;
/*  58 */     this.callback = onComplete;
/*     */ 
/*     */     
/*  61 */     calculateEffectiveValues();
/*     */     
/*  63 */     if (!this.smoothRotation) {
/*     */       
/*  65 */       setYawAngle(targetYaw);
/*  66 */       setPitchAngle(targetPitch);
/*  67 */       if (this.callback != null) this.callback.run();
/*     */ 
/*     */       
/*     */       return;
/*     */     } 
/*  72 */     this.isRotating = true;
/*  73 */     this.currentYaw = this.mc.field_1724.method_36454();
/*  74 */     this.currentPitch = this.mc.field_1724.method_36455();
/*  75 */     this.currentRotationSpeed = 0.0F;
/*  76 */     this.currentPitchSpeed = 0.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   private void calculateEffectiveValues() {
/*  81 */     if (this.randomVariation <= 0.0D) {
/*     */       
/*  83 */       this.effectiveSpeed = this.baseSpeed;
/*  84 */       this.effectiveAcceleration = this.acceleration;
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/*  89 */     double speedMultiplier = this.random.nextDouble() * 2.0D - 1.0D;
/*  90 */     double accelMultiplier = this.random.nextDouble() * 2.0D - 1.0D;
/*     */ 
/*     */     
/*  93 */     double speedVariation = this.randomVariation;
/*  94 */     this.effectiveSpeed = this.baseSpeed + speedMultiplier * speedVariation;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  99 */     double accelRatio = this.acceleration / this.baseSpeed;
/* 100 */     double accelVariation = this.randomVariation * accelRatio;
/* 101 */     this.effectiveAcceleration = this.acceleration + accelMultiplier * accelVariation;
/*     */ 
/*     */     
/* 104 */     this.effectiveSpeed = Math.max(0.5D, this.effectiveSpeed);
/* 105 */     this.effectiveAcceleration = Math.max(0.1D, this.effectiveAcceleration);
/*     */ 
/*     */     
/* 108 */     this.effectiveSpeed = Math.min(this.baseSpeed * 2.0D, this.effectiveSpeed);
/* 109 */     this.effectiveAcceleration = Math.min(this.acceleration * 2.0D, this.effectiveAcceleration);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void update() {
/* 119 */     if (!this.isRotating)
/*     */       return; 
/* 121 */     boolean yawComplete = updateYaw();
/* 122 */     boolean pitchComplete = updatePitch();
/*     */ 
/*     */     
/* 125 */     if (yawComplete && pitchComplete) {
/* 126 */       this.isRotating = false;
/*     */ 
/*     */       
/* 129 */       if (this.preciseLanding) {
/* 130 */         setYawAngle(this.targetYaw);
/* 131 */         setPitchAngle(this.targetPitch);
/*     */       } 
/*     */       
/* 134 */       if (this.callback != null) {
/* 135 */         this.callback.run();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean updateYaw() {
/* 142 */     float targetSpeed, deltaAngle = class_3532.method_15393(this.targetYaw - this.currentYaw);
/* 143 */     float distance = Math.abs(deltaAngle);
/*     */ 
/*     */     
/* 146 */     float snapThreshold = this.preciseLanding ? 1.0F : 0.5F;
/*     */ 
/*     */     
/* 149 */     if (distance < snapThreshold) {
/* 150 */       if (this.preciseLanding) {
/* 151 */         this.currentYaw = this.targetYaw;
/* 152 */         setYawAngle(this.targetYaw);
/*     */       } 
/* 154 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 161 */     double speedToUse = this.effectiveSpeed;
/* 162 */     if (this.preciseLanding && distance < 5.0F && this.randomVariation > 0.0D) {
/*     */       
/* 164 */       double blendFactor = distance / 5.0D;
/* 165 */       speedToUse = this.baseSpeed + (this.effectiveSpeed - this.baseSpeed) * blendFactor;
/*     */     } 
/*     */     
/* 168 */     if (distance > 45.0F) {
/* 169 */       targetSpeed = (float)(speedToUse * 1.5D);
/* 170 */     } else if (distance > 15.0F) {
/* 171 */       targetSpeed = (float)speedToUse;
/*     */     } else {
/*     */       
/* 174 */       targetSpeed = (float)(speedToUse * (distance / 15.0F));
/* 175 */       targetSpeed = Math.max(targetSpeed, this.preciseLanding ? 0.3F : 0.5F);
/*     */     } 
/*     */ 
/*     */     
/* 179 */     float accel = (float)this.effectiveAcceleration;
/* 180 */     if (this.currentRotationSpeed < targetSpeed) {
/* 181 */       this.currentRotationSpeed = Math.min(this.currentRotationSpeed + accel, targetSpeed);
/*     */     } else {
/* 183 */       this.currentRotationSpeed = Math.max(this.currentRotationSpeed - accel, targetSpeed);
/*     */     } 
/*     */ 
/*     */     
/* 187 */     float jitter = 0.0F;
/* 188 */     float speedVariation = 1.0F;
/* 189 */     if (this.humanLike && (!this.preciseLanding || distance > 5.0F)) {
/* 190 */       jitter = (this.random.nextFloat() - 0.5F) * 0.2F;
/* 191 */       speedVariation = 0.9F + this.random.nextFloat() * 0.2F;
/*     */ 
/*     */       
/* 194 */       if (this.random.nextFloat() < 0.02D && distance > 10.0F) {
/* 195 */         this.currentRotationSpeed *= 0.3F;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/* 200 */     float step = Math.min(distance, this.currentRotationSpeed * speedVariation);
/* 201 */     if (deltaAngle < 0.0F) step = -step;
/*     */ 
/*     */     
/* 204 */     this.currentYaw += step + jitter;
/*     */ 
/*     */     
/* 207 */     if (this.preciseLanding) {
/* 208 */       float newDelta = class_3532.method_15393(this.targetYaw - this.currentYaw);
/* 209 */       if (Math.signum(newDelta) != Math.signum(deltaAngle))
/*     */       {
/* 211 */         this.currentYaw = this.targetYaw;
/*     */       }
/*     */     } 
/*     */     
/* 215 */     setYawAngle(this.currentYaw);
/*     */     
/* 217 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean updatePitch() {
/* 222 */     float targetSpeed, deltaAngle = this.targetPitch - this.currentPitch;
/* 223 */     float distance = Math.abs(deltaAngle);
/*     */ 
/*     */     
/* 226 */     float snapThreshold = this.preciseLanding ? 1.0F : 0.5F;
/*     */ 
/*     */     
/* 229 */     if (distance < snapThreshold) {
/* 230 */       if (this.preciseLanding) {
/* 231 */         this.currentPitch = this.targetPitch;
/* 232 */         setPitchAngle(this.targetPitch);
/*     */       } 
/* 234 */       return true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     double speedToUse = this.effectiveSpeed;
/* 242 */     if (this.preciseLanding && distance < 3.0F && this.randomVariation > 0.0D) {
/*     */       
/* 244 */       double blendFactor = distance / 3.0D;
/* 245 */       speedToUse = this.baseSpeed + (this.effectiveSpeed - this.baseSpeed) * blendFactor;
/*     */     } 
/*     */     
/* 248 */     if (distance > 30.0F) {
/* 249 */       targetSpeed = (float)(speedToUse * 1.2D);
/* 250 */     } else if (distance > 10.0F) {
/* 251 */       targetSpeed = (float)(speedToUse * 0.8D);
/*     */     } else {
/*     */       
/* 254 */       targetSpeed = (float)(speedToUse * 0.8D * (distance / 10.0F));
/* 255 */       targetSpeed = Math.max(targetSpeed, this.preciseLanding ? 0.25F : 0.4F);
/*     */     } 
/*     */ 
/*     */     
/* 259 */     float accel = (float)(this.effectiveAcceleration * 0.8D);
/* 260 */     if (this.currentPitchSpeed < targetSpeed) {
/* 261 */       this.currentPitchSpeed = Math.min(this.currentPitchSpeed + accel, targetSpeed);
/*     */     } else {
/* 263 */       this.currentPitchSpeed = Math.max(this.currentPitchSpeed - accel, targetSpeed);
/*     */     } 
/*     */ 
/*     */     
/* 267 */     float jitter = 0.0F;
/* 268 */     float speedVariation = 1.0F;
/* 269 */     if (this.humanLike && (!this.preciseLanding || distance > 3.0F)) {
/* 270 */       jitter = (this.random.nextFloat() - 0.5F) * 0.15F;
/* 271 */       speedVariation = 0.92F + this.random.nextFloat() * 0.16F;
/*     */     } 
/*     */ 
/*     */     
/* 275 */     float step = Math.min(distance, this.currentPitchSpeed * speedVariation);
/* 276 */     if (deltaAngle < 0.0F) step = -step;
/*     */ 
/*     */     
/* 279 */     this.currentPitch += step + jitter;
/*     */ 
/*     */     
/* 282 */     if (this.preciseLanding) {
/* 283 */       float newDelta = this.targetPitch - this.currentPitch;
/* 284 */       if (Math.signum(newDelta) != Math.signum(deltaAngle))
/*     */       {
/* 286 */         this.currentPitch = this.targetPitch;
/*     */       }
/*     */     } 
/*     */     
/* 290 */     setPitchAngle(this.currentPitch);
/*     */     
/* 292 */     return false;
/*     */   }
/*     */   
/*     */   private void setYawAngle(float yawAngle) {
/* 296 */     this.mc.field_1724.method_36456(yawAngle);
/* 297 */     this.mc.field_1724.field_6241 = yawAngle;
/* 298 */     this.mc.field_1724.field_6283 = yawAngle;
/*     */   }
/*     */ 
/*     */   
/*     */   private void setPitchAngle(float pitchAngle) {
/* 303 */     pitchAngle = class_3532.method_15363(pitchAngle, -90.0F, 90.0F);
/* 304 */     this.mc.field_1724.method_36457(pitchAngle);
/*     */   }
/*     */   public boolean isRotating() {
/* 307 */     return this.isRotating;
/*     */   }
/*     */   
/*     */   public void resetPitch(Runnable onComplete) {
/* 311 */     if (Math.abs(this.mc.field_1724.method_36455()) > 1.0F) {
/* 312 */       startRotation(this.mc.field_1724.method_36454(), 0.0F, onComplete);
/*     */     } else {
/*     */       
/* 315 */       if (this.preciseLanding) {
/* 316 */         setPitchAngle(0.0F);
/*     */       }
/* 318 */       if (onComplete != null) {
/* 319 */         onComplete.run();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public float getCurrentYaw() {
/* 325 */     return this.currentYaw; }
/* 326 */   public float getCurrentPitch() { return this.currentPitch; }
/* 327 */   public float getTargetYaw() { return this.targetYaw; } public float getTargetPitch() {
/* 328 */     return this.targetPitch;
/*     */   }
/*     */   
/* 331 */   public double getEffectiveSpeed() { return this.effectiveSpeed; } public double getEffectiveAcceleration() {
/* 332 */     return this.effectiveAcceleration;
/*     */   }
/*     */   
/*     */   private boolean isLocked = false;
/*     */   private float lockedYaw;
/*     */   private float lockedPitch;
/*     */   
/*     */   public void lockRotation(float yaw, float pitch) {
/* 340 */     this.isLocked = true;
/* 341 */     this.lockedYaw = yaw;
/* 342 */     this.lockedPitch = pitch;
/*     */   }
/*     */   
/*     */   public void lockCurrentRotation() {
/* 346 */     if (this.mc.field_1724 != null) {
/* 347 */       this.isLocked = true;
/* 348 */       this.lockedYaw = this.mc.field_1724.method_36454();
/* 349 */       this.lockedPitch = this.mc.field_1724.method_36455();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void unlockRotation() {
/* 354 */     this.isLocked = false;
/*     */   }
/*     */   
/*     */   public boolean isLocked() {
/* 358 */     return this.isLocked;
/*     */   }
/*     */   
/*     */   public void maintainLock() {
/* 362 */     if (this.isLocked && this.mc.field_1724 != null) {
/* 363 */       setYawAngle(this.lockedYaw);
/* 364 */       setPitchAngle(this.lockedPitch);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\AI\RotationController.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */