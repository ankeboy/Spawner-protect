/*     */ package dev.FORE.AI;
/*     */ import java.util.ArrayList;
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Queue;
/*     */ import net.minecraft.class_2338;
/*     */ import net.minecraft.class_2350;
/*     */ 
/*     */ public class DirectionalPathfinder {
/*  10 */   public Queue<class_2338> currentDetour = new LinkedList<>();
/*     */   
/*     */   private class_2350 primaryDirection;
/*     */   
/*     */   private class_2350 originalPrimaryDirection;
/*     */   public boolean isDetouring = false;
/*     */   private final PathScanner pathScanner;
/*     */   private static final int APPROACH_STOP_DISTANCE = 7;
/*     */   private static final int DETOUR_START_BUFFER = 5;
/*     */   private static final int DETOUR_SIDE_CLEARANCE = 2;
/*  20 */   private int detourCount = 0;
/*  21 */   private int directionChangeCount = 0;
/*  22 */   private String lastDecisionReason = "";
/*     */   
/*     */   public DirectionalPathfinder(PathScanner scanner) {
/*  25 */     this.pathScanner = scanner;
/*  26 */     System.out.println("=== DirectionalPathfinder Initialized ===");
/*  27 */     System.out.println("Detour start buffer: 5 blocks");
/*  28 */     System.out.println("Side clearance: 2 blocks");
/*  29 */     System.out.println("Approach stop distance: 7 blocks");
/*     */   }
/*     */   
/*     */   public void setInitialDirection(class_2350 dir) {
/*  33 */     this.primaryDirection = dir;
/*  34 */     this.originalPrimaryDirection = dir;
/*  35 */     System.out.println("DEBUG: Primary direction set to " + dir.method_10151());
/*  36 */     System.out.println("DEBUG: Will maintain " + dir.method_10151() + " as primary unless completely blocked");
/*     */   }
/*     */   
/*     */   public class_2350 getPrimaryDirection() {
/*  40 */     return this.primaryDirection;
/*     */   }
/*     */   
/*     */   public boolean isDetouring() {
/*  44 */     return this.isDetouring;
/*     */   }
/*     */   
/*     */   public Queue<class_2338> peekAllWaypoints() {
/*  48 */     return new LinkedList<>(this.currentDetour);
/*     */   }
/*     */   
/*     */   public class_2338 getNextWaypoint() {
/*  52 */     if (this.currentDetour.isEmpty()) {
/*  53 */       System.out.println("DEBUG: No more waypoints, detour complete");
/*  54 */       this.isDetouring = false;
/*  55 */       return null;
/*     */     } 
/*  57 */     class_2338 next = this.currentDetour.poll();
/*  58 */     System.out.println("DEBUG: Next waypoint: " + String.valueOf(next) + " (" + this.currentDetour.size() + " remaining)");
/*  59 */     return next;
/*     */   }
/*     */   
/*     */   public class_2338 peekNextWaypoint() {
/*  63 */     return this.currentDetour.peek();
/*     */   }
/*     */   
/*     */   public static class PathPlan {
/*     */     public final boolean needsDetour;
/*     */     public final Queue<class_2338> waypoints;
/*     */     public final String reason;
/*     */     public final class_2350 newPrimaryDirection;
/*     */     
/*     */     public PathPlan(boolean needsDetour, Queue<class_2338> waypoints, String reason) {
/*  73 */       this.needsDetour = needsDetour;
/*  74 */       this.waypoints = waypoints;
/*  75 */       this.reason = reason;
/*  76 */       this.newPrimaryDirection = null;
/*     */     }
/*     */     
/*     */     public PathPlan(class_2350 newDirection, String reason) {
/*  80 */       this.needsDetour = false;
/*  81 */       this.waypoints = new LinkedList<>();
/*  82 */       this.reason = reason;
/*  83 */       this.newPrimaryDirection = newDirection;
/*     */     }
/*     */   }
/*     */   
/*     */   public PathPlan calculateDetour(class_2338 playerPos, PathScanner.ScanResult hazard) {
/*  88 */     System.out.println("\n=== CALCULATING DETOUR ===");
/*  89 */     System.out.println("Player position: " + String.valueOf(playerPos));
/*  90 */     System.out.println("Hazard type: " + String.valueOf(hazard.getHazardType()));
/*  91 */     System.out.println("Hazard distance: " + hazard.getHazardDistance());
/*  92 */     System.out.println("Maintaining primary direction: " + this.primaryDirection.method_10151());
/*     */ 
/*     */     
/*  95 */     if (hazard.getHazardDistance() > 10) {
/*  96 */       System.out.println("Hazard is " + hazard.getHazardDistance() + " blocks away (far)");
/*  97 */       return createApproachPlan(playerPos, hazard);
/*     */     } 
/*     */ 
/*     */     
/* 101 */     System.out.println("Hazard is close (" + hazard.getHazardDistance() + " blocks), planning detour");
/*     */ 
/*     */     
/* 104 */     HazardBounds bounds = scanHazardBoundaries(playerPos, hazard);
/* 105 */     System.out.println("Hazard boundaries: width=" + bounds.width + ", depth=" + bounds.depth);
/*     */ 
/*     */     
/* 108 */     List<class_2338> leftPath = buildMinimalDetourPath(playerPos, bounds, true);
/* 109 */     List<class_2338> rightPath = buildMinimalDetourPath(playerPos, bounds, false);
/*     */     
/* 111 */     System.out.println("Left detour: " + ((leftPath != null) ? ("" + leftPath.size() + " waypoints") : "BLOCKED"));
/* 112 */     System.out.println("Right detour: " + ((rightPath != null) ? ("" + rightPath.size() + " waypoints") : "BLOCKED"));
/*     */ 
/*     */     
/* 115 */     if (leftPath != null && rightPath != null) {
/* 116 */       if (leftPath.size() <= rightPath.size()) {
/* 117 */         System.out.println("DECISION: Taking LEFT detour (" + leftPath.size() + " waypoints)");
/* 118 */         return createDetourPlan(leftPath, "Left detour");
/*     */       } 
/* 120 */       System.out.println("DECISION: Taking RIGHT detour (" + rightPath.size() + " waypoints)");
/* 121 */       return createDetourPlan(rightPath, "Right detour");
/*     */     } 
/* 123 */     if (leftPath != null) {
/* 124 */       System.out.println("DECISION: Taking LEFT detour (only option)");
/* 125 */       return createDetourPlan(leftPath, "Left detour");
/* 126 */     }  if (rightPath != null) {
/* 127 */       System.out.println("DECISION: Taking RIGHT detour (only option)");
/* 128 */       return createDetourPlan(rightPath, "Right detour");
/*     */     } 
/* 130 */     System.out.println("WARNING: No detour possible for close hazard, need to change primary direction");
/* 131 */     return handleCompletelyBlocked(playerPos);
/*     */   }
/*     */ 
/*     */   
/*     */   private PathPlan createApproachPlan(class_2338 playerPos, PathScanner.ScanResult hazard) {
/* 136 */     System.out.println("\n=== APPROACH PLAN ===");
/*     */ 
/*     */     
/* 139 */     int safeApproachDistance = Math.max(hazard.getHazardDistance() - 7, 0);
/*     */     
/* 141 */     if (safeApproachDistance <= 0) {
/*     */       
/* 143 */       System.out.println("Already within approach distance, treating as close hazard");
/* 144 */       return new PathPlan(false, new LinkedList<>(), "Already close to hazard");
/*     */     } 
/*     */ 
/*     */     
/* 148 */     class_2338 approachPoint = playerPos.method_10079(this.primaryDirection, safeApproachDistance);
/*     */ 
/*     */     
/* 151 */     System.out.println("Planning approach: " + safeApproachDistance + " blocks forward");
/* 152 */     if (!validateSegment(playerPos, approachPoint, this.primaryDirection, safeApproachDistance)) {
/* 153 */       System.out.println("Approach path blocked! Need to handle intermediate obstacle");
/*     */       
/* 155 */       return handleCompletelyBlocked(playerPos);
/*     */     } 
/*     */ 
/*     */     
/* 159 */     List<class_2338> approachPath = new ArrayList<>();
/* 160 */     approachPath.add(approachPoint);
/*     */     
/* 162 */     System.out.println("SUCCESS: Can safely approach to within 7 blocks of hazard");
/* 163 */     System.out.println("Will reassess when closer");
/*     */     
/* 165 */     Queue<class_2338> waypoints = new LinkedList<>(approachPath);
/* 166 */     this.currentDetour = new LinkedList<>(waypoints);
/* 167 */     this.isDetouring = true;
/*     */     
/* 169 */     return new PathPlan(true, waypoints, "Approaching distant hazard");
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private List<class_2338> buildMinimalDetourPath(class_2338 playerPos, HazardBounds bounds, boolean goLeft) {
/* 175 */     class_2350 sideDir = goLeft ? this.primaryDirection.method_10160() : this.primaryDirection.method_10170();
/*     */     
/* 177 */     String sideName = goLeft ? "LEFT" : "RIGHT";
/* 178 */     System.out.println("\nDEBUG: Building minimal " + sideName + " detour");
/* 179 */     System.out.println("Starting detour 5 blocks before hazard");
/*     */ 
/*     */     
/* 182 */     int sideDistance = bounds.width / 2 + 2;
/*     */ 
/*     */     
/* 185 */     for (int attempt = 0; attempt < 3; attempt++) {
/* 186 */       List<class_2338> path = tryDetourPath(playerPos, bounds, sideDir, sideDistance + attempt);
/* 187 */       if (path != null) {
/* 188 */         System.out.println("SUCCESS: Found " + sideName + " path with " + path.size() + " waypoints");
/* 189 */         return path;
/*     */       } 
/*     */     } 
/*     */     
/* 193 */     return null;
/*     */   }
/*     */   
/*     */   private List<class_2338> tryDetourPath(class_2338 playerPos, HazardBounds bounds, class_2350 sideDir, int sideDistance) {
/* 197 */     List<class_2338> waypoints = new ArrayList<>();
/*     */ 
/*     */ 
/*     */     
/* 201 */     int approachDistance = Math.max(bounds.startDistance - 5, 1);
/* 202 */     int forwardPastHazard = bounds.depth + 3;
/*     */ 
/*     */     
/* 205 */     class_2338 turnPoint = playerPos.method_10079(this.primaryDirection, approachDistance);
/* 206 */     turnPoint = adjustToGroundLevel(turnPoint);
/* 207 */     if (!validateSegment(playerPos, turnPoint, this.primaryDirection, approachDistance)) {
/* 208 */       return null;
/*     */     }
/* 210 */     waypoints.add(turnPoint);
/*     */ 
/*     */     
/* 213 */     class_2338 sidePoint = turnPoint.method_10079(sideDir, sideDistance);
/* 214 */     sidePoint = adjustToGroundLevel(sidePoint);
/* 215 */     if (!validateSegment(turnPoint, sidePoint, sideDir, sideDistance)) {
/* 216 */       return null;
/*     */     }
/* 218 */     waypoints.add(sidePoint);
/*     */ 
/*     */     
/* 221 */     class_2338 pastHazard = sidePoint.method_10079(this.primaryDirection, forwardPastHazard);
/* 222 */     pastHazard = adjustToGroundLevel(pastHazard);
/* 223 */     if (!validateSegment(sidePoint, pastHazard, this.primaryDirection, forwardPastHazard)) {
/* 224 */       return null;
/*     */     }
/* 226 */     waypoints.add(pastHazard);
/*     */ 
/*     */ 
/*     */     
/* 230 */     return waypoints;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private class_2338 adjustToGroundLevel(class_2338 pos) {
/* 236 */     PathScanner.ScanResult currentScan = this.pathScanner.scanDirection(pos, this.primaryDirection, 0, 1, false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 241 */     if (currentScan.getHazardType() == PathScanner.HazardType.UNSAFE_GROUND || 
/* 242 */       !isGroundSolid(pos)) {
/*     */ 
/*     */       
/* 245 */       class_2338 oneDown = pos.method_10074();
/* 246 */       if (isGroundSolid(oneDown)) {
/* 247 */         System.out.println("  Adjusted waypoint down 1 block to ground level");
/* 248 */         return oneDown;
/*     */       } 
/*     */ 
/*     */       
/* 252 */       class_2338 twoDown = pos.method_10087(2);
/* 253 */       if (isGroundSolid(twoDown)) {
/* 254 */         System.out.println("  Adjusted waypoint down 2 blocks to ground level");
/* 255 */         return twoDown;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 260 */     class_2338 oneUp = pos.method_10084();
/* 261 */     PathScanner.ScanResult upScan = this.pathScanner.scanDirection(oneUp, this.primaryDirection, 0, 1, false);
/*     */ 
/*     */     
/* 264 */     if (upScan.isSafe() && !isGroundSolid(pos) && isGroundSolid(pos.method_10074())) {
/*     */       
/* 266 */       System.out.println("  Adjusted waypoint up 1 block to avoid collision");
/* 267 */       return oneUp;
/*     */     } 
/*     */     
/* 270 */     return pos;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean isGroundSolid(class_2338 pos) {
/* 276 */     PathScanner.ScanResult groundCheck = this.pathScanner.scanDirection(pos
/* 277 */         .method_10084(), this.primaryDirection, 0, 1, false);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 282 */     return (groundCheck.isSafe() || (groundCheck
/* 283 */       .getHazardType() != PathScanner.HazardType.LAVA && groundCheck
/* 284 */       .getHazardType() != PathScanner.HazardType.WATER && groundCheck
/* 285 */       .getHazardType() != PathScanner.HazardType.UNSAFE_GROUND));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean validateSegment(class_2338 start, class_2338 end, class_2350 moveDir, int distance) {
/* 290 */     if (distance > 10) {
/* 291 */       System.out.println("  Validating long segment (" + distance + " blocks) in chunks");
/* 292 */       class_2338 currentPos = start;
/*     */       
/* 294 */       for (int chunk = 0; chunk < distance; chunk += 5) {
/* 295 */         int chunkSize = Math.min(5, distance - chunk);
/*     */ 
/*     */         
/* 298 */         for (int j = 1; j <= chunkSize; j++) {
/* 299 */           class_2338 checkPos = currentPos.method_10079(moveDir, j);
/*     */ 
/*     */           
/* 302 */           int scanAhead = (distance > 10) ? 2 : 1;
/* 303 */           PathScanner.ScanResult scan = this.pathScanner.scanDirection(checkPos, moveDir, scanAhead, 4, false);
/*     */ 
/*     */ 
/*     */           
/* 307 */           if (!scan.isSafe()) {
/* 308 */             System.out.println("  Segment blocked at offset " + chunk + j + ": " + String.valueOf(scan.getHazardType()));
/* 309 */             return false;
/*     */           } 
/*     */ 
/*     */           
/* 313 */           if (!checkGroundSafety(checkPos)) {
/* 314 */             System.out.println("  Unsafe ground at offset " + chunk + j);
/* 315 */             return false;
/*     */           } 
/*     */         } 
/*     */         
/* 319 */         currentPos = currentPos.method_10079(moveDir, chunkSize);
/*     */       } 
/*     */       
/* 322 */       System.out.println("  Long segment validated successfully");
/* 323 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 327 */     for (int i = 1; i <= distance; i++) {
/* 328 */       class_2338 checkPos = start.method_10079(moveDir, i);
/*     */ 
/*     */ 
/*     */       
/* 332 */       PathScanner.ScanResult scan = this.pathScanner.scanDirection(checkPos, moveDir, 1, 4, false);
/*     */ 
/*     */ 
/*     */       
/* 336 */       if (!scan.isSafe()) {
/* 337 */         System.out.println("  Segment blocked at offset " + i + ": " + String.valueOf(scan.getHazardType()));
/* 338 */         return false;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 343 */       if (moveDir != this.primaryDirection && i == distance) {
/*     */         
/* 345 */         PathScanner.ScanResult forwardCheck = this.pathScanner.scanDirection(checkPos, this.primaryDirection, 2, 4, false);
/*     */ 
/*     */ 
/*     */         
/* 349 */         if (!forwardCheck.isSafe() && forwardCheck.getHazardDistance() <= 1) {
/* 350 */           System.out.println("  Can't continue forward from end of segment: " + String.valueOf(forwardCheck.getHazardType()));
/* 351 */           return false;
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 356 */       if (!checkGroundSafety(checkPos)) {
/* 357 */         System.out.println("  Unsafe ground at offset " + i);
/* 358 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 362 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean checkGroundSafety(class_2338 pos) {
/* 367 */     for (int depth = 1; depth <= 2; depth++) {
/* 368 */       class_2338 below = pos.method_10087(depth);
/*     */ 
/*     */       
/* 371 */       for (class_2350 dir : new class_2350[] { class_2350.field_11043, class_2350.field_11035, class_2350.field_11034, class_2350.field_11039 }) {
/* 372 */         PathScanner.ScanResult scan = this.pathScanner.scanDirection(below, dir, 0, 1, false);
/*     */ 
/*     */ 
/*     */         
/* 376 */         if (!scan.isSafe() && scan.getHazardDistance() == 0 && 
/* 377 */           scan.getHazardType() == PathScanner.HazardType.LAVA) {
/* 378 */           System.out.println("    Lava detected " + depth + " blocks below!");
/* 379 */           return false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 385 */     return true;
/*     */   }
/*     */   
/*     */   private PathPlan createDetourPlan(List<class_2338> waypoints, String reason) {
/* 389 */     Queue<class_2338> waypointQueue = new LinkedList<>(waypoints);
/*     */     
/* 391 */     this.currentDetour = new LinkedList<>(waypointQueue);
/* 392 */     this.isDetouring = true;
/* 393 */     this.detourCount++;
/* 394 */     this.lastDecisionReason = "Detour #" + this.detourCount + ": " + reason;
/*     */     
/* 396 */     System.out.println("Created minimal detour with " + waypoints.size() + " waypoints");
/* 397 */     System.out.println("Will resume " + this.primaryDirection.method_10151() + " with full scanning after last waypoint");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 404 */     return new PathPlan(true, waypointQueue, this.lastDecisionReason);
/*     */   }
/*     */   
/*     */   private HazardBounds scanHazardBoundaries(class_2338 playerPos, PathScanner.ScanResult initialHazard) {
/* 408 */     int hazardDistance = initialHazard.getHazardDistance();
/* 409 */     class_2338 hazardCenter = playerPos.method_10079(this.primaryDirection, hazardDistance);
/*     */     
/* 411 */     int leftWidth = 0;
/* 412 */     int rightWidth = 0;
/* 413 */     int forwardDepth = 0;
/*     */     
/* 415 */     class_2350 leftDir = this.primaryDirection.method_10160();
/* 416 */     class_2350 rightDir = this.primaryDirection.method_10170();
/*     */     
/*     */     int i;
/* 419 */     for (i = 1; i <= 10; i++) {
/* 420 */       class_2338 checkPos = hazardCenter.method_10079(leftDir, i);
/* 421 */       PathScanner.ScanResult scan = this.pathScanner.scanDirection(checkPos, this.primaryDirection, 1, 4, false);
/*     */ 
/*     */       
/* 424 */       if (scan.isSafe())
/* 425 */         break;  leftWidth = i;
/*     */     } 
/*     */     
/* 428 */     for (i = 1; i <= 10; i++) {
/* 429 */       class_2338 checkPos = hazardCenter.method_10079(rightDir, i);
/* 430 */       PathScanner.ScanResult scan = this.pathScanner.scanDirection(checkPos, this.primaryDirection, 1, 4, false);
/*     */ 
/*     */       
/* 433 */       if (scan.isSafe())
/* 434 */         break;  rightWidth = i;
/*     */     } 
/*     */ 
/*     */     
/* 438 */     for (i = 0; i <= 20; i++) {
/* 439 */       class_2338 checkPos = hazardCenter.method_10079(this.primaryDirection, i);
/* 440 */       PathScanner.ScanResult scan = this.pathScanner.scanDirection(checkPos, this.primaryDirection, 1, 4, false);
/*     */ 
/*     */       
/* 443 */       if (scan.isSafe())
/* 444 */         break;  forwardDepth = i;
/*     */     } 
/*     */     
/* 447 */     int totalWidth = leftWidth + rightWidth + 1;
/* 448 */     int totalDepth = Math.max(forwardDepth, 1);
/*     */     
/* 450 */     return new HazardBounds(hazardDistance, totalWidth, totalDepth, hazardCenter);
/*     */   }
/*     */   
/*     */   private PathPlan handleCompletelyBlocked(class_2338 playerPos) {
/* 454 */     System.out.println("\n=== COMPLETELY BLOCKED ===");
/* 455 */     System.out.println("Cannot continue " + this.primaryDirection.method_10151());
/* 456 */     System.out.println("Will center first, then rotate to a new direction");
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 461 */     class_2350[] alternatives = { this.primaryDirection.method_10170(), this.primaryDirection.method_10160() };
/*     */ 
/*     */     
/* 464 */     for (class_2350 newDir : alternatives) {
/* 465 */       System.out.println("Checking " + newDir.method_10151() + "...");
/* 466 */       PathScanner.ScanResult scan = this.pathScanner.scanDirection(playerPos, newDir, 20, 4, false);
/*     */ 
/*     */ 
/*     */       
/* 470 */       if (scan.isSafe()) {
/* 471 */         System.out.println("Found safe direction: " + newDir.method_10151());
/* 472 */         System.out.println("Will center, then rotate to face " + newDir.method_10151());
/* 473 */         this.directionChangeCount++;
/* 474 */         this.lastDecisionReason = "Perpendicular direction change #" + this.directionChangeCount;
/* 475 */         return new PathPlan(newDir, this.lastDecisionReason);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 480 */     class_2350 opposite = this.primaryDirection.method_10153();
/* 481 */     System.out.println("NOT checking " + opposite.method_10151() + " (that's where we came from)");
/* 482 */     System.out.println("ERROR: No valid forward paths - all perpendicular directions blocked!");
/*     */ 
/*     */ 
/*     */     
/* 486 */     return new PathPlan((class_2350)null, "No valid paths - RTP recovery needed");
/*     */   }
/*     */   
/*     */   public void completeDetour() {
/* 490 */     System.out.println("DEBUG: Detour completed");
/* 491 */     System.out.println("DEBUG: Resuming primary direction: " + this.primaryDirection.method_10151());
/* 492 */     System.out.println("DEBUG: Returning to normal scanning/mining logic");
/* 493 */     this.isDetouring = false;
/* 494 */     this.currentDetour.clear();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDebugInfo() {
/* 502 */     if (this.primaryDirection == null) {
/* 503 */       return "Primary: NOT SET | Pathfinder not initialized";
/*     */     }
/*     */     
/* 506 */     return String.format("Primary: %s (original: %s) | Detouring: %s | Detours: %d | Changes: %d | Reason: %s", new Object[] { this.primaryDirection
/*     */           
/* 508 */           .method_10151(), 
/* 509 */           (this.originalPrimaryDirection != null) ? this.originalPrimaryDirection.method_10151() : "NOT SET", 
/* 510 */           Boolean.valueOf(this.isDetouring), 
/* 511 */           Integer.valueOf(this.detourCount), 
/* 512 */           Integer.valueOf(this.directionChangeCount), this.lastDecisionReason });
/*     */   }
/*     */ 
/*     */   
/*     */   private static class HazardBounds
/*     */   {
/*     */     final int startDistance;
/*     */     
/*     */     final int width;
/*     */     final int depth;
/*     */     final class_2338 center;
/*     */     
/*     */     HazardBounds(int startDistance, int width, int depth, class_2338 center) {
/* 525 */       this.startDistance = startDistance;
/* 526 */       this.width = width;
/* 527 */       this.depth = depth;
/* 528 */       this.center = center;
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\AI\DirectionalPathfinder.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */