package dev.FORE.imixin;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_3959;

public interface IRaycastContext {
  void a(class_243 paramclass_2431, class_243 paramclass_2432, class_3959.class_3960 paramclass_3960, class_3959.class_242 paramclass_242, class_1297 paramclass_1297);
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\imixin\IRaycastContext.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */