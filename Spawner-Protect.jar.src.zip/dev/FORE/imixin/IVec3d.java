/*    */ package dev.FORE.imixin;
/*    */ 
/*    */ import net.minecraft.class_2382;
/*    */ import org.joml.Vector3d;
/*    */ 
/*    */ public interface IVec3d {
/*    */   void set(double paramDouble1, double paramDouble2, double paramDouble3);
/*    */   
/*    */   default void a(class_2382 vec3i) {
/* 10 */     set(vec3i.method_10263(), vec3i.method_10264(), vec3i.method_10260());
/*    */   }
/*    */   
/*    */   default void a(Vector3d vector3d) {
/* 14 */     set(vector3d.x, vector3d.y, vector3d.z);
/*    */   }
/*    */   
/*    */   void setXZ(double paramDouble1, double paramDouble2);
/*    */   
/*    */   void setY(double paramDouble);
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\imixin\IVec3d.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */