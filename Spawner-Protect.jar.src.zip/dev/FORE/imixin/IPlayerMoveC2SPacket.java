package dev.FORE.imixin;

public interface IPlayerMoveC2SPacket {
  void setTag(int paramInt);
  
  int getTag();
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\imixin\IPlayerMoveC2SPacket.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */