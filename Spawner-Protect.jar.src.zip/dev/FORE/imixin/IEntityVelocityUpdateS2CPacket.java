package dev.FORE.imixin;

import net.minecraft.class_243;

public interface IEntityVelocityUpdateS2CPacket {
  class_243 getVelocity();
  
  void setVelocity(class_243 paramclass_243);
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\imixin\IEntityVelocityUpdateS2CPacket.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */