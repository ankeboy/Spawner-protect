package dev.FORE.imixin;

import net.minecraft.class_1297;

public interface IPlayerInteractEntityC2SPacket {
  class_1297 getEntity();
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\imixin\IPlayerInteractEntityC2SPacket.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */