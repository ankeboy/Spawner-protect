package dev.FORE.event;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
public @interface EventListener {
  Priority priority() default Priority.NORMAL;
}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\EventListener.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */