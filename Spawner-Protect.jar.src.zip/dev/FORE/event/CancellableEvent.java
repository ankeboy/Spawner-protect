/*    */ package dev.FORE.event;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class CancellableEvent
/*    */   implements Event
/*    */ {
/*    */   private boolean cancelled = false;
/*    */   
/*    */   public boolean isCancelled() {
/* 11 */     return this.cancelled;
/*    */   }
/*    */   
/*    */   public void cancel() {
/* 15 */     this.cancelled = true;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\CancellableEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */