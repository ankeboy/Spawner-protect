/*    */ package dev.FORE.event;
/*    */ 
/*    */ import java.lang.reflect.Method;
/*    */ 
/*    */ public class Listener {
/*    */   private final Object instance;
/*    */   private final Method method;
/*    */   private final Priority priority;
/*    */   
/*    */   public Listener(Object instance, Method method, Priority priority) {
/* 11 */     this.instance = instance;
/* 12 */     this.method = method;
/* 13 */     this.priority = priority;
/*    */   }
/*    */   
/*    */   public void invoke(Event event) throws Throwable {
/* 17 */     this.method.invoke(this.instance, new Object[] { event });
/*    */   }
/*    */   
/*    */   public Object getInstance() {
/* 21 */     return this.instance;
/*    */   }
/*    */   
/*    */   public Priority getPriority() {
/* 25 */     return this.priority;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\Listener.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */