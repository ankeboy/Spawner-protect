/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2350;
/*    */ 
/*    */ public class AttackBlockEvent extends CancellableEvent {
/*    */   public class_2338 pos;
/*    */   public class_2350 direction;
/*    */   
/*    */   public AttackBlockEvent(class_2338 pos, class_2350 direction) {
/* 12 */     this.pos = pos;
/* 13 */     this.direction = direction;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\AttackBlockEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */