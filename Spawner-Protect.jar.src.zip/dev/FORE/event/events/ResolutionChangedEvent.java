/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_1041;
/*    */ 
/*    */ public class ResolutionChangedEvent extends CancellableEvent {
/*    */   public class_1041 window;
/*    */   
/*    */   public ResolutionChangedEvent(class_1041 window) {
/* 10 */     this.window = window;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\ResolutionChangedEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */