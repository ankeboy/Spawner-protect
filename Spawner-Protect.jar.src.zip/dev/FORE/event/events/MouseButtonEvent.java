/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ 
/*    */ public class MouseButtonEvent extends CancellableEvent {
/*    */   public int button;
/*    */   public int actions;
/*    */   public long window;
/*    */   
/*    */   public MouseButtonEvent(int button, long window, int actions) {
/* 11 */     this.button = button;
/* 12 */     this.window = window;
/* 13 */     this.actions = actions;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\MouseButtonEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */