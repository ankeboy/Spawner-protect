/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ 
/*    */ public class KeyEvent extends CancellableEvent {
/*    */   public int key;
/*    */   public int mode;
/*    */   public long window;
/*    */   
/*    */   public KeyEvent(int key, long window, int mode) {
/* 11 */     this.key = key;
/* 12 */     this.window = window;
/* 13 */     this.mode = mode;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\KeyEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */