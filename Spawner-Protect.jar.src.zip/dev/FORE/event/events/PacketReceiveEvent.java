/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ public class PacketReceiveEvent extends CancellableEvent {
/*    */   public class_2596<?> packet;
/*    */   
/*    */   public PacketReceiveEvent(class_2596<?> packet) {
/* 10 */     this.packet = packet;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\PacketReceiveEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */