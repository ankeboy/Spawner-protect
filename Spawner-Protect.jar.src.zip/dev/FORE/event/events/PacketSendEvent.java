/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_2596;
/*    */ 
/*    */ public class PacketSendEvent extends CancellableEvent {
/*    */   private final class_2596<?> packet;
/*    */   
/*    */   public PacketSendEvent(class_2596<?> packet) {
/* 10 */     this.packet = packet;
/*    */   }
/*    */   
/*    */   public class_2596<?> getPacket() {
/* 14 */     return this.packet;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\PacketSendEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */