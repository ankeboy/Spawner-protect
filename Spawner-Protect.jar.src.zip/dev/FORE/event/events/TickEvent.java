package dev.FORE.event.events;

import dev.FORE.event.CancellableEvent;

public class TickEvent extends CancellableEvent {}


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\TickEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */