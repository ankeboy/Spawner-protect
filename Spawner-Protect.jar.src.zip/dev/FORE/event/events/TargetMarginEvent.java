/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_1297;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ public class TargetMarginEvent extends CancellableEvent {
/*    */   public class_1297 entity;
/*    */   public CallbackInfoReturnable<Float> cir;
/*    */   
/*    */   public TargetMarginEvent(class_1297 entity, CallbackInfoReturnable<Float> cir) {
/* 12 */     this.entity = entity;
/* 13 */     this.cir = cir;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\TargetMarginEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */