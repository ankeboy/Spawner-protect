/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.Event;
/*    */ import net.minecraft.class_1268;
/*    */ import net.minecraft.class_1799;
/*    */ import net.minecraft.class_4587;
/*    */ 
/*    */ public class HeldItemRendererEvent implements Event {
/*    */   private final class_1268 hand;
/*    */   private final class_1799 item;
/*    */   private final float equipProgress;
/*    */   private final class_4587 matrices;
/*    */   
/*    */   public HeldItemRendererEvent(class_1268 hand, class_1799 item, float equipProgress, class_4587 matrices) {
/* 15 */     this.hand = hand;
/* 16 */     this.item = item;
/* 17 */     this.equipProgress = equipProgress;
/* 18 */     this.matrices = matrices;
/*    */   }
/*    */   
/*    */   public class_1268 getHand() {
/* 22 */     return this.hand;
/*    */   }
/*    */   
/*    */   public class_1799 getItem() {
/* 26 */     return this.item;
/*    */   }
/*    */   
/*    */   public float getEquipProgress() {
/* 30 */     return this.equipProgress;
/*    */   }
/*    */   
/*    */   public class_4587 getMatrices() {
/* 34 */     return this.matrices;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\HeldItemRendererEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */