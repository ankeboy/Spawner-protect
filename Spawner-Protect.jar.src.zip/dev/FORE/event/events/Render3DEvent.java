/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_4587;
/*    */ import org.joml.Matrix4f;
/*    */ 
/*    */ public class Render3DEvent extends CancellableEvent {
/*    */   public class_4587 matrixStack;
/*    */   public Matrix4f matrix4f;
/*    */   public float tickDelta;
/*    */   
/*    */   public Render3DEvent(class_4587 matrixStack, Matrix4f matrix4f, float tickDelta) {
/* 13 */     this.matrixStack = matrixStack;
/* 14 */     this.matrix4f = matrix4f;
/* 15 */     this.tickDelta = tickDelta;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\Render3DEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */