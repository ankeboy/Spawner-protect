/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.DonutBBC;
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_2672;
/*    */ import net.minecraft.class_2791;
/*    */ 
/*    */ public class ChunkDataEvent
/*    */   extends CancellableEvent {
/*    */   public class_2672 packet;
/*    */   
/*    */   public ChunkDataEvent(class_2672 packet) {
/* 13 */     this.packet = packet;
/*    */   }
/*    */   
/*    */   public class_2791 getChunk() {
/* 17 */     if (DonutBBC.mc.field_1687 == null) return null; 
/* 18 */     return (class_2791)DonutBBC.mc.field_1687.method_8497(this.packet.method_11523(), this.packet.method_11524());
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\ChunkDataEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */