/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_2338;
/*    */ import net.minecraft.class_2680;
/*    */ 
/*    */ public class SetBlockStateEvent extends CancellableEvent {
/*    */   public class_2338 pos;
/*    */   public class_2680 newState;
/*    */   public class_2680 oldState;
/*    */   
/*    */   public SetBlockStateEvent(class_2338 pos, class_2680 newState, class_2680 oldState) {
/* 13 */     this.pos = pos;
/* 14 */     this.newState = oldState;
/* 15 */     this.oldState = newState;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\SetBlockStateEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */