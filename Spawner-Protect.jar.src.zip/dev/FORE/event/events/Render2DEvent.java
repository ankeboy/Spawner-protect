/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_332;
/*    */ 
/*    */ public class Render2DEvent extends CancellableEvent {
/*    */   public class_332 context;
/*    */   public float tickDelta;
/*    */   
/*    */   public Render2DEvent(class_332 context, float tickDelta) {
/* 11 */     this.context = context;
/* 12 */     this.tickDelta = tickDelta;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\Render2DEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */