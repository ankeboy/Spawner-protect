/*    */ package dev.FORE.event.events;
/*    */ 
/*    */ import dev.FORE.event.CancellableEvent;
/*    */ import net.minecraft.class_1297;
/*    */ import net.minecraft.class_4050;
/*    */ import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
/*    */ 
/*    */ public class TargetPoseEvent extends CancellableEvent {
/*    */   public class_1297 entity;
/*    */   public CallbackInfoReturnable<class_4050> cir;
/*    */   
/*    */   public TargetPoseEvent(class_1297 entity, CallbackInfoReturnable<class_4050> cir) {
/* 13 */     this.entity = entity;
/* 14 */     this.cir = cir;
/*    */   }
/*    */ }


/* Location:              C:\Users\simon\Downloads\fore-1.0.0 (7).jar!\dev\FORE\event\events\TargetPoseEvent.class
 * Java compiler version: 21 (65.0)
 * JD-Core Version:       1.1.3
 */